#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Samples.Model;
using CchenSoft.Framework;

namespace Samples.Service
{
    public interface IUserService : IService
    {
        User LoadUser(int userId);

        int ValidateLogin(string username, string passwd);

        string GetPermission(int userId, string resource);

        void UpdatePermission(int userId, string resource, string permission);

        IList<User> GetUsers();

        void DeleteUser(int userId);

        void SaveUser(User user);
    }
}
