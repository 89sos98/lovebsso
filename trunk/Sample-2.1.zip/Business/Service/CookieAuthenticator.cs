#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using CchenSoft.Framework;
using CchenSoft.Framework.Attributes;

namespace Samples.Service
{
    public class CookieAuthenticator : IAuthenticator
    {
        private const string CookieKey = "webfx";
        private const string IdentityKey = "userId";
        private const string IdentityNameKey = "userName";

        private string loginUrl;
        private string logOnPage;

        [Bean]
        protected IUserService userService;

        #region IAuthenticator ��Ա

        public string LoginUrl
        {
            get { return loginUrl; }
            set { loginUrl = value; }
        }

        public string LogOnPage
        {
            get { return logOnPage; }
            set { logOnPage = value; }
        }

        public int Authenticate(string name, string passwd, int persist)
        {
            int identity = userService.ValidateLogin(name, passwd);
            if (identity > 0)
            {
                HttpCookie cookie = new HttpCookie(CookieKey);
                cookie[IdentityKey] = identity.ToString();
                cookie[IdentityNameKey] = "";
                if (persist > 0)
                {
                    cookie.Expires = DateTime.Now.AddDays(persist);
                }
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
            return identity;
        }

        public bool IsAuthenticated
        {
            get
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
                return cookie != null ? !string.IsNullOrEmpty(cookie[IdentityKey]) : false;
            }
        }

        public string Identity
        {
            get
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
                return (cookie != null) ? cookie[IdentityKey] : null;
            }
        }

        public string IdentityName
        {
            get
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
                return (cookie != null) ? cookie[IdentityNameKey] : null;
            }
        }

        public void SignOut()
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
            if (cookie != null)
            {
                cookie.Expires = DateTime.Now.AddDays(-1);
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
        }

        public void CheckPermission(string resource, int action)
        {
            bool flag = false;

            if (IsAuthenticated)
            {
                if (Identity.Equals("1"))
                {
                    flag = true;
                }
                else
                {
                    string permissions = userService.GetPermission(Convert.ToInt32(Identity), resource);

                    string perms = "".PadRight(200, '0');

                    flag = (perms[action] == '1');
                }
            }

            if (flag == false)
            {
                string[] actionNames = ResourceManager.GetActionNames(resource);
                string message = actionNames != null
                    ? string.Format("û��{0}��Ȩ��!", actionNames[action])
                    : string.Format("û�в���{0}��Ȩ��!", resource);

                throw new SecurityException(message);
            }
        }

        #endregion

        private char GetPermission(char p, char p2)
        {
            if (p == '0' && p2 == '0')
                return '0';
            return '1';
        }

    }
}
