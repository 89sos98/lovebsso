#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Samples.Dao;
using Samples.Model;
using CchenSoft.Framework.Attributes;

namespace Samples.Service.Impl
{
    public class UserServiceImpl : IUserService
    {
        [Bean]
        protected ISampleDao sampleDao;

        public void CreateInfo(Info info)
        {
            //
        }

        #region IService ��Ա

        public void Initialize()
        {
        }

        #endregion

        #region IUserService ��Ա

        public User LoadUser(int userId)
        {
            return sampleDao.LoadUser(userId);
        }

        [Log("��֤��¼, name={0}")]
        public int ValidateLogin(string username, string passwd)
        {
            return sampleDao.ValidateLogin(username, passwd);
        }

        public string GetPermission(int userId, string resource)
        {
            return sampleDao.GetPermission(userId, resource);
        }

        public void UpdatePermission(int userId, string resource, string permission)
        {
            sampleDao.UpdatePermission(userId, resource, permission);
        }

        public IList<User> GetUsers()
        {
            return sampleDao.GetUsers();
        }

        [Transaction(TransactionOption.Required)]
        public void DeleteUser(int userId)
        {
            sampleDao.DeleteUser(userId);
        }

        public void SaveUser(User user)
        {
            sampleDao.SaveUser(user);
        }

        #endregion
    }
}
