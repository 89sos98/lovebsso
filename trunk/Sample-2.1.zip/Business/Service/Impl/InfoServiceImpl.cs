#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Web;
using System.Collections.Generic;
using Samples.Dao;
using Samples.Model;
using CchenSoft.Framework.Attributes;

namespace Samples.Service.Impl
{
	/// <summary>
	/// Class1 ��ժҪ˵����
	/// </summary>
    [Resource(InfoResource.Name)]
	public class InfoServiceImpl : IInfoService
	{
        [Bean]
		protected ISampleDao sampleDao;

        private CreateHandler createHandler;

		public InfoServiceImpl()
		{
		}

        public CreateHandler CreateHandler
        {
            set { this.createHandler = value; }
        }

		[Log("������Ϣ��ID={0}")]
        [Security(InfoAction.AddInfo)]
		public void SaveInfo(Info info)
		{
			sampleDao.SaveInfo(info);
            createHandler(info);
		}

        [Log("������Ϣ��ID={0}")]
        public void UpdateInfo(Info info)
        {
            sampleDao.UpdateInfo(info);
        }

        public IList<Info> GetInfos(int pageIndex, int pageSize, ref int count)
        {
            return sampleDao.GetInfos(pageIndex, pageSize, ref count);
        }

        [Cacheable]
        public Info LoadInfo(int id)
        {
            return sampleDao.LoadInfo(id);
        }

        #region IService ��Ա

        public void Initialize()
        {
        }

        #endregion
    }

}
