#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;

namespace Samples.Model
{
	/// <summary>
	/// Info ��ժҪ˵����
	/// </summary>
	public class Info
	{
		private int id;
		private string title;
        private string category;
		private string content;
        private DateTime addDate;

		public Info()
		{
			title = "";
			content = "";            
            addDate = DateTime.Now;
		}

		/// <summary>
		/// ��ѶId
		/// </summary>
		public int Id
		{
			get { return id; }
			set { id = value; }
		}

		/// <summary>
		/// ����
		/// </summary>
		public string Title
		{
			get { return title; }
			set { title = value; }
		}

        /// <summary>
        /// ���
        /// </summary>
        public string Category
        {
            get { return category; }
            set { category = value; }
        }

		/// <summary>
		/// ����
		/// </summary>
		public string Content
		{
			get { return content; }
			set { content = value; }
		}

        /// <summary>
        /// ��������
        /// </summary>
        public DateTime AddDate
        {
            get { return addDate; }
            set { addDate = value; }
        }

        public override string ToString()
        {
            return this.GetType() + "," + id.ToString();
        }
	}
}
