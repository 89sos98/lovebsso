#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Samples.Model;
using System.Collections;
using CchenSoft.Framework.Data;
using System.Data;
using CchenSoft.Framework.Attributes;

namespace Samples.Dao
{
    public class ADONetSampleDao : ISampleDao
    {
        [Bean]
        protected IDataService dataService;

        #region User

        public int ValidateLogin(string username, string passwd)
        {
            string sql = "SELECT userId FROM t_users WHERE username=@Username AND passwd=@Passwd";
            IDbDataParameter[] paras = new IDbDataParameter[] {
                dataService.CreateParameter("@Username", username),
                dataService.CreateParameter("@Passwd", passwd)
            };
            return dataService.QueryForObject<int>(sql, paras);
        }


        public User LoadUser(int userId)
        {
            string sql = "SELECT * FROM t_users WHERE userid=@UserId";
            IDbDataParameter[] paras = new IDbDataParameter[] { dataService.CreateParameter("@UserId", userId) };
            return dataService.QueryForObject<User>(sql, paras);
        }

        public void SaveUser(User user)
        {
            string sql = "INSERT INFO t_users (username, passwd) VALUES (@Username, @Passwd)";
            IDbDataParameter[] paras = new IDbDataParameter[] {
                dataService.CreateParameter("@Username", user.Username),
                dataService.CreateParameter("@Passwd", user.Passwd)
            };

            object ret = dataService.Insert(sql, paras);
            user.UserId = Convert.ToInt32(ret);
        }

        public void DeleteUser(int userId)
        {
            IDbDataParameter[] paras = new IDbDataParameter[] { dataService.CreateParameter("@UserId", userId) };
            dataService.Delete("DELETE FROM t_users_resources WHERE userid=@UserId", paras);
            dataService.Delete("DELETE FROM t_users WHERE userid=@UserId", paras);
        }

        public IList<User> GetUsers()
        {
            return dataService.QueryForList<User>("SELECT * FROM t_users", null);
        }

        public void UpdatePermission(int userId, string resource, string permission)
        {
            IDbDataParameter[] paras = new IDbDataParameter[]
            {
                dataService.CreateParameter("@UserId", userId),
                dataService.CreateParameter("@Resource", resource),
                dataService.CreateParameter("@Permission", permission),
            };
            int i = dataService.Update("UPDATE t_users_resources SET Permission=@Permission WHERE UserId=@UserID, Resource=@Resource", paras);

            if (i == 0)
            {
                dataService.Insert("INSERT t_users_resources (userId, resource, permission) values (@UserID, @Resource, @Permission)", paras);
            }
        }

        public string GetPermission(int userId, string resource)
        {
            IDbDataParameter[] paras = new IDbDataParameter[]
            {
                dataService.CreateParameter("@UserId", userId),
                dataService.CreateParameter("@Resource", resource),
            };
            return dataService.QueryForObject<string>("SELECT permission FROM t_users_resources WHERE userid=@UserId AND resource=@Resource", paras);
        }

        #endregion

        #region Info

        public void SaveInfo(Info info)
        {
            string sql = "INSERT INFO t_infos (title, content, category, add_date) VALUES (@Title, @Content, @Category, @AddDate)";
            IDbDataParameter[] paras = new IDbDataParameter[] {
                dataService.CreateParameter("@Title", info.Title),
                dataService.CreateParameter("@Content", info.Content),
                dataService.CreateParameter("@Category", info.Category),
                dataService.CreateParameter("@AddDate", info.AddDate),
            };

            object ret = dataService.Insert(sql, paras);
            info.Id = Convert.ToInt32(ret);
        }

        public void UpdateInfo(Info info)
        {
            string sql = "UPDATE t_infos SET title=@Title, content=@Content, category=@Category, add_date=@AddDate WHERE id=@Id";
            IDbDataParameter[] paras = new IDbDataParameter[] {
                dataService.CreateParameter("@Title", info.Title),
                dataService.CreateParameter("@Content", info.Content),
                dataService.CreateParameter("@Category", info.Category),
                dataService.CreateParameter("@AddDate", info.AddDate),
                dataService.CreateParameter("@Id", info.Id),
            };

            dataService.Update(sql, paras);
        }

        public IList<Info> GetInfos(int pageIndex, int pageSize, ref int count)
        {
            count = dataService.QueryForObject<int>("SELECT COUNT(*) FROM t_Infos", null);
            return dataService.QueryForList<Info>("SELECT * FROM t_Infos", null, (pageIndex - 1) * pageSize, pageSize);
        }

        public Info LoadInfo(int id)
        {
            string sql = "SELECT * FROM t_infos WHERE id=@Id";
            IDbDataParameter[] paras = new IDbDataParameter[] { dataService.CreateParameter("@Id", id) };
            return dataService.QueryForObject<Info>(sql, paras);
        }

        #endregion
    }
}
