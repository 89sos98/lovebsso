using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Framework.DataAccess;
using System.Data;
using Samples.Model;

namespace Samples.Dao
{
    public class CustomConverter : IConverter
    {
        #region IConverter ��Ա

        public T Convert<T>(IDataReader reader)
        {
            if (typeof(T) == typeof(Info))
                return (T)GetInfo(reader);
            else if (typeof(T) == typeof(User))
                return (T)GetUser(reader);

            return default(T);
        }

        #endregion

        private object GetInfo(IDataReader reader)
        {
            Info info = new Info();
            info.Id = (int)reader["id"];
            info.Title = (string)reader["title"];
            info.Category = (string)reader["category"];
            info.Content = (string)reader["content"];
            info.AddDate = (DateTime)reader["add_date"];
            return info;
        }

        private object GetUser(IDataReader reader)
        {
            User user = new User();
            user.UserId = (int)reader["user_id"];
            user.Username = (string)reader["username"];
            user.Passwd = (string)reader["passwd"];
            return user;
        }
    }
}
