#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Samples.Model;
using System.Collections;
using CchenSoft.Framework.Data;
using System.Data;
using CchenSoft.Framework.Attributes;

namespace Samples.Dao
{
    public class NHibernateSampleDao : ISampleDao
    {
        [Bean]
        protected IDataService dataService;

        #region User

        public int ValidateLogin(string username, string passwd)
        {
            string hql = "SELECT u.UserId FROM User u WHERE u.Username=:Username AND u.Passwd=:Passwd";
            Dictionary<string, object> dict = new Dictionary<string, object>();
            dict["Username"] = username;
            dict["Passwd"] = passwd;
            return dataService.QueryForObject<int>(hql, dict);
        }


        public User LoadUser(int userId)
        {
            return dataService.Load<User>(userId);
        }

        public IList<User> GetUsers()
        {
            return dataService.QueryForList<User>("FROM User", null);
        }

        public void UpdatePermission(int userId, string resource, string permission)
        {
            IDbDataParameter[] paras = new IDbDataParameter[]
            {
                dataService.CreateParameter("@UserId", userId),
                dataService.CreateParameter("@Resource", resource),
                dataService.CreateParameter("@Permission", permission),
            };
            int i = dataService.ExecuteNonQuery("UPDATE webfx_users_resources SET Permission=@Permission WHERE UserId=@UserID, Resource=@Resource", paras);

            if (i == 0)
            {
                dataService.ExecuteNonQuery("INSERT webfx_users_resources (userId, resource, permission) values (@UserID, @Resource, @Permission)", paras);
            }
        }

        public string GetPermission(int userId, string resource)
        {
            IDbDataParameter[] paras = new IDbDataParameter[]
            {
                dataService.CreateParameter("@UserId", userId),
                dataService.CreateParameter("@Resource", resource),
            };
            return dataService.QueryForObject<string>("SELECT permission FROM webfx_users_resources WHERE userid=@UserId AND resource=@Resource", paras);
        }

        public void SaveUser(User user)
        {
            dataService.Insert(null, user);
        }

        public void DeleteUser(int userId)
        {
            dataService.ExecuteNonQuery("DELETE FROM webfx_users_resources WHERE userid=" + userId, null);
            dataService.ExecuteNonQuery("DELETE FROM webfx_users WHERE userid=" + userId, null);
        }

        #endregion

        #region Info

        public void SaveInfo(Info info)
        {
            dataService.Insert(null, info);
        }

        public void UpdateInfo(Info info)
        {
            dataService.Update(null, info);
        }

        public IList<Info> GetInfos(int pageIndex, int pageSize, ref int count)
        {
            count = Convert.ToInt32(dataService.QueryForObject("SELECT COUNT(*) FROM Info", null));
            return dataService.QueryForList<Info>("FROM Info", null, (pageIndex - 1) * pageSize, pageSize);
        }

        public Info LoadInfo(int id)
        {
            return dataService.Load<Info>(id);
        }

        #endregion
    }
}
