#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Samples.Model;
using System.Collections;
using CchenSoft.Framework.Data;
using CchenSoft.Framework.Attributes;

namespace Samples.Dao
{
    public class IBatisSampleDao : ISampleDao
    {
        [Bean]
        protected IDataService dataService;

        #region User

        public int ValidateLogin(string username, string passwd)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            dict["username"] = username;
            dict["passwd"] = passwd;
            return dataService.QueryForObject<int>("ValidateLogin", dict);
        }

        public User LoadUser(int userId)
        {
            return dataService.QueryForObject<User>("SelectUser", userId);
        }

        public IList<User> GetUsers()
        {
            return dataService.QueryForList<User>("SelectUser", null);
        }

        public void UpdatePermission(int userId, string resource, string permission)
        {
            Dictionary<string, object> dict = new Dictionary<string,object>();
            dict["userId"] = userId;
            dict["resource"] = resource;
            if (dataService.QueryForObject<int>("CheckUserResourceExists", dict) > 0)
            {
                dict["permission"] = permission;
                dataService.Update("UpdateUserResource", dict);
            }
            else
            {
                dict["permission"] = permission;
                dataService.Update("InsertUserResource", dict);
            }
        }

        public string GetPermission(int userId, string resource)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            dict["userId"] = userId;
            dict["resource"] = resource;
            return dataService.QueryForObject<string>("GetPermission", dict);
        }

        public void SaveUser(User user)
        {
            dataService.Insert("InsertUser", user);
        }

        public void DeleteUser(int userId)
        {
            dataService.Delete("DeleteUserResources", userId);
            dataService.Delete("DeleteUser", userId);
        }

        #endregion

        #region Info

        public void SaveInfo(Info info)
        {
            dataService.Insert("InsertInfo", info);
        }

        public void UpdateInfo(Info info)
        {
            dataService.Update("UpdateInfo", info);
        }

        public IList<Info> GetInfos(int pageIndex, int pageSize, ref int count)
        {
            count = dataService.QueryForObject<int>("GetInfoCount", null);
            return dataService.QueryForList<Info>("SelectInfo", null, (pageIndex - 1) * pageSize, pageSize);
        }

        public Info LoadInfo(int id)
        {
            return dataService.QueryForObject<Info>("SelectInfo", id);
        }

        #endregion

        //#region Role

        //public Role LoadRole(int roleId)
        //{
        //    return dataService.QueryForObject<Role>("SelectRole", roleId);
        //}

        //public IList<Role> GetRoles()
        //{
        //    return dataService.QueryForList<Role>("SelectRole", null);
        //}

        //public int SaveRole(Role role)
        //{
        //    dataService.Insert("InsertRole", role);
        //    return 0;
        //}

        //public int UpdateRole(Role role)
        //{
        //    return dataService.Update("UpdateRole", role);
        //}

        //public int DeleteRole(int roleId)
        //{
        //    dataService.Delete("DeleteResource", roleId);
        //    return dataService.Delete("DeleteRole", roleId);
        //}

        //public IList<string> GetRoleUsers(int roleId)
        //{
        //    return dataService.QueryForList<string>("GetRoleUsers", roleId);
        //}

        //public IList<Role> GetUserRoles(int userId)
        //{
        //    return dataService.QueryForList<Role>("GetUserRoles", userId);
        //}

        //public int DeleteRoleUsers(int roleId)
        //{
        //    return dataService.Delete("DeleteRoleUsers", roleId);
        //}

        //public int DeleteUserFromRole(int roleId, int userId)
        //{
        //    Dictionary<string, object> dict = new Dictionary<string, object>();
        //    dict["roleId"] = roleId;
        //    dict["userId"] = userId;
        //    return dataService.Delete("DeleteUserFromRole", dict);
        //}

        //public int InsertUserToRole(int roleId, int userId)
        //{
        //    Dictionary<string, object> dict = new Dictionary<string, object>();
        //    dict["roleId"] = roleId;
        //    dict["userId"] = userId;
        //    dataService.Insert("InsertUserToRole", dict);
        //    return 0;
        //}

        //public string GetRolePermissions(int roleId, string name)
        //{
        //    Dictionary<string, object> dict = new Dictionary<string, object>();
        //    dict["roleId"] = roleId;
        //    dict["name"] = name;
        //    return dataService.QueryForObject<string>("GetRolePermissions", dict);
        //}

        //public IList<string> GetUserPermissions(string userId, string name)
        //{
        //    Dictionary<string, object> dict = new Dictionary<string, object>();
        //    dict["userId"] = userId;
        //    dict["name"] = name;
        //    IList<string> result = dataService.QueryForList<string>("GetUserPermissions", dict);
        //    return result;
        //}

        //public int UpdateResource(int roleId, string name, string permissions)
        //{
        //    Dictionary<string, object> dict = new Dictionary<string, object>();
        //    dict["roleId"] = roleId;
        //    dict["name"] = name;
        //    dict["permissions"] = permissions;

        //    int exists = CheckResourceExists(roleId, name);

        //    if (exists == 0)
        //        dataService.Insert("InsertResource", dict);
        //    else
        //        dataService.Update("UpdateResource", dict);

        //    return 0;
        //}

        //private int CheckResourceExists(int roleId, string name)
        //{
        //    Dictionary<string, object> dict = new Dictionary<string, object>();
        //    dict["roleId"] = roleId;
        //    dict["name"] = name;

        //    return dataService.QueryForObject<int>("CheckResourceExists", dict);
        //}

        //#endregion

    }
}
