﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CchenSoft.Framework.Attributes;
using CchenSoft.Framework;
using Samples.Service;


namespace Samples.Web.Admin
{
    [Resource(SystemResource.Name)]
    [Security(SystemAction.ViewUser)]
    public partial class ListUser : Page
    {
        [Bean]
        protected IUserService userService;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GridView1.DataSource = userService.GetUsers();
                GridView1.DataBind();
            }
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "delete")
            {
                int userId = int.Parse(e.CommandArgument.ToString());
                userService.DeleteUser(userId);
                //JavaScript.Alert("删除成功！", this);
                Response.Redirect("listUser.aspx");

            }
        }
    }
}
