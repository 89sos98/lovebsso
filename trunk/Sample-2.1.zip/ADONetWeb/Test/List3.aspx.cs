#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CchenSoft.Framework.Attributes;
using Samples.Service;
using Samples.Model;

namespace Samples.Web.Test
{
	/// <summary>
	/// WebForm1 ��ժҪ˵����
	/// </summary>
	public partial class List3 : System.Web.UI.Page
	{
        [Bean]
        protected IInfoService infoService;

		protected void Page_Load(object sender, System.EventArgs e)
		{
            int count = 0;
            int pageIndex = 1;
            int pageSize = 10;

            r.DataSource = infoService.GetInfos(pageIndex, pageSize, ref count);
            r.DataBind();
        }

        protected void r_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Info info = (Info)e.Item.DataItem;

                ((Label)e.Item.FindControl("l_i")).Text = info.Id.ToString();
                ((Label)e.Item.FindControl("l_c")).Text = info.Category;
                ((Label)e.Item.FindControl("l_a")).Text = info.AddDate.ToString("yyyy-MM-dd");

                HyperLink h_t = ((HyperLink)e.Item.FindControl("h_t"));
                h_t.Text = info.Title;
                h_t.NavigateUrl = "viewinfo.aspx?id=" + info.Id;

                ((HyperLink)e.Item.FindControl("h_e")).NavigateUrl = "edit.aspx?id=" + info.Id;
            }
        }

	}
}
