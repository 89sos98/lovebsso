#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Utils;
using Samples.Service;
using CchenSoft.Framework;
using Samples.Model;

namespace Samples.Web.Test
{
	/// <summary>
	/// WebForm1 ��ժҪ˵����
	/// </summary>
    [Resource(InfoResource.Name)]
    [Security(InfoAction.AddInfo)]
    public partial class Add : System.Web.UI.Page
	{
        [Bean]
        protected IInfoService infoService;

		protected void Page_Load(object sender, System.EventArgs e)
		{
            if (!IsPostBack)
            {
                d1.Items.Add(new ListItem("���һ", "c1"));
                d1.Items.Add(new ListItem("����", "c2"));
                d1.Items.Add(new ListItem("�����", "c3"));
            }
		}

        protected void Button1_Click(object sender, System.EventArgs e)
        {
            Info info = new Info();

            FormUtil.GetModel(info, this.Form);

            infoService.SaveInfo(info);

            Response.Redirect(Request.Url.ToString());
        }
	}
}
