﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.Unity;
using System.Reflection;
using System.Resources;

namespace Loning.MVP
{
    public interface IPresenter
    {
        void SetView(IView view);
        void SetModel(IModel model);
        void SetUnityContainer(IUnityContainer unityContainer);
        void Initialize();
        string Name { get; }
        Guid ID { get; }
        IView GetView();
        IModel GetModel();
    }
    public interface IPresenter<V, M> : IPresenter
        where V : IView
        where M : IModel
    {
        void SetView(V view);
        void SetModel(M model);
    }

    public abstract class BasePresenter<V, M> : IPresenter<V, M>
        where V : IView
        where M : IModel
    {

        public BasePresenter()
        {
            var type = this.GetType();
            var assembly = type.Assembly;
            try
            {
                ResourceManager rm = new ResourceManager(assembly.GetName().Name + ".TextResource", assembly);

                Name = rm.GetString(type.Name);
            }
            catch
            {
            }
            finally
            {
                if (Name == null)
                    Name = type.Name;
            }
            ID = Guid.NewGuid();
        }
        public IView GetView()
        {
            return this.View;
        }
        public IModel GetModel()
        {
            return this.Model;
        }
        public V View { get; private set; }
        public M Model { get; private set; }
        public string Name { get; protected set; }
        public Guid ID { get; protected set; }
        protected IUnityContainer UnityContainer { get; private set; }
        public delegate void ThreadInvoker();
        
        protected virtual void Invoke(ThreadInvoker invoker)
        {
            invoker.BeginInvoke(null, null);
        }
        /// <summary>
        /// Remove the model events bound to the Presenter
        /// Note:The Initialized event.
        /// </summary>
        protected abstract void BindModelEvents();

        /// <summary>
        /// Remove the model events bound to the Presenter
        /// Note:The Initialized event.
        /// </summary>
        protected abstract void RemoveModelEvents();


        #region IPresenter<V,M> 成员

        public virtual void SetView(V view)
        {
            this.View = view;
        }

        public virtual void SetModel(M model)
        {
            if (this.Model != null)
            {
                Model.Initialized -= new EventHandler(ModelInitialized);
                RemoveModelEvents();
            }
            this.Model = model;
            Model.Initialized += new EventHandler(ModelInitialized);
            BindModelEvents();
        }

        public void SetView(IView view)
        {
            SetView((V)view);
        }

        public void SetModel(IModel model)
        {
            SetModel((M)model);
        }

        public virtual void Initialize()
        {
            View.Initialize();
            Model.Initialize();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected abstract void ModelInitialized(object sender, EventArgs e);

        [InjectionMethod]
        public void SetUnityContainer(IUnityContainer unityContainer)
        {
            this.UnityContainer = unityContainer;
        }

        #endregion
    }
    /// <summary>
    /// 自动注入的MVP，会自动注入<c>V</c>及<c>M</c>
    /// </summary>
    /// <typeparam name="V"></typeparam>
    /// <typeparam name="M"></typeparam>
    public abstract class Presenter<V, M> : BasePresenter<V, M>
        where V : IView
        where M : IModel
    {
        [Microsoft.Practices.Unity.InjectionMethod]
        public override void SetModel(M model)
        {
            base.SetModel(model);
        }
        [Microsoft.Practices.Unity.InjectionMethod]
        public override void SetView(V view)
        {
            base.SetView(view);
        }
    }
}
