﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Loning.MVP
{
    public class EventArgs<T>:System.EventArgs
    {
        public T Data { get; set; }
    }
    public class EventArgs<T1,T2> : System.EventArgs
    {
        public T1 Data1 { get; set; }
        public T2 Data2 { get; set; }
    }
    public class EventArgs<T1, T2,T3> : System.EventArgs
    {
        public T1 Data1 { get; set; }
        public T2 Data2 { get; set; }
        public T3 Data3 { get; set; }
    }
}
