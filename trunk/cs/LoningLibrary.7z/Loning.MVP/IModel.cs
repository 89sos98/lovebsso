﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Loning.MVP
{
    public interface IModel
    {
        void Initialize();
        event EventHandler Initialized;
    }
}
