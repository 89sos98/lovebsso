﻿using System;
using System.Collections.Generic;
using System.Text;
using Loning.MVP;
namespace Loning.MvpWinform.Presenter
{
    public class TaskBoxPresenter : CommonPresenter<View.ITaskBoxView, Model.ITaskBox>
    {
        protected override void BindModelEvents()
        {
            Model.TaskAdded += new EventHandler<EventArgs<string, Loning.Tasks.Task>>(Model_TaskAdded);
            Model.TaskFailed += new EventHandler<EventArgs<Loning.Tasks.Task, Exception>>(Model_TaskFailed);
            //throw new NotImplementedException();
        }

        void Model_TaskFailed(object sender, EventArgs<Loning.Tasks.Task, Exception> e)
        {
#if DEBUG
            Output(e.Data2.ToString());
#else
            Output(e.Data2.ToString());
#endif
            //throw new NotImplementedException();
        }

        void Model_TaskAdded(object sender, EventArgs<string, Loning.Tasks.Task> e)
        {
            View.AddTask(e.Data1, e.Data2);
            //throw new NotImplementedException();
        }

        protected override void RemoveModelEvents()
        {
            //throw new NotImplementedException();
        }

        protected override void ModelInitialized(object sender, EventArgs e)
        {
            
            //throw new NotImplementedException();
        }
        public override void Initialize()
        {
            this.Name = "任务管理";
            base.Initialize();
        }
    }
}
