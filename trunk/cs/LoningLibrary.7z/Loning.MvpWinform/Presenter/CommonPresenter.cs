﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.Unity;
using Loning.MvpWinform.Model;
using Loning.Tasks;
using Loning.MVP;

namespace Loning.MVP
{
    /// <summary>
    /// 有默认的几个容器的引用
    /// </summary>
    /// <typeparam name="V"></typeparam>
    /// <typeparam name="M"></typeparam>
    public abstract class CommonBasePresenter<V, M> : Loning.MVP.BasePresenter<V, M>
        where V : IView
        where M : IModel
    {
        [Dependency]
        public IOutputBox OutputBox { get; set; }
        [Dependency]
        public IProgressBox ProgressBox { get; set; }
        [Dependency]
        public ITaskBox TaskBox { get; set; }
        protected override void Invoke(Presenter<V, M>.ThreadInvoker invoker)
        {
            TaskBox.GetTaskSheduler("系统").AddTask(
                new DelegateTask(invoker, DateTime.Now, invoker.ToString()));
            //base.Invoke(invoker);
        }
        protected void Invoke(string name, Presenter<V, M>.ThreadInvoker invoker)
        {
            TaskBox.GetTaskSheduler("系统").AddTask(
                new DelegateTask(invoker, DateTime.Now, name));
        }
        protected void Output(string value, bool show, params object[] objs)
        {
            OutputBox.AppendLine(Name, show, value, objs);
        }
        protected void Output(string value, params object[] objs)
        {
            Output(value, false, objs);
        }
    }
    /// <summary>
    /// 自动注入的CommonMVP，会自动注入<c>V</c>及<c>M</c>
    /// </summary>
    /// <typeparam name="V"></typeparam>
    /// <typeparam name="M"></typeparam>
    public abstract class CommonPresenter<V, M> : CommonBasePresenter<V, M>
        where V : IView
        where M : IModel
    {
        [Microsoft.Practices.Unity.InjectionMethod]
        public override void SetModel(M model)
        {
            base.SetModel(model);
        }
        [Microsoft.Practices.Unity.InjectionMethod]
        public override void SetView(V view)
        {
            base.SetView(view);
        }
    }
    public class SimplePresenter<V,M>:CommonPresenter<V,M>
        where V : IView
        where M : IModel
    {

        protected override void BindModelEvents()
        {
            //throw new NotImplementedException();
        }

        protected override void RemoveModelEvents()
        {
            //throw new NotImplementedException();
        }

        protected override void ModelInitialized(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }
    }
}
