﻿using System;
using System.Collections.Generic;
using System.Text;
using Loning.MVP;
namespace Loning.MvpWinform.Presenter
{
    public class OutputBox:Presenter<View.IOutputBox,Model.IOutputBox>
    {
        protected override void BindModelEvents()
        {
            this.Model.SourceAdded += new EventHandler<EventArgs<string>>(Model_NewSourceAdded);
            this.Model.TextUpdated += new EventHandler<EventArgs<KeyValuePair<string, string>>>(Model_TextUpdated);
            this.Model.SourceSelected += new EventHandler<EventArgs<string>>(Model_SourceSelected);
        }

        void Model_SourceSelected(object sender, EventArgs<string> e)
        {
            this.View.SelectSource(e.Data);
        }

        void Model_TextUpdated(object sender, EventArgs<KeyValuePair<string, string>> e)
        {
            this.View.UpdateText(e.Data.Key, e.Data.Value);
        }

        void Model_NewSourceAdded(object sender, EventArgs<string> e)
        {
            this.View.AddSource(e.Data);
        }

        protected override void RemoveModelEvents()
        {
            this.Model.SourceAdded -= new EventHandler<EventArgs<string>>(Model_NewSourceAdded);
            this.Model.TextUpdated -= new EventHandler<EventArgs<KeyValuePair<string, string>>>(Model_TextUpdated);
            this.Model.SourceSelected -= new EventHandler<EventArgs<string>>(Model_SourceSelected);
            //throw new NotImplementedException();
        }
        public override void Initialize()
        {
            base.Initialize();
            this.View.SourceChanged += new EventHandler<EventArgs<string>>(View_SourceChanged);
        }

        void View_SourceChanged(object sender, EventArgs<string> e)
        {
            this.Model.SelectSource(e.Data);
        }
        protected override void ModelInitialized(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }
    }
}
