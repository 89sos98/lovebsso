﻿using System;
using System.Collections.Generic;
using System.Text;
using Loning.MVP;
using Loning.MvpWinform.Model;

namespace Loning.MvpWinform.Presenter
{
    
    public class ProgressBox:Presenter<View.IProgressBox,Model.IProgressBox>
    {

        protected override void BindModelEvents()
        {
            Model.ItemCreated += new EventHandler<EventArgs<Loning.MvpWinform.Model.ProgressItem>>(Model_ItemCreated);
            Model.ItemRemoved += new EventHandler<EventArgs<KeyValuePair<Type, string>>>(Model_ItemRemoved);
            //throw new NotImplementedException();
        }

        void Model_ItemRemoved(object sender, EventArgs<KeyValuePair<Type, string>> e)
        {
            //View.GetProgressItem(e.Data).Remove();
            View.RemoveItem(e.Data);
            //throw new NotImplementedException();
        }

        void Model_ItemCreated(object sender, EventArgs<Loning.MvpWinform.Model.ProgressItem> e)
        {
            e.Data.Changed += new EventHandler(Data_Changed);
            View.GetProgressItem(e.Data.Key).StopRequested += delegate(object sender1, EventArgs e1)
            {
                e.Data.StopRequest();
            };
            //throw new NotImplementedException();
        }


        void Data_Changed(object sender, EventArgs e)
        {
            ProgressItem item = (ProgressItem)sender;
            Loning.MvpWinform.View.IProgressItem itemView = View.GetProgressItem(item.Key);
            itemView.Message = item.Message;
            itemView.Title = item.Title;
            itemView.Value = item.Value;
        }

        protected override void RemoveModelEvents()
        {
            //throw new NotImplementedException();
        }

        protected override void ModelInitialized(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }
    }
}
