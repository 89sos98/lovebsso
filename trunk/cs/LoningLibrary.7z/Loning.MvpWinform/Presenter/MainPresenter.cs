﻿using System;
using System.Collections.Generic;
using System.Text;
using Loning.MVP;
using Loning.MvpWinform.View;
using Loning.MvpWinform.Model;
using System.Threading;
using System.Windows.Forms;

namespace Loning.MvpWinform.Presenter
{
    public class MainPresenter : Presenter<IMainView, IMainModel>
    {
        protected override void BindModelEvents()
        {

        }

        protected override void RemoveModelEvents()
        {
            //throw new NotImplementedException();
        }

        protected override void ModelInitialized(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }
    }
    public class AdvancedMainPresenter : Presenter<IAdvancedMainView, IAdvancedMainModel>
    {
        public ThreadInvoker LoadingInvoker;
        protected override void BindModelEvents()
        {
            Model.PresenterLoadingStateChanged += new EventHandler<EventArgs<IPresenter, PresenterLoadingState>>(Model_PresenterLoadingStateChanged);
            Model.PresentersLoaded += new EventHandler(Model_PresentersLoaded);
            //throw new NotImplementedException();
        }

        void Model_PresentersLoaded(object sender, EventArgs e)
        {
            View.LoadLayout();
            View.ChangeLoadingItemState(this.ID, PresenterLoadingState.Loaded);
            View.FinishLoading();
            View.Show();
            //throw new NotImplementedException();
        }

        void Model_PresenterLoadingStateChanged(object sender, EventArgs<IPresenter, PresenterLoadingState> e)
        {
            switch (e.Data2)
            {
                case PresenterLoadingState.Failed:
                case PresenterLoadingState.Loaded:
                case PresenterLoadingState.Loading:
                    View.ChangeLoadingItemState(e.Data1.ID, e.Data2);
                    break;
                case PresenterLoadingState.Unstarted:
                    break;
            }
            //throw new NotImplementedException();
        }


        protected override void RemoveModelEvents()
        {
            //throw new NotImplementedException();
        }

        protected override void ModelInitialized(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }
        public override void Initialize()
        {
            this.Name = "主窗体";
            View.LoadingFormShowed += new EventHandler(View_LoadingFormShowed);
            base.Initialize();
        }

        void View_LoadingFormShowed(object sender, EventArgs e)
        {
            Invoke(() =>
            {
                if (LoadingInvoker != null)
                    LoadingInvoker();
                View.BeginUpdateLoadingForm();
                View.AddLoadingItem(this.ID, this.Name);
                foreach (IPresenter p in Model.Presenters)
                {
                    if (p.GetView() is Form)
                        View.AddLoadingItem(p.ID, p.Name, ((Form)p.GetView()).Icon.ToBitmap());
                    else
                        View.AddLoadingItem(p.ID, p.Name);
                }
                View.EndUdateLoadingForm();
                //Thread.Sleep(20000);
                Model.LoadPresenters();
            });
            //throw new NotImplementedException();
        }

    }

}
