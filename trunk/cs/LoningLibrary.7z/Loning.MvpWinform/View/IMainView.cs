﻿using System;
using System.Collections.Generic;
using System.Text;
using Loning.MVP;
using System.Drawing;
namespace Loning.MvpWinform.View
{
    public interface IMainView : IView
    {

        void AddWindow(WeifenLuo.WinFormsUI.Docking.DockContent dockContent);

    }
    public interface IAdvancedMainView : IMainView
    {
        /// <summary>
        /// 载入完成
        /// </summary>
        event EventHandler LoadingFinished;

        /// <summary>
        /// Loading form was showed.
        /// </summary>
        event EventHandler LoadingFormShowed;
        /// <summary>
        /// 加入Loading项目
        /// </summary>
        /// <param name="id">唯一标识符</param>
        /// <param name="title">名称</param>
        /// <param name="icon">图标</param>
        void AddLoadingItem(Guid id, string title, Image icon);
        void AddLoadingItem(Guid id, string title);

        void BeginUpdateLoadingForm();
        void EndUdateLoadingForm();
        /// <summary>
        /// 显示正在载入某项目字样
        /// </summary>
        /// <param name="id"></param>
        void ChangeLoadingItemState(Guid id,Model.PresenterLoadingState state);

        /// <summary>
        /// 显示正在载入某项目中子项目部分
        /// </summary>
        /// <param name="text"></param>
        void UpdateLoadingText(string text);

        /// <summary>
        /// 载入布局
        /// </summary>
        void LoadLayout();

        /// <summary>
        /// 显示
        /// </summary>
        void Show();

        /// <summary>
        /// 隐藏
        /// </summary>
        void Hide();

        /// <summary>
        /// 完成载入
        /// </summary>
        void FinishLoading();
    }
}
