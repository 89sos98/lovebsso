﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Loning.MvpWinform.View
{
    public interface IProgressItem
    {
        int Value { get; set; }
        string Title { get; set; }
        string Message { get; set; }
        //void Remove();
        event EventHandler StopRequested;
    }
    public partial class ProgressItem : UserControl,IProgressItem
    {
        public ProgressItem()
        {
            InitializeComponent();
        }
        public ProgressItem(int value, string title, string message):this()
        {
            this.progressBar1.Value = value;
            this.Caption.Text = title;
            this.MessageLabel.Text = message;
        }


        public int Value
        {
            get
            {
                return this.progressBar1.Value;
            }
            set
            {
                if (InvokeRequired)
                {

                    this.Invoke(new MethodInvoker(delegate()
                    {
                        this.progressBar1.Value = value;

                    }));
                }
                else
                    this.progressBar1.Value = value;
            }
        }

        public string Title
        {
            get
            {
                return this.Caption.Text;
            }
            set
            {
                if (InvokeRequired)
                {

                    this.Invoke(new MethodInvoker(delegate()
                    {
                        this.Caption.Text = value;
                    }));
                }
                else
                    this.Caption.Text = value;
                
            }
        }

        public string Message
        {
            get
            {
                return this.MessageLabel.Text;
            }
            set
            {
                if (InvokeRequired)
                {

                    this.Invoke(new MethodInvoker(delegate()
                    {

                        this.MessageLabel.Text = value;
                        
                    }));
                }
                else
                    this.MessageLabel.Text = value;
                
            }
        }


        public void Remove()
        {
            if (Closed != null)
                Closed(this, EventArgs.Empty);
        }


        public event EventHandler Closed;

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (StopRequested != null)
                StopRequested(this, e);
        }



        public event EventHandler StopRequested;


        private void MessageLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
