﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Loning.Tasks;
using Loning.MvpWinform.Model;
using Microsoft.Practices.Unity;
using System.Windows.Forms;

namespace Loning.MvpWinform.View
{
    public class SimpleToolBaseWindow:ToolBaseWindow
    {
        [Dependency]
        public IUnityContainer UnityContainer { get; set; }
        [Dependency]
        public Model.IOutputBox OutputBox { get; set; }
        [Dependency]
        public Model.IProgressBox ProgressBox { get; set; }
        [Dependency]
        public Model.ITaskBox TaskBox { get; set; }
        protected void TaskInvoke(ThreadStart invoker)
        {
            TaskBox.GetTaskSheduler(this.Text).AddTask(
                new DelegateTask(invoker, DateTime.Now, invoker.ToString()));
        }
        protected void TaskInvoke(string name, ThreadStart invoker)
        {
            TaskBox.GetTaskSheduler(this.Text).AddTask(
                new DelegateTask(invoker, DateTime.Now, name));
        }
        protected void Output(string value, bool show, params object[] objs)
        {
            OutputBox.AppendLine(Name, show, value, objs);
        }
        protected void Output(string value, params object[] objs)
        {
            Output(value, false, objs);
        }
        protected void Message(string value)
        {
            Invoke(() =>
            {
                MessageBox.Show(value,this.Text);
            });
        }
    }
}
