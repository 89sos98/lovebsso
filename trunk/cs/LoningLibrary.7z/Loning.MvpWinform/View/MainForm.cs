﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Loning.MVP;
using Microsoft.Practices.Unity;

namespace Loning.MvpWinform.View
{
    public interface IMainView : IView
    {

        void AddWindow(WeifenLuo.WinFormsUI.Docking.DockContent dockContent);
        
    }
    public partial class MainForm : Form,IMainView
    {
        public MainForm()
        {
            InitializeComponent();
        }

        #region IView 成员

        public virtual void Initialize()
        {
            //throw new NotImplementedException();
        }

        #endregion

        #region IMainView 成员
        

        public void AddWindow(WeifenLuo.WinFormsUI.Docking.DockContent dockContent)
        {
            dockContent.Show(this.dockPanel1);
        }

        #endregion
    }
}
