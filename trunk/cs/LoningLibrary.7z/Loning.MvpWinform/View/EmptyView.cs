﻿using System;
using System.Collections.Generic;
using System.Text;
using Loning.MVP;

namespace Loning.MvpWinform.View
{
    public class EmptyView:IView
    {
        public void Initialize()
        {
            //throw new NotImplementedException();
        }
    }
}
