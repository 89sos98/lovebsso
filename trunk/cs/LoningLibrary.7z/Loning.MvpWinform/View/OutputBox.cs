﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Loning.MVP;

namespace Loning.MvpWinform.View
{
    
    public interface IOutputBox:IView
    {
        void AddSource(string name);
        event EventHandler<EventArgs<string>> SourceChanged;
        void UpdateText(string name, string value);
        void SelectSource(string name);
    }
    public partial class OutputBox : Loning.MvpWinform.View.ToolBaseWindow,IOutputBox
    {
        public OutputBox()
        {
            InitializeComponent();
        }

        #region IView 成员

        public void Initialize()
        {
            MainView.AddWindow(this);
        }

        #endregion

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {
           
        }

        #region IOutputBox 成员

        public void AddSource(string name)
        {
            Invoke(delegate()
            {
                this.toolStripComboBox1.Items.Add(name);
                //throw new NotImplementedException();
            });
        }

        public event EventHandler<EventArgs<string>> SourceChanged;

        public void UpdateText(string name, string value)
        {
            Invoke(delegate()
            {
                if (this.toolStripComboBox1.ComboBox.Text == name)
                {
                    
                    this.textBox1.Text = value;
                    this.textBox1.SelectionStart = value.Length;
                    this.textBox1.ScrollToCaret();
                }
            });
        }

        #endregion

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (SourceChanged != null)
                SourceChanged(this, new EventArgs<string> { Data = toolStripComboBox1.ComboBox.Text });
        }

        #region IOutputBox 成员


        public void SelectSource(string name)
        {
            this.Invoke(delegate()
            {
                toolStripComboBox1.SelectedItem = name;
            });
        }

        #endregion
    }
}
