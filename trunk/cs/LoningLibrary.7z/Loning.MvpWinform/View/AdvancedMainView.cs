﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Loning.MvpWinform.View;
using System.Reflection;
using WeifenLuo.WinFormsUI.Docking;
using System.IO;
using Microsoft.Practices.Unity;

namespace Loning.MvpWinform.View
{
    public partial class AdvancedMainView : Form, IAdvancedMainView
    {

        private DeserializeDockContent deserializeDockContent;
        private Dictionary<string, DockContent> windows;
        protected ToolStripMenuItem ViewMenu;
        private LoadingForm loadingForm;

        [Dependency]
        public IUnityContainer UnityContainer { get; set; }
        public AdvancedMainView()
        {
            InitializeComponent();
            deserializeDockContent = new DeserializeDockContent(GetContentFromPersistString);
            windows = new Dictionary<string, DockContent>();
            ViewMenu = this.viewToolStripMenuItem;
            //this.Visible = false;
        }


        private void AdvancedMainView_Load(object sender, EventArgs e)
        {
            //this.Hide();
            if (UnityContainer != null)
            {
                loadingForm = UnityContainer.Resolve<LoadingForm>();
                //loadingForm.Show();
            }
            //#if DEBUG
            //            loadingForm.Visible = false;
            //#else

            //#endif


            if (LoadingFormShowed != null)
                LoadingFormShowed(this, EventArgs.Empty);
        }
        protected virtual IDockContent GetContentFromPersistString(string persistString)
        {
            IDockContent content = null;
            if (windows.ContainsKey(persistString))
            {
                return windows[persistString];
            }
            return content;
        }


        void showWindow(DockContent content)
        {
            content.Show(this.dockPanel1);
        }
        #region IMainView 成员

        public void AddWindow(WeifenLuo.WinFormsUI.Docking.DockContent dockContent)
        {
            Invoke(() =>
            {
                if (dockContent is ToolBaseWindow)
                {
                    if (!windows.ContainsKey(dockContent.GetType().ToString()))
                    {
                        windows.Add(dockContent.GetType().ToString(), dockContent);
                        dockContent.Show(this.dockPanel1);
                        if (ViewMenu != null)
                        {
                            ToolStripMenuItem menuItem = new ToolStripMenuItem();
                            menuItem.Image = dockContent.Icon.ToBitmap();
                            menuItem.DisplayStyle = ToolStripItemDisplayStyle.ImageAndText;
                            menuItem.Text = dockContent.Text;
                            menuItem.Size = ViewMenu.Size;
                            //menuItem.Checked = dockContent.Visible;
                            menuItem.Checked = dockContent.DockState != DockState.Hidden;

                            menuItem.Click += delegate(object sender, EventArgs e)
                            {
                                if (dockContent.DockState == DockState.Hidden)
                                    showWindow(dockContent);
                                else
                                    dockContent.DockState = DockState.Hidden;
                            };
                            dockContent.DockStateChanged += (s, e) =>
                            {
                                menuItem.Checked = dockContent.DockState != DockState.Hidden;
                            };
                            //dockContent.VisibleChanged += (s, e) =>
                            //{
                            //    menuItem.Checked = dockContent.Visible;
                            //};
                            dockContent.TextChanged += (s, e) =>
                            {
                                menuItem.Text = dockContent.Text;
                            };
                            ViewMenu.DropDownItems.Add(menuItem);
                        }
                    }
                }
                else
                {
                    dockContent.Show(this.dockPanel1);
                    dockContent.Activate();
                }
            });
            //showWindow(dockContent);
        }


        #endregion

        #region IView 成员

        public void Initialize()
        {
            //
            //throw new NotImplementedException();
        }

        #endregion


        void LoadDocks()
        {
            if (File.Exists(Environment.CurrentDirectory + "/dock.xml"))
            {
                dockPanel1.SuspendLayout(true);
                CloseDocks();
                dockPanel1.LoadFromXml(Environment.CurrentDirectory + "/dock.xml", this.deserializeDockContent);
                foreach (var win in windows.Values)
                {
                    if (win.DockPanel == null)
                        win.Show(dockPanel1);
                }
                dockPanel1.ResumeLayout(true, true);
            }
            else
            {
                LoadDefaultDocks();
            }
        }
        public new void Show()
        {
            Invoke(() =>
            {
                base.Show();
            });
        }
        void LoadDefaultDocks()
        {
            dockPanel1.SuspendLayout(true);
            foreach (var win in windows.Values)
            {
                win.Show(dockPanel1);
            }
            dockPanel1.ResumeLayout(true, true);
            /*
            dockPanel1.SuspendLayout(true);
            CloseDocks();
            Assembly assembly = Assembly.GetAssembly(typeof(AdvancedMainView));
            Stream xmlStream = assembly.GetManifestResourceStream("LargeFoot.Resources.defaultDock.xml");
            
            dockPanel1.LoadFromXml(xmlStream, this.deserializeDockContent, true);
            dockPanel1.ResumeLayout(true, true);*/

        }
        void SaveDocks()
        {
            this.dockPanel1.SaveAsXml(Environment.CurrentDirectory + "/dock.xml");
        }
        private void CloseAllDocuments()
        {
            if (dockPanel1.DocumentStyle == DocumentStyle.SystemMdi)
            {
                foreach (Form form in MdiChildren)
                    form.Close();
            }
            else
            {
                for (int index = dockPanel1.Contents.Count - 1; index >= 0; index--)
                {
                    if (dockPanel1.Contents[index] is IDockContent)
                    {
                        IDockContent content = (IDockContent)dockPanel1.Contents[index];
                        content.DockHandler.Close();
                    }
                }
            }
        }

        private void MainView_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.ApplicationExitCall)
                return;
            if (MessageBox.Show("请确认退出", this.Text, MessageBoxButtons.YesNo)
                == DialogResult.Yes)
            {
                SaveDocks();
            }
            else
            {
                e.Cancel = true;
            }
        }
        void CloseDocks()
        {
            foreach (DockContent content in windows.Values)
            {
                content.DockPanel = null;
            }
            CloseAllDocuments();
        }
        private void LoadDefaultDocksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadDefaultDocks();
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (FormShowed != null)
                FormShowed(this, EventArgs.Empty);

        }

        #region IMainView 成员

        public event EventHandler FormShowed;

        #endregion

        void ChangeVisible()
        {
            this.Visible = !this.Visible;
            if (this.Visible)
                this.Activate();
        }

        private void NotifyIcon_Click(object sender, EventArgs e)
        {
            ChangeVisible();

        }

        private void NotifyIcon_Click(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ChangeVisible();
            }
        }

        private void showHideToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangeVisible();

        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MainView_VisibleChanged(object sender, EventArgs e)
        {
            showHideToolStripMenuItem.Text = this.Visible ? "隐藏" : "显示";
        }

        private void loginToolStripButton_Click(object sender, EventArgs e)
        {

        }

        #region IAdvancedMainView 成员



        public event EventHandler LoadingFinished;

        public event EventHandler LoadingFormShowed;

        public void AddLoadingItem(Guid id, string title, Image icon)
        {
            Invoke(() =>
            {
                this.loadingForm.AddLoadingItem(id, title, icon);
            });
            //throw new NotImplementedException();
        }

        public void AddLoadingItem(Guid id, string title)
        {
            Invoke(() =>
            {
                AddLoadingItem(id, title, null);
            });
            //throw new NotImplementedException();
        }

        public void ChangeLoadingItemState(Guid id, Loning.MvpWinform.Model.PresenterLoadingState state)
        {
            Invoke(() =>
            {
                this.loadingForm.UpdateLoadingItem(id, state);
            });
            //throw new NotImplementedException();
        }

        public void UpdateLoadingText(string text)
        {
            throw new NotImplementedException();
        }

        public void LoadLayout()
        {
            Invoke(() =>
            {
                LoadDocks();
            });
            //throw new NotImplementedException();
        }

        public void FinishLoading()
        {
            Invoke(() =>
            {
                this.loadingForm.Close();
            });
            if (LoadingFinished != null)
                LoadingFinished(this, EventArgs.Empty);
        }

        public void Invoke(MethodInvoker del)
        {
            if (this.InvokeRequired)
            {
                this.Invoke((Delegate)del);
            }
            else
            {
                del.Invoke();
            }
        }


        public void BeginUpdateLoadingForm()
        {
            this.loadingForm.SuspendLayout();
            //throw new NotImplementedException();
        }

        public void EndUdateLoadingForm()
        {

            this.loadingForm.ResumeLayout();

            //throw new NotImplementedException();
        }

        #endregion

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
