﻿namespace Loning.MvpWinform.View
{
    partial class TaskBoxView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButtonCategory = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripButtonFinished = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonFailed = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonUnstarted = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonRunning = new System.Windows.Forms.ToolStripButton();
            this.listView1 = new BrightIdeasSoftware.FastObjectListView();
            this.olvColumnInvokeTime = new BrightIdeasSoftware.OLVColumn();
            this.olvColumnCategory = new BrightIdeasSoftware.OLVColumn();
            this.olvColumnName = new BrightIdeasSoftware.OLVColumn();
            this.olvColumnState = new BrightIdeasSoftware.OLVColumn();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.listView1)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButtonCategory,
            this.toolStripButtonFinished,
            this.toolStripButtonFailed,
            this.toolStripButtonUnstarted,
            this.toolStripButtonRunning});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(725, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButtonCategory
            // 
            this.toolStripDropDownButtonCategory.Image = global::Loning.MvpWinform.Properties.Resources._1_folder_empty;
            this.toolStripDropDownButtonCategory.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButtonCategory.Name = "toolStripDropDownButtonCategory";
            this.toolStripDropDownButtonCategory.Size = new System.Drawing.Size(61, 22);
            this.toolStripDropDownButtonCategory.Text = "分类";
            // 
            // toolStripButtonFinished
            // 
            this.toolStripButtonFinished.Checked = true;
            this.toolStripButtonFinished.CheckOnClick = true;
            this.toolStripButtonFinished.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButtonFinished.Image = global::Loning.MvpWinform.Properties.Resources.finish;
            this.toolStripButtonFinished.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonFinished.Name = "toolStripButtonFinished";
            this.toolStripButtonFinished.Size = new System.Drawing.Size(64, 22);
            this.toolStripButtonFinished.Text = "完成项";
            this.toolStripButtonFinished.CheckedChanged += new System.EventHandler(this.toolStripButtonFinished_Click);
            // 
            // toolStripButtonFailed
            // 
            this.toolStripButtonFailed.Checked = true;
            this.toolStripButtonFailed.CheckOnClick = true;
            this.toolStripButtonFailed.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButtonFailed.Image = global::Loning.MvpWinform.Properties.Resources.agt_action_fail;
            this.toolStripButtonFailed.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonFailed.Name = "toolStripButtonFailed";
            this.toolStripButtonFailed.Size = new System.Drawing.Size(64, 22);
            this.toolStripButtonFailed.Text = "错误项";
            this.toolStripButtonFailed.CheckedChanged += new System.EventHandler(this.toolStripButtonFailed_Click);
            // 
            // toolStripButtonUnstarted
            // 
            this.toolStripButtonUnstarted.Checked = true;
            this.toolStripButtonUnstarted.CheckOnClick = true;
            this.toolStripButtonUnstarted.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButtonUnstarted.Image = global::Loning.MvpWinform.Properties.Resources.queue;
            this.toolStripButtonUnstarted.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonUnstarted.Name = "toolStripButtonUnstarted";
            this.toolStripButtonUnstarted.Size = new System.Drawing.Size(64, 22);
            this.toolStripButtonUnstarted.Text = "队列项";
            this.toolStripButtonUnstarted.CheckedChanged += new System.EventHandler(this.toolStripButtonUnstarted_Click);
            // 
            // toolStripButtonRunning
            // 
            this.toolStripButtonRunning.Checked = true;
            this.toolStripButtonRunning.CheckOnClick = true;
            this.toolStripButtonRunning.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButtonRunning.Image = global::Loning.MvpWinform.Properties.Resources.runprocesscatcher;
            this.toolStripButtonRunning.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonRunning.Name = "toolStripButtonRunning";
            this.toolStripButtonRunning.Size = new System.Drawing.Size(64, 22);
            this.toolStripButtonRunning.Text = "执行项";
            this.toolStripButtonRunning.CheckedChanged += new System.EventHandler(this.toolStripButtonRunning_Click);
            // 
            // listView1
            // 
            this.listView1.AllColumns.Add(this.olvColumnInvokeTime);
            this.listView1.AllColumns.Add(this.olvColumnCategory);
            this.listView1.AllColumns.Add(this.olvColumnName);
            this.listView1.AllColumns.Add(this.olvColumnState);
            this.listView1.AllowColumnReorder = true;
            this.listView1.AlternateRowBackColor = System.Drawing.Color.White;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnInvokeTime,
            this.olvColumnCategory,
            this.olvColumnName,
            this.olvColumnState});
            this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(0, 25);
            this.listView1.Name = "listView1";
            this.listView1.OwnerDraw = true;
            this.listView1.ShowGroups = false;
            this.listView1.Size = new System.Drawing.Size(725, 132);
            this.listView1.Sorting = System.Windows.Forms.SortOrder.Descending;
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.VirtualMode = true;
            // 
            // olvColumnInvokeTime
            // 
            this.olvColumnInvokeTime.AspectName = "InvokeTime";
            this.olvColumnInvokeTime.DisplayIndex = 1;
            this.olvColumnInvokeTime.Text = "执行时间";
            this.olvColumnInvokeTime.Width = 150;
            // 
            // olvColumnCategory
            // 
            this.olvColumnCategory.AspectName = "Category";
            this.olvColumnCategory.DisplayIndex = 0;
            this.olvColumnCategory.Text = "分类";
            this.olvColumnCategory.Width = 54;
            // 
            // olvColumnName
            // 
            this.olvColumnName.AspectName = "Name";
            this.olvColumnName.Text = "任务说明";
            this.olvColumnName.Width = 194;
            // 
            // olvColumnState
            // 
            this.olvColumnState.AspectName = "State";
            this.olvColumnState.Text = "状态";
            this.olvColumnState.Width = 265;
            // 
            // TaskBoxView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(725, 157);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "TaskBoxView";
            this.ShowHint = WeifenLuo.WinFormsUI.Docking.DockState.DockBottom;
            this.Text = "任务列表";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.listView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonFinished;
        private System.Windows.Forms.ToolStripButton toolStripButtonFailed;
        private System.Windows.Forms.ToolStripButton toolStripButtonUnstarted;
        private System.Windows.Forms.ToolStripButton toolStripButtonRunning;
        private BrightIdeasSoftware.FastObjectListView listView1;
        private BrightIdeasSoftware.OLVColumn olvColumnCategory;
        private BrightIdeasSoftware.OLVColumn olvColumnName;
        private BrightIdeasSoftware.OLVColumn olvColumnInvokeTime;
        private BrightIdeasSoftware.OLVColumn olvColumnState;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButtonCategory;
    }
}