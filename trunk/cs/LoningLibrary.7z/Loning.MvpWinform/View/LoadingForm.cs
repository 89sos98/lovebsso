﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Loning.MvpWinform.View
{
    public partial class LoadingForm : Form
    {
        public int LoadedItemCount { get; private set; }
        public IDictionary<Guid, LoadingItem> Items { get; private set; }
        public Color LoadingColor { get; set; }
        public Color LoadedColor { get; set; }
        public LoadingForm()
        {
            InitializeComponent();
            Items = new Dictionary<Guid, LoadingItem>();
            LoadedItemCount = 0;
            LoadingColor = Color.Green;
            LoadedColor = Color.Blue;
        }
        public void AddLoadingItem(Guid id, string text, Image image)
        {
            PictureBox box = new PictureBox();
            box.Image = image;
            box.Dock = DockStyle.Fill;
            box.SizeMode = PictureBoxSizeMode.StretchImage;
            Label label = new Label();
            label.Dock = DockStyle.Fill;
            label.TextAlign = ContentAlignment.MiddleLeft;
            label.Text = text;
            Items.Add(id, new LoadingItem { Image=box,ID=id,Name=label,Index=Items.Count+1 });
            this.tableLayoutPanel1.Controls.Add(box, 0, Items.Count);
            this.tableLayoutPanel1.Controls.Add(label, 1, Items.Count);
            //this.Update();
        }
        public void UpdateLoadingItem(Guid id, Model.PresenterLoadingState state)
        {
            var item=Items[id];
            this.label1.Text = "Update "+item.Name.Text;
            switch (state)
            {
                case Loning.MvpWinform.Model.PresenterLoadingState.Loading:
                    item.Name.ForeColor = LoadingColor;
                    break;
                case Loning.MvpWinform.Model.PresenterLoadingState.Loaded:
                    item.Name.ForeColor = LoadedColor;
                    LoadedItemCount++;
                    SetProcess((float)LoadedItemCount / Items.Count);
                    break;
                case Loning.MvpWinform.Model.PresenterLoadingState.Failed:
                    item.Name.ForeColor = Color.Red;
                    break;
                default:
                    break;
            }
            
        }
        public void SetProcess(float p)
        {
            if(p>0&&p<1)
                this.gradientLine1.HighlightTransitionPercent = p;
        }
    }
    public class LoadingItem
    {
        public PictureBox Image { get; set; }
        public Guid ID { get; set; }
        public Label Name { get; set; }
        public int Index { get; set; }
    }
}
