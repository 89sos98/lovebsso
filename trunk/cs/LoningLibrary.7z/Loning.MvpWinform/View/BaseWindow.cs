﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Loning.MVP;
using Microsoft.Practices.Unity;
using WeifenLuo.WinFormsUI.Docking;

namespace Loning.MvpWinform.View
{
    public partial class BaseWindow : WeifenLuo.WinFormsUI.Docking.DockContent
    {
        [Dependency]
        public IMainView MainView { get; set; }
        public BaseWindow()
        {
            InitializeComponent();
        }
        public void Invoke(MethodInvoker del)
        {
            if (this.InvokeRequired)
            {
                this.Invoke((Delegate)del);
            }
            else
            {
                del.Invoke();
            }
        }
        public void BeginInvoke(MethodInvoker del)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke((Delegate)del);
            }
            else
            {
                del.Invoke();
            }
        }
    }
}
