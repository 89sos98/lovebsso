﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Loning.MvpWinform.View
{
    public partial class ToolBaseWindow : Loning.MvpWinform.View.BaseWindow
    {
        public ToolBaseWindow()
        {
            InitializeComponent();
            
        }
    }
}
