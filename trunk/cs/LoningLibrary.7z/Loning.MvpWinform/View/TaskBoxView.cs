﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Loning.MVP;
using Loning.Tasks;
using BrightIdeasSoftware;

namespace Loning.MvpWinform.View
{
    public interface ITaskBoxView : IView
    {
        void AddTask(string category, Task task);
    }
    public partial class TaskBoxView : ToolBaseWindow,ITaskBoxView
    {
        Dictionary<string, bool> categories;
        public TaskBoxView()
        {
            InitializeComponent();
            //this.listView1.ListViewItemSorter = new ListViewItemComparer();
            this.listView1.LastSortColumn = this.olvColumnInvokeTime;
            this.listView1.LastSortOrder = SortOrder.Ascending;
            hidelist = new List<TaskItem>();
            categories = new Dictionary<string, bool>();
            TypedObjectListView<TaskItem> tlist = new TypedObjectListView<TaskItem>(this.listView1);
            tlist.GenerateAspectGetters();

            taskState = TaskState.Failed | TaskState.Finished | TaskState.Running | TaskState.Unstarted ;
            
        }

        #region ITaskBoxView 成员
        
        public void AddTask(string category, Task task)
        {
            
            Invoke(delegate()
            {
                if (!categories.ContainsKey(category))
                {
                    categories.Add(category, true);
                    ToolStripButton button=new ToolStripButton();
                    button.CheckOnClick = true;
                    button.Checked = true;
                    button.Text = category;
                    button.CheckedChanged += delegate(object sender,EventArgs e)
                    {
                        Invoke(delegate()
                        {
                            ToolStripButton b = (ToolStripButton)sender;
                            categories[b.Text] = b.Checked;
                            updatelist();
                        });
                    };
                    
                    this.toolStripDropDownButtonCategory.DropDownItems.Add(button);
                }
                //list.Add(
                //    new TaskItem(task, category));
                TaskItem taskItem = new TaskItem(task, category);
                task.StateChanged += delegate(object sender, StateChangedEventArgs e)
                {
                    Invoke(delegate()
                    {
                        ChangeTaskItem(taskItem);
                    });
                };
                task.Canceled += delegate(object sender, EventArgs e)
                {
                    Invoke(delegate()
                    {
                        if (hidelist.Contains(taskItem))
                        {
                            System.Threading.Monitor.Enter(hidelist);
                            hidelist.Remove(taskItem);
                            System.Threading.Monitor.Exit(hidelist);
                        }
                        else
                        {
                            listView1.RemoveObject(taskItem);
                        }
                    });
                };
                ChangeTaskItem(taskItem);
            });
        }

        void ChangeTaskItem(TaskItem item)
        {
            if ((item.State & taskState) == item.State && categories[item.Category])
            {
                //应该显示到listView
                if (this.listView1.ModelToItem(item) == null)
                    this.listView1.AddObject(item);
                //else
                //    this.listView1.RefreshObject(item);
                if (this.hidelist.Contains(item))
                    this.hidelist.Remove(item);
            }
            else
            {
                if (this.listView1.ModelToItem(item) != null)
                    this.listView1.RemoveObject(item);
                if (!this.hidelist.Contains(item))
                    this.hidelist.Add(item);
            }
        }
        
        #endregion

        #region IView 成员

        public void Initialize()
        {
            this.listView1.Sort(
                this.olvColumnCategory,SortOrder.Ascending);
            this.toolStripButtonFinished.Checked = false;//设置为未按
            this.MainView.AddWindow(this);
            
            //throw new NotImplementedException();
        }

        #endregion
        TaskState taskState;
        List<TaskItem> hidelist;
        void updatelist()
        {
            System.Threading.Monitor.Enter(this.listView1);
            System.Threading.Monitor.Enter(this.hidelist);
            this.listView1.BeginUpdate();
            List<TaskItem> templist = new List<TaskItem>();
            if (listView1.Objects != null)
            {
                System.Collections.IEnumerator rator = listView1.Objects.GetEnumerator();
                while (rator.MoveNext())
                {
                    TaskItem item = (TaskItem)rator.Current;
                    if ((item.State & taskState) != item.State || !categories[item.Category])
                    {
                        //不应该显示
                        //this.listView1.RemoveObject(item);
                        templist.Add(item);
                        this.hidelist.Add(item);
                    }
                }
                this.listView1.RemoveObjects(templist);
                templist.Clear();
            }
            List<TaskItem>.Enumerator r = hidelist.GetEnumerator();
            while (r.MoveNext())
            {
                TaskItem item = (TaskItem)r.Current;
                if ((item.State & taskState) == item.State && categories[item.Category])
                {
                    //应该显示
                    //this.listView1.AddObject(item);
                    templist.Add(item);
                    //this.hidelist.Remove(item);
                }
            }
            this.listView1.AddObjects(templist);
            this.listView1.EndUpdate();
            foreach (TaskItem toRemoveItem in templist)
            {
                this.hidelist.Remove(toRemoveItem);
            }
            System.Threading.Monitor.Exit(this.hidelist);
            System.Threading.Monitor.Exit(this.listView1);
        }
        
        private void toolStripButtonFinished_Click(object sender, EventArgs e)
        {
            //if(taskState  TaskState.Finished)
            if (toolStripButtonFinished.Checked)
                taskState = taskState | TaskState.Finished;
            else
                taskState = taskState ^ TaskState.Finished;
            updatelist();
        }

        private void toolStripButtonFailed_Click(object sender, EventArgs e)
        {
            if (toolStripButtonFailed.Checked)
                taskState = taskState | TaskState.Failed;
            else
                taskState = taskState ^ TaskState.Failed;
            updatelist();
        }

        private void toolStripButtonUnstarted_Click(object sender, EventArgs e)
        {
            if (toolStripButtonUnstarted.Checked)
                taskState = taskState | TaskState.Unstarted;
            else
                taskState = taskState ^ TaskState.Unstarted;
            updatelist();
        }

        private void toolStripButtonRunning_Click(object sender, EventArgs e)
        {
            if (toolStripButtonRunning.Checked)
                taskState = taskState | TaskState.Running;
            else
                taskState = taskState ^ TaskState.Running;
            updatelist();
        }
    }
    public class TaskItem
    {
        Task task;
        public string Category { get; private set; }
        public TaskItem(Task task,string category)
        {
            this.task = task;
            this.Category = category;
        }
        public string Name
        {
            get
            {
                return task.Name;
            }
        }
        public DateTime InvokeTime
        {
            get
            {
                return task.InvokeTime;
            }
        }
        public TaskState State
        {
            get
            {
                return task.State;
            }
        }
    }

    
}
