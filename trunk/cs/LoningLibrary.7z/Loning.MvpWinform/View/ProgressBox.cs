﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Loning.MVP;

namespace Loning.MvpWinform.View
{
    
    public interface IProgressBox : IView
    {
        IProgressItem GetProgressItem(KeyValuePair<Type,string> key);

        void RemoveItem(KeyValuePair<Type, string> keyValuePair);
    }
    public partial class ProgressBox : Loning.MvpWinform.View.ToolBaseWindow ,IProgressBox
    {
        IDictionary<
            KeyValuePair<Type, string>,
            IProgressItem>
            dic;
        public ProgressBox()
        {
            InitializeComponent();
        }

        #region IView 成员

        public void Initialize()
        {
            dic = new Dictionary<
            KeyValuePair<Type, string>,
            IProgressItem>();

            MainView.AddWindow(this);
        }

        #endregion

        #region IProgressBox 成员
        //int ProgressCount = 0;
        public IProgressItem CreateProgress(KeyValuePair<Type, string> key)
        {
            ProgressItem progressItem1=null;
            Invoke(delegate()
            {
                //ProgressCount++;
                progressItem1 = new ProgressItem();
                progressItem1.Dock = System.Windows.Forms.DockStyle.Top;
                progressItem1.Location = new System.Drawing.Point(0, 0);
                progressItem1.Name = key.Key.ToString() + key.Value;
                //progressItem1.Size = new System.Drawing.Size(150, 75);
                progressItem1.Padding = new Padding(0, 2, 0, 2);
                
                this.Controls.Add(progressItem1);
            });
            return progressItem1;
        }
        #endregion

        #region IProgressBox 成员



        public IProgressItem GetProgressItem(KeyValuePair<Type, string> key)
        {
            
            if (dic.ContainsKey(key))
            {
                return dic[key];
            }
            else
            {
                IProgressItem item = CreateProgress(key);
                dic.Add(key, item);
                return item;
            }
        }

        #endregion

        #region IProgressBox 成员


        public void RemoveItem(KeyValuePair<Type, string> keyValuePair)
        {
            if (dic.ContainsKey(keyValuePair))
            {
                
                if (!InvokeRequired)
                {
                    this.Controls.Remove((Control)dic[keyValuePair]);
                    dic.Remove(keyValuePair);
                }
                else
                {
                    this.Invoke(new MethodInvoker(delegate()
                    {
                        this.Controls.Remove((Control)dic[keyValuePair]);
                        dic.Remove(keyValuePair);
                    }));
                }
            }
        }

        #endregion
    }
}
