﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using Microsoft.Practices.Unity;
using System.Threading;

namespace Loning.MvpWinform
{
    public class Runner
    {
        [Dependency]
        public IUnityContainer UnityContainer { get; set; }
        ApplicationContext _Context;
        public Form LoadingForm { get; private set; }
        public ThreadStart Invoker { get; set; }
        public void Run()
        {
            LoadingForm = UnityContainer.Resolve<Loning.MvpWinform.View.LoadingForm>();
#if DEBUG
#else
            LoadingForm.Show();
#endif
            
            _Context = new ApplicationContext();
            Application.Idle += new EventHandler(Application_Idle);
            Application.Run(_Context);
        }
        private void Application_Idle(object sender, EventArgs e)
        {
            if (_Context.MainForm == null)
            {
                Application.Idle -= new EventHandler(Application_Idle);
                try
                {
                    if (Invoker != null)
                        Invoker();
                    _Context.MainForm = (Form) UnityContainer.Resolve<Loning.MvpWinform.View.IMainView>();
                    System.Windows.Forms.Application.DoEvents();
                    _Context.MainForm.Show();
                    System.Windows.Forms.Application.DoEvents();

                    LoadingForm.Close();
                    LoadingForm.Dispose();
                }
                catch (Exception ex)
                {
                    //File.AppendAllText("Error.log", ex.ToString() + Environment.NewLine);
                    throw ex;
                }
                //_Context.MainForm.Show();
                //System.Windows.Forms.Application.DoEvents();
            }
        }
    }
}
