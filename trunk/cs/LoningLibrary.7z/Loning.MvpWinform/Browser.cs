﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Loning.MVP;
using System.Threading;

namespace Loning.MvpWinform
{
    public interface IBrowserView : IView
    {
        string HomePage { get; set; }
        void Navigate(string url,string headers, params string[] data);
        void Navigate(string url);
        void Navigate(string urlString, string targetFrameName, byte[] postData, string additionalHeaders);
    }
    public interface IBrowserModel : IModel
    {
        void Navigate(string url);
    }
    public partial class Browser : Loning.MvpWinform.View.BaseWindow,IBrowserView,IBrowserModel
    {
        public Browser()
        {
            InitializeComponent();
            
        }
        public void Navigate(string url,string headers,params string[] data)
        {
            StringBuilder sb = new StringBuilder(data.Length * 20);

            for (int i = 0; i < data.Length; i += 2)
            {
                sb.AppendFormat("{0}={1}&",
                    Uri.EscapeDataString(data[i]),
                    Uri.EscapeDataString(data[i + 1]));
            }
            if (sb.Length > 0)
                sb.Remove(sb.Length - 1, 1);
            string str = sb.ToString();
            var bytes=Encoding.UTF8.GetBytes(str);
            Invoke(delegate()
            {
                if (string.IsNullOrEmpty(headers))
                    headers = "Content-Type: application/x-www-form-urlencoded";
                else
                    headers += Environment.NewLine + "Content-Type: application/x-www-form-urlencoded";
                this.webBrowser1.Navigate(url,null,bytes,headers);
                //this.webBrowser1.
            });
        }
        public void Navigate(string url)
        {
            Invoke(delegate()
            {
                this.webBrowser1.Navigate(url);
            });
        }
        public void Navigate(string urlString, string targetFrameName, byte[] postData, string additionalHeaders)
        {
            Invoke(delegate()
            {
                this.webBrowser1.Navigate(urlString,targetFrameName,postData,additionalHeaders);
            });
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.webBrowser1.Navigate(this.toolStripComboBox1.Text);
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            this.Text = webBrowser1.Document.Title;
        }

        #region IView 成员

        public void Initialize()
        {
            
            MainView.AddWindow(this);
        }

        #endregion



        #region IModel Members


        public event EventHandler Initialized;

        #endregion

        private void webBrowser1_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            this.toolStripComboBox1.Text = e.Url.ToString();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            this.webBrowser1.GoBack();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            this.webBrowser1.GoForward();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            this.webBrowser1.Refresh();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            if (HomePage == null)
                this.webBrowser1.GoHome();
            else
                this.webBrowser1.Navigate(HomePage);
        }


        #region IBrowserView Members

        public string HomePage
        {
            get;
            set;
        }

        #endregion

        private void toolStripComboBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                this.Navigate(this.toolStripComboBox1.Text);
        }
    }
}
