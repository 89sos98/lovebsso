﻿using System;
using System.Collections.Generic;
using System.Text;
using Loning.MVP;

namespace Loning.MvpWinform.Model
{
    public class ProgressItem
    {
        

        private string title;
        public string Title
        {
            get
            {
                return title;
            }
            set
            {
                title = value;
                OnChanged();
            }
        }
        private string message;
        public string Message
        {
            get
            {
                return message;
            }
            set
            {
                message = value;
                OnChanged();
            }
        }
        private int value;
        public int Value
        {
            get
            {
                
                return this.value;
            }
            set
            {
                if (value > 100 || value < 0)
                    return;
                this.value = value;
                OnChanged();
            }
        }
        public KeyValuePair<Type, string> Key { get; set; }
        protected virtual void OnChanged()
        {
            if (Changed != null)
                Changed(this, EventArgs.Empty);
        }
        public void StopRequest()
        {
            if (StopRequested != null)
                StopRequested(this, EventArgs.Empty);
        }
        public event EventHandler StopRequested;
        public event EventHandler Changed;
        public override string ToString()
        {
            return this.title;
        }
    }
    public interface IProgressBox : IModel
    {
        ProgressItem GetProgressItem(KeyValuePair<Type, string> key);
        ProgressItem GetProgressItem(Type type, string key);
        ProgressItem GetProgressItem<T>(string key);
        void RemoveProgressItem(KeyValuePair<Type, string> key);
        void RemoveProgressItem<T>(string key);
        /// <summary>
        /// 项目移除
        /// </summary>
        event EventHandler<EventArgs<KeyValuePair<Type, string>>> ItemRemoved;
        event EventHandler<EventArgs<ProgressItem>> ItemCreated;
    }
    public class ProgressBox:IProgressBox
    {
        Dictionary<KeyValuePair<Type, string>,ProgressItem> dic;
        #region IModel 成员

        public void Initialize()
        {
            dic = new Dictionary<KeyValuePair<Type, string>, ProgressItem>();
            if (Initialized != null)
                Initialized(this, EventArgs.Empty);
        }

        public event EventHandler Initialized;


        public ProgressItem GetProgressItem(KeyValuePair<Type, string> key)
        {
            ProgressItem item;
            if (!dic.ContainsKey(key))
            {
                item = new ProgressItem();
                item.Key = key;
                dic.Add(key, item);
                if (ItemCreated != null)
                    ItemCreated(this, new EventArgs<ProgressItem>() { Data = item });
            }
            else
            {
                item = dic[key];
            }
            return item;
            //throw new NotImplementedException();
        }


        public void RemoveProgressItem(KeyValuePair<Type, string> key)
        {
            if (dic.Remove(key))
                if (ItemRemoved != null)
                    ItemRemoved(this, new EventArgs<KeyValuePair<Type, string>>()
                    {
                        Data = key
                    });
            //throw new NotImplementedException();
        }


        public event EventHandler<EventArgs<KeyValuePair<Type, string>>> ItemRemoved;



        public event EventHandler<EventArgs<ProgressItem>> ItemCreated;



        public ProgressItem GetProgressItem(Type type, string key)
        {
            return GetProgressItem(
                new KeyValuePair<Type, string>(type, key));
        }

        public ProgressItem GetProgressItem<T>(string key)
        {
            return GetProgressItem(typeof(T), key);
        }


        public void RemoveProgressItem<T>(string key)
        {
            RemoveProgressItem(
                new KeyValuePair<Type,string>(typeof(T),key));
        }

        #endregion
    }
}
