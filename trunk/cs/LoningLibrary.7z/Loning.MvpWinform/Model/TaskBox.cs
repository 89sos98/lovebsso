﻿using System;
using System.Collections.Generic;
using System.Text;
using Loning.MVP;
using Loning.Tasks;

namespace Loning.MvpWinform.Model
{
    public interface ITaskBox : IModel
    {
        /// <summary>
        /// 获取一个计划任务列表
        /// 不存在则创建
        /// </summary>
        /// <param name="category"></param>
        /// <returns></returns>
        TaskSheduler GetTaskSheduler(string category);
        /// <summary>
        /// 添加一个已经存在的计划任务列表
        /// </summary>
        /// <param name="category"></param>
        /// <param name="taskSheduler"></param>
        void AddTaskSheduler(string category, TaskSheduler taskSheduler);
        //event EventHandler<EventArgs<string,Task>>
        /// <summary>
        /// 任务添加到列表
        /// </summary>
        event EventHandler<EventArgs<string, Task>> TaskAdded;
        /// <summary>
        /// 任务调入线程池准备运行(时间已到)
        /// </summary>
        event EventHandler<EventArgs<Task>> TaskStarted;
        /// <summary>
        /// 任务正式开始运行
        /// </summary>
        event EventHandler<EventArgs<Task>> TaskInvoked;
        /// <summary>
        /// 任务结束
        /// </summary>
        event EventHandler<EventArgs<Task>> TaskFinished;

        event EventHandler<EventArgs<Task>> TaskCanceled;
        /// <summary>
        /// 任务失败
        /// </summary>
        event EventHandler<EventArgs<Task,Exception>> TaskFailed;
    }
    public class TaskBox : ITaskBox
    {
        IDictionary<string, TaskSheduler> dictionary;
        public TaskBox()
        {
            dictionary = new Dictionary<string, TaskSheduler>();
        }
        #region ITaskBoxModel 成员

        public TaskSheduler GetTaskSheduler(string category)
        {
            if (dictionary.ContainsKey(category))
                return dictionary[category];
            else
            {
                TaskSheduler ts = new TaskSheduler();
                AddTaskSheduler(category, ts);
                return ts;
            }
            //throw new NotImplementedException();
        }

        public void AddTaskSheduler(string category, TaskSheduler taskSheduler)
        {
            taskSheduler.TaskAdded += delegate(object sender, TaskEventArgs e)
            {
                if (TaskAdded != null)
                    TaskAdded(this, 
                        new EventArgs<string, Task>() { Data1 = category, Data2 = e.Task });
            };
            taskSheduler.TaskCanceled += new EventHandler<TaskEventArgs>(taskSheduler_TaskCanceled);
            taskSheduler.TaskInvoking += delegate(object sender, TaskEventArgs e)
            {
                e.Task.Invoked += new EventHandler(Task_Invoked);
                e.Task.Started += new EventHandler(Task_Started);
                e.Task.Finished += new EventHandler(Task_Finished);
                e.Task.Failed += new EventHandler<FailureEventArgs>(Task_Failed);
            };
            
            //throw new NotImplementedException();
        }

        void taskSheduler_TaskCanceled(object sender, TaskEventArgs e)
        {
            if (TaskCanceled != null)
                TaskCanceled(this,
                    new EventArgs<Task>() { Data = e.Task });
            //throw new NotImplementedException();
        }

        void Task_Failed(object sender, FailureEventArgs e)
        {
            if (TaskFailed != null)
                TaskFailed(this, new EventArgs<Task, Exception>() { Data1 = (Task)sender, Data2 = e.Exception });
            //throw new NotImplementedException();

        }

        void Task_Finished(object sender, EventArgs e)
        {
            if (TaskFinished != null)
                TaskFinished(this,
                    new EventArgs<Task>() { Data = (Task)sender });
            //throw new NotImplementedException();
        }

        void Task_Started(object sender, EventArgs e)
        {
            if (TaskStarted != null)
                TaskStarted(this,
                    new EventArgs<Task>() { Data = (Task)sender });
            //throw new NotImplementedException();
        }

        void Task_Invoked(object sender, EventArgs e)
        {
            if (TaskInvoked != null)
                TaskInvoked(this,
                    new EventArgs<Task>() { Data = (Task)sender });
            //throw new NotImplementedException();
        }

        #endregion

        #region IModel 成员

        public void Initialize()
        {
            //throw new NotImplementedException();
            if (Initialized != null)
                Initialized(this, EventArgs.Empty);
        }

        public event EventHandler Initialized;

        #endregion


        #region ITaskBoxModel 成员


        public event EventHandler<EventArgs<string, Task>> TaskAdded;

        public event EventHandler<EventArgs<Task>> TaskStarted;

        public event EventHandler<EventArgs<Task>> TaskInvoked;

        public event EventHandler<EventArgs<Task>> TaskFinished;

        public event EventHandler<EventArgs<Task, Exception>> TaskFailed;

        #endregion

        #region ITaskBox 成员


        public event EventHandler<EventArgs<Task>> TaskCanceled;

        #endregion
    }
}
