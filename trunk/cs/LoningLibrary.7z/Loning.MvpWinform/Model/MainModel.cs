﻿using System;
using System.Collections.Generic;
using System.Text;
using Loning.MVP;
using Microsoft.Practices.Unity;
namespace Loning.MvpWinform.Model
{
    public interface IMainModel : IModel
    {
    }
    public interface IAdvancedMainModel : IMainModel
    {
        /// <summary>
        /// Add sub presenter
        /// </summary>
        /// <param name="presenter"></param>
        void AddPresenter(IPresenter presenter);
        void AddPresenter<P>() where P:IPresenter;
        void AddRegisteredPresenters();
        void SetUnityContainer(IUnityContainer uc);
        void RegisterMvp<IM, M, IV, V, P>()
            where P : IPresenter
            where IM : IModel
            where M : IM, new()
            where IV : IView
            where V : IV, new();
        void RegisterMvp<M,V,P>()
            where P : IPresenter
            where M : IModel, new()
            where V : IView, new();
        void RegisterMvp<V>()
            where V : IView,IModel, new();
        /// <summary>
        /// Load Presenters and theri model and view.
        /// </summary>
        void LoadPresenters();

        event EventHandler<EventArgs<IPresenter,PresenterLoadingState>> PresenterLoadingStateChanged;
        event EventHandler PresentersLoaded;
        IList<IPresenter> Presenters{get;}
    }
    public enum PresenterLoadingState
    {
        Unstarted,
        Loading,
        Loaded,
        Failed
    }
    public class AdvancedMainModel : IAdvancedMainModel
    {
        #region IAdvancedMainModel 成员
        public IList<IPresenter> Presenters { get; private set; }
        protected IUnityContainer UnityContainer { get; private set; }
        private Queue<Type> presToLoad;
        public void AddPresenter(IPresenter presenter)
        {
            this.Presenters.Add(presenter);
            
            //throw new NotImplementedException();
        }

        public void LoadPresenters()
        {
            foreach (IPresenter p in Presenters)
            {
                try
                {
                    if (PresenterLoadingStateChanged != null)
                        PresenterLoadingStateChanged(this, new EventArgs<IPresenter, PresenterLoadingState> { Data1 = p, Data2 = PresenterLoadingState.Loading });
                    p.Initialize();
                    if (PresenterLoadingStateChanged != null)
                        PresenterLoadingStateChanged(this, new EventArgs<IPresenter, PresenterLoadingState> { Data1 = p, Data2 = PresenterLoadingState.Loaded });
                }
                catch(Exception ex)
                {
                    
                    if (PresenterLoadingStateChanged != null)
                        PresenterLoadingStateChanged(this, new EventArgs<IPresenter, PresenterLoadingState> { Data1 = p,Data2=PresenterLoadingState.Failed });
                    
                }
            }
            if (PresentersLoaded != null)
                PresentersLoaded(this, EventArgs.Empty);
            //throw new NotImplementedException();
        }

        public event EventHandler PresentersLoaded;
        public event EventHandler<EventArgs<IPresenter, PresenterLoadingState>> PresenterLoadingStateChanged;

        public void Initialize()
        {
            Presenters = new List<IPresenter>();
            presToLoad = new Queue<Type>();
            //throw new NotImplementedException();
            if (Initialized != null)
                Initialized(this, EventArgs.Empty);
        }

        public event EventHandler Initialized;

        public void AddPresenter<P>() where P : IPresenter
        {
            AddPresenter(this.UnityContainer.Resolve<P>());
            //throw new NotImplementedException();
        }

        [InjectionMethod]
        public void SetUnityContainer(IUnityContainer uc)
        {
            this.UnityContainer = uc;
            //throw new NotImplementedException();
        }

        public void RegisterMvp<IM, M, IV, V, P>()
            where IM : IModel
            where M : IM, new()
            where IV : IView
            where V : IV, new()
            where P : IPresenter
        {
            UnityContainer.RegisterType<IV, V>
                (new ContainerControlledLifetimeManager());
            UnityContainer.RegisterType<IM, M>
                (new ContainerControlledLifetimeManager());
            UnityContainer.RegisterType<P>
                (new ContainerControlledLifetimeManager());
            presToLoad.Enqueue(typeof(P));
            //throw new NotImplementedException();
        }

        public void AddRegisteredPresenters()
        {
            while(presToLoad.Count>0)
            {
                AddPresenter((IPresenter)UnityContainer.Resolve(presToLoad.Dequeue()));
            }
            //throw new NotImplementedException();
        }

        public void RegisterMvp<M, V, P>()
            where M : IModel, new()
            where V : IView, new()
            where P : IPresenter
        {
            UnityContainer.RegisterType<V>
                (new ContainerControlledLifetimeManager());
            UnityContainer.RegisterType<M>
                (new ContainerControlledLifetimeManager());
            UnityContainer.RegisterType<P>
                (new ContainerControlledLifetimeManager());
            presToLoad.Enqueue(typeof(P));
        }

        public void RegisterMvp<V>() where V : IView,IModel, new()
        {
            RegisterMvp<V, V, V, V, SimplePresenter<V, V>>();
        }

        #endregion
    }
    public class NoneModel:IModel{
        #region IModel Members

        public void Initialize()
        {
            if (Initialized != null)
                Initialized(this,EventArgs.Empty);
            //throw new NotImplementedException();
        }

        public event EventHandler Initialized;

        #endregion
    }
    public class MainModel:IMainModel
    {
        #region IModel 成员

        public void Initialize()
        {
            if (Initialized != null)
                Initialized(this, EventArgs.Empty);
        }

        public event EventHandler Initialized;

        #endregion
    }
}
