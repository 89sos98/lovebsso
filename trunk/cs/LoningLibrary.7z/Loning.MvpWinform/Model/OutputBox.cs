﻿using System;
using System.Collections.Generic;
using System.Text;
using Loning.MVP;

namespace Loning.MvpWinform.Model
{
    
    public interface IOutputBox : IModel
    {
        void AppendLine(string name, string value);
        void AppendLine(string name, string value, bool show);
        event EventHandler<EventArgs<KeyValuePair<string,string>>> TextUpdated;
        event EventHandler<EventArgs<string>> SourceAdded;
        event EventHandler<EventArgs<string>> SourceSelected;
        void SelectSource(string name);
        void AppendLine(string name, string value, params object[] objs);
        void AppendLine(string name, bool show, string value, params object[] objs);

        void AppendLine(Exception ex);
        void AppendLine(string name, Exception ex);
    }
    public class OutputBox:IOutputBox
    {
        IDictionary<string, string> dic = new Dictionary<string, string>();
        #region IModel 成员

        public void Initialize()
        {
            if (Initialized != null)
                Initialized(this, EventArgs.Empty);
        }

        public event EventHandler Initialized;

        #endregion

        void OnSourceSelected(string source)
        {
            if (SourceSelected != null)
                SourceSelected(this, new EventArgs<string> { Data = source });
        }

        #region IOutputBox 成员
        public void AppendLine(string name, string value)
        {
            AppendLine(name, value, false);
        }
        public void AppendLine(string name, string value,bool show)
        {
            
            if (!dic.ContainsKey(name))
            {
                dic.Add(name, string.Empty);
                if (SourceAdded != null)
                    SourceAdded(this, new EventArgs<string> { Data = name });
                if (dic.Count == 1)
                    OnSourceSelected(name);
            }
            if (dic[name].Length > 20000)
                dic[name] = string.Empty;
            string str = dic[name] += value + Environment.NewLine;

            if (show)
                OnSourceSelected(name);
            if(TextUpdated!=null)
                TextUpdated(this, new EventArgs<KeyValuePair<string, string>> { Data = new KeyValuePair<string, string>(name, str) });

        }

        public event EventHandler<EventArgs<KeyValuePair<string, string>>> TextUpdated;

        #endregion

        #region IOutputBox 成员


        public event EventHandler<EventArgs<string>> SourceAdded;

        #endregion

        #region IOutputBox 成员


        public event EventHandler<EventArgs<string>> SourceSelected;

        #endregion

        #region IOutputBox 成员


        public void SelectSource(string name)
        {
            if (dic.ContainsKey(name))
            {
                OnSourceSelected(name);
                if (TextUpdated != null)
                    TextUpdated(this, new EventArgs<KeyValuePair<string, string>> { Data = new KeyValuePair<string, string>(name, dic[name]) });
            }
        }

        #endregion

        #region IOutputBox 成员


        public void AppendLine(string name, string value, params object[] objs)
        {
            AppendLine(name, string.Format(value, objs));
        }

        public void AppendLine(string name, bool show, string value, params object[] objs)
        {
            AppendLine(name, string.Format(value, objs), show);
        }

        #endregion

        #region IOutputBox 成员


        public void AppendLine(Exception ex)
        {
            AppendLine("系统", ex);
        }

        public void AppendLine(string p, Exception ex)
        {
            AppendLine(p, ex.Message);
            //throw new NotImplementedException();
        }

        #endregion
    }
}
