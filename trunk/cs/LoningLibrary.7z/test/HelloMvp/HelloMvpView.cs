﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Loning.MVP;
using System.Threading;

namespace HelloMvp
{
    public interface IHelloMvpView : IView
    {
        void SetNumber(int number);
        event EventHandler ChangeNumberRequested;
    }
    public partial class HelloMvpView : Form,IHelloMvpView
    {
        public HelloMvpView()
        {
            InitializeComponent();
        }

        public void SetNumber(int number)
        {
            Invoke((MethodInvoker)delegate()
            {
                this.Text = number.ToString();
            });
            //throw new NotImplementedException();
        }

        public void Initialize()
        {
            
            //throw new NotImplementedException();
        }


        public event EventHandler ChangeNumberRequested;

        private void button1_Click(object sender, EventArgs e)
        {
            if (ChangeNumberRequested != null)
                ChangeNumberRequested(this, EventArgs.Empty);
        }
    }
}
