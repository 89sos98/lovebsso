﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Loning.MVP;
namespace HelloMvp
{
    class HelloMvpPresenter:Presenter<IHelloMvpView,IHelloMvpModel>
    {
        protected override void BindModelEvents()
        {
            //throw new NotImplementedException();
            Model.NumberChanged += new EventHandler(Model_NumberChanged);
        }

        void Model_NumberChanged(object sender, EventArgs e)
        {
            View.SetNumber(Model.GetNumber);
            //throw new NotImplementedException();
        }

        protected override void RemoveModelEvents()
        {
            Model.NumberChanged -= new EventHandler(Model_NumberChanged);
            //throw new NotImplementedException();
        }

        protected override void ModelInitialized(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }
        public override void Initialize()
        {
            View.ChangeNumberRequested += new EventHandler(View_ChangeNumberRequested);
            base.Initialize();
        }

        void View_ChangeNumberRequested(object sender, EventArgs e)
        {
            Model.Plus();
            //throw new NotImplementedException();
        }
    }
}
