﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Loning.MVP;

namespace HelloMvp
{
    public interface IHelloMvpModel : IModel
    {
        void Plus();
        int GetNumber { get; }
        event EventHandler NumberChanged;
    }
    public class HelloMvpModel : IHelloMvpModel
    {
        private int _Number;
        public void Plus()
        {
            ++_Number;
            if (NumberChanged != null)
                NumberChanged(this, EventArgs.Empty);
        }

        public int GetNumber
        {
            get { return _Number; }
        }

        public void Initialize()
        {
            if (Initialized != null)
                Initialized(this, EventArgs.Empty);
        }

        public event EventHandler Initialized;


        public event EventHandler NumberChanged;
    }

}
