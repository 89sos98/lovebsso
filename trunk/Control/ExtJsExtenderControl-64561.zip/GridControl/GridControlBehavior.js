// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.


// README
//
// There are three steps to adding a property:
//
// 1. Create a member variable to store your property
// 2. Add the property to the type descriptor for this class
// 3. Add the get_ and set_ accessors for your property.
//
// Remember that all three are case sensitive!
//
Type.registerNamespace('ExtExtenders');
ExtExtenders.DataType= function() {
  throw Error.invalidOperation();
}
ExtExtenders.DataType.prototype={   
        /// <summary>
        /// The column being edited is a standart Text (default)
        /// </summary>
        Text:0,
        /// <summary>
        /// The colum being edited has only numbers
        /// </summary>
        Numeric:1,
        /// <summary>
        /// The column being edited is a date
        /// </summary>
        Date: 2,
        /// <summary>
        /// Use a text area to edit the value
        /// </summary>
        MultiLine:3
       
}
ExtExtenders.DataType.registerEnum("ExtExtenders.DataType", false);

ExtExtenders.GridEventArgs = function() {
   
    ExtExtenders.GridEventArgs.initializeBase(this);

}

ExtExtenders.GridEventArgs.prototype = {
  
    serialise : function(eventName,arguments){
    /// <summary>
    /// Method used to prepare an event to be fired
    /// </summary>
    /// <param name="eventName" type="string">
    /// Name of the event to be fired
    /// </param>
    /// <param name="arguments" type="object">
    /// Object containing the parameters to be passed
    /// </param>
        return Sys.Serialization.JavaScriptSerializer.serialize(
                {
                    EventName: eventName,
                    Arguments: Sys.Serialization.JavaScriptSerializer.serialize
                        (arguments)
                });
    } 
}

ExtExtenders.GridEventArgs.registerClass('ExtExtenders.GridEventArgs', Sys.EventArgs);

ExtExtenders.PagingStyle = function() {
  
    throw Error.invalidOperation();
}
ExtExtenders.PagingStyle.prototype = {
    NumberPaging:0,
    NavBar:1
}
ExtExtenders.PagingStyle.registerEnum("ExtExtenders.PagingStyle", false);
ExtExtenders.GridControlBehavior = function(element) {
    ExtExtenders.GridControlBehavior.initializeBase(this, [element]);



    this.initialize = function() {
        ExtExtenders.GridControlBehavior.callBaseMethod(this, 'initialize');
        this._initGrid();
    }

    this.dispose = function() {

        // TODO: add your cleanup code here
        ExtExtenders.GridControlBehavior.callBaseMethod(this, 'dispose');
    }



    // TODO: (Step 3) Add your property accessors here.
    //

    // EnableBufferData
    this.get_EnableBufferData = function() {
        return this._EnableBufferData;
    }
    this.set_EnableBufferData = function(value) {
        this._EnableBufferData = value;
    }
    this.get_ProcessingPage = function() {
        return this._ProcessingPage;
    }

    this.set_ProcessingPage = function(value) {
        this._ProcessingPage = value;
    }

    this.get_Columns = function() {
        return this._Columns;
    }
    this.set_Columns = function(value) {
        this._Columns = value;
    }
    this.get_GridControlId = function() {
        if (this._GridControlId == null)
            this._GridControlId = this.get_element().id;
        return this._GridControlId;
    }

    this.set_GridControlId = function(value) {
        this._GridControlId = value;
    }
    //tagname
    this.get_TagName = function() {
        return this._TagName;
    }

    this.set_TagName = function(value) {
        this._TagName = value;
    }
    //totaltag
    this.get_totalTag = function() {
        return this._totalTag;
    }

    this.set_totalTag = function(value) {
        this._totalTag = value;
    }

    //Id
    this.get_IdRecord = function() {
        return this._IdRecord;
    }

    this.set_IdRecord = function(value) {
        this._IdRecord = value;
    }
    //Fields
    this.get_Fields = function() {
        return this._Fields;
    }

    this.set_Fields = function(value) {
        this._Fields = value;
    }
    //DataGrid
    this.get_Grid = function() {
        return this.DataGrid;
    }
    //

    //EnableRowSorting
    this.get_EnableRowSorting = function() {
        return this._EnableRowSorting;
    }

    this.set_EnableRowSorting = function(value) {
        this._EnableRowSorting = value;
    }
    //PageSize
    this.get_PageSize = function() {
        if (this._PageSize == null || this._PageSize <= 0)
            this._PageSize = 10;
        return this._PageSize;
    }

    this.set_PageSize = function(value) {
        this._PageSize = value;
    }
    //EnablePaging
    this.get_EnablePaging = function() {
        return this._EnablePaging;
    }

    this.set_EnablePaging = function(value) {
        this._EnablePaging = value;
    }
    //SelectMultiple
    this.get_SelectMultiple = function() {
        return this._SelectMultiple;
    }

    this.set_SelectMultiple = function(value) {
        this._SelectMultiple = value;
    }

    //CheckboxSelection
    this.get_CheckboxSelection = function() {
        return this._CheckboxSelection;
    }

    this.set_CheckboxSelection = function(value) {
        this._CheckboxSelection = value;
    }
    //WebServiceMethod
    this.get_WebServiceMethod = function() {
        return this._WebServiceMethod;
    }

    this.set_WebServiceMethod = function(value) {
        this._WebServiceMethod = value;
    }
    //WebServicePath
    this.get_WebServicePath = function() {
        return this._WebServicePath;
    }

    this.set_WebServicePath = function(value) {
        this._WebServicePath = value;
    }
    //PagingStyle
    this.get_PagingStyle = function() {

        return this._PagingStyle;
    }
    this.set_PagingStyle = function(value) {

        if (this._PagingStyle != value) {
            this._PagingStyle = value;

        }
    }
    this.get_AutoPostBack = function() {
        return this._AutoPostBack;
    }
    this.set_AutoPostBack = function(value) {
        this._AutoPostBack = value;
    }
    this.get_title = function() {
        return this._ConfigOptions.title;
    }
    this.set_title = function(value) {
        this._ConfigOptions.title = value;
    }
    this.get_JsonData = function() {
        return this._JsonData;
    }
    this.set_JsonData = function(value) {
        this._JsonData = value;
    }
    this.get_Data = function() {
       
        var data = this.get_JsonData();
        if (typeof (data) == "string")
            return Sys.Serialization.JavaScriptSerializer.deserialize(data);
        else
            return data;
    }
    this.set_GroupingField = function(value) {
        this._GroupingField = value;
    }
    this.get_GroupingField = function() {
        return this._GroupingField;
    }
    this.get_UniqueID = function() {
        return this._UniqueID;
    }
    this.set_UniqueID = function(value) {
        this._UniqueID = value;
    }
    this.get_TopToolBar = function() {
        return this._TopToolBar;
    }
    this.set_TopToolBar = function(value) {
        this._TopToolBar = value;
    }
    this.get_EnableEdit = function() {
        return this._EnableEdit;
    }
    this.set_EnableEdit = function(value) {
        this._EnableEdit = value;
    }
    this.get_EnableDragDrop = function() {
        return this._ConfigOptions.enableDragDrop;
    }
    this.get_GridEvents = function() {
        return this._GridEvents;
    }
    this.set_GridEvents = function(value) {
        this._GridEvents = value;
    }
    this.get_stripeRows = function() {
        return this._ConfigOptions.stripeRows;
    }
    this.set_stripeRows = function(value) {
        this._ConfigOptions.stripeRows = value;
    }
    this.get_ConfigOptions = function() {
        return this._ConfigOptions;
    }
    this.set_ConfigOptions = function(value) {
        this._ConfigOptions = value;
    }
    this.get_ViewOptions = function() {
        return this._ViewOptions;
    }
    this.set_ViewOptions = function(value) {
        this._ViewOptions = value;
    }
    this.get_RowContextMenu = function() {
        return this._RowContextMenu;
    }
    this.set_RowContextMenu = function(value) {
        this._RowContextMenu = value;
    }
    this.HasEvent = function(eventName) {

        if (this._ev == null) {
            this._ev = eval(this.get_GridEvents());
        }

        return this._ev.HasElement(eventName);
    }

    this.get_NewRecord = function(data) {
        var fields = this.get_FieldsArray();
        if (!data) {
            data = {};
            var len = fields.length;
            for (var i = 0; i < len; i++) {
                data[fields[i]] = "";
            }
        }
        var recordCreator = Ext.data.Record.create(fields);
        return new recordCreator(data);
    }

    this.get_FieldsArray = function() {

        var fields = this.get_Fields();

        if (fields == null || fields == "")
            return new Array();
        else
            return fields.split(',');
    }

    /////////////////////////
    // Internal Factory Methods
    // - Don Isbell
    ////////////////////////

    //////////////////
    // View Factory
    this.create_View = function() {
        var config = this.get_ViewOptions();
        config.forceFit = true;
        if (typeof (config.enableRowBody) == 'undefined')
            config.enableRowBody = true;
        if (typeof (config.showPreview) == 'undefined')
            config.showPreview = true;

        if (this.get_EnableBufferData()) {
            return new Ext.ux.grid.BufferedGridView({
                nearLimit: Math.ceil(this._PageSize / 2),
                loadMask: { msg: 'Please wait...' }
            });
        }
        else if (this.get_GroupingField() != null && this.get_GroupingField() != "") {
            config.groupTextTpl = '{text} ({[values.rs.length]} {[values.rs.length > 1 ? "Items" : "Item"]})';
            return new Ext.grid.GroupingView(config);
        }
        return new Ext.grid.GridView(config);
    }

    this.get_View = function() {
        if (this._View == null)
            this._View = this.create_View();
        return this._View;
    }

    ///////////////////////////////
    // SelectionModel Factory
    this.create_SelectionModel = function() {
        // Live Grid Requires Buffered Row Selection Model
        if (this.get_EnableBufferData()) {
            return new Ext.ux.grid.BufferedRowSelectionModel();
            // Doesn't support editing at this time
            //this.set_EnableEdit(false);
        }

        config = { singleSelect: !this.get_SelectMultiple() };

        if (this.get_CheckboxSelection())
            return new Ext.grid.CheckboxSelectionModel(config);

        return new Ext.grid.RowSelectionModel(config);
    }

    this.get_SelectionModel = function() {
        if (this._SelectionModel == null)
            this._SelectionModel = this.create_SelectionModel();
        return this._SelectionModel;
    }

    ////////////////////////
    // Reader Factory
    this.create_Reader = function() {
        if (this._WebServicePath != null && this._WebServiceMethod != null) {
            return new Ext.data.DataSetReader({
                totalRecords: this.get_totalTag(),
                id: this.get_IdRecord()
            }, this.get_FieldsArray());
        }
        else if (this._ProcessingPage != null && this._ProcessingPage != "") {
            return new Ext.data.XmlReader({
                record: this.get_TagName(),
                id: this.get_IdRecord(),
                totalRecords: this.get_totalTag()
            }, this.get_FieldsArray()
            );
        }
        return new Ext.data.MSJsonReader({
            id: this.get_IdRecord(),
            root: "records",
            totalProperty: "totalCount"
        }, this.get_FieldsArray()
        );
    }
    this.get_Reader = function() {
        if (this._Reader == null)
            this._Reader = this.create_Reader();
        return this._Reader;
    }

    ////////////////////////////
    // ColumnModel Factory
    this.create_ColumnModel = function() {
        var objColumns = new Array();

        if (this.get_CheckboxSelection())
            objColumns.push(this.get_SelectionModel());

        var cols = this.get_Columns();
        var len = cols.length;
        for (var i = 0; i < len; i++) {

            if (cols[i].ConfigOptions.expanderdataIndex != null && cols[i].ConfigOptions.expanderHeader != null) {
                objColumns.push(this.getExpanderModel(cols[i].ConfigOptions));
            }
            //Convert render value from string to function name literal
            if (cols[i].ConfigOptions.renderer)
                cols[i].ConfigOptions.renderer = eval(cols[i].ConfigOptions.renderer);

            if (cols[i].ConfigOptions.renderer == null && cols[i].EditorOptions.DataType == ExtExtenders.DataType.Date) {

                cols[i].ConfigOptions.renderer = Ext.util.Format.dateRenderer(cols[i].EditorOptions.DateFormat); //Ext.util.Format.date(dt, format)
            }
            if (this.get_EnableEdit() && cols[i].Editable != false) {
                // If grid is editable then added column editors
                cols[i].ConfigOptions.editor = this.CreateEditor(cols[i].EditorOptions);
            }
            objColumns.push(cols[i].ConfigOptions);
        }
        return new Ext.grid.ColumnModel(objColumns);
    }
    this.get_ColumnModel = function() {
        if (this._ColumnModel == null)
            this._ColumnModel = this.create_ColumnModel();
        return this._ColumnModel;
    }
    this.getExpanderModel = function(config) {

        var expander = new Ext.grid.RowExpander({
            tpl: new Ext.Template(
                '<p><b>' + config.header + ':</b> {' + config.dataIndex + '}<br>',
                '<p><b>' + config.expanderHeader + ': </b>{' + config.expanderdataIndex + '}</p>'
            )
        });
        this.expander = expander;
        return expander;
    }
    //////////////////
    // Store Factory
    this.create_Store = function() {
        var reader = this.get_Reader();
        var proxy;

        if (this.get_EnableBufferData()) {
            return new Ext.ux.grid.BufferedStore({
                autoLoad: true,
                bufferSize: this._PageSize * 1.4, //size to be loaded
                reader: reader,
                url: location.href
            });
        }

        if (this._WebServicePath != null && this._WebServiceMethod != null)
        // load using a webservice
            proxy = new Ext.data.WebserviceProxy({
                _WebservicePath: this._WebServicePath,
                _WebServiceMethod: this._WebServiceMethod
            });
        else if (this._ProcessingPage != null && this._ProcessingPage != "")
            proxy = new Ext.data.HttpProxy({ url: this._ProcessingPage });
        else
            proxy = new Ext.data.HttpProxy({ url: location.href });

        if (this.get_GroupingField() != null && this.get_GroupingField() != "") {
            return new Ext.data.GroupingStore({
                reader: reader,
                proxy: proxy,
                groupField: this.get_GroupingField(),
                sortInfo: { field: this.get_GroupingField(), direction: "ASC" },
                remoteSort: this._EnablePaging //if paging is enabled then sorting is server-sided
            });
        }

        return new Ext.data.Store({
            reader: reader,
            proxy: proxy,
            remoteSort: this._EnablePaging
        });
    }

    this.get_Store = function() {
        if (this._Store == null)
            this._Store = this.create_Store();
        return this._Store;
    }

    //////////////////
    // Pager Factory
    this.create_Pager = function() {
        if (this.get_EnableBufferData()) {
            return new Ext.ux.BufferedGridToolbar({
                view: obj,
                displayInfo: this.get_View()
            });
        }

        if (this.get_PagingStyle() == ExtExtenders.PagingStyle.NumberPaging) {
            return new Ext.NumberPagingToolbar({
                store: this.get_Store(),
                pageSize: this.get_PageSize()
            });
        }

        return new Ext.PagingToolbar({
            store: this.get_Store(),
            pageSize: this.get_PageSize(),
            displayInfo: true,
            displayMsg: 'Displaying records {0} - {1} of {2}',
            emptyMsg: "No record to display"
        });
    }
    this.get_Pager = function() {
        if (this._Pager == null)
            this._Pager = this.create_Pager();
        return this._Pager;
    }

    //////////////////
    // Grid Factory
    this.create_Grid = function() {

        var config = this.get_ConfigOptions();
        config.renderTo = this.get_GridControlId();
        config.view = this.get_View();
        config.selModel = this.get_SelectionModel();
        config.colModel = this.get_ColumnModel();
        config.store = this.get_Store();
        config.loadMask = { msg: 'Loading...' };

        if (this.expander) {
            config.plugins = this.expander;
        }
        if (!config.autoHeight && !config.height)
            config.autoHeight = true;


        if (this.get_EnablePaging() == true) {
            config.bbar = this.get_Pager();
        }
        //fixed topToolBar
        if (this.get_TopToolBar() != null) {
            config.tbar = eval(this._TopToolBar);
        }

        if (this.get_EnableBufferData()) {
            config.enableDragDrop = false;
        }
        else if (this.get_EnableRowSorting()) {//set drag and drop config options
            config.enableDragDrop = true;
            config.ddGroup = 'ExtExtenderGroup';
            config.enableColumnMove = true;
        }

        // Fire onClientInit event
        var onClientInit;
        var args = { config: config };
        if (config.onClientInit)
            onClientInit = eval(String.format('({0})', config.onClientInit));
        if (onClientInit)
            onClientInit(this, args);


        if (this.get_EnableEdit()) {
            return new Ext.grid.EditorGridPanel(args.config);
        }

        return new Ext.grid.GridPanel(args.config);
    }

    ///////////////////////
    // Grid Init
    ///////////////////////
    this._initGrid = function() {
        var grid = this.create_Grid();
        var ds = grid.getStore();
        ds.reader.grid = this;
        this.DataGrid = grid;

        // Fire onPreRender event
        var config = this.get_ConfigOptions();
        var onClientPreRender;
        if (config.onClientPreRender)
            onClientPreRender = eval(String.format('({0})', config.onClientPreRender));
        if (onClientPreRender)
            onClientPreRender(this, Sys.EventArgs.Empty);

        grid.render();

        if (this.get_EnableRowSorting()) {
            this.EnableDragDrop();
        }
        if (this.get_EnableEdit() && this.HasEvent("CellEdited")) {
            grid.on("afteredit", this.raiseCellEdited, this);
        }
        else {//election change not enabled if is editable grid
            if (this.HasEvent("SelectedRow"))
                grid.selModel.on("selectionchange", this.raiseSelectedIndexChanged, this);
        }
        if (this.HasEvent("RowRemoved"))
            grid.selModel.on("remove", this.raiseRemoveRow, this);

        if (this._RowContextMenu != "" && this._RowContextMenu != null && this._RowContextMenu != "null") {
            this.oContextMenu = this.BuildContextMenu();
            grid.on('rowcontextmenu', this.ShowMenu, this);

        }

        ds.firstLoad({ params: { start: 0, limit: this._PageSize, sort: '', dir: ''} });

        ds.loadData(this.get_Data());
    }
    this.BuildContextMenu = function() {
        var MenuTmp = eval('(' + this.get_RowContextMenu() + ')');
        var extMenuItems = [];
        if (MenuTmp == null) {
            return;
        }
        for (i = 0; i < MenuTmp.Items.length; i++) {
            var objTemp = {};
            var tmpItem = MenuTmp.Items[i];
            objTemp.text = tmpItem.Text;
            objTemp.id = tmpItem.Id;
            Ext.apply(objTemp, tmpItem);

            if (tmpItem.OnClientClick != null && tmpItem.OnClientClick != "") {
                objTemp.handler = eval(tmpItem.OnClientClick);
                //objTemp.scope=this;
            }
            else {
                objTemp.handler = this.raiseMenuItemClicked;
                objTemp.scope = this;
            }
            extMenuItems.push(objTemp);
        }
        oContextMenu = new Ext.menu.Menu({ items: extMenuItems });
        return oContextMenu;
    },
    this.ShowMenu = function(grid, rowIndex, e) {
        if (this.oContextMenu != null) {
            this.rowIndexMenu = rowIndex;
            e.stopEvent();
            var xy = e.getXY();
            this.oContextMenu.showAt(xy);
        }
    },
    ///////////////////
    // Enables Drag & Drop
    this.EnableDragDrop = function() {

        var ddrowTarget = new Ext.dd.DropTarget(
            this.DataGrid.container, {
                destiny: this.DataGrid,
                extender: this,
                ddGroup: "ExtExtenderGroup",
                notifyDrop: function(source, e, data) {

                    var sm = source.grid.getSelectionModel();
                    var rows = sm.getSelections();
                    var store = source.grid.store;

                    var cindex;
                    try {
                        cindex = source.getDragData(e).rowIndex;
                    }
                    catch (e) {
                        cindex = 0;
                    }
                    if (typeof (cindex) == "undefined") {
                        cindex = 0;
                    }
                    var destinyGrid = this.destiny;
                    var destStore = destinyGrid.store;
                    for (i = 0; i < rows.length; i++) {
                        rowData = store.getById(rows[i].id);
                        store.remove(rowData);
                        destStore.insert(cindex, rowData);
                    }
                    //row droped event should only fire when source grid 
                    // and destination grid is not the same grid
                    if (destinyGrid.id != source.grid.id) {
                        this.extender.raiseRowDroped(rows);
                    }


                }
            })
    }

    ///////////////////
    // Refreshes the grid
    this.refresh = function() {

        var grid = this.get_Grid();
        var ds = grid.getStore();

        var total = ds.getTotalCount();
        if (this.removedCount) {
            total -= this.removedCount;
        }
        var pageParams = ds.lastOptions.params;
        var pageSize = pageParams.limit;

        var cursor = pageParams.start;
        var currPage;

        currPage = Math.ceil((cursor + pageSize) / pageSize);

        var totPages = total < pageSize ? 1 : Math.ceil(total / pageSize);
        if (currPage > totPages) {
            pageParams.start -= pageSize;
            ds.load({ params: pageParams });
        }
        else {
            ds.reload();
        }
    }
    ///////////////////
    // Factory method that returns an editor appropriate for the given column.
    this.CreateEditor = function(objCol) {

        var editor;
        // shorthand alias
        var fm = Ext.form;
        //EditControlId means the column is going to be edited 
        //using a combobox
        if (objCol.Editor != "" && objCol.Editor != null) {
            return eval(objCol.Editor);
        }
        if (objCol.EditControlId != "" && objCol.EditControlId != null) {
            var elem = Ext.getDom(objCol.EditControlId);
            if (elem == null || elem.tagName != 'SELECT')
                throw Error.create(String.format('EditControlID "{0}" is not a SELECT element.'), objCol.EditControlId);
            editor = new fm.ComboBox({
                typeAhead: true,
                triggerAction: 'all',
                transform: objCol.EditControlId,
                forceSelection: true,
                lazyRender: true,
                listClass: 'x-combo-list-small'
            });
            return editor;
        }
        switch (objCol.DataType) {
            case ExtExtenders.DataType.Text:
                editor = new fm.TextField({
                    allowBlank: objCol.allowBlank,
                    maxLength: objCol.maxLength
                })
                break;
            case ExtExtenders.DataType.Numeric:
                editor = new fm.NumberField({
                    allowBlank: objCol.allowBlank,
                    maxLength: objCol.maxLength,
                    allowNegative: false
                })
                break;
            case ExtExtenders.DataType.Date:
                editor = new fm.DateField({
                    allowBlank: objCol.allowBlank,
                    format: objCol.DateFormat
                })
                break;
            case  ExtExtenders.DataType.MultiLine:
                    editor = new fm.TextArea({ 
                                            allowBlank: objCol.allowBlank,
                                            maxLength: objCol.maxLength 
                                            });
        }
        return editor;
    }
    // These are helper functions for communicating state back to the extender on the
    // server side.  They take or return a custom string that is available in your initialize method
    // and later.
    //
    this.getClientState = function() {
        var value = ExtExtenders.GridControlBehavior.callBaseMethod(this, 'get_ClientState');
        if (value == '') value = null;
        return value;
    }

    this.setClientState = function(value) {
        return ExtExtenders.GridControlBehavior.callBaseMethod(this, 'set_ClientState', [value]);
    }
    //helper to fire events
    this.invoke = function(args, onComplete$delegate, context, onError$delegate, async) {
        var callbackId = this._GridControlId;
        callbackId = callbackId.replace(/_/g, "$");
        var objArgs = eval('(' + args + ')');
        if (this._AutoPostBack && objArgs.EventName != "PageIndexChanged") {
            __doPostBack(callbackId, args);
        }
        else {
            WebForm_DoCallback(callbackId, args, onComplete$delegate, context, onError$delegate, async);
        }
    }
    this.raiseSelectedIndexChanged = function(selModel) {

        var row_data = selModel.getSelected();
        if (row_data) {
            var eventArgs = new ExtExtenders.GridEventArgs();
            var arguments = new Object();

            arguments.SelectedRow = row_data.data;
            this.invoke(eventArgs.serialise("SelecteIndexChanged", arguments), null, this, this.onCallbackError, true);
        }
    }
    this.raiseCellEdited = function(editArgs) {
        var eventArgs = new ExtExtenders.GridEventArgs();
        var arguments = new Object();
        arguments.Record = editArgs.record.data;
        arguments.Field = editArgs.field;
        arguments.Value = editArgs.value;
        var grid = this.get_Grid();
        var store = grid.getStore();
        store.commitChanges();
        this.invoke(eventArgs.serialise("CellEdited", arguments), null, this, this.onCallbackError, true);
    }
    this.raiseMenuItemClicked = function(item) {

        var grid = this.get_Grid()
        var row_data = grid.selModel.getSelected();
        if (typeof (row_data) == "undefined") {
            var store = grid.getStore();
            row_data = store.getAt(this.rowIndexMenu);
        }
        if (row_data) {
            var eventArgs = new ExtExtenders.GridEventArgs();
            var arguments = new Object();
            arguments.SelectedRow = row_data.data;
            arguments.MenuClicked = { Id: item.Id };
            this.invoke(eventArgs.serialise("GridContextMenu", arguments), null, this, this.onCallbackError, true);
        }
    }
    this.raiseRowDroped = function(rows) {
        var eventArgs = new ExtExtenders.GridEventArgs();
        var arguments = new Object();
        var data = [];
        for (i = 0; i < rows.length; i++) {
            data.push(rows[i].data);
        }
        arguments.RowsDropped = data;

        this.invoke(eventArgs.serialise("RowDroped", arguments), null, this, this.onCallbackError, true);
    },
    this.raisePageIndexChanged = function(o, proxy) {

        var eventArgs = new ExtExtenders.GridEventArgs();
        var argumentos = new Object();
        var grid = this.get_Grid();
        var ds = grid.getStore();

        var total = ds.getTotalCount();
        var pageParams = o.params;
        var pageSize = pageParams.limit;

        var cursor = pageParams.start;
        argumentos.currentRecord = cursor;
        argumentos.pageSize = pageSize;
        if (pageParams.sort) {
            argumentos.sortColumn = pageParams.sort;
            argumentos.sortDir = pageParams.dir;
        }
        else {
            argumentos.sortColumn = "";
            argumentos.sortDir = "";
        }
        argumentos.json = Ext.encode(pageParams);
        this._proxy = proxy;
        this._o = o;

        this.invoke(eventArgs.serialise("PageIndexChanged", argumentos), this.pageIndexSucess, this, this.onCallbackError, true);
    },
    this.pageIndexSucess = function(response, caller) {
        var objResponse = new Object();
        objResponse.responseText = response;
        caller._proxy.loadResponse(caller._o, true, objResponse);
    }
    /*
    removes a row(s) from the grid and fires the event
    */
    this.raiseRemoveRow = function(args) {
        this.removeRow();
    }
    this.removeRow = function() {
        var eventArgs = new ExtExtenders.GridEventArgs();
        var arguments = new Object();

        var grid = this.get_Grid();
        var store = grid.getStore();
        var row_data = grid.selModel.getSelections(); //always gets the selected rows as an array
        var rows = [];
        for (var i = 0; i < row_data.length; i++) {
            rows.push(row_data[i].data);
            store.remove(row_data[i]);
        }
        this.removedCount = rows.length;
        arguments.RowsRemoved = rows;
        store.commitChanges();
        this.invoke(eventArgs.serialise("RowRemoved", arguments), this.refresh.createDelegate(this), this, this.onCallbackError, true);
    },
   this.renderDate = function(format) {
       return function(v) {
           var exp = /\/Date\(([-]*\d+)\)/;
           if (v != null) {
               var x = exp.exec(v);
               var dt = new Date(parseInt(x[1]));
               return Ext.util.Format.date(dt, format)
           }
           else {
               return "  ";
           }
       };
   }
    this.encodeObject = function(obj) {
        var cleanObj = {};
        for (var p in obj) {
            if (typeof (obj[p]) != "function" && typeof (obj[p]) != "object") {
                cleanObj[p] = obj[p];
            }
        }

        return cleanObj;
    }
}

ExtExtenders.GridControlBehavior.registerClass('ExtExtenders.GridControlBehavior',Sys.UI.Control);

if (typeof (Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 