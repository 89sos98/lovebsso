using System;
using System.Collections.Generic;
using System.Reflection;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Text;

[assembly: WebResource("ExtExtenders.HtmlEditor.HtmlEditorBehavior.js", "text/javascript")]

namespace ExtExtenders
{
    /// <summary>
    /// A control that provides WYSIWYG html edition
    /// </summary>
    public class HtmlEditor : Panel, IScriptControl
    {
        private List<string> _fontFamilies;
        private ScriptManager sm;

        /// <summary>
        /// Initializes a new instance of the <see cref="T:HtmlEditor"/> class.
        /// </summary>
        public HtmlEditor()
        {
            Enabled = true;
            _fontFamilies = new List<string>();
            _fontFamilies.Add("Arial");
            _fontFamilies.Add("Verdana");
            _fontFamilies.Add("Times New Roman");
        }


        public string Value
        {
            get
            {
                // this call must exists for button validation    
                setValueWithHiddenField();

                return (ViewState["textToDisplay"] == null) ? "" : ViewState["textToDisplay"].ToString();
            }
            set { ViewState["textToDisplay"] = value; }
        }


        public void setValueWithHiddenField()
        {
            string val = "";
            string[] keys = Page.Request.Form.AllKeys;

            if (keys.Length > 0)
            {
                foreach (string key in keys)
                {
                    if (key.Contains("hid") && key.Contains(this.ID))
                    {
                        val = Page.Request.Form[key];
                    }
                }

                Value = val;
            }
        }

        public override void RenderEndTag(HtmlTextWriter writer)
        {
            base.RenderEndTag(writer);


            StringBuilder strToDisplayInDiv = new StringBuilder();
            strToDisplayInDiv.Append("<script>$get('" + this.ClientID + "').innerHTML='" + Value + "';</script>");
            writer.Write(strToDisplayInDiv);

        }



        /// <summary>
        /// available font families for the editor
        /// </summary>
        public List<string> fontFamilies
        {
            get
            {
                if (_fontFamilies == null)
                {
                    _fontFamilies = new List<string>();
                }
                return _fontFamilies;
            }
        }

        /// <summary>
        /// The default value for the create link prompt (defaults to http:/ /)
        /// </summary>
        public string defaultLinkValue { get; set; }

        /// <summary>
        /// The default text for the create link prompt
        /// </summary>
        public string createLinkText { get; set; }

        #region IScriptControl Members

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            var ser = new JavaScriptSerializer();
            var descriptor = new ScriptControlDescriptor(
                "ExtExtenders.HtmlEditorBehavior", ClientID);

            Type t = GetType();

            //properties that will be serialized
            string[] propsToSerialize = {
                                            "createLinkText", "defaultLinkValue", "Enabled"
                                        };
            foreach (string prop in propsToSerialize)
            {
                PropertyInfo p = t.GetProperty(prop);
                if (p == null)
                {
                    throw new Exception(prop);
                }
                descriptor.AddProperty(p.Name, p.GetValue(this, null));
            }
            //descriptor.AddProperty("id", ID);
            descriptor.AddProperty("fontFamilies", ser.Serialize(fontFamilies));

            return new ScriptDescriptor[] { descriptor };
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ScriptReference> GetScriptReferences()
        {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.HtmlEditor.HtmlEditorBehavior.js");

            return new[] { reference };
        }

        #endregion

        /// <summary>
        /// Renders the control to the specified HTML writer.
        /// </summary>
        /// <param name="writer">The <see cref="T:System.Web.UI.HtmlTextWriter"></see> object that receives the control content.</param>
        protected override void Render(HtmlTextWriter writer)
        {
            base.Render(writer);
            if (!DesignMode)
                sm.RegisterScriptDescriptors(this);

        }

        /// <summary>
        /// Overrides OnPreRender.  Registers scripts common to the ExtExtenders library
        /// </summary>
        /// <param name="e">The event arguments</param>
        protected override void OnPreRender(EventArgs e)
        {

            //setValueWithHiddenField();

            string resource = Page.ClientScript.GetWebResourceUrl(GetType(), "ExtExtenders.yui-ext.css");
            string csslink = "<link href='" + resource + "' rel='stylesheet' type='text/css' />";
            Page.Header.Controls.Add(new LiteralControl(csslink));
            ClientScriptManager man = Page.ClientScript;
            //render the yui-ext scripts
            man.RegisterClientScriptResource(typeof(YUI), "ExtExtenders.yui.js");
            man.RegisterClientScriptResource(typeof(YUI_ext), "ExtExtenders.yui-ext.js");
            man.RegisterClientScriptResource(typeof(ext_yui_adapter), "ExtExtenders.ext-yui-adapter.js");
            if (!DesignMode)
            {
                // Test for ScriptManager and register if it exists
                sm = ScriptManager.GetCurrent(Page);

                if (sm == null)
                    throw new HttpException("A ScriptManager control must exist on the current page.");

                sm.RegisterScriptControl(this);
            }


            base.OnPreRender(e);


        }
    }
}