// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

Type.registerNamespace('ExtExtenders');

ExtExtenders.HtmlEditorBehavior = function(element) {
    /// <summary>
    /// The HtmlEditorBehavior makes the target element BasicDialog
    /// </summary>
    /// <param name="element" type="Sys.UI.DomElement" domElement="true">
    /// DOM element associated with the behaviro
    /// </param>
    ExtExtenders.HtmlEditorBehavior.initializeBase(this, [element]);
    
    // Properties
    this._MinimumWidth = 0;
    this._MinimumHeight = 0;
    
}
ExtExtenders.HtmlEditorBehavior.prototype = {
    initialize : function() {
        /// <summary>
        /// Initialize the behavior
        /// </summary>
        ExtExtenders.HtmlEditorBehavior.callBaseMethod(this, 'initialize');
        Ext.QuickTips.init();
        var ElId=this.get_element().id;
        this.hiddenName='hid'+ElId;
        
        var hid=Ext.DomHelper.append(document.forms[0],{tag:'input',type:'hidden',id:this.hiddenName,name:this.hiddenName});
        var el=Ext.get(ElId);
        var editor = new Ext.form.HtmlEditor(
                {
                 applyTo:ElId,
                 createLinkText:this.get_createLinkText(),
                 defaultLinkValue:this.get_defaultLinkValue(),
                 fontFamilies:eval(this.get_fontFamilies()),
                 disabled:!this.get_Enabled(),
                 value:el.dom.innerHTML,
                 width:el.getWidth(),
                 height:el.getHeight()
                }
            );
        this.editor=editor;
        this.updateValue();
        this.editor.on('sync',this.updateValue,this);
        
    },
    updateValue:function(){
        $get(this.hiddenName).value=this.editor.getValue();
    },
    get_createLinkText:function(){
        return this._createLinkText;
    },
    set_createLinkText:function(value){
        this._createLinkText=value;
    },
    get_defaultLinkValue:function(){
        return this._defaultLinkValue;
    },
    set_defaultLinkValue:function(value){
        this._defaultLinkValue =value;
    },
    get_fontFamilies:function(){
        return this._fontFamilies;
    },
    set_fontFamilies:function(value){
        this._fontFamilies=value;
    },
    get_Enabled:function(){
        return this._Enabled;
    },
    set_Enabled:function(value){
        this._Enabled=value;
    }
    
    
}
ExtExtenders.HtmlEditorBehavior.registerClass('ExtExtenders.HtmlEditorBehavior', Sys.UI.Control);
if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 
