// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

// This behavior can be attached to a textbox to enable auto-complete/auto-suggest
// scenarios.
Type.registerNamespace('ExtExtenders');

ExtExtenders.MenuType = function() {
  
    throw Error.invalidOperation();
}
ExtExtenders.MenuType.prototype = {
        /// <summary>
        /// The menu has a checkbox and a text
        /// </summary>
        CheckItem:0,
        /// <summary>
        /// The menu displays a color picker
        /// </summary>
        ColorItem:1,
        /// <summary>
        /// default menu
        /// </summary>
        TextItem:2,
        /// <summary>
        /// The item is separator
        /// </summary>
        Separator:3,
        /// <summary>
        /// The menu displays a date picker
        /// </summary>
        DateItem:4,
        /// <summary>
        /// The menu is used as a link
        /// </summary>
        URL:5
}
ExtExtenders.MenuType.registerEnum("ExtExtenders.MenuType", false);

ExtExtenders.ToolBarEventArgs = function() {
   
    ExtExtenders.ToolBarEventArgs.initializeBase(this);

}
ExtExtenders.ToolBarEventArgs.prototype = {
  
    serialise : function(eventName,arguments){
    /// <summary>
    /// Method used to prepare an event to be fired
    /// </summary>
    /// <param name="eventName" type="string">
    /// Name of the event to be fired
    /// </param>
    /// <param name="arguments" type="object">
    /// Object containing the parameters to be passed
    /// </param>
        return Sys.Serialization.JavaScriptSerializer.serialize(
                {
                    EventName: eventName,
                    Arguments: Sys.Serialization.JavaScriptSerializer.serialize
                        (arguments)
                });
    } 
}

ExtExtenders.ToolBarEventArgs.registerClass('ExtExtenders.ToolBarEventArgs', Sys.EventArgs);

ExtExtenders.ToolBarExtenderBehavior = function(element) {
   
    ExtExtenders.ToolBarExtenderBehavior.initializeBase(this, [element]);
      
}
ExtExtenders.ToolBarExtenderBehavior.prototype = {
    initialize: function() {

        ExtExtenders.ToolBarExtenderBehavior.callBaseMethod(this, 'initialize');
        var id = this.get_element().id;
        var tb = new Ext.Toolbar();
        tb.render(id);
        this.tool = tb;
        var menu = this.get_Menu();
        var ListMenu = eval('(' + this.get_Menu() + ')');

        if (ListMenu.length > 0) {
            var objMenuItem = {};
            for (var i = 0; i < ListMenu.length; i++) {
                tmpMenu = ListMenu[i].Items;

                this.build_menu_object(tmpMenu, false);
            }
        }
        else {

            //add items directly to the menu
            var ListMenu = eval('(' + this.get_Items() + ')');
            for (var i = 0; i < ListMenu.length; i++) {
                tmpMenu = ListMenu[i];

                tb.add(this.buildMenuObject(tmpMenu));
            }

        }

    },
    get_Items: function() {
        return this._Items;
    },
    set_Items: function(value) {
        this._Items = value;
    },
    get_Menu: function() {

        return this._Menu;
    },
    set_Menu: function(value) {
        this._Menu = value;
    },
    get_AutoPostBack: function() {
        return this._AutoPostBack;
    },
    set_AutoPostBack: function(value) {
        this._AutoPostBack = value;
    },
    build_menu_object: function(tmpMenu, isSubMenu) {
        var tb = this.tool;

        for (var i = 0; i < tmpMenu.length; i++) {
            if (i == 0 && !isSubMenu) {
                this.mainMenu = new Ext.menu.Menu({ id: Ext.id() });
                tb.add({
                    text: tmpMenu[i].Text,
                    menu: this.mainMenu,
                    icon: tmpMenu[i].icon,
                    iconCls: tmpMenu[i].iconCls
                });
                continue;
            }

            var tmpItem = tmpMenu[i];
            var objFinal = this.buildMenuObject(tmpItem);
            if (objFinal == null) {
                continue; //separator
            }
            if (tmpItem.SubMenu) {

                if (objFinal.menu == null) {
                    objFinal.menu = {};
                    objFinal.menu.items = [];
                }
                for (var j = 0; j < tmpItem.SubMenu.Items.length; j++) {
                    var objSub = this.buildMenuObject(tmpItem.SubMenu.Items[j]);
                    objFinal.menu.items.push(objSub);
                }

                this.mainMenu.add(objFinal);
            }
            else {
                this.mainMenu.add(objFinal);

            }

        }
    },
    buildMenuObject: function(tmpItem) {
        var objMenuItem = {};
        if (tmpItem.ItemType == ExtExtenders.MenuType.Separator) {
            this.mainMenu.addSeparator();
            return;
        }
        objMenuItem.text = tmpItem.Text;
        objMenuItem.id = tmpItem.Id;

        //copy all properties
        Ext.apply(objMenuItem, tmpItem);

        if (tmpItem.OnClientClick != null && tmpItem.OnClientClick != "") {
            if (tmpItem.ItemType == ExtExtenders.MenuType.CheckItem) {
                objMenuItem.checked = tmpItem.IsChecked;
                objMenuItem.checkHandler = eval(tmpItem.OnClientClick);
            }
            else if (tmpItem.ItemType == ExtExtenders.MenuType.URL) {
                objMenuItem.href = tmpItem.OnClientClick;
            }
            else {
                objMenuItem.handler = eval(tmpItem.OnClientClick);
            }
            //objTemp.scope=this;
        }
        else {
            if (tmpItem.ItemType == ExtExtenders.MenuType.CheckItem) {
                objMenuItem.checked = tmpItem.IsChecked;
                //objMenuItem.scope=this;
                objMenuItem.checkHandler = this.raiseMenuItemClicked.createDelegate(this);

            }
            else {
                //objMenuItem.scope=this;
                objMenuItem.handler = this.raiseMenuItemClicked.createDelegate(this);


            }
        }
        switch (tmpItem.ItemType) {
            case ExtExtenders.MenuType.DateItem:
                objMenuItem.menu = this.createDateMenu(objMenuItem.handler);
                objMenuItem.handler = function() { };
                break;
            case ExtExtenders.MenuType.ColorItem:
                objMenuItem.menu = this.createColorMenu(objMenuItem.handler);
                objMenuItem.handler = function() { };
                break;
        }
        return objMenuItem;
    },
    createDateMenu: function(_handler) {
        var dateMenu = new Ext.menu.DateMenu({ handler: _handler });
        return dateMenu;
    },
    createColorMenu: function(_handler) {
        var colorMenu = new Ext.menu.ColorMenu({ handler: _handler });
        return colorMenu;
    },
    invoke: function(args, onComplete$delegate, context, onError$delegate, async) {
        var callbackId = this.get_element().id;
        callbackId = callbackId.replace(/_/g, "$");
        if (this._AutoPostBack) {
            __doPostBack(callbackId, args);
        }
        else {
            WebForm_DoCallback(callbackId, args, onComplete$delegate, context, onError$delegate, async);
        }
    },
    raiseMenuItemClicked: function() {
       
        var eventArgs = new ExtExtenders.ToolBarEventArgs();
        var myArguments = new Object();
        var args = arguments;
        var item = args[0];
        item.DateSelected = new Date();
        
        if (item.ItemType != ExtExtenders.MenuType.TextItem) {
            if (item.ctype) {
                switch (item.ctype) {
                    case "Ext.Component":
                        item = {}; //its not a menuitem
                        item.ItemType = ExtExtenders.MenuType.DateItem;
                        item.DateSelected = args[1];
                        break;
                    case "Ext.ColorPalette":
                        item = {}; //its not a menuitem
                        item.ColorSelected = args[1];
                        item.ItemType = ExtExtenders.MenuType.ColorItem;
                        break;
                    case "Ext.menu.BaseItem":
                        return;

                }
            }
        }
        if (item.ItemType == ExtExtenders.MenuType.CheckItem) {

            item.isChecked = item.checked;
        }
        //dateitem does not need to be cleaned
        if (item.ItemType == ExtExtenders.MenuType.DateItem) {
            myArguments.MenuClicked = item;
        }
        else {
            myArguments.MenuClicked = this.encodeObject(item);
        }

        this.invoke(eventArgs.serialise("MenuItemClicked", myArguments), null, this, this.onCallbackError, true);
    },
    encodeObject: function(obj) {
        var cleanObj = {};
        for (var p in obj) {
            if (typeof (obj[p]) != "function" && typeof (obj[p]) != "object") {
                cleanObj[p] = obj[p];
            }
        }

        return cleanObj;
    }

}
ExtExtenders.ToolBarExtenderBehavior.registerClass('ExtExtenders.ToolBarExtenderBehavior', Sys.UI.Control);
if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded()
