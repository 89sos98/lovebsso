using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web.Script.Serialization;
using System.Web.UI;
using ExtExtenders.Helpers;

[assembly: WebResource("ExtExtenders.ToolBar.ToolBarExtenderBehavior.js", "text/javascript")]

namespace ExtExtenders
{
    /// <summary>
    /// Toolbar control 
    /// </summary>
    public class ToolBar : ExtScriptWebControlBase, INamingContainer, ICallbackEventHandler, IPostBackEventHandler
    {
        /// <summary>
        /// Menu item clicked
        /// </summary>
        private static readonly Object OnItemClickedKey = new Object();

        private readonly List<string> _Events = new List<string>();

        private readonly JavaScriptSerializer jsSerialiser;
        private bool _autoPostBack;
        private List<Menu> _menu;
        private List<MenuItem> _menuItems;

        /// <summary>
        /// Initializes a new instance of the <see cref="T:ToolBar"/> class.
        /// </summary>
        public ToolBar() : base(HtmlTextWriterTag.Div)
        {
            jsSerialiser = new JavaScriptSerializer();
        }

        /// <summary>
        /// Gets or sets a value indicating whether [auto post back].
        /// </summary>
        /// <value><c>true</c> if [auto post back]; otherwise, <c>false</c>.</value>
        public bool AutoPostBack
        {
            get
            {
                EnsureChildControls();
                return _autoPostBack;
            }
            set
            {
                EnsureChildControls();
                _autoPostBack = value;
            }
        }

        /// <summary>
        /// The Menus for the toolbar
        /// </summary>
        /// <value></value>
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public List<Menu> Menus
        {
            get
            {
                EnsureChildControls();
                if (_menu == null)
                {
                    _menu = new List<Menu>();
                }

                return _menu;
            }
        }

        /// <summary>
        /// Menu items for the toolbar
        /// </summary>
        /// <value></value>
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public List<MenuItem> Items
        {
            get
            {
                EnsureChildControls();
                if (_menuItems == null)
                {
                    _menuItems = new List<MenuItem>();
                }

                return _menuItems;
            }
        }

        #region ICallbackEventHandler Members

        /// <summary>
        /// Returns the results of a callback event that targets a control.
        /// </summary>
        /// <returns>The result of the callback.</returns>
        public string GetCallbackResult()
        {
            return null;
        }

        /// <summary>
        /// Processes a callback event that targets a control.
        /// </summary>
        /// <param name="eventArgument">A string that represents an event argument to pass to the event handler.</param>
        public void RaiseCallbackEvent(string eventArgument)
        {
            RaisePostBackEvent(eventArgument);
        }

        #endregion

        #region IPostBackEventHandler Members

        /// <summary>
        /// When implemented by a class, enables a server control to process an event raised when a form is posted to the server.
        /// </summary>
        /// <param name="eventArgument">A <see cref="T:System.String"></see> that represents an optional event argument to be passed to the event handler.</param>
        public void RaisePostBackEvent(string eventArgument)
        {
          
            var eventArgs = jsSerialiser.Deserialize<TreeEventArgs>(eventArgument);
            switch (eventArgs.EventName.ToLower())
            {
                case "menuitemclicked":
                    OnMenuItemClicked(jsSerialiser.Deserialize<ToolBarEventArgs>(eventArgs.Arguments));
                    break;

                default:
                    //Do nothing
                    break;
            }
        }

        #endregion

        /// <summary>
        /// Event to be fired when a node is inserted
        /// </summary>
        public event ToolBarEventHandler MenuItemClicked
        {
            add
            {
                _Events.Add("MenuItemClicked");
                Events.AddHandler(OnItemClickedKey, value);
            }
            remove { Events.RemoveHandler(OnItemClickedKey, value); }
        }

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Load"></see> event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            Page.ClientScript.GetCallbackEventReference(this, "", "", "");
        }

        /// <summary>
        /// Raises the menu item clicked event
        /// </summary>
        /// <param name="e">The <see cref="T:ExtExtenders.ToolBarEventArgs"/> instance containing the event data.</param>
        protected virtual void OnMenuItemClicked(ToolBarEventArgs e)
        {
            var eventHandler = (ToolBarEventHandler) Events[OnItemClickedKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }

        ///// <summary>
        ///// Transforms an xml string into a menu
        ///// </summary>
        ///// <param name="sXml"></param>
        //public void FromXmlString(string sXml)
        //{
            
        //}
        /// <summary>
        /// Transforms a simple toolbar (with items only into a json string)
        /// </summary>
        /// <returns></returns>
        public string ToJson()
        {
            var sb = new StringBuilder();
            //grid toolbar can only have one menu
            sb.Append("[");

            for (var i = 0; i < Items.Count; i++)
            {
                var it = Items[i];
                var handler = string.IsNullOrEmpty(it.OnClientClick) ? "Ext.emptyFn" : it.OnClientClick;
                sb.Append("{id:'" + it.Id + "',text :'" + it.Text + "',iconCls:'" + it.iconCls + "', handler:" + handler +
                          ",disabled:" + it.disabled.ToString().ToLower() + "}");
                if (i < Items.Count - 1)
                {
                    sb.Append(",");
                }
            }
            sb.Append("]");
            return sb.ToString();
        }

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            var descriptor = new ScriptControlDescriptor(
                "ExtExtenders.ToolBarExtenderBehavior", ClientID);

            //properties that will be serialized
            descriptor.AddProperty("AutoPostBack",
                                   AutoPostBack);

            descriptor.AddProperty("Menu",
                                   jsSerialiser.Serialize(Menus));
            descriptor.AddProperty("Items",
                                   jsSerialiser.Serialize(Items));


            return new ScriptDescriptor[] {descriptor};
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptReference> GetScriptReferences()
        {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.ToolBar.ToolBarExtenderBehavior.js");

            return new[] {reference};
        }
    }
}