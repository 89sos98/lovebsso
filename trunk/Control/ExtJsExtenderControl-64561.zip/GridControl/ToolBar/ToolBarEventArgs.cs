using System;

namespace ExtExtenders
{
    /// <summary>
    /// Event handler for the menu
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e">Arguments for the event</param>
    public delegate void ToolBarEventHandler(Object sender, ToolBarEventArgs e);

    /// <summary>
    /// Event arguments for the menu item clicked event
    /// </summary>
    public class ToolBarEventArgs : EventArgs
    {
        /// <summary>
        /// The menuitem that was clicked
        /// </summary>
        /// <value>The menu clicked.</value>
        public MenuItem MenuClicked { get; set; }
    }
}