using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using ExtExtenders.Helpers;

[assembly: WebResource("ExtExtenders.Button.ButtonExtenderBehavior.js", "text/javascript")]

namespace ExtExtenders
{
    /// <summary>
    /// Deletgate for the click event
    /// </summary>
    /// <param name="sender"></param>
    public delegate void ClickEventHandler(Object sender);

    /// <summary>
    /// Class to represent a ext button
    /// </summary>
    [Designer(typeof (ExtButtonDesigner))]
    [ToolboxBitmap(typeof (Button))]
    public class ExtButton : ExtScriptWebControlBase, IPostBackEventHandler, INamingContainer
    {
        /// <summary>
        /// Key for the selectedrowindexchanged event
        /// </summary>
        private static readonly Object ClickKey = new Object();

        /// <summary>
        /// Initializes a new instance of the <see cref="T:ExtButton"/> class.
        /// </summary>
        public ExtButton() : base(HtmlTextWriterTag.Div)
        {
        }

        /// <summary>
        /// Gets or sets a value indicating whether [causes validation].
        /// </summary>
        /// <value><c>true</c> if [causes validation]; otherwise, <c>false</c>.</value>
        [DescribableProperty]
        public bool CausesValidation { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [disable after click].
        /// </summary>
        /// <value><c>true</c> if [disable after click]; otherwise, <c>false</c>.</value>
        [DescribableProperty]
        public bool DisableAfterClick { get; set; }

        /// <summary>
        /// Id used for the postback
        /// </summary>
        /// <value>The post back id.</value>
        public string PostBackId { get; set; }

        /// <summary>
        /// Gets or sets the text.
        /// </summary>
        /// <value>The text.</value>
        public string Text { get; set; }

        /// <summary>
        /// The Button menu
        /// </summary>
        public Menu Menu { get; set; } 
        /// <summary>
        /// String pointing to the javascript function 
        /// to be executed
        /// </summary>
        public string OnClientClick { get; set; }

        #region IPostBackEventHandler Members

        /// <summary>
        /// When implemented by a class, enables a server control to process an event raised when a form is posted to the server.
        /// </summary>
        /// <param name="eventArgument">A <see cref="T:System.String"></see> that represents an optional event argument to be passed to the event handler.</param>
        public void RaisePostBackEvent(string eventArgument)
        {
            var jsSerialiser = new JavaScriptSerializer();
            OnClick(this);
        }

        #endregion

        /// <summary>
        /// Click Event
        /// </summary>
        public event ClickEventHandler Click
        {
            add { base.Events.AddHandler(ClickKey, value); }
            remove { base.Events.RemoveHandler(ClickKey, value); }
        }

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Load"></see> event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            PostBackId = ID;
        }


        /// <summary>
        /// Called when the button is clicked 
        /// </summary>
        /// <param name="sender">The sender.</param>
        protected virtual void OnClick(Object sender)
        {
            var eventHandler = (ClickEventHandler) base.Events[ClickKey];
            if (eventHandler != null)
            {
                eventHandler(this);
            }
        }

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            var conv = new JavaScriptSerializer();
            var descriptor = new ScriptControlDescriptor(
                "ExtExtenders.ButtonExtenderBehavior", ClientID);

            descriptor.AddProperty("Text",
                                   Text);

            descriptor.AddProperty("PostBackId",
                                   PostBackId);
            descriptor.AddProperty("OnClientClick",
                                   OnClientClick);

            if (Menu !=null)
            {
                descriptor.AddProperty("Menu", conv.Serialize(Menu));
            }
            Util.DescribeProperties(this, descriptor);

            return new ScriptDescriptor[] {descriptor};
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptReference> GetScriptReferences()
        {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.Button.ButtonExtenderBehavior.js");

            return new[] {reference};
        }
    }
}