// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

// This behavior can be attached to a textbox to enable auto-complete/auto-suggest
// scenarios.
Type.registerNamespace('ExtExtenders');
ExtExtenders.ButtonExtenderBehavior = function(element) {
   
    ExtExtenders.ButtonExtenderBehavior.initializeBase(this, [element]);
      
}
ExtExtenders.ButtonExtenderBehavior.prototype = {
    initialize: function() {

        ExtExtenders.ButtonExtenderBehavior.callBaseMethod(this, 'initialize');
        var id = this.get_element().id;
        var btn = new Ext.Button({
            renderTo: id,
            handler: this.raiseClicked.createDelegate(this),
            text: this.get_Text()
        });
        if (this._Menu != null && this._Menu != "") {
            btn.Menu= this.BuildContextMenu()
        }
        this._button = btn;
    },
    BuildContextMenu : function() {
        var MenuTmp = eval('(' + this.get_Menu() + ')');
        var extMenuItems = [];
        if (MenuTmp == null) {
            return;
        }
        for (i = 0; i < MenuTmp.Items.length; i++) {
            var objTemp = {};
            var tmpItem = MenuTmp.Items[i];
            objTemp.text = tmpItem.Text;
            objTemp.id = tmpItem.Id;
            Ext.apply(objTemp, tmpItem);

            if (tmpItem.OnClientClick != null && tmpItem.OnClientClick != "") {
                objTemp.handler = eval(tmpItem.OnClientClick);
                //objTemp.scope=this;
            }
            else {
                objTemp.handler = this.raiseMenuItemClicked;
                objTemp.scope = this;
            }
            extMenuItems.push(objTemp);
        }
        oContextMenu = new Ext.menu.Menu({ items: extMenuItems });
        return oContextMenu;
    },
    get_CausesValidation: function() {
        return this._CausesValidation;
    },
    set_CausesValidation: function(value) {
        this._CausesValidation = value;
    },
    get_Text: function() {

        return this._Text;
    },
    set_Text: function(value) {
        this._Text = value;
    },
    get_OnClientClick: function() {
        return this._OnClientClick;
    },
    set_OnClientClick: function(value) {
        this._OnClientClick = value;
    },
    get_PostBackId: function() {
        return this._PostBackId;
    },
    set_PostBackId: function(value) {
        this._PostBackId = value
    },
    get_DisableAfterClick: function() {
        return this._DisableAfterClick;
    },
    set_DisableAfterClick: function(value) {
        this._DisableAfterClick = value;
    },
    get_Menu: function() {
        return this._Menu;
    },
    set_Menu: function(value) {
        this._Menu = value;
    },
    invoke: function(args, onComplete$delegate, context, onError$delegate, async) {
        if (this.get_DisableAfterClick()) {
            this._button.dom.disable();
        }
        var callbackId = this.get_element().id;
        callbackId = callbackId.replace(/_/g, "$");
        if (typeof (Page_ClientValidate) == 'function' && this.get_CausesValidation() == true) {
            var valid = Page_ClientValidate();
            if (!valid) {
                return;
            }
        }
        __doPostBack(callbackId, '');
    },
    raiseClicked: function() {

        var clientClick = this.get_OnClientClick();
        if (clientClick == null || clientClick == "") {
            this.invoke("click", null, this, this.onCallbackError, true);
        }
        else {
            var fn = eval(clientClick);
            fn.call();
        }
    },
    raiseMenuItemClicked : function(item) {
      
        var grid = this.get_Grid()
        var eventArgs = new ExtExtenders.GridEventArgs();
        var arguments = new Object();
        arguments.MenuClicked = { Id: item.Id };
        this.invoke(eventArgs.serialise("GridContextMenu", arguments), null, this, this.onCallbackError, true);
        
    }

}
ExtExtenders.ButtonExtenderBehavior.registerClass('ExtExtenders.ButtonExtenderBehavior', Sys.UI.Control);
if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 
