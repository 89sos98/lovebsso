using System;
using System.ComponentModel;
using System.Web.UI.Design;

namespace ExtExtenders
{
    /// <summary>
    /// Designer for the ExtButton
    /// </summary>
    public class ExtButtonDesigner : ControlDesigner
    {
        //private string _btnHtml="<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"x-btn-wrap\"><tbody><tr>"+
        //            "<td class=\"x-btn-left\"><i>&#160;</i></td><td class=\"x-btn-center\">"+
        //            "<em unselectable=\"on\"><button class=\"x-btn-text\" type=\"{1}\">{0}</button></em></td>"+
        //            "<td class=\"x-btn-right\"><i>&#160;</i></td>"+
        //            "</tr></tbody></table>";
        private ExtButton _component;

        /// <summary>
        /// Initializes the control designer and loads the specified component.
        /// </summary>
        /// <param name="component">The control being designed.</param>
        public override void Initialize(IComponent component)
        {
            _component = component as ExtButton;
            if (_component == null)
                throw new ArgumentException("Component must be an ExtButton control", "component");
            base.Initialize(component);
        }

        /// <summary>
        /// Retrieves the HTML markup that is used to represent the control at design time.
        /// </summary>
        /// <returns>
        /// The HTML markup used to represent the control at design time.
        /// </returns>
        public override string GetDesignTimeHtml()
        {
            return "<input style='width:" + _component.Width + "' type='button' value='" + _component.Text + "'/>";
                //String.Format(_btnHtml, _component.Text,"button");
        }
    }
}