/*
 * Ext.ux.grid.BufferedGridDragZone V0.1
 * Copyright(c) 2007, http://www.siteartwork.de
 * 
 * Licensed under the terms of the Open Source LGPL 3.0
 * http://www.gnu.org/licenses/lgpl.html
 *
 * @author Thorsten Suckow-Homberg <ts@siteartwork.de>
 */

Ext.namespace("Ext.ux.grid");Ext.ux.grid.BufferedGridDragZone=function(B,A){this.view=B.getView();Ext.ux.grid.BufferedGridDragZone.superclass.constructor.call(this,this.view.mainBody.dom,A);if(this.view.lockedBody){this.setHandleElId(Ext.id(this.view.mainBody.dom));this.setOuterHandleElId(Ext.id(this.view.lockedBody.dom))}this.scroll=false;this.grid=B;this.ddel=document.createElement("div");this.ddel.className="x-grid-dd-wrap";this.view.ds.on("beforeselectionsload",this.onBeforeSelectionsLoad,this);this.view.ds.on("selectionsload",this.onSelectionsLoad,this)};Ext.extend(Ext.ux.grid.BufferedGridDragZone,Ext.dd.DragZone,{ddGroup:"GridDD",isDropValid:true,getDragData:function(B){var A=Ext.lib.Event.getTarget(B);var D=this.view.findRowIndex(A);if(D!==false){var C=this.grid.selModel;if(!C.isSelected(D)||B.hasModifier()){C.handleMouseDown(this.grid,D,B)}return{grid:this.grid,ddel:this.ddel,rowIndex:D,selections:C.getSelections()}}return false},onInitDrag:function(B){this.view.ds.loadSelections(this.grid.selModel.getPendingSelections(true));var A=this.dragData;this.ddel.innerHTML=this.grid.getDragDropText();this.proxy.update(this.ddel)},onBeforeSelectionsLoad:function(){this.isDropValid=false;Ext.fly(this.proxy.el.dom.firstChild).addClass("x-dd-drop-waiting")},onSelectionsLoad:function(){this.isDropValid=true;this.ddel.innerHTML=this.grid.getDragDropText();Ext.fly(this.proxy.el.dom.firstChild).removeClass("x-dd-drop-waiting")},afterRepair:function(){this.dragging=false},getRepairXY:function(B,A){return false},onStartDrag:function(){},onEndDrag:function(A,B){},onValidDrop:function(A,B,C){this.hideProxy()},beforeInvalidDrop:function(A,B){}})
