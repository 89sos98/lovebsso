/*
 * Ext.ux.data.BufferedJsonReader V0.1
 * Copyright(c) 2007, http://www.siteartwork.de
 * 
 * Licensed under the terms of the Open Source LGPL 3.0
 * http://www.gnu.org/licenses/lgpl.html
 *
 * @author Thorsten Suckow-Homberg <ts@siteartwork.de>
 */
Ext.namespace("Ext.ux.data");Ext.ux.data.BufferedJsonReader=function(A,B){Ext.ux.data.BufferedJsonReader.superclass.constructor.call(this,A,B)};Ext.extend(Ext.ux.data.BufferedJsonReader,Ext.data.JsonReader,{readRecords:function(D){var B=this.meta;if(!this.ef&&B.versionProperty){this.getVersion=this.getJsonAccessor(B.versionProperty)}if(!this.__readRecords){this.__readRecords=Ext.ux.data.BufferedJsonReader.superclass.readRecords}var C=this.__readRecords.call(this,D);if(B.versionProperty){var A=this.getVersion(D);C.version=(A===undefined||A==="")?null:A}return C}})

