/*
 * Ext.ux.BufferedGridToolbar V1.0
 * Copyright(c) 2007, http://www.siteartwork.de
 * 
 * Licensed under the terms of the Open Source LGPL 3.0
 * http://www.gnu.org/licenses/lgpl.html
 *
 *
 * @author Thorsten Suckow-Homberg <ts@siteartwork.de>
 */

/**
 * @class Ext.ux.BufferedGridToolbar
 * @extends Ext.Toolbar
 * A specialized toolbar that is bound to a {@link Ext.ux.grid.BufferedGridView} 
 * and provides information about the indexes of the requested data and the buffer 
 * state.
 * @constructor
 * @param {Object} config
 */
Ext.namespace("Ext.ux");Ext.ux.BufferedGridToolbar=Ext.extend(Ext.Toolbar,{displayMsg:"Displaying {0} - {1} of {2}",emptyMsg:"No data to display",refreshText:"Refresh",initComponent:function(){Ext.ux.BufferedGridToolbar.superclass.initComponent.call(this);this.bind(this.view)},updateInfo:function(D,C,A){if(this.displayEl){var B=A==0?this.emptyMsg:String.format(this.displayMsg,D+1,D+C,A);this.displayEl.update(B)}},unbind:function(A){A.un("rowremoved",this.onRowRemoved,this);A.un("rowsinserted",this.onRowsInserted,this);A.un("beforebuffer",this.beforeBuffer,this);A.un("cursormove",this.onCursorMove,this);A.un("buffer",this.onBuffer,this);this.view=undefined},bind:function(A){A.on("rowremoved",this.onRowRemoved,this);A.on("rowsinserted",this.onRowsInserted,this);A.on("beforebuffer",this.beforeBuffer,this);A.on("cursormove",this.onCursorMove,this);A.on("buffer",this.onBuffer,this);this.view=A},onCursorMove:function(B,D,C,A){this.updateInfo(D,C,A)},onRowsInserted:function(B,C,A){this.updateInfo(B.rowIndex,Math.min(B.ds.totalLength,B.visibleRows),B.ds.totalLength)},onRowRemoved:function(B,C,A){this.updateInfo(B.rowIndex,Math.min(B.ds.totalLength,B.visibleRows),B.ds.totalLength)},beforeBuffer:function(B,C,E,D,A){this.loading.disable();this.updateInfo(E,D,A)},onBuffer:function(B,C,E,D,A){this.loading.enable();this.updateInfo(E,D,A)},onClick:function(A){switch(A){case"refresh":this.view.reset(true);break}},onRender:function(B,A){Ext.PagingToolbar.superclass.onRender.call(this,B,A);this.loading=this.addButton({tooltip:this.refreshText,iconCls:"x-tbar-loading",handler:this.onClick.createDelegate(this,["refresh"])});this.addSeparator();if(this.displayInfo){this.displayEl=Ext.fly(this.el.dom).createChild({cls:"x-paging-info"})}}})
