using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using ExtExtenders.Helpers;

[assembly: WebResource("ExtExtenders.MemberShip.LoginExtenderBehavior.js", "text/javascript")]

namespace ExtExtenders
{
    /// <summary>
    /// Class to extend a DropDownList
    /// </summary>
    [ToolboxBitmap(typeof (Login)), Designer(typeof (LoginDesigner))]
    public class ExtLogin : ExtScriptWebControlBase, INamingContainer, ICallbackEventHandler, IPostBackEventHandler
    {
        /// <summary>
        /// Menu item clicked
        /// </summary>
        private static readonly Object OnLoginClickedKey = new Object();

        /// <summary>
        /// Constructor
        /// </summary>
        public ExtLogin() : base(HtmlTextWriterTag.Div)
        {
            UserNameLabel = "User Name";
            PassWordLabel = "Password";
            ErrorMessage = "Invalid login or password";
            RememberMeLabel = "Remember me";
            Title = "Login";
            Width = 300;
            Height = 300;
        }

        /// <summary>
        /// The label for the user Name Control
        /// </summary>
        [DescribableProperty]
        public string UserNameLabel { get; set; }

        /// <summary>
        /// The Label for the password control
        /// </summary>
        [DescribableProperty]
        public string PassWordLabel { get; set; }

        /// <summary>
        /// The message that will show for a invalid login
        /// </summary>
        [DescribableProperty]
        public string ErrorMessage { get; set; }

        /// <summary>
        /// The title of the form
        /// </summary>
        [DescribableProperty]
        public string Title { get; set; }

        /// <summary>
        /// The label for the remember me checkbox
        /// </summary>
        [DescribableProperty]
        public string RememberMeLabel { get; set; }

        #region ICallbackEventHandler Members

        /// <summary>
        /// Returns the results of a callback event that targets a control.
        /// </summary>
        /// <returns>The result of the callback.</returns>
        public string GetCallbackResult()
        {
            return null;
        }

        /// <summary>
        /// Processes a callback event that targets a control.
        /// </summary>
        /// <param name="eventArgument">A string that represents an event argument to pass to the event handler.</param>
        public void RaiseCallbackEvent(string eventArgument)
        {
            RaisePostBackEvent(eventArgument);
        }

        #endregion

        #region IPostBackEventHandler Members

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="eventArgument"></param>
        public void RaisePostBackEvent(string eventArgument)
        {
            var jsSerialiser = new JavaScriptSerializer();
            var eventArgs = jsSerialiser.Deserialize<TreeEventArgs>(eventArgument);
            switch (eventArgs.EventName.ToLower())
            {
                case "loginclicked":
                    OnLoginClicked(jsSerialiser.Deserialize<LoginEventArgs>(eventArgs.Arguments));
                    break;

                default:
                    //Do nothing
                    break;
            }
        }

        #endregion

        /// <summary>
        /// Event to be fired when a node is inserted
        /// </summary>
        public event ValidadeLoginHandler LoginClicked
        {
            add { Events.AddHandler(OnLoginClickedKey, value); }
            remove { Events.RemoveHandler(OnLoginClickedKey, value); }
        }

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Load"></see> event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            Page.ClientScript.GetCallbackEventReference(this, "", "", "");
        }

        /// <summary>
        /// Raises the menu item clicked event
        /// </summary>
        /// <param name="e">The <see cref="T:ExtExtenders.ToolBarEventArgs"/> instance containing the event data.</param>
        protected virtual void OnLoginClicked(LoginEventArgs e)
        {
            var eventHandler = (ValidadeLoginHandler) Events[OnLoginClickedKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            var descriptor = new ScriptControlDescriptor(
                "ExtExtenders.LoginExtenderBehavior", ClientID);

            Util.DescribeProperties(this, descriptor);
            return new ScriptDescriptor[] {descriptor};
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptReference> GetScriptReferences()
        {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.MemberShip.LoginExtenderBehavior.js");

            return new[] {reference};
        }
    }
}