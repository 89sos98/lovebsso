
Type.registerNamespace('ExtExtenders');
ExtExtenders.LoginEventArgs = function() {
   
    ExtExtenders.LoginEventArgs.initializeBase(this);

}
ExtExtenders.LoginEventArgs.prototype = {
  
    serialise : function(eventName,arguments){
    /// <summary>
    /// Method used to prepare an event to be fired
    /// </summary>
    /// <param name="eventName" type="string">
    /// Name of the event to be fired
    /// </param>
    /// <param name="arguments" type="object">
    /// Object containing the parameters to be passed
    /// </param>
        return Sys.Serialization.JavaScriptSerializer.serialize(
                {
                    EventName: eventName,
                    Arguments: Sys.Serialization.JavaScriptSerializer.serialize
                        (arguments)
                });
    } 
}
ExtExtenders.LoginExtenderBehavior = function(element) {
   
    ExtExtenders.LoginExtenderBehavior.initializeBase(this, [element]);
      
}
ExtExtenders.LoginExtenderBehavior.prototype = {
    initialize: function() {
    
        ExtExtenders.LoginExtenderBehavior.callBaseMethod(this, 'initialize');
        Ext.QuickTips.init();
        //Ext.form.Field.prototype.msgTarget = 'side';
        this._AutoPostBack=true;
        var id=this.get_element().id;
         var simple = new Ext.Panel({
            labelWidth: 75, // label settings here cascade unless overridden
            frame:true,
            title:this.get_Title(),
            bodyStyle:'padding:5px 5px 0',
            width: 350,
            defaults: {width: 230},
            defaultType: 'textfield',
            layout:'form',
            frame:true,
            items: [{
                    fieldLabel: this.get_UserNameLabel(),
                    name: 'userName',
                    id:'userName',
                    allowBlank:false
                },{
                    fieldLabel: this.get_PassWordLabel(),
                    name: 'password',
                    id: 'password',
                    inputType :'password',
                    allowBlank:false
                },
                {
                    boxLabel: this.get_RememberMeLabel() ,
                    labelSeparator:'',
                    name: 'rememberMe',
                    id: 'rememberMe',
                    xtype :'checkbox',
                    labelWidth:100
                }
            ],

            buttons: [{
                text: 'Login',
                handler:this.perform_Login,
                scope:this
            }]
        });

        simple.render(Ext.get(id));
        $get("userName").focus();
        this.form=simple;
      
    },
    perform_Login: function(){
        
        if($get("userName").value ==""){
            return;
        }
        if($get("password").value ==""){
            return;
        }
        this.raiseLoginClicked();
        
    },
  
    errorCallback:function(error){
         Ext.Msg.alert('',error.get_message());
    },
    get_UserNameLabel:function(){
        return this._UserNameLabel;
    },
    set_UserNameLabel:function(value){
        this._UserNameLabel=value;
    },
    get_RememberMeLabel:function(){
        return this._RememberMeLabel;
    },
    set_RememberMeLabel:function(value){
        this._RememberMeLabel=value;
    },
    get_PassWordLabel:function(){
        return this._PassWordLabel;
    },
    set_PassWordLabel:function(value){
        this._PassWordLabel=value;
    },
    get_ErrorMessage:function(){
        return this._ErrorMessage;
    },
    set_ErrorMessage:function(value){
        this._ErrorMessage=value;
    },
    get_Title:function(){
        return this._Title;
    },
    set_Title:function(value){
        this._Title=value;
    },
    invoke :function( args, onComplete$delegate, context, onError$delegate ,async){
        var callbackId = this.get_element().id;
        callbackId = callbackId.replace(/_/g, "$");
        if (this._AutoPostBack) {                    
            __doPostBack(callbackId, args);
        }
        else {
            WebForm_DoCallback(callbackId, args, onComplete$delegate, context, onError$delegate, async);
        }        
    },
    raiseLoginClicked:function(){
        var eventArgs = new ExtExtenders.LoginEventArgs();
        var myArguments= new Object();
        myArguments.username=$get("userName").value;
        myArguments.password=$get("password").value;
        myArguments.rememberme=$get("rememberMe").checked;
       
        this.invoke(eventArgs.serialise("LoginClicked",myArguments), null, this, this.onCallbackError, true);
    }
}
ExtExtenders.LoginExtenderBehavior.registerClass('ExtExtenders.LoginExtenderBehavior',Sys.UI.Control);
if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 