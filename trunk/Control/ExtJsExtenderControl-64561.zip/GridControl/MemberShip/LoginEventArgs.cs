using System;

namespace ExtExtenders
{
    /// <summary>
    /// Event handler for the login control
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e">Arguments for the event</param>
    public delegate void ValidadeLoginHandler(Object sender, LoginEventArgs e);

    /// <summary>
    /// Event arguments for the menu item clicked event
    /// </summary>
    public class LoginEventArgs : EventArgs
    {
        /// <summary>
        /// The user name to validade the login
        /// </summary>
        public string username { get; set; }

        /// <summary>
        /// The password to validate the login
        /// </summary>
        public string password { get; set; }

        /// <summary>
        /// if the user should be remebered
        /// </summary>
        public bool rememberme { get; set; }
    }
}