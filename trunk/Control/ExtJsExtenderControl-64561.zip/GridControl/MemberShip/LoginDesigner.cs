// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Web.UI.Design;

namespace ExtExtenders
{
    /// <summary>
    /// Simple read-only designer for the yui control
    /// </summary>
    [SuppressMessage("Microsoft.Security", "CA2117:AptcaTypesShouldOnlyExtendAptcaBaseTypes",
        Justification = "Security handled by base class")]
    public class LoginDesigner : ControlDesigner
    {
        /// <summary>
        /// Reference to the YuiGrid control we're designing
        /// </summary>
        private ExtLogin _component;

        /// <summary>
        /// Initialize to make sure we're attached to an YuiGrid control
        /// </summary>
        /// <param name="component">Component</param>
        [SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters",
            Justification = "Assembly is not localized")]
        [SuppressMessage("Microsoft.Security", "CA2116:AptcaMethodsShouldOnlyCallAptcaMethods",
            Justification = "Security handled by base class")]
        public override void Initialize(IComponent component)
        {
            _component = component as ExtLogin;
            if (_component == null)
                throw new ArgumentException("Component must be an ExtLogin control", "component");
            base.Initialize(component);
        }

        /// <summary>
        /// Provides the markup that is used to render the control at design time when an error has occurred.
        /// </summary>
        /// <param name="e">The <see cref="T:System.Exception"></see> that was thrown.</param>
        /// <returns>
        /// The markup used to render the control at design time when an error has occurred.
        /// </returns>
        protected override string GetErrorDesignTimeHtml(Exception e)
        {
            var html = new StringBuilder();

            html.Append("<div style='width:" + _component.Width + ";height:" + _component.Height + "'>");
            html.Append(e.ToString());
            html.Append("</div>");
            return html.ToString();
        }

        /// <summary>
        /// Generates the markup that is used to render the control at design time.
        /// </summary>
        /// <returns>
        /// The markup used to render the control at design time.
        /// </returns>
        public override string GetDesignTimeHtml()
        {
            var html = new StringBuilder();
            html.Append("<div style=\"width: " + _component.Width + "px;\" class=\"x-panel\">");
            html.Append("<div class=\"x-panel-tl\"><div class=\"x-panel-tr\">");
            html.Append(
                "<div class=\"x-panel-tc\"><div style=\"-moz-user-select: none;\" class=\"x-panel-header x-unselectable\">");
            html.Append("<span id=\"ext-gen23\" class=\"x-panel-header-text\">" + _component.Title + "</span></div>");
            html.Append("</div></div></div><div class=\"x-panel-bwrap\"><div class=\"x-panel-ml\">");
            html.Append("<div class=\"x-panel-mr\"><div class=\"x-panel-mc\">");
            html.Append("<div style=\"padding: 5px 5px 0pt; width: 328px;\" class=\"x-panel-body\">");
            html.Append("<div class=\"x-form-item\" tabindex=\"-1\">");
            html.Append("<label for=\"userName\" style=\"width: 75px;\" class=\"x-form-item-label\">");
            html.Append(_component.UserNameLabel + ":</label><div class=\"x-form-element\" id=\"x-form-el-userName\"");
            html.Append(
                "style=\"padding-left: 80px;\"><input style=\"width: 222px;\" class=\"x-form-text x-form-field\"");
            html.Append("size=\"20\" autocomplete=\"off\" id=\"userName\" name=\"userName\" type=\"text\"></div>");
            html.Append("<div class=\"x-form-clear-left\"></div></div>");
            html.Append("<div class=\"x-form-item\" tabindex=\"-1\">");
            html.Append("<label for=\"password\" style=\"width: 75px;\" class=\"x-form-item-label\">" +
                        _component.PassWordLabel + ":</label>");
            html.Append("<div class=\"x-form-element\" id=\"x-form-el-password\" style=\"padding-left: 80px;\">");
            html.Append(
                "<input style=\"width: 222px;\" class=\"x-form-text x-form-field\" size=\"20\" autocomplete=\"off\" id=\"password\" name=\"password\" type=\"password\"></div>");
            html.Append("<div class=\"x-form-clear-left\"></div></div>");
            html.Append("<div class=\"x-form-item\" tabindex=\"-1\">");
            html.Append("<label for=\"rememberMe\" style=\"width: 75px;\" class=\"x-form-item-label\"></label>");
            html.Append("<div class=\"x-form-element\" style=\"padding-left: 80px;\">");
            html.Append("<div style=\"width: 230px;\" class=\"x-form-check-wrap\">");
            html.Append(
                "<input class=\"x-form-checkbox x-form-field\" autocomplete=\"off\" id=\"rememberMe\" name=\"rememberMe\" type=\"checkbox\">");
            html.Append("<label for=\"rememberMe\" class=\"x-form-cb-label\">" + _component.RememberMeLabel + "</label>");
            html.Append("</div></div><div class=\"x-form-clear-left\"></div></div></div></div></div></div>");
            html.Append("<div class=\"x-panel-bl\"><div class=\"x-panel-br\"><div class=\"x-panel-bc\">");
            html.Append("<div id=\"ext-gen13\" class=\"x-panel-footer\">");
            html.Append("<div class=\"x-panel-btns-ct\"><div class=\"x-panel-btns x-panel-btns-right\">");
            html.Append("<table cellspacing=\"0\"><tbody><tr><td class=\"x-panel-btn-td\">");
            html.Append("<table style=\"width: 75px;\" class=\"x-btn-wrap x-btn\" border=\"0\" cellpadding=\"0\"");
            html.Append("cellspacing=\"0\"><tbody><tr><td class=\"x-btn-left\"><i>&nbsp;</i></td>");
            html.Append("<td class=\"x-btn-center\"><em unselectable=\"on\"><button class=\"x-btn-text\"");
            html.Append("type=\"button\">Login</button></em></td><td class=\"x-btn-right\"><i>&nbsp;</i></td>");
            html.Append("</tr></tbody></table></td></tr></tbody></table><div class=\"x-clear\"></div>");
            html.Append("</div></div></div></div></div></div></div></div>");
            return html.ToString();
        }
    }
}