﻿using System;
using System.Collections;
using System.Text;

namespace ExtExtenders
{
    /// <summary>
    /// Container object intented to be used to store objects passed to the ExtJs.
    /// </summary>
    public class ExtDataContainer
    {
        /// <summary>
        /// Default constructor for ExtDataContainer
        /// </summary>
        public ExtDataContainer() { }
        private IEnumerable _records;
        /// <summary>
        /// Records object should contain enumerable data objects
        /// </summary>
        public IEnumerable Records 
        { 
            get
            {
                if(_records == null)
                    _records = new object[0];
                return _records;
            } 
            set
            {
                _records = value;
            }
        }
        /// <summary>
        /// Equals the total number of records contained in the super set of data represented. This may not be the same as records.count.
        /// </summary>
        public int TotalCount { get; set; }
    }
}
