
Type.registerNamespace('ExtExtenders');

ExtExtenders.PanelBehavior = function(element) {

    ExtExtenders.PanelBehavior.initializeBase(this, [element]);
}
ExtExtenders.PanelBehavior.prototype = {
    initialize: function() {
        ExtExtenders.PanelBehavior.callBaseMethod(this, 'initialize');
        var id=this.get_element().id;
        Ext.QuickTips.init();
        Ext.form.Field.prototype.msgTarget = 'side';
        var contentItems=eval(this._Contents);
        var objConfig={};
        
        if (this._Title!="" && this._Title!=null){
            objConfig.title=this._Title;
        }
        if (this._ErrorMessage!="" && this._ErrorMessage!=null){
            objConfig.title=this._ErrorMessage;
        }
        objConfig.collapsible=this._Collapsible;
        objConfig.collapsed=false;
        objConfig.width=this._Width;
        objConfig.renderTo = id;
        objConfig.items = contentItems;
        
        //�Ƿ���ʾ������
        //objConfig.header = true;
        
        objConfig.autoHeight=true;
        objConfig.frame = this._Frame;
        //objConfig.draggable=true;
        var myPanel = new Ext.Panel(objConfig);
        //myPanel.disable();
        myPanel.render();
        
        if (this._FocusControlId!="" && this._FocusControlId!=null){
            var f = Ext.get(this._FocusControlId); 
            f.focus.defer(600, f); 
        }
    },
    get_Contents:function(){
        return this._Contents;
    },
    set_Contents:function(value){
        this._Contents=value;
    },
    get_Title:function(){
        return this._Title;
    },
    set_Title:function(value){
        this._Title=value;
    },
    get_ErrorMessage:function(){
        return this._ErrorMessage;
    },
    set_ErrorMessage:function(value){
        this._ErrorMessage=value;
    },
    get_Frame:function(){
        return this._Frame;
    },
    set_Frame:function(value){
        this._Frame=value;
    },
    get_Collapsible:function(){
        return this._Collapsible;
    },
    set_Collapsible:function(value){
        this._Collapsible=value;
    },
    get_FocusControlId:function(){
        return this._FocusControlId;
    },
    set_FocusControlId:function(value){
        this._FocusControlId=value;
    },
    get_Width:function(){
        return this._Width;
    },
    set_Width:function(value){
        this._Width=value;
    }
}
ExtExtenders.PanelBehavior.registerClass('ExtExtenders.PanelBehavior',Sys.UI.Control);
if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded();
