using System;
using System.ComponentModel;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web;
using System.Text;
using System.Web.Script.Serialization;
using ExtExtenders.Helpers;

[assembly: WebResource("ExtExtenders.Panel.PanelBehavior.js", "text/javascript")]
namespace ExtExtenders
{
    /// <summary>
    /// Class to extend a Control 
    /// </summary>
    [ToolboxBitmap(typeof(System.Web.UI.WebControls.Panel))]
    public class ExtPanelExtender : Panel, IScriptControl
    {
        private ClientScriptProxy ClientScriptProxy;
        private ScriptManager sm;
        private ITemplate _contentTemplate;

        private string _TargetControlId;
        /// <summary>
        /// Id of the control that will be transformed
        /// into a resizable element
        /// </summary>
        public string TargetControlId
        {
            get { return _TargetControlId; }
            set { _TargetControlId = value; }
        }

        private string _FocusControlId;
        /// <summary>
        /// ��ʼ��ʱ���ͣ��λ��
        /// </summary>
        public string FocusControlId
        {
            get { return _FocusControlId; }
            set { _FocusControlId = value; }
        }

        private string _Width;
        //�˴�û�ж����int������Ϊ��Ҫ֧��100%
        /// <summary>
        /// Panel�Ŀ��ȣ�����Ϊһ������Ŀ��ȣ�Ҳ������'100%'
        /// </summary>
        public string Width
        {
            get
            {
                return _Width;
            }
            set
            {
                _Width = value;
            }
        }

        private string _Title;
        /// <summary>
        /// Panel�ı���
        /// </summary>
        public string Title
        {
            get
            {
                return _Title;
            }
            set
            {
                _Title = value;
            }
        }

        private string _ErrorMessage;
        /// <summary>
        /// Panel�ı���
        /// </summary>
        public string ErrorMessage
        {
            get
            {
                return _ErrorMessage;
            }
            set
            {
                _ErrorMessage = "<font color =red>" + value + "</font>";
            }
        }

        private bool _Collapsible;
        /// <summary>
        /// ȷ��Panel�Ƿ��������
        /// </summary>
        public bool Collapsible
        {
            get
            {
                return _Collapsible;
            }
            set
            {
                _Collapsible = value;
            }
        }

        private bool _Frame;
        /// <summary>
        /// �Ƿ���ʾFrame
        /// </summary>
        public bool Frame
        {
            get
            {
                return _Frame;
            }
            set
            {
                _Frame = value;
            }
        }

        /// <summary>
        /// Gets or sets the content template.
        /// </summary>
        /// <value>The content template.</value>
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateInstance(TemplateInstance.Single)]
        [Browsable(false)]
        [MergableProperty(false)]
        public ITemplate ContentTemplate
        {
            get { return _contentTemplate; }
            set { _contentTemplate = value; }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public ControlCollection Contents
        {
            get { return (ControlCollection)Controls; }
        }

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Init"></see> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Reliability", "CA2000:DisposeObjectsBeforeLosingScope", Justification = "Local c is handed off to Controls collection")]
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            ClientScriptProxy = ClientScriptProxy.Current;
            if (_contentTemplate != null)
            {
                Control c = new Control();
                _contentTemplate.InstantiateIn(c);
                Controls.Add(c);
            }
        }
        
        /// <summary>
        /// Raises the pre render event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.EventArgs"/> instance containing the event data.</param>
        protected override void OnPreRender(EventArgs e)
        {
			base.OnPreRender(e);
			string resource = Page.ClientScript.GetWebResourceUrl(GetType(), "ExtExtenders.yui-ext.css");
			string csslink = "<link href='" + resource + "' rel='stylesheet' type='text/css' />";
			Page.Header.Controls.Add(new LiteralControl(csslink));
          
			//render the yui-ext scripts
			this.ClientScriptProxy.RegisterClientScriptResource(this,typeof(YUI), "ExtExtenders.yui.js");
			this.ClientScriptProxy.RegisterClientScriptResource(this,typeof(YUI_ext), "ExtExtenders.yui-ext.js");
			this.ClientScriptProxy.RegisterClientScriptResource(this,typeof(ext_yui_adapter), "ExtExtenders.ext-yui-adapter.js");

            if (!this.DesignMode)
            {
                // Test for ScriptManager and register if it exists
                sm = ScriptManager.GetCurrent(Page);

                if (sm == null)
                    throw new HttpException("A ScriptManager control must exist on the current page.");

                sm.RegisterScriptControl(this);
            }
        }
        /// <summary>
        /// Renders the control to the specified HTML writer.
        /// </summary>
        /// <param name="writer">The <see cref="T:System.Web.UI.HtmlTextWriter"></see> object that receives the control content.</param>
        protected override void Render(HtmlTextWriter writer)
        {
            if (!this.DesignMode)
                sm.RegisterScriptDescriptors(this);
            base.Render(writer);
        }

        #region IScriptControl Members

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        public System.Collections.Generic.IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            ScriptControlDescriptor descriptor = new ScriptControlDescriptor(
                                       "ExtExtenders.PanelBehavior", this.ClientID);

            StringBuilder sb = new StringBuilder();
            sb.Append("[");
            sb.Append("{");
            sb.Append("contentEl:'" + this.TargetControlId + "'");
            sb.Append("}");
            sb.Append("]");

            descriptor.AddProperty("Contents", sb.ToString());
            descriptor.AddProperty("FocusControlId", FocusControlId);
            descriptor.AddProperty("Width", Width);
            descriptor.AddProperty("Title", Title);
            descriptor.AddProperty("ErrorMessage", ErrorMessage);
            descriptor.AddProperty("Collapsible", Collapsible);
            descriptor.AddProperty("Frame", Frame);
            return new ScriptDescriptor[] { descriptor };
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        public System.Collections.Generic.IEnumerable<ScriptReference> GetScriptReferences()
        {
            ScriptReference reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(this.GetType(),
                                  "ExtExtenders.Panel.PanelBehavior.js");

            return new ScriptReference[] { reference };
        }

        #endregion
    }
}
