// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.


Type.registerNamespace("ExtExtenders");
ExtExtenders.BorderLayout = function(element) {
    ExtExtenders.BorderLayout.initializeBase(this, [element]);
}
ExtExtenders.BorderLayout.prototype = {
  
   get_North:function(){
    return this._North;
   },
   set_North:function(value){
     this._North=value;
   },
   get_South:function(){
    return this._South;
   },
   set_South:function(value){
     this._South=value;
   },
   get_West:function(){
    return this._West;
   },
   set_West:function(value){
     this._West=value;
   },
   get_East:function(){
    return this._East;
   },
   set_East:function(value){
     this._East=value;
   },
   get_Center:function(){
    return this._Center;
   },
   set_Center:function(value){
    this._Center=value;
   },
  
   get_Region:function(id_region,nm_region){
     if(id_region ==null || id_region==""){
        return null;
     }

     var rg=$find(id_region);
     if(rg==null){
        return null;
     }
     if(rg){
          
          if(nm_region=="north"){
           
            return new Ext.BoxComponent(
                                    rg.ToExtRegion(nm_region)
                                    )
            
            return;
          }
          
          if(rg.get_Tabs() ==null){
                
                 return rg.ToExtRegion(nm_region);
       
          }
          else{
             
                return new Ext.TabPanel({
                                 deferredRender:false,
                                 activeTab:0,
                                 tabPosition:'top',
                                 items:rg.getTabItems(),
                                 region:nm_region,
                                 split:rg._split
                                }
                           )
                
          }
     }
     
     
   },
   initialize : function() {
        ExtExtenders.BorderLayout.callBaseMethod(this, "initialize");
     
        var id=this.get_element().id;
        var el=Ext.get(id);
    
        
        //TODO -- Layout Regions have to be first on page 
        var north=this.get_Region(this.get_North(),'north');
        var south=this.get_Region(this.get_South(),'south');
        var west=this.get_Region(this.get_West(),'west');
        var east=this.get_Region(this.get_East(),'east');
        var center=this.get_Region(this.get_Center(),'center');
        this.items=[];
        if(north){
            this.items.push(north);
        }
        if(south){
            this.items.push(south);
        }
        if(west){
            this.items.push(west);
        }
        if(east){
            this.items.push(east);
        }
        if(center){
            this.items.push(center);
        }
        var viewport = new Ext.FormViewport({
            layout:'border',
            items:this.items
            }
        );
            
        
    }
}
ExtExtenders.BorderLayout.registerClass("ExtExtenders.BorderLayout", Sys.UI.Behavior);


//LayoutRegion
ExtExtenders.LayoutRegion = function(element) {
    ExtExtenders.LayoutRegion.initializeBase(this, [element]);

}
ExtExtenders.LayoutRegion.prototype = {

   get_titlebar:function(){
    return this._titlebar;
   },
   set_titlebar:function(value){
    this._titlebar=value;
   },
   get_tabPosition:function(){
    return this._tabPosition;
   },
   set_tabPosition:function(value){
    this._tabPosition=value;
   },
   get_Tabs:function(){
    return this._Tabs;
   },
   set_Tabs:function(value){
     this._Tabs=value;
   },
   get_split:function(){
    return this._split;
   },
   set_split:function(value){
     this._split=value;
   },
   get_initialSize:function(){
    return this._initialSize;
   },
   set_initialSize:function(value){
     this._initialSize=value;
   },
   get_minSize:function(){
    return this._minSize;
   },
   set_minSize:function(value){
     this._minSize=value;
   },
   get_maxSize:function(){
    return this._maxSize;
   },
   set_maxSize:function(value){
     this._maxSize=value;
   },
   get_collapsible:function(){
    return this._collapsible;
   },
   set_collapsible:function(value){
     this._collapsible=value;
   },
   get_title:function(){
     return this._title;
   },
   set_title:function(value){
        this._title=value;
   },
   getTabItems:function(){
        
        var tabItems=[];
        var vetTabs=this.get_Tabs().split(',');
        var vetTitles=this.get_title().split(',');
        tabItems.push({contentEl:this.get_element().id,title:vetTitles[0]});
        for(var i=0;i<vetTabs.length;i++){
            tabItems.push({contentEl:vetTabs[i],title:vetTitles[i+1]});
        }
        return tabItems;
   },
   /*
     Returns a compatible object 
     with the ExtJs
   */
   ToExtRegion:function(rg_name){
    
     var objRet= {};
     for(var p in this){
         if(typeof this[p]!="function" && p !="_id"){
            objRet[p.replace("_","")]=this[p];
         }
     }
    
     objRet.region=rg_name;
 
     var id=this.get_element().id;
     if(rg_name=="north"){
        objRet.el=id;
     }
     else{
        objRet.contentEl=id;
     }
     
 
     //objRet.frame=true;
     switch(rg_name){
        case "south":
        case "north":
            objRet.height=objRet.initialSize;
            break;
        case "east":
        case "west":
            objRet.width=objRet.initialSize;
            objRet.autoHeight=true;
            break;
     }
  
     return objRet;
   }
 
      
}
ExtExtenders.LayoutRegion.registerClass("ExtExtenders.LayoutRegion",  Sys.UI.Behavior);
if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 