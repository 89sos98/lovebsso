using System;
using System.Collections.Generic;
using System.Reflection;
using System.Web.UI;
using ExtExtenders.Helpers;

namespace ExtExtenders
{
    /// <summary>
    /// Adds properties to an asp.net panel
    /// </summary>
    [ParseChildren(true)]
    public class LayoutRegion : ExtScriptControlBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="T:LayoutRegion"/> class.
        /// </summary>
        public LayoutRegion()
        {
            split = true;
            maxSize = int.MaxValue;
            minSize = 0;
        }

        /// <summary>
        /// The control where the region will be applied to
        /// </summary>
        public string TargetControlID { get; set; }

        /// <summary>
        /// If the region is splited
        /// </summary>
        public bool split { get; set; }

        /// <summary>
        /// Gets or sets the initial size.
        /// </summary>
        /// <value>The initial size.</value>
        public int initialSize { get; set; }

        /// <summary>
        /// Minimun size of the region
        /// </summary>
        public int minSize { get; set; }

        /// <summary>
        /// Maximun size of the region
        /// </summary>
        public int maxSize { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="T:LayoutRegion"/> is collapsible.
        /// </summary>
        /// <value><c>true</c> if collapsible; otherwise, <c>false</c>.</value>
        public bool collapsible { get; set; }

        /// <summary>
        /// Gets or sets the title for the region
        /// </summary>
        /// <value>The title.</value>
        public string title { get; set; }

        /// <summary>
        /// Tabs (other then TargetControlId)comma sepparated
        /// </summary>
        public string Tabs { get; set; }

        /// <summary>
        /// Position  of the tab
        /// </summary>
        public string tabPosition { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="T:LayoutRegion"/> has a titlebar.
        /// </summary>
        /// <value><c>true</c> if has a titlebar; otherwise, <c>false</c>.</value>
        public bool titlebar { get; set; }

        #region IScriptControl Members

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            var descriptor = new ScriptBehaviorDescriptor(
                "ExtExtenders.LayoutRegion", FindControl(TargetControlID).ClientID);

            Type t = GetType();
            //properties that will be serialized
            string[] propsToSerialize = {
                                            "split", "initialSize", "minSize",
                                            "maxSize", "collapsible", "title",
                                            "Tabs", "tabPosition", "titlebar"
                                        };

            foreach (string prop in propsToSerialize)
            {
                PropertyInfo p = t.GetProperty(prop);
                if (p == null)
                {
                    throw new Exception(prop);
                }
                descriptor.AddProperty(p.Name, p.GetValue(this, null));
            }
            descriptor.AddProperty("id", ID);
            return new ScriptDescriptor[] {descriptor};
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptReference> GetScriptReferences()
        {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.BorderLayout.Borderlayout.js");

            return new[] {reference};
        }

        #endregion
    }
}