// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.


using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ExtExtenders
{
    /// <summary>
    /// Collection of TabPanels
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1035:ICollectionImplementationsHaveStronglyTypedMembers", Justification = "Unnecessary for this specialized class")]
    public class ContentPanelCollection : ControlCollection
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="T:TabPanelCollection"/> class.
        /// </summary>
        /// <param name="owner">The ASP.NET server control that the control collection is created for.</param>
        /// <exception cref="T:System.ArgumentException">Occurs if the owner parameter is null. </exception>
        public ContentPanelCollection(Control owner)
            : base(owner)
        {
        }

        /// <summary>
        /// Adds the specified <see cref="T:System.Web.UI.Control"></see> object to the collection.
        /// </summary>
        /// <param name="child">The <see cref="T:System.Web.UI.Control"></see> to add to the collection.</param>
        /// <exception cref="T:System.ArgumentNullException">Thrown if the child parameter does not specify a control. </exception>
        /// <exception cref="T:System.Web.HttpException">Thrown if the <see cref="T:System.Web.UI.ControlCollection"></see> is read-only. </exception>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", Justification = "Assembly is not localized")]
        public override void Add(Control child)
        {
            if (!(child is Panel))
            {
                throw new ArgumentException("ContentPanelCollection can only contain colModel controls.");
            }
            base.Add(child);
        }

        /// <summary>
        /// Adds the specified <see cref="T:System.Web.UI.Control"></see> object to the collection at the specified index location.
        /// </summary>
        /// <param name="index">The location in the array at which to add the child control.</param>
        /// <param name="child">The <see cref="T:System.Web.UI.Control"></see> to add to the collection.</param>
        /// <exception cref="T:System.ArgumentNullException">The child parameter does not specify a control. </exception>
        /// <exception cref="T:System.Web.HttpException">The <see cref="T:System.Web.UI.ControlCollection"></see> is read-only. </exception>
        /// <exception cref="T:System.ArgumentOutOfRangeException">The index parameter is less than zero or greater than the <see cref="P:System.Web.UI.ControlCollection.Count"></see> property. </exception>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", Justification = "Assembly is not localized")]
        public override void AddAt(int index, Control child)
        {
            if (!(child is Panel))
            {
                throw new ArgumentException("ContentPanelCollection can only contain colModel controls.");
            }
            base.AddAt(index, child);
        }

        /// <summary>
        /// Gets the <see cref="T:ColModel"/> at the specified index.
        /// </summary>
        /// <value></value>
        public new Panel this[int index]
        {
            get { return (Panel)base[index]; }
        }
    }
}
