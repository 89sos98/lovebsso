using System;
using System.Collections.Generic;
using System.Reflection;
using System.Web.UI;
using ExtExtenders.Helpers;

[assembly: WebResource("ExtExtenders.BorderLayout.Borderlayout.js", "text/javascript")]

namespace ExtExtenders
{
    /// <summary>
    /// Class to transform BorderLayout into a control
    /// </summary>
    public class LayoutManager : ExtScriptControlBase
    {
        #region Properties

        /// <summary>
        /// Id of the control that will be extended
        /// </summary>
        public string TargetControlId { get; set; }

        /// <summary>
        ///   Id of the LayoutRegion that is in the north region
        /// </summary>
        public string North { get; set; }

        /// <summary>
        /// Id of the LayoutRegion that is in the South region
        /// </summary>
        public string South { get; set; }

        /// <summary>
        /// Id of the LayoutRegion that is in the West region
        /// </summary>
        public string West { get; set; }

        /// <summary>
        /// Id of the LayoutRegion that is in the East region
        /// </summary>
        public string East { get; set; }

        /// <summary>
        /// Id of the LayoutRegion that is in the East region
        /// </summary>
        public string Center { get; set; }

        #endregion

        #region IScriptControl Members

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            var descriptor = new ScriptBehaviorDescriptor(
                "ExtExtenders.BorderLayout", FindControl(TargetControlId).ClientID);


            Type t = GetType();
            //properties that will be serialized
            string[] propsToSerialize = {
                                            "North", "South", "West",
                                            "East", "Center"
                                        };
            foreach (string prop in propsToSerialize)
            {
                PropertyInfo p = t.GetProperty(prop);
                if (p == null)
                {
                    throw new Exception(prop);
                }
                descriptor.AddProperty(p.Name, p.GetValue(this, null));
            }
            return new ScriptDescriptor[] {descriptor};
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptReference> GetScriptReferences()
        {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.BorderLayout.BorderLayout.js");

            return new[] {reference};
        }

        #endregion
    }
}