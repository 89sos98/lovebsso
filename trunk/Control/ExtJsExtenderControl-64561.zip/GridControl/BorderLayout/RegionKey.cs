using System;
using System.Collections.Generic;
using System.Text;

namespace ExtExtenders
{
    /// <summary>
    /// Enum for possible layout regions
    /// </summary>
    public enum RegionKey
    {
        /// <summary>
        /// Represents north region
        /// </summary>
       North=0,
        /// <summary>
        /// Represents south
        /// </summary>
       South=1,
       /// <summary>
       /// Represents west
       /// </summary>
       West=2,
       /// <summary>
       /// Represents East
       /// </summary>
       East=3
    }
}
