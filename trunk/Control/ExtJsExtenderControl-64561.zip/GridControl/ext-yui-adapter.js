/*
* Code that will be used globally
* 
*/
Array.prototype.HasElement=function(element){
    var arrTmp=this;
    for(i=0;i< arrTmp.length;i++){
        if(arrTmp[i]==element){
            return true;
        }
    }
    return false;
}
String.prototype.replaceAll=function(pstrProcura,pstrNovo){
    return this.replace(new RegExp(pstrProcura, "gi"), pstrNovo);
}
/*
    function to store options for the store
    without loading the data
*/
Ext.data.Store.prototype.firstLoad=function(options){
      
        options = options || {};
        if(this.fireEvent("beforeload", this, options) !== false){
            this.storeOptions(options);
           
            return true;
        } else {
          return false;
        }
}
/*
    Override to make the paging toolbar work
    with data loaded
*/
Ext.PagingToolbar.prototype.onLoad = function(store, r, o){
        if(!this.rendered){
            this.dsLoaded = [store, r, o];
            return;
        }
       if (!o.params){
        o=this.store.lastOptions;
       }
       this.cursor = o.params ? o.params[this.paramNames.start] : 0;
       var d = this.getPageData(), ap = d.activePage, ps = d.pages;

       this.afterTextEl.el.innerHTML = String.format(this.afterPageText, d.pages);
       this.field.dom.value = ap;
       this.first.setDisabled(ap == 1);
       this.prev.setDisabled(ap == 1);
       this.next.setDisabled(ap == ps);
       this.last.setDisabled(ap == ps);
       this.loading.enable();
       this.updateInfo();
    }

/*form viewport*/ 
    
Ext.FormViewport = Ext.extend(Ext.Container, {
    initComponent : function() {
        Ext.FormViewport.superclass.initComponent.call(this);
        document.getElementsByTagName('html')[0].className += ' x-viewport';
        this.el = Ext.get(document.forms[0]);
        this.el.setHeight = Ext.emptyFn;
        this.el.setWidth = Ext.emptyFn;
        this.el.setSize = Ext.emptyFn;
        this.el.dom.scroll = 'no';
        this.allowDomMove = false;
        this.autoWidth = true;
        this.autoHeight = true;
        Ext.EventManager.onWindowResize(this.fireResize, this);
        this.renderTo = this.el;
    },

    fireResize : function(w, h){
        this.fireEvent('resize', this, w, h, w, h);
    }
});
Ext.reg('FormViewport', Ext.FormViewport);




Ext.BLANK_IMAGE_URL = '<%=WebResource("ExtExtenders.images.default.s.gif")%>'; 

//////////////////////////
// MS Json Reader is an Extention to JsonReader that calls JavaScriptSerializer.deserialize rather than eval(). 
// This fixes many issues most notably date realated issues.
//
// By Don Isbell & Mark Cook
//////////////////////////
Ext.data.MSJsonReader = function(meta, recordType){
    meta = meta || {};
    Ext.data.MSJsonReader.superclass.constructor.call(this, meta, recordType || meta.fields);
};
Ext.extend(Ext.data.MSJsonReader,Ext.data.JsonReader, {
    read : function(response){
        var json = response.responseText;
        var o = json;
        if(typeof(json) == 'string'){
            o = Sys.Serialization.JavaScriptSerializer.deserialize(json);
        }
        if(!o) {
            throw {message: "MSJsonReader.read: Json object not found"};
        }
        return this.readRecords(o);
    }
});
Ext.data.HttpProxy.prototype.load = function(params, reader, callback, scope, arg) {
      if (this.fireEvent("beforeload", this, params) !== false) {
        var o = {
            params: params || {},
            request: {
                callback: callback,
                scope: scope,
                arg: arg
            },
            reader: reader,
            callback: this.loadResponse,
            scope: this
        };
        if (this.useAjax) {
            Ext.applyIf(o, this.conn);
            if (this.activeRequest) {
                Ext.Ajax.abort(this.activeRequest);
            }
            reader.grid.raisePageIndexChanged(o,this);
        } else {
            this.conn.request(o);
        }
    } else {
        callback.call(scope || this, null, arg, false);
    }
}