﻿Ext.tree.TreePanel.prototype.toJsonString=function(){
  var rtNode=this.getRootNode();
  this.arrNodes=[];
  this.arrNodes.push(rtNode.attributes);//include the rootnode
  this.processChildren(rtNode);
  return Ext.encode(this.arrNodes);
}
/*
    Recursive function 
    sweeps the tree in all levels
*/
Ext.tree.TreePanel.prototype.processChildren=function(node){
   
    node.eachChild(
            function(node){
                 node.attributes.loader="";
                 this.arrNodes.push(node.attributes);
                 this.processChildren(node)
            },this);
 }

/*
 * Copyright(c) 2006-2007, Rodrigo Diniz
 * 
 * http://www.extendersamples.qsh.eu
 */

/**
 * @class Ext.tree.WebserviceTreeLoader
 */
 Ext.tree.WebserviceTreeLoader = function(config){
    this.baseParams = {};
    this.requestMethod = "POST";
    Ext.apply(this, config);

    this.addEvents(
        "beforeload",
        "load",
        "loadexception"
    );

    Ext.tree.WebserviceTreeLoader.superclass.constructor.call(this);
};

Ext.extend(Ext.tree.WebserviceTreeLoader, Ext.util.Observable, {

    uiProviders: {},
    clearOnLoad: true,
    addEvents: function(o) {
        if (!this.events) {
            this.events = {};
        }
        if (typeof o == 'string') {
            for (var i = 0, a = arguments, v; v = a[i]; i++) {
                if (!this.events[a[i]]) {
                    o[a[i]] = true;
                }
            }
        } else {
            Ext.applyIf(this.events, o);
        }
    },
    load: function(node, callback) {

        if (this.clearOnLoad) {
            while (node.firstChild) {
                node.removeChild(node.firstChild);
            }
        }
        if (this.doPreload(node)) { // preloaded json children
            if (typeof callback == "function") {
                callback();
            }
        } else if (this._WebServicePath || this.url) {
            this.requestData(node, callback);
        }
    },

    doPreload: function(node) {
        if (node.attributes.children) {
            if (node.childNodes.length < 1) { // preloaded?
                var cs = node.attributes.children;
                node.beginUpdate();
                for (var i = 0, len = cs.length; i < len; i++) {
                    var cn = node.appendChild(this.createNode(cs[i]));
                    if (this.preloadChildren) {
                        this.doPreload(cn);
                    }
                }
                node.endUpdate();
            }
            return true;
        } else {
            return false;
        }
    },

    getParams: function(node) {
        var buf = [], bp = this.baseParams;
        for (var key in bp) {
            if (typeof bp[key] != "function") {
                buf.push(encodeURIComponent(key), "=", encodeURIComponent(bp[key]), "&");
            }
        }
        buf.push("node=", encodeURIComponent(node.id));
        return buf.join("");
    },

    requestData: function(node, callback) {

        if (this.fireEvent("beforeload", this, node, callback) !== false) {
            var params = {};
            params.node = node.id;
            this.node = node;
            var userContext = { callback: callback, node: node, scope: this }
            this.callback = callback;
            Sys.Net.WebServiceProxy.invoke(this._WebServicePath, this._WebServiceMethod, false, params, Function.createDelegate(this, this.handleResponse), Function.createDelegate(this, this.handleFailure), userContext);
        } else {
            // if the load is cancelled, make sure we notify
            // the node that we are done
            if (typeof callback == "function") {
                callback();
            }
        }
    },

    isLoading: function() {
        return this.transId ? true : false;
    },

    abort: function() {
        if (this.isLoading()) {
            Ext.Ajax.abort(this.transId);
        }
    },
    createNode: function(attr) {

        if (this.baseAttrs) {
            Ext.applyIf(attr, this.baseAttrs);
        }
        if (this.applyLoader !== false) {
            attr.loader = this;
        }
        if (typeof attr.uiProvider == 'string') {
            attr.uiProvider = this.uiProviders[attr.uiProvider] || eval(attr.uiProvider);
        }
        return (attr.leaf ?
                        new Ext.tree.TreeNode(attr) :
                        new Ext.tree.AsyncTreeNode(attr));
    },

    processResponse: function(response) {

        var node = this.node;
        var callback = this.callback;
        var json = response;
        try {
           
            var o = json;
            node.beginUpdate();
            for (var i = 0, len = o.length; i < len; i++) {
                var n = this.createNode(o[i]);
                if (n) {
                    node.appendChild(n);
                }
            }
            //node.expanded = true;
            node.endUpdate();
            if (typeof callback == "function") {
                callback(this, node);
            }
        } catch (e) {
            this.handleFailure(response);
        }
    },

    handleResponse: function(response) {

        this.transId = false;
        var a = response.argument;
        this.processResponse(response);
        this.fireEvent("load", this, this.node, response);
    },

    handleFailure: function(response) {
        this.transId = false;
        var a = response.argument;
        this.fireEvent("loadexception", this, a.node, response);
        if (typeof this.callback == "function") {
            this.callback(this, this.node);
        }
    }
});

