// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Web.UI;
using ExtExtenders.Helpers;

[assembly: WebResource("ExtExtenders.Resizable.ResizableControlBehavior.js", "text/javascript")]

namespace ExtExtenders
{
    /// <summary>
    /// Class to Extend any control into a resizable element
    /// </summary>
    [ToolboxBitmap("ExtExtenders.Resisable.ResizableControl.ico")]
    public class ResizableControlExtender : ExtScriptControlBase
    {
        private const int MaximumValue = 100000;

        /// <summary>
        /// Initializes a new instance of the <see cref="T:ResizableControlExtender"/> class.
        /// </summary>
        public ResizableControlExtender()
        {
            MaximumHeight = int.MaxValue;
            MaximumWidth = int.MaxValue;
            handles = "all";
        }

        /// <summary>
        /// Id of the control that will be transformed
        /// into a resizable element
        /// </summary>
        public string TargetControlId { get; set; }

        /// <summary>
        /// Gets or sets the minimum width of the resizable.
        /// </summary>
        /// <value>The minimum width.</value>
        [DefaultValue(0)]
        public int MinimumWidth { get; set; }

        /// <summary>
        /// Gets or sets the minimum height.
        /// </summary>
        /// <value>The minimum height.</value>
        [DefaultValue(0)]
        public int MinimumHeight { get; set; }

        /// <summary>
        /// Gets or sets the maximum width.
        /// </summary>
        /// <value>The maximum width.</value>
        [DefaultValue(MaximumValue)]
        public int MaximumWidth { get; set; }

        /// <summary>
        /// Gets or sets the maximum height.
        /// </summary>
        /// <value>The maximum height.</value>
        [DefaultValue(MaximumValue)]
        public int MaximumHeight { get; set; }

        /// <summary>
        /// If the control is also draggable 
        /// </summary>
        public bool Draggable { get; set; }

        /// <summary>
        /// String consisting of the resize handles to display (defaults to false)
        ///<example>
        /// Value   Description
        ///    ------  -------------------
        ///     'n'     north
        ///     's'     south
        ///      'e'     east
        ///      'w'     west
        ///      'nw'    northwest
        ///      'sw'    southwest
        ///      'se'    southeast
        ///      'ne'    northeast
        ///     'all'   all
        /// </example>
        /// </summary>
        public string handles { get; set; }

        /// <summary>
        /// True to ensure that the resize handles are always visible, 
        /// false to display them only when the user mouses over the 
        /// resizable borders
        /// </summary>
        public bool pinned { get; set; }

        /// <summary>
        /// True to preserve the original ratio
        /// between height and width during resize (defaults to false)
        /// </summary>
        public bool preserveRatio { get; set; }

        /// <summary>
        /// True for transparent handles.
        /// </summary>
        public bool transparent { get; set; }

        /// <summary>
        /// True to wrap an element with a div if needed 
        /// (required for textareas and images, defaults to false)
        /// </summary>
        public bool wrap { get; set; }

        /// <summary>
        /// If the resizing is dynamic
        /// </summary>
        public bool dynamic { get; set; }

        #region IScriptControl Members

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            var descriptor = new ScriptBehaviorDescriptor(
                "ExtExtenders.ResizableControlBehavior", FindControl(TargetControlId).ClientID);

            Type t = GetType();
            //properties that will be serialized
            string[] propsToSerialize = {
                                            "dynamic", "wrap", "transparent",
                                            "preserveRatio", "pinned", "handles",
                                            "Draggable", "MaximumHeight", "MaximumWidth",
                                            "MinimumHeight", "MinimumWidth"
                                        };
            foreach (string prop in propsToSerialize)
            {
                PropertyInfo p = t.GetProperty(prop);
                if (p == null)
                {
                    throw new Exception(prop);
                }
                descriptor.AddProperty(p.Name, p.GetValue(this, null));
            }

            descriptor.AddProperty("id",
                                   ID);
            return new ScriptDescriptor[] {descriptor};
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptReference> GetScriptReferences()
        {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.Resizable.ResizableControlBehavior.js");

            return new[] {reference};
        }

        #endregion
    }
}