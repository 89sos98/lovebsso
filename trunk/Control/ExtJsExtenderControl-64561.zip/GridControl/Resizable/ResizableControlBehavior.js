// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

Type.registerNamespace('ExtExtenders');

ExtExtenders.ResizableControlBehavior = function(element) {
    /// <summary>
    /// The ResizableControlBehavior makes the target element resizable
    /// </summary>
    /// <param name="element" type="Sys.UI.DomElement" domElement="true">
    /// DOM element associated with the behaviro
    /// </param>
    ExtExtenders.ResizableControlBehavior.initializeBase(this, [element]);
    
    // Properties
    this._MinimumWidth = 0;
    this._MinimumHeight = 0;
    this._MaximumWidth = 100000;
    this._MaximumHeight = 100000;
}
ExtExtenders.ResizableControlBehavior.prototype = {
    initialize : function() {
        /// <summary>
        /// Initialize the behavior
        /// </summary>
        ExtExtenders.ResizableControlBehavior.callBaseMethod(this, 'initialize');
        var ElId=this.get_element().id;
   
        var width=0;
        var height=0;
      
        var el=Ext.get(ElId);
        width=el.getWidth();
        height=el.getHeight();

        var animated = new Ext.Resizable(ElId,{
                width: width,
                height: height,
                pinned: this._pinned,
                minWidth:this._MinimumWidth,
                minHeight:this._MinimumHeight,
                preserveRatio: this._preserveRatio,
                transparent: this._transparent,
                wrap: this._wrap,
                handles:this._handles,
                maxHeight:this._MaximumHeight,
                maxWidth:this._MaximumWidth,
                dynamic:this._dynamic,
                draggable:this._Draggable
               
        });
       
        
    },
    _rememberSize : function(el,width,height,obj) {
        /// <summary>
        /// Save the size in ClientState
        /// </summary>
        
        ExtExtenders.ResizableControlBehavior.callBaseMethod(this, 'set_ClientState', [ width+','+height ]);
       
    },
    get_MinimumWidth : function() {
        /// <value type="Number" integer="true">
        /// Minimum width of the resizable element
        /// </value>
        return this._MinimumWidth;
    },
    set_MinimumWidth : function(value) {
        if (this._MinimumWidth != value) {
            this._MinimumWidth = value;
            this.raisePropertyChanged('MinimumWidth');
        }
    },

    get_MinimumHeight : function() {
        /// <value type="Number" integer="true">
        /// Minimum height of the resizable element
        /// </value>
        return this._MinimumHeight;
    },
    set_MinimumHeight : function(value) {
        if (this._MinimumHeight != value) {
            this._MinimumHeight = value;
            this.raisePropertyChanged('MinimumHeight');
        }
    },

    get_MaximumWidth : function() {
        /// <value type="Number" integer="true">
        /// Maximum width of the resizing element
        /// </value>
        return this._MaximumWidth;
    },
    set_MaximumWidth : function(value) {
        if (this._MaximumWidth != value) { 
            this._MaximumWidth = value;
            this.raisePropertyChanged('MaximumWidth');
        }
    },

    get_MaximumHeight : function() {
        /// <value type="Number" integer="true">
        /// Maximum height of the resizing element
        /// </value>
        return this._MaximumHeight;
    },
    set_MaximumHeight : function(value) {
        if (this._MaximumHeight != value) {
            this._MaximumHeight = value;
            this.raisePropertyChanged('MaximumHeight');
        }
    },
    get_Draggable:function(){
        return this._Draggable;
    },
    set_Draggable:function(value){
        this._Draggable=value;
    },
    get_handles:function(){
        return this._handles;
    },
    set_handles:function(value){
        this._handles=value;
    },
    get_pinned:function(){
        return this._pinned;
    },
    set_pinned:function(value){
        this._pinned=value;
    },
    get_preserveRatio:function(){
        return this._preserveRatio;
    },
    set_preserveRatio:function(value){
        this._preserveRatio=value;
    },
    get_transparent:function(){
        return this._transparent;
    },
    set_transparent:function(value){
        this._transparent=value;
    },
    get_wrap:function(){
        return this._wrap;
    },
    set_wrap:function(value){
        this._wrap=value;
    },
    get_dynamic:function(){
        return this._dynamic;
    },
    set_dynamic:function(value){
        this._dynamic=value;
    }
    
   
}
ExtExtenders.ResizableControlBehavior.registerClass('ExtExtenders.ResizableControlBehavior', Sys.UI.Behavior);
if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 
