using System;
using System.IO;
using System.Web.UI;
using ExtExtenders;
using Manoli.Utils.CSharpFormat;

public partial class TreeSource : Page
{
    protected string sourceHtml
    {
        get { return ViewState["sourceHtml"] != null ? ViewState["sourceHtml"].ToString() : ""; }
        set { ViewState["sourceHtml"] = value; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsCallback)
        {
            string[] files = Directory.GetFiles(Server.MapPath("."));
            TreeNode node;
            node = new TreeNode();
            node.id = "root";
            node.IsRoot = true;
            node.text = "";
            node.leaf = true;
            TreeFile.TreeNodes.Add(node);
            foreach (string file in files)
            {
                string extension = Path.GetExtension(file);
                if (extension == ".aspx" || extension == ".cs")
                {
                    node = new TreeNode();
                    node.id = Path.GetFileName(file);
                    node.text = Path.GetFileName(file);
                    node.parentNodeId = "root";
                    node.leaf = true;
                    TreeFile.TreeNodes.Add(node);
                }
            }
        }
    }


    protected void TreeFile_NodeClicked(object sender, NodeClickedEventArgs e)
    {
        string fileName = e.NodeClicked.id;
        var read = new StreamReader(Server.MapPath(fileName));
        string source = read.ReadToEnd();
        read.Close();
        read.Dispose();
        if (fileName.IndexOf("aspx") == -1)
        {
            var format = new CSharpFormat();
            sourceHtml = format.FormatCode(source);
        }
        else
        {
            var htmformat = new HtmlFormat();
            sourceHtml = htmformat.FormatCode(source);
        }
    }
}