﻿using System;
using System.Web.UI;
using ExtExtenders;

public partial class LoginTest : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void login_LoginClicked(object sender, LoginEventArgs e)
    {
        Response.Write("Login=" + e.username + "<br>Password=" + e.password);
    }
}