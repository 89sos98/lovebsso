using System;
using System.Web.UI;

public partial class TabTest : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
}