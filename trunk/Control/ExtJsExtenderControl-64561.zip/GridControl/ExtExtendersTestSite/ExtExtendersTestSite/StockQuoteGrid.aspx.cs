using System;
using System.Data;
using System.Net;
using System.Text;
using System.Web.UI;

public partial class StockQuoteGrid : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //make button do a callback instead of a postback
        ScriptManager1.RegisterAsyncPostBackControl(btnChange);
        string symbol = "A";
        if (!string.IsNullOrEmpty(Request["symbol"]))
        {
            symbol = Request["symbol"];
        }
        BindData(symbol);
    }

    private DataTable CreateTable()
    {
        var dt = new DataTable();
        var dc = new DataColumn();
        dc.ColumnName = "Symbol";
        dt.Columns.Add(dc);

        dc = new DataColumn();
        dc.ColumnName = "Last";
        dt.Columns.Add(dc);

        dc = new DataColumn();
        dc.ColumnName = "Date";
        dt.Columns.Add(dc);


        dc = new DataColumn();
        dc.ColumnName = "Time";
        dt.Columns.Add(dc);

        dc = new DataColumn();
        dc.ColumnName = "Change";
        dt.Columns.Add(dc);

        dc = new DataColumn();
        dc.ColumnName = "Name";
        dt.Columns.Add(dc);
        return dt;
    }

    private void BindData(string symbol)
    {
        string url; //stores url of yahoo quote engine
        string buffer;
        var bufferList = new string[] {};
        var cli = new WebClient();


        url = "http://quote.yahoo.com/d/quotes.csv?s=" + symbol + "&f=sl1d1t1c1ohgvj1pp2owern";
        byte[] data = cli.DownloadData(url);

        buffer = Encoding.UTF8.GetString(data);
        bufferList = buffer.Split(new[] {','});


        DataTable dt = CreateTable();

        if (bufferList.Length == 17)
        {
            DataRow dr = dt.NewRow();
            dr["Symbol"] = bufferList[0];
            dr["Last"] = bufferList[1];
            dr["Date"] = bufferList[2];
            dr["Time"] = bufferList[3];
            dr["Change"] = bufferList[4];
            dr["Name"] = bufferList[16];
            dt.Rows.Add(dr);
        }
        YuiGrid1.DataSource = dt;
        YuiGrid1.DataBind();
    }
}