using System;
using System.Diagnostics;
using System.Web.UI;

public partial class HtmlEditor : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string value = Request["hid" + Editor.ID];
        Debug.WriteLine(value);
    }
}