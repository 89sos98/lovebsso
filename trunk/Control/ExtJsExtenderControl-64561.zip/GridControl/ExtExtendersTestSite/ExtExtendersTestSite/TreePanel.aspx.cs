using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web.UI;
using ExtExtenders;

public partial class TreePanel : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var root = new TreeNode {id = "0", leaf = false, text = "root"};
        TreePane.TreeNodes.Add(root);

        var menu = new Menu();
        var childMenu = new Menu();
        var item = new MenuItem {Text = "Create new node", OnClientClick = "CreateNode"};
        menu.Items.Add(item);

        item = new MenuItem {Text = "Delete node", Id = "deletenode", OnClientClick = "DeleteNode"};
        childMenu.Items.Add(item);


        TreePane.ContextMenu = menu;
        TreePane.ChildContextMenu = childMenu;
    }


    protected void TreePane_NodeEdited(object sender, NodeEditedEventArgs e)
    {
        //updates the database to reflect the edition

        HomePageDataContext db = Util.getContext();
        //use Single to make sure only one record returns
        TBTree nodeToUpdate = (from t in db.TB_Trees
                               where t.ID == int.Parse(e.NodeRenamed.id)
                               select t).Single();

        nodeToUpdate.Text = e.NewValue;
        db.SubmitChanges();
    }

    protected void TreePane_NodeMoved(object sender, NodeMoveEventArgs e)
    {
        if (e.NewParent.id == e.OldParent.id) //do nothing... node still has the same parent
        {
            return;
        }

        HomePageDataContext db = Util.getContext();
        //use Single to make sure only one record returns
        TBTree nodeToUpdate = (from t in db.TB_Trees
                               where t.ID == int.Parse(e.NodeMoved.id)
                               select t).Single();

        nodeToUpdate.IDParent = int.Parse(e.NodeMoved.id);
        db.SubmitChanges();
    }


    protected void TreePane_NodeInserted(object sender, NodeInsertedEventArgs e)
    {
        HomePageDataContext db = Util.getContext();
        var node = new TBTree {Text = e.NewNode.text, IDParent = int.Parse(e.ParentNode.id)};
        db.TB_Trees.InsertOnSubmit(node);
        db.SubmitChanges();
    }

    protected void TreePane_NodeRemoved(object sender, NodeClickedEventArgs e)
    {
        HomePageDataContext db = Util.getContext();
        //get the node to delete
        TBTree nodeToDelete = (from t in db.TB_Trees
                               where t.ID == int.Parse(e.NodeClicked.id)
                               select t).Single();
        //get his children
        List<TBTree> children = (from t in db.TB_Trees
                                 where t.IDParent == nodeToDelete.ID
                                 select t).ToList();
        try
        {
            db.TB_Trees.DeleteOnSubmit(nodeToDelete);
            db.TB_Trees.DeleteAllOnSubmit(children);
            db.SubmitChanges();
        }
        catch (Exception ex)
        {
            Debug.WriteLine(ex.ToString());
        }
    }
    protected void TreePane_NodeDroped(object sender, NodeDropedEventArgs e)
    {
        Debug.WriteLine(e.DropedNode.id);
    }
}