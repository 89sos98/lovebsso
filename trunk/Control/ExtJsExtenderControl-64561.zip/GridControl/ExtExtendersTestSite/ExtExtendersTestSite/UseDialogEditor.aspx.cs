﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UseDialogEditor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var tbar = new ExtExtenders.ToolBar();
        tbar.Items.Add(new ExtExtenders.MenuItem {Text="Add",OnClientClick="AddRecord"});
        tbar.Items.Add(new ExtExtenders.MenuItem { Text = "Edit", OnClientClick = "EditRecord" });
        YuiGrid1.TopToolBar=tbar;

        for (int i = 1960; i < DateTime.Now.Year; i++)
        {
            cboYear.Items.Add(i.ToString());
        }

        BindGrid(0, 10, string.Empty, string.Empty);
    }
    protected void YuiGrid1_PageIndexChanged(object sender, ExtExtenders.PageIndexChangedArgs e)
    {
        BindGrid(e.currentRecord, e.pageSize, e.sortColumn, e.sortDir);
    }
    private void BindGrid(int currentPage, int pageSize, string sortColumn, string sortDir)
    {
        if (string.IsNullOrEmpty(sortColumn))
        {
            sortColumn = "IDMovie";
            sortDir = "ASC";
        }

        YuiGrid1.TotalRecords = Movie.GetMovieCount();
        YuiGrid1.DataSource = Movie.GetPagedMovies(sortColumn, currentPage, pageSize, sortDir);
        YuiGrid1.DataBind();
    }
}
