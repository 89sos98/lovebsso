﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for PageData
/// </summary>
public class PageData
{
    public int start { get; set; }
    public int limit { get; set; }
    public string sort { get; set; }
    public string dir { get; set; }
    public string nodeSelected { get; set; }
}
