using System;
using System.Data;
using System.Data.SQLite;
using System.IO;
using System.Text;
using System.Web;
using System.Web.Mail;
using System.Xml;
using System.Xml.Xsl;

/// <summary>
/// Summary description for Util
/// </summary>
public static class Util
{
    public static string PascalCase(this string str)
    {
        string newstr = string.Empty;
        for (int i = 0; i < str.Length; i++)
        {
            if (i != 0)
            {
                newstr += Char.ToLower(str[i]);
            }
            else
            {
                newstr += Char.ToUpper(str[i]);
            }
        }
        return newstr;
    }

    public static HomePageDataContext getContext()
    {
        IDbConnection conn = new SQLiteConnection();
        string path_db = HttpContext.Current.Server.MapPath(".") + "\\Homepage.db";
        string consTring = "Data Source=" + path_db + ";Version=3;New=False;Compress=True";
        conn.ConnectionString = consTring;
        conn.Open();
        return new HomePageDataContext(conn);
    }

    /// <summary>
    /// Send an email using System.Web.Mail.MailMessage
    /// for some strange reason the new System.Net.MailMessage
    /// does not work
    /// </summary>
    /// <param name="MailFrom">From</param>
    /// <param name="Subject">Subject</param>
    /// <param name="Body">Body</param>
    public static void SendMail(string MailFrom, string Subject, string Body)
    {
        var mailMsg = new MailMessage();
        mailMsg.From = MailFrom; //"rochagasdiniz@gmail.com";
        mailMsg.To = "rodiniz@mail.com";
        mailMsg.Subject = Subject;
        mailMsg.BodyFormat = MailFormat.Text;
        mailMsg.Body = Body;
        mailMsg.Priority = MailPriority.High;
        try
        {
            SmtpMail.Send(mailMsg);
        }
        catch
        {
            throw;
        }
    }


    public static string ReaderToXML(IDataReader objReader)
    {
        return ReaderToXML(objReader, null, null);
    }

    public static string ReaderToXML(IDataReader objReader, string rootNode, string tableName)
    {
        var doc = new XmlDocument();
        var writer = new StringWriterWithEncoding(new StringBuilder(), Encoding.GetEncoding("ISO-8859-1"));

        int num = 0;
        if ((rootNode == null) || (rootNode.Trim().Length == 0))
        {
            rootNode = "ROOT";
        }
        if ((tableName == null) || (tableName.Trim().Length == 0))
        {
            tableName = "ROWS";
        }
        string text1 = string.Empty;
        try
        {
            int num1 = objReader.FieldCount;
            string text2 = string.Concat(new[] {"<", rootNode, "></", rootNode, ">"});
            doc.LoadXml(text2);
            text2 = null;
            while (objReader.Read())
            {
                num++;
                XmlElement element1 = doc.CreateElement(tableName);
                doc.DocumentElement.AppendChild(element1);
                for (int num2 = 0; num2 < num1; num2++)
                {
                    if (!objReader.IsDBNull(num2))
                    {
                        text1 = objReader.GetValue(num2).ToString();
                    }
                    else
                    {
                        text1 = "  ";
                    }
                    XmlElement element2 = doc.CreateElement(objReader.GetName(num2).ToUpper());
                    try
                    {
                        element2.InnerText = text1;
                        element1.AppendChild(element2);
                    }

                    catch (Exception)
                    {
                        throw;
                    }
                }
            }

            doc.Save(writer);
        }
        catch (Exception)
        {
            throw;
        }
        return writer.ToString();
    }


    public static string ReaderToXML(IDataReader objReader, int PageNumber, int PageSize, out int totalRecords)
    {
        var document1 = new XmlDocument();
        var writer1 = new StringWriterWithEncoding(new StringBuilder(), Encoding.GetEncoding("ISO-8859-1"));
        string text3 = "ROOT";
        string text4 = "ROWS";
        int num3 = 0;
        int num4 = (PageNumber - 1)*PageSize;
        int num5 = num4 + PageSize;
        string text1 = string.Empty;
        try
        {
            int num1 = objReader.FieldCount;
            string text2 = string.Concat(new[] {"<", text3, "></", text3, ">"});
            document1.LoadXml(text2);
            text2 = null;
            while (objReader.Read())
            {
                num3++;
                if ((num3 >= num4) && (num3 <= num5))
                {
                    XmlElement element1 = document1.CreateElement(text4);
                    document1.DocumentElement.AppendChild(element1);
                    for (int num2 = 0; num2 < num1; num2++)
                    {
                        if (!objReader.IsDBNull(num2))
                        {
                            text1 = objReader.GetValue(num2).ToString();
                        }
                        else
                        {
                            text1 = "   ";
                        }
                        XmlElement element2 = document1.CreateElement(objReader.GetName(num2).ToUpper());
                        try
                        {
                            element2.InnerText = text1;
                        }
                        catch (Exception)
                        {
                            throw;
                        }
                        element1.AppendChild(element2);
                    }
                }
            }
            document1.Save(writer1);
        }
        catch (Exception)
        {
            throw;
        }
        totalRecords = num3;
        return writer1.ToString();
    }

    /// <summary>
    ///	Transforms a xml string
    /// </summary>
    /// <param name="sXml">String to be transformed</param>
    /// <param name="camXSLT">Path to the xslt file</param>
    /// <returns>Transformed string(usually an html)</returns>
    public static string Transform(string sXml, string camXSLT)
    {
        var doc = new XmlDocument();
        var trans = new XslTransform();


        doc.LoadXml(sXml);

        trans.Load(camXSLT);
        var sw = new StringWriter();

        trans.Transform(doc, null, sw, null);
        sw.Flush();
        return sw.ToString();
    }
}