using System.Collections;
using System.ComponentModel;
using System.Linq;
using System.Linq.Dynamic;

/// <summary>
/// Summary description for Movie
/// </summary>
[DataObject]
public class Movie
{
    public int MyProperty { get; set; }
    public int id_movie { get; set; }

    public string Title { get; set; }

    public static int GetMovieCount()
    {
        HomePageDataContext _context = Util.getContext();
        return (from t in _context.TB_Movies select t).Count();
        ;
    }
    public static int GetMovieCount(string genre)
    {
        HomePageDataContext _context = Util.getContext();
        return (from t in _context.TB_Movies where t.Genre==genre select t).Count();
        ;
    }
    public static IEnumerable GetGenres()
    {
        HomePageDataContext _context = Util.getContext();
        return _context.TB_Movies.Select(c => c.Genre).Distinct();
    }
    public static int GetMovieCount2()
    {
        HomePageDataContext _context = Util.getContext();
        return (from t in _context.TB_Movies where t.Title.Contains('a') select t).Count();
        ;
    }
  
    public static IEnumerable GetMovies()
    {
        HomePageDataContext _context = Util.getContext();

        return (from t in _context.TB_Movies select t).Take(30);
    }
    public static IEnumerable GetPagedMovies(string sort, int offset, int page_size, string dir,string genre)
    {
        HomePageDataContext _context = Util.getContext();

        IQueryable<TBMovie> ret = (from t in _context.TB_Movies where t.Genre==genre select t)
            .OrderBy(sort + " " + dir)
            .Skip(offset)
            .Take(page_size);


        return ret;
    }
    public static IEnumerable GetPagedMovies(string sort, int offset, int page_size, string dir)
    {
        HomePageDataContext _context = Util.getContext();

        IQueryable<TBMovie> ret = (from t in _context.TB_Movies select t)
            .OrderBy(sort + " " + dir)
            .Skip(offset)
            .Take(page_size);


        return ret;
    }
    public static IEnumerable GetPagedMovies2(string sort, int offset, int page_size, string dir)
    {
        HomePageDataContext _context = Util.getContext();

        IQueryable<TBMovie> ret = (from t in _context.TB_Movies where t.Title.Contains('a')  select t)
            .OrderBy(sort + " " + dir)
            .Skip(offset)
            .Take(page_size);


        return ret;
    }
}