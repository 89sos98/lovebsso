using System.IO;
using System.Text;

/// <summary>
/// Summary description for Class1
/// </summary>
public class StringWriterWithEncoding : StringWriter
{
    private readonly Encoding _Encoding;

    public StringWriterWithEncoding(StringBuilder stringbuilder, Encoding encoding)
        : base(stringbuilder)
    {
        _Encoding = encoding;
    }

    public override Encoding Encoding
    {
        get { return _Encoding; }
    }
}