﻿using System;
using System.Collections.Generic;

/// <summary>
/// Summary description for ComplexMovieType
/// </summary>
public class ComplexMovieType
{
    public string Title { get; set; }

    public DateTime Year { get; set; }

    public Person Director { get; set; }
}

public class ComplexMovieTypeCollection : List<ComplexMovieType>
{
}

public class Person
{
    public string FirstName { get; set; }

    public string LastName { get; set; }

    public string FullName
    {
        get { return string.Format("{1}, {0}", FirstName, LastName); }
    }

    public Studio Studio { get; set; }
}

public class Studio
{
    public string Name { get; set; }
}