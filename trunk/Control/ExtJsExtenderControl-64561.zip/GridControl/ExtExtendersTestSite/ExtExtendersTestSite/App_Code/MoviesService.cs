using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic;
using System.Web.Script.Services;
using System.Web.Services;
using ExtExtenders;

/// <summary>
/// Summary description for MoviesService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[ScriptService]
public class MoviesService : WebService
{
    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Xml)]
    public List<TBMovie> GetMovies(int limit, int start, string sort, string dir)
    {
        HomePageDataContext _context = Util.getContext();

        string sortCol, sortDir;
        if (string.IsNullOrEmpty(sort))
        {
            sortCol = "IDMovie";
            sortDir = "ASC";
        }
        else
        {
            sortCol = sort;
            sortDir = dir;
        }
        //page_size = limit;//int.Parse(limit);
        IQueryable<TBMovie> iQuery = (from m in _context.TB_Movies select m)
            .Take(limit)
            .Skip(start)
            .OrderBy(sortCol + sortDir);


        //offset += 1;
        ////query that gets only the records needed to the page
        //// using the new ROW_NUMBER function in sql2005
        //string sql = "WITH MOVIES AS ( " +
        //            " SELECT ROW_NUMBER() OVER " +
        //            "(ORDER BY " + sortCol + " " + sortDir + ")AS Row," +
        //            " IDMovie,TITLE, RATING,VOTES,YEAR,GENRE " +
        //            " FROM TB_MOVIE )" +
        //            " SELECT IDMovie,TITLE, GENRE,RATING,VOTES,YEAR" +
        //            " FROM MOVIES " +
        //            " WHERE Row between (@PageIndex-1)* @PageSize+1  and @PageIndex*@PageSize";

        //SqlCommand cmd = new SqlCommand(sql, con);
        ////add the parameters to the query to grab the correct page
        //cmd.Parameters.AddWithValue("@PageIndex", offset);
        //cmd.Parameters.AddWithValue("@PageSize", page_size);
        //SqlDataAdapter adapt = new SqlDataAdapter(cmd);
        //DataSet ds = new DataSet();
        //adapt.Fill(ds);

        ////closes the objects and disposes

        //GetMovieCount(ds);
        //con.Close();
        //cmd.Dispose();
        //con.Dispose();
        //return ds;
        return iQuery.ToList();
    }

    [WebMethod]
    public List<TreeNode> getNodes(string node)
    {
        var nodes = new List<TreeNode>();
        int ini = int.Parse(node.Replace("node", ""));
        for (int i = ini + 1; i < ini + 10; i++)
        {
            var no = new TreeNode();
            no.draggable = true;
            no.id = i.ToString();
            no.text = "Node" + i;
            no.leaf = true;
            nodes.Add(no);
        }
        return nodes;
    }
}