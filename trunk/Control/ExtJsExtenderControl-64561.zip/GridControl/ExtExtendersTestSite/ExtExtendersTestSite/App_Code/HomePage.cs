#region Auto-generated classes for main database on 2008-09-01 09:34:36Z

//
//  ____  _     __  __      _        _
// |  _ \| |__ |  \/  | ___| |_ __ _| |
// | | | | '_ \| |\/| |/ _ \ __/ _` | |
// | |_| | |_) | |  | |  __/ || (_| | |
// |____/|_.__/|_|  |_|\___|\__\__,_|_|
//
// Auto-generated from main on 2008-09-01 09:34:36Z
// Please visit http://linq.to/db for more information

#endregion

using System.ComponentModel;
using System.Data;
using System.Data.Linq.Mapping;
using System.Diagnostics;
using DbLinq.Data.Linq;
using DbLinq.Sqlite;
using DbLinq.Vendor;

//using DbLinq.Linq;
//using DbLinq.Linq.Mapping;

public class HomePageDataContext : DataContext
{
    public HomePageDataContext(IDbConnection connection)
        : base(connection, new SqliteVendor())
    {
    }

    public HomePageDataContext(IDbConnection connection, IVendor vendor)
        : base(connection, vendor)
    {
    }

    public Table<TBAvailableMovie> TB_AvailableMovies
    {
        get { return GetTable<TBAvailableMovie>(); }
    }

    public Table<TBMovie> TB_Movies
    {
        get { return GetTable<TBMovie>(); }
    }

    public Table<TBSelectedMovie> TB_SelectedMovies
    {
        get { return GetTable<TBSelectedMovie>(); }
    }

    public Table<TBTree> TB_Trees
    {
        get { return GetTable<TBTree>(); }
    }
}

[Table(Name = "TB_AVAILABLE_MOVIE")]
public class TBAvailableMovie : INotifyPropertyChanged
{
    #region INotifyPropertyChanged handling

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
        if (PropertyChanged != null)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    #endregion

    #region int IDMovie

    private int _idmOvie;

    [DebuggerNonUserCode]
    [Column(Storage = "_idmOvie", Name = "ID_MOVIE", DbType = "int", IsPrimaryKey = true, IsDbGenerated = true,
        CanBeNull = false)]
    public int IDMovie
    {
        get { return _idmOvie; }
        set
        {
            if (value != _idmOvie)
            {
                _idmOvie = value;
                OnPropertyChanged("IDMovie");
            }
        }
    }

    #endregion

    #region string Title

    private string _title;

    [DebuggerNonUserCode]
    [Column(Storage = "_title", Name = "TITLE", DbType = "varchar(150)", CanBeNull = false)]
    public string Title
    {
        get { return _title; }
        set
        {
            if (value != _title)
            {
                _title = value;
                OnPropertyChanged("Title");
            }
        }
    }

    #endregion
}

[Table(Name = "TB_MOVIE")]
public class TBMovie : INotifyPropertyChanged
{
    #region INotifyPropertyChanged handling

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
        if (PropertyChanged != null)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    #endregion

    #region string Genre

    private string _genre;

    [DebuggerNonUserCode]
    [Column(Storage = "_genre", Name = "GENRE", DbType = "varchar(150)", CanBeNull = false)]
    public string Genre
    {
        get { return _genre; }
        set
        {
            if (value != _genre)
            {
                _genre = value;
                OnPropertyChanged("Genre");
            }
        }
    }

    #endregion

    #region int IDMovie

    private int _idmOvie;

    [DebuggerNonUserCode]
    [Column(Storage = "_idmOvie", Name = "ID_MOVIE", DbType = "int", IsPrimaryKey = true, IsDbGenerated = true,
        CanBeNull = false)]
    public int IDMovie
    {
        get { return _idmOvie; }
        set
        {
            if (value != _idmOvie)
            {
                _idmOvie = value;
                OnPropertyChanged("IDMovie");
            }
        }
    }

    #endregion

    #region decimal Rating

    private decimal _rating;

    [DebuggerNonUserCode]
    [Column(Storage = "_rating", Name = "RATING", DbType = "numeric(18,0)", CanBeNull = false)]
    public decimal Rating
    {
        get { return _rating; }
        set
        {
            if (value != _rating)
            {
                _rating = value;
                OnPropertyChanged("Rating");
            }
        }
    }

    #endregion

    #region string Title

    private string _title;

    [DebuggerNonUserCode]
    [Column(Storage = "_title", Name = "TITLE", DbType = "varchar(250)", CanBeNull = false)]
    public string Title
    {
        get { return _title; }
        set
        {
            if (value != _title)
            {
                _title = value;
                OnPropertyChanged("Title");
            }
        }
    }

    #endregion

    #region int Votes

    private int _votes;

    [DebuggerNonUserCode]
    [Column(Storage = "_votes", Name = "VOTES", DbType = "int", CanBeNull = false)]
    public int Votes
    {
        get { return _votes; }
        set
        {
            if (value != _votes)
            {
                _votes = value;
                OnPropertyChanged("Votes");
            }
        }
    }

    #endregion

    #region string Year

    private string _year;

    [DebuggerNonUserCode]
    [Column(Storage = "_year", Name = "\"YEAR\"", DbType = "varchar(10)", CanBeNull = false)]
    public string Year
    {
        get { return _year; }
        set
        {
            if (value != _year)
            {
                _year = value;
                OnPropertyChanged("Year");
            }
        }
    }

    #endregion

    private string _plot;

    [DebuggerNonUserCode]
    [Column(Storage = "_plot", Name = "\"PLOT\"", DbType = "varchar(500)", CanBeNull = true)]
    public string Plot
    {
        get { return _plot; }
        set
        {
            if (value != _plot)
            {
                _plot = value;
                OnPropertyChanged("Plot");
            }
        }
    }
}

[Table(Name = "TB_SELECTED_MOVIE")]
public class TBSelectedMovie : INotifyPropertyChanged
{
    #region INotifyPropertyChanged handling

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
        if (PropertyChanged != null)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    #endregion

    #region int IDMovie

    private int _idmOvie;

    [DebuggerNonUserCode]
    [Column(Storage = "_idmOvie", Name = "ID_MOVIE", DbType = "int", IsPrimaryKey = true, IsDbGenerated = true,
        CanBeNull = false)]
    public int IDMovie
    {
        get { return _idmOvie; }
        set
        {
            if (value != _idmOvie)
            {
                _idmOvie = value;
                OnPropertyChanged("IDMovie");
            }
        }
    }

    #endregion

    #region string Title

    private string _title;

    [DebuggerNonUserCode]
    [Column(Storage = "_title", Name = "TITLE", DbType = "varchar(150)", CanBeNull = false)]
    public string Title
    {
        get { return _title; }
        set
        {
            if (value != _title)
            {
                _title = value;
                OnPropertyChanged("Title");
            }
        }
    }

    #endregion
}

[Table(Name = "TB_TREE")]
public class TBTree : INotifyPropertyChanged
{
    #region INotifyPropertyChanged handling

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
        if (PropertyChanged != null)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    #endregion

    #region int ID

    private int _id;

    [DebuggerNonUserCode]
    [Column(Storage = "_id", Name = "ID", DbType = "int", IsPrimaryKey = true, IsDbGenerated = true, CanBeNull = false)]
    public int ID
    {
        get { return _id; }
        set
        {
            if (value != _id)
            {
                _id = value;
                OnPropertyChanged("ID");
            }
        }
    }

    #endregion

    #region int? IDParent

    private int? _idpArent;

    [DebuggerNonUserCode]
    [Column(Storage = "_idpArent", Name = "ID_PARENT", DbType = "int")]
    public int? IDParent
    {
        get { return _idpArent; }
        set
        {
            if (value != _idpArent)
            {
                _idpArent = value;
                OnPropertyChanged("IDParent");
            }
        }
    }

    #endregion

    #region string Text

    private string _text;

    [DebuggerNonUserCode]
    [Column(Storage = "_text", Name = "\"TEXT\"", DbType = "varchar(50)", CanBeNull = false)]
    public string Text
    {
        get { return _text; }
        set
        {
            if (value != _text)
            {
                _text = value;
                OnPropertyChanged("Text");
            }
        }
    }

    #endregion
}