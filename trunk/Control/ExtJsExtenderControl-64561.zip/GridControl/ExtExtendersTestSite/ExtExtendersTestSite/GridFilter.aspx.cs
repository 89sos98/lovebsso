﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ExtExtenders;
using System.Web.Script.Serialization;

public partial class GridFilter : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //cboGender.DataSource = Movie.GetGenres();
        //cboGender.DataBind();
        BindGrid("",0, 10, "", "");
        var genres = Movie.GetGenres();
       

    }
    private void BindGrid(string genre,int currentPage, int pageSize, string sortColumn, string sortDir)
    {
        if (string.IsNullOrEmpty(sortColumn))
        {
            sortColumn = "IDMovie";
            sortDir = "ASC";
        }
        if (string.IsNullOrEmpty(genre))
        {

            YuiGrid1.TotalRecords = Movie.GetMovieCount();
            YuiGrid1.DataSource = Movie.GetPagedMovies(sortColumn, currentPage, pageSize, sortDir);
        }
        else
        {
            YuiGrid1.TotalRecords = Movie.GetMovieCount(genre);
            YuiGrid1.DataSource = Movie.GetPagedMovies(sortColumn, currentPage, pageSize, sortDir,genre);
        }
        YuiGrid1.DataBind();
    }
    protected void YuiGrid1_PageIndexChanged(object sender, PageIndexChangedArgs e)
    {
        var ser = new JavaScriptSerializer();
        PageData data = ser.Deserialize<PageData>(e.json);
        BindGrid(data.nodeSelected,e.currentRecord, e.pageSize, e.sortColumn, e.sortDir);
    }
}
