using System;
using System.IO;
using System.Web.UI;
using ExtExtenders;
using Manoli.Utils.CSharpFormat;

public partial class BorderLayoutSample : Page
{
    protected string sourceHtml
    {
        get
        {
            return ViewState["sourceHtml"] != null
                       ? ViewState["sourceHtml"].ToString()
                       : "Click on an example to see the source here";
        }
        set { ViewState["sourceHtml"] = value; }
    }

    protected string sourceCS
    {
        get { return ViewState["sourceCS"] != null ? ViewState["sourceCS"].ToString() : ""; }
        set { ViewState["sourceCS"] = value; }
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Request.Browser.Browser=="IE")
        //{
        //    Response.Redirect("Default2.aspx");
        //}
    }

    protected void TreePane_NodeClicked(object sender, NodeClickedEventArgs e)
    {
        if (!e.NodeClicked.leaf)
        {
            return;
        }
        string fileName = e.NodeClicked.id + ".aspx";
        var read = new StreamReader(Server.MapPath(fileName));
        string source = read.ReadToEnd();
        read.Close();
        read.Dispose();
        var htmformat = new HtmlFormat();
        var format = new CSharpFormat();
        sourceHtml = htmformat.FormatCode(source);

        fileName = e.NodeClicked.id + ".aspx.cs";
        var readcs = new StreamReader(Server.MapPath(fileName));
        source = readcs.ReadToEnd();
        readcs.Close();
        readcs.Dispose();
        //
        sourceCS = format.FormatCode(source);
    }
}