﻿using System;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;

public partial class GridDataBound3 : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var mtc = new ComplexMovieTypeCollection();
        mtc.Add(
            new ComplexMovieType
                {
                    Title = "American Beauty",
                    Year = new DateTime(1999, 1, 1),
                    Director = new Person
                                   {
                                       FirstName = "Sam",
                                       LastName = "Mendes",
                                       Studio = new Studio
                                                    {
                                                        Name = "Dreamworks"
                                                    }
                                   }
                });
        mtc.Add(
            new ComplexMovieType
                {
                    Title = "Antz",
                    Year = new DateTime(1998, 1, 1),
                    Director = new Person
                                   {
                                       FirstName = "Woody",
                                       LastName = "Allen",
                                       Studio = new Studio
                                                    {
                                                        Name = "Dreamworks"
                                                    }
                                   }
                });
        mtc.Add(
            new ComplexMovieType
                {
                    Title = "Antz",
                    Year = new DateTime(1998, 1, 1),
                    Director = new Person
                                   {
                                       FirstName = "Woody",
                                       LastName = "Allen",
                                       Studio = new Studio
                                                    {
                                                        Name = "Dreamworks"
                                                    }
                                   }
                });
        mtc.Add(
            new ComplexMovieType
                {
                    Title = "Back to the Future",
                    Year = new DateTime(1985, 1, 1),
                    Director = new Person
                                   {
                                       FirstName = "Steven",
                                       LastName = "Spielberg",
                                       Studio = new Studio
                                                    {
                                                        Name = "Dreamworks"
                                                    }
                                   }
                });
        mtc.Add(
            new ComplexMovieType
                {
                    Title = "ET",
                    Year = new DateTime(1987, 1, 1),
                    Director = new Person
                                   {
                                       FirstName = "Steven",
                                       LastName = "Spielberg",
                                       Studio = new Studio
                                                    {
                                                        Name = "Universal"
                                                    }
                                   }
                });

        YuiGrid1.TotalRecords = mtc.Count;
        YuiGrid1.DataSource = mtc;
        YuiGrid1.DataBind();
    }

    [WebMethod]
    public static string btnGo_Click(ICollection<ComplexMovieType> data)
    {
        var mtc = new ComplexMovieTypeCollection();
        var ser = new JavaScriptSerializer();
        //System.Runtime.Serialization.Json.DataContractJsonSerializer ser2 = new System.Runtime.Serialization.Json.DataContractJsonSerializer();
        foreach (object obj in data)
        {
            var cmt1 = ser.ConvertToType<ComplexMovieType>(obj);
            //ComplexMovieType cmt2 = ser2.
        }
        return "true";
    }
}