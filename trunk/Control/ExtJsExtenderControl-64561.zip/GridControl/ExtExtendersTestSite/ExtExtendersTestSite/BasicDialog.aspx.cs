using System;
using System.Diagnostics;
using System.Web.UI;

public partial class BasicDialog : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Debug.WriteLine("Event fired");
    }
}