﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using ExtExtenders;

public partial class DragDropGrids : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HomePageDataContext db = Util.getContext();
        IQueryable<TBAvailableMovie> avai = from d in db.TB_AvailableMovies
                                            select d;
        YuiGrid1.DataSource = avai;
        YuiGrid1.DataBind();

        IQueryable<TBSelectedMovie> selec = from s in db.TB_SelectedMovies
                                            select s;
        YuiGrid2.DataSource = selec;
        YuiGrid2.DataBind();
    }

    protected void YuiGrid1_RowDroped(object sender, DropRowsEventArgs e)
    {
        HomePageDataContext db = Util.getContext();
        //available movies
        List<Dictionary<string, object>> rows = e.RowsDropped;
        //remove from selected movies and add to available movies

        for (int i = 0; i < rows.Count; i++)
        {
            var mo = new TBAvailableMovie();
            mo.IDMovie = int.Parse(rows[i]["IDMovie"].ToString());
            mo.Title = rows[i]["TITLE"].ToString();

            db.TB_AvailableMovies.InsertOnSubmit(mo);
            int id_movie = int.Parse(rows[i]["IDMovie"].ToString());
            TBSelectedMovie protoRemove = (from m in db.TB_SelectedMovies
                                           where m.IDMovie == id_movie
                                           select m).Single();

            db.TB_SelectedMovies.DeleteOnSubmit(protoRemove);
            db.SubmitChanges();
        }
    }

    protected void YuiGrid2_RowDroped(object sender, DropRowsEventArgs e)
    {
        //selected movies
        HomePageDataContext db = Util.getContext();
        //available movies
        List<Dictionary<string, object>> rows = e.RowsDropped;
        //remove from available movies and add to selected movies

        for (int i = 0; i < rows.Count; i++)
        {
            var mo = new TBSelectedMovie();
            mo.IDMovie = int.Parse(rows[i]["IDMovie"].ToString());
            mo.Title = rows[i]["TITLE"].ToString();
            db.TB_SelectedMovies.InsertOnSubmit(mo);
            int id_movie = int.Parse(rows[i]["IDMovie"].ToString());
            TBAvailableMovie protoRemove = (from m in db.TB_AvailableMovies
                                            where m.IDMovie == id_movie
                                            select m).Single();

            db.TB_AvailableMovies.DeleteOnSubmit(protoRemove);
            db.SubmitChanges();
        }
    }
}