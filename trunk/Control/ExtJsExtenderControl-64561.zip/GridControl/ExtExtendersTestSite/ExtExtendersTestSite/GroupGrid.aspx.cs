using System;
using System.Linq;
using System.Web.UI;

public partial class GroupGrid : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //change the theme
        string csslink = "<link href=\"css/xtheme-black.css\" rel=\"stylesheet\" type=\"text/css\" />";
        var include = new LiteralControl(csslink);
        Controls.Add(include);
        HomePageDataContext db = Util.getContext();
        if (!IsPostBack)
        {
            var ds = (from c in db.TB_Movies select new {c.Title, c.Votes, c.Genre, c.Year}).Take(300);

            YuiGrid1.DataSource = ds;
            YuiGrid1.DataBind();
        }
    }
}