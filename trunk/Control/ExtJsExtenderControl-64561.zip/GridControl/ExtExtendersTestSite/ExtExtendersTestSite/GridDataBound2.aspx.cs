using System;
using System.Diagnostics;
using System.Web.UI;
using ExtExtenders;
using System.Linq;
public partial class GridDataBound2 : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
     

        var gridMenu = new Menu();
        gridMenu.Items.Add(new MenuItem {Id = "Test", Text = "Do something"});
        gridMenu.Items.Add(new MenuItem {Id = "Test2", Text = "Client click", OnClientClick = "DoClient"});
        YuiGrid1.RowContextMenu = gridMenu;
        YuiGrid1.RowContextMenuClicked += YuiGrid1_RowContextMenuClicked;
        if (!IsPostBack)
        {
            BindGrid(0, 10, string.Empty, string.Empty);
            BindGrid2(0, 10, string.Empty, string.Empty);
        }
    }
    private void BindGrid(int currentPage,int pageSize,string sortColumn, string sortDir)
    {
        if (string.IsNullOrEmpty(sortColumn))
        {
            sortColumn = "IDMovie";
            sortDir = "ASC";
        }
   
        YuiGrid1.TotalRecords = Movie.GetMovieCount();
        YuiGrid1.DataSource = Movie.GetPagedMovies(sortColumn,currentPage, pageSize, sortDir);
        YuiGrid1.DataBind();
    }

    private void BindGrid2(int currentPage, int pageSize, string sortColumn, string sortDir)
    {
        if (string.IsNullOrEmpty(sortColumn))
        {
            sortColumn = "IDMovie";
            sortDir = "ASC";
        }
        YuiGrid2.TotalRecords = Movie.GetMovieCount2();
        YuiGrid2.DataSource = Movie.GetPagedMovies2(sortColumn, currentPage, pageSize, sortDir);
        YuiGrid2.DataBind();
    }
    private void YuiGrid1_RowContextMenuClicked(object sender, GridContextMenuEventArgs e)
    {
        switch (e.MenuClicked.Id)
        {
            case "Test":
                Debug.WriteLine("Do something");
                break;
            default:
                break;
        }
    }
    protected void YuiGrid1_PageIndexChanged(object sender, PageIndexChangedArgs e)
    {
        BindGrid(e.currentRecord, e.pageSize, e.sortColumn, e.sortDir);
    }
    protected void YuiGrid2_PageIndexChanged(object sender, PageIndexChangedArgs e)
    {
        BindGrid2(e.currentRecord, e.pageSize, e.sortColumn, e.sortDir);
    }
    protected void cboGender_SelectedIndexChanged(object sender, EventArgs e)
    {
        string gender = cboGender.SelectedValue;
        HomePageDataContext _context = Util.getContext();
        var movies=_context.TB_Movies.Where(c => c.Genre == gender);
        YuiGrid1.DataSource = movies;
        YuiGrid1.DataBind();
    }
}