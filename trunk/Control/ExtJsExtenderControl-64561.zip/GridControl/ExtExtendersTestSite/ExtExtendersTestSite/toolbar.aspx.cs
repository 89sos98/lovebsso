using System;
using System.Web.UI;
using ExtExtenders;

public partial class toolbar : Page
{
    protected string menuSelected
    {
        get { return ViewState["menuSelected"] != null ? ViewState["menuSelected"].ToString() : ""; }
        set { ViewState["menuSelected"] = value; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        var mainMenu = new Menu();
        mainMenu.AddIconItem("My First menu", "bmenu");
        var check = new MenuItem();
        check.Text = "I like Ext";
        check.ItemType = MenuType.CheckItem;
        check.IsChecked = true;
        mainMenu.Items.Add(check);
        mainMenu.AddItem("I like ExtJsExtenderControls", MenuType.CheckItem);
        mainMenu.AddItem("Choose a date", MenuType.DateItem, "AlertDate");
        mainMenu.AddSeparador();
        //mainMenu.AddItem("Choose a color", ExtExtenders.MenuType.ColorItem, "AlertColor");
        var colorIt = new MenuItem();
        colorIt.Text = "Choose a color";
        colorIt.ItemType = MenuType.ColorItem;
        colorIt.icon = "images/color-trigger.gif";
        mainMenu.Items.Add(colorIt);

        mytool.Menus.Add(mainMenu);

        var fontMenu = new Menu();
        fontMenu.AddItem("Font Menu");
        fontMenu.AddItem("<b>Bold</b>");
        fontMenu.AddItem("<i>Italic</i>");
        fontMenu.AddItem("<u>Underline</u>");

        mytool.Menus.Add(fontMenu);

        var subMenu = new Menu();
        subMenu.AddItem("I am a submenu");

        var otherMenu = new Menu();
        otherMenu.AddItem("Another one");

        var it = new MenuItem();

        it.Text = "I have a submenu";
        it.OnClientClick = "function(){}"; //
        it.SubMenu = subMenu;
        otherMenu.Items.Add(it);

        mytool.Menus.Add(otherMenu);


        it = new MenuItem();
        it.Text = "Only Buttons";
        it.OnClientClick = "Ext.emptyFn";
        Tool.Items.Add(it);

        it = new MenuItem();
        it.Text = "One More";
        it.OnClientClick = "Ext.emptyFn";
        Tool.Items.Add(it);
    }


    protected void mytool_MenuItemClicked(object sender, ToolBarEventArgs e)
    {
        MenuItem it = e.MenuClicked;
        switch (it.ItemType)
        {
            case MenuType.CheckItem:
                menuSelected = it.Text + " and " + it.IsChecked;
                break;
            case MenuType.ColorItem:
                menuSelected = "&nbsp;" + it.ColorSelected + "&nbsp;<div style='background-color:" + it.ColorSelected +
                               ";height:20px;width:50px'></div>";
                break;
            case MenuType.TextItem:
                menuSelected = it.Text;
                break;

            case MenuType.DateItem:
                menuSelected = it.DateSelected.ToString("dd/MM/yyyy");
                break;
            default:
                break;
        }

        Panel1.Visible = true;
    }
}