using System;
using System.Diagnostics;
using System.Web.UI;
using ExtExtenders;

public partial class CheckBoxTree : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var no = new TreeNode();
        no.IsRoot = true;
        no.leaf = false;
        no.text = "root";
        no.id = "root";
        tree1.TreeNodes.Add(no);

        no = new TreeNode();
        no.IsRoot = false;
        no.IsChecked = true;
        no.parentNodeId = "root";
        no.text = "child";
        no.draggable = false;
        no.id = "Treenode1";
        no.leaf = true;
        tree1.TreeNodes.Add(no);

        no = new TreeNode();
        no.IsChecked = false;
        no.id = "TreeNode2";
        no.text = "TreeNode2";
        no.leaf = false;
        no.parentNodeId = "root";
        tree1.TreeNodes.Add(no);

        no = new TreeNode();
        no.IsChecked = false;
        no.id = "TreeNode3";
        no.text = "TreeNode3";
        no.leaf = true;
        no.parentNodeId = "TreeNode2";
        tree1.TreeNodes.Add(no);

        no = new TreeNode();
        no.IsChecked = true;
        no.id = "TreeNode4";
        no.text = "TreeNode4";
        no.leaf = true;
        no.parentNodeId = "TreeNode2";
        tree1.TreeNodes.Add(no);
    }

    protected void tree1_NodeChecked(object sender, NodeCheckedEventArgs e)
    {
        //do something with the node..
        if (e.NodeChecked.IsChecked)
        {
            Debug.WriteLine(e.NodeChecked.id);
        }
    }
}