﻿using System;
using System.Collections;
using System.Web.UI;

public partial class clearCache : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        IDictionaryEnumerator cache = Cache.GetEnumerator();
        while (cache.MoveNext())
        {
            Response.Write(cache.Key);
            Cache.Remove(cache.Key.ToString());
        }
    }
}