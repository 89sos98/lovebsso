using System;
using System.Web.UI;
using ExtExtenders;

public partial class GridInMaster : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void YuiGrid1_SelectedIndexChanged(object sender, SelectedRowArgs e)
    {
    }

    protected void ExtButton1_Click(object sender)
    {
        Response.Write("Master ok");
    }
}