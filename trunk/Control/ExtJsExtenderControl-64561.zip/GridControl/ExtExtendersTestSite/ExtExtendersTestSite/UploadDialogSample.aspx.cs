﻿using System;
using System.Web.UI;

public partial class UploadDialogSample : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
}