using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Linq.Dynamic;
using System.Reflection;
using System.Web.UI;
using ExtExtenders;

public partial class GridInlineEditing : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        YuiGrid1.RowRemoved += YuiGrid1_RowRemoved;
        for (int i = 1960; i < DateTime.Now.Year; i++)
        {
            cboYear.Items.Add(i.ToString());
        }
        if (!IsCallback)
        {
            BindGrid(10, 0, string.Empty, string.Empty);
        }
    }
    private void BindGrid(int page_size, int offset,string sortCol, string sortDir)
    {

        if (string.IsNullOrEmpty(sortCol))
        {
            sortCol = "IDMovie";
            sortDir = "ASC";
        }
      
        HomePageDataContext db = Util.getContext();
        //query that gets only the records needed to the page
        IQueryable<TBMovie> ds = (from m in db.TB_Movies select m)
            .Take(page_size).Skip(offset)
            .OrderBy(sortCol + " " + sortDir);


        YuiGrid1.TotalRecords = Movie.GetMovieCount();
        YuiGrid1.DataSource = ds;
        YuiGrid1.DataBind();
    }
    private void YuiGrid1_RowRemoved(object sender, RemovedRowArgs e)
    {
        HomePageDataContext db = Util.getContext();
        List<Dictionary<string, object>> rows = e.RowsRemoved;
        int movie_selected;
        for (int i = 0; i < rows.Count; i++)
        {
            movie_selected = int.Parse(rows[i]["IDMovie"].ToString());
            TBMovie protoRemove = (from m in db.TB_Movies
                                   where m.IDMovie == movie_selected
                                   select m).Single();

            db.TB_Movies.DeleteOnSubmit(protoRemove);
        }
        try
        {
            db.SubmitChanges();
        }
        catch (Exception ex)
        {
            Debug.WriteLine(ex.Message);
        }
    }


    protected void YuiGrid1_CellEdited(object sender, GridCellEditedArgs e)
    {
        HomePageDataContext db = Util.getContext();
        int movie_selected = int.Parse(e.Record["IDMovie"].ToString());
        TBMovie protoUpdate = (from m in db.TB_Movies
                               where m.IDMovie == movie_selected
                               select m).Single();
        //use reflection to get the property to update

        PropertyInfo info = protoUpdate.GetType().GetProperty(e.Field.PascalCase());
        try
        {
            info.SetValue(protoUpdate, e.Value, null);
            db.SubmitChanges();
        }
        catch (Exception ex)
        {
            Debug.WriteLine(ex.Message);
        }
    }
    protected void YuiGrid1_PageIndexChanged(object sender, PageIndexChangedArgs e)
    {
        BindGrid(e.pageSize, e.currentRecord, e.sortColumn, e.sortDir);
    }
}