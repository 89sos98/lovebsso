﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.UI;
using System.Xml.Linq;

public partial class Loader : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!File.Exists(Server.MapPath("data.xml")))
        {
            string url =
                "http://demos.openrico.org/livegrid_demo/ajax_livegrid_content?id=data_grid&page_size=800&offset=0&get_total=true";
            var cli = new WebClient();
            string data = cli.DownloadString(url);
            var writer = new StreamWriter(Server.MapPath("data.xml"));
            writer.WriteLine(data);
            writer.Close();
            writer.Dispose();
        }
        else
        {
            XDocument loaded = XDocument.Load(Server.MapPath("data.xml"));
            var q = from c in loaded.Descendants("rows").Descendants("tr")
                    select new
                               {
                                   movie = (from m in c.Elements("td") select m.Value).ToList(),
                               };

            HomePageDataContext _context = Util.getContext();
            IQueryable<TBMovie> current = from m in _context.TB_Movies select m;
            _context.TB_Movies.DeleteAllOnSubmit(current);
            _context.SubmitChanges();
            foreach (var item in q)
            {
                var m = new TBMovie
                            {
                                IDMovie = int.Parse(item.movie[0]),
                                Title = item.movie[1],
                                Genre = item.movie[2],
                                Rating = decimal.Parse(item.movie[3]),
                                Votes = int.Parse(item.movie[4]),
                                Year = item.movie[5]
                            };
                _context.TB_Movies.InsertOnSubmit(m);
            }
            _context.SubmitChanges();
        }
    }
}