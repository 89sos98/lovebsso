﻿using System;
using System.Linq;
using System.Web.UI;

public partial class GridWithLinq : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        BindGrid();
    }

    public void BindGrid()
    {
  
        HomePageDataContext context = Util.getContext();
        IQueryable<TBMovie> movies = (from t in context.TB_Movies select t).Take(15);
        YuiGrid1.DataSource = movies;
        YuiGrid1.DataBind();
    }
}