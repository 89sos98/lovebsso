﻿using System;
using System.Linq;
using System.Web.UI;

public partial class GridWithRowExpander : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HomePageDataContext context = Util.getContext();
        IQueryable<TBMovie> regs = context.TB_Movies.Where(c => c.Plot.Length > 0);
        YuiGrid1.DataSource = regs;
        YuiGrid1.DataBind();
    }
}