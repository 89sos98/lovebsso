﻿using System;
using System.Linq;
using System.Web.UI;
using ExtExtenders;

public partial class DragDropTree : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var root = new TreeNode {id = "0", leaf = false, text = "root"};
        treeAvailable.TreeNodes.Add(root);

        root = new TreeNode {id = "0", leaf = false, text = "root"};
        treeSelected.TreeNodes.Add(root);
    }

    protected void treeSelected_NodeDroped(object sender, NodeDropedEventArgs e)
    {
        //remove node from tb_available
        TreeNode nodeDroped = e.DropedNode;
        HomePageDataContext db = Util.getContext();
        TBAvailableMovie nToRemove = db.TB_AvailableMovies.Where(n => n.IDMovie == int.Parse(nodeDroped.id)).Single();
        db.TB_AvailableMovies.DeleteOnSubmit(nToRemove);
        db.SubmitChanges();

        var NodeToInsert = new TBSelectedMovie {IDMovie = int.Parse(nodeDroped.id), Title = nodeDroped.text};
        db.TB_SelectedMovies.InsertOnSubmit(NodeToInsert);
        db.SubmitChanges();
        //System.Globalization.CultureInfo.CurrentCulture.NumberFormat.CurrencyDecimalSeparator
    }

    protected void treeAvailable_NodeDroped(object sender, NodeDropedEventArgs e)
    {
        //remove node from tb_available
        TreeNode nodeDroped = e.DropedNode;
        HomePageDataContext db = Util.getContext();
        TBSelectedMovie nToRemove = db.TB_SelectedMovies.Where(n => n.IDMovie == int.Parse(nodeDroped.id)).Single();
        db.TB_SelectedMovies.DeleteOnSubmit(nToRemove);
        db.SubmitChanges();

        var NodeToInsert = new TBAvailableMovie {IDMovie = int.Parse(nodeDroped.id), Title = nodeDroped.text};
        db.TB_AvailableMovies.InsertOnSubmit(NodeToInsert);
        db.SubmitChanges();
    }
}