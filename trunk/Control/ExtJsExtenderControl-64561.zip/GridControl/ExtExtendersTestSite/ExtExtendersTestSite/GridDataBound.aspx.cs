using System;
using System.Web.UI;
using ExtExtenders;

public partial class GridDataBound : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        YuiGrid1.SelectedIndexChanged += YuiGrid1_SelectedIndexChanged;
        ScriptManager1.RegisterAsyncPostBackControl(YuiGrid1);
        if (!IsPostBack)
        {
            YuiGrid1.DataSource = Movie.GetMovies();
            YuiGrid1.DataBind();
        }
    }

    private void YuiGrid1_SelectedIndexChanged(object sender, SelectedRowArgs e)
    {
        txtTitle.Text = e.SelectedRow["TITLE"].ToString();
        txtRating.Text = e.SelectedRow["RATING"].ToString();
        txtVotes.Text = e.SelectedRow["VOTES"].ToString();
    }
    protected void YuiGrid1_RowDataBound(object sender, RowDataBoundEventArgs e)
    {
        var obj = e.Row as TBMovie;
        if (obj !=null)
        {
            if (obj.Rating > 80)
            {
                obj.Rating =  obj.Rating *2;
            }
            if (int.Parse(obj.Year) <1973 )
            {
                obj.Year = string.Format("<font color='blue'>{0}</font>", obj.Year);
            }

        }
    }
}