using System;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CalendarTest : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        for (int i = 1998; i < DateTime.Now.Year; i++)
        {
            cboYears.Items.Add(new ListItem(i.ToString(), i.ToString()));
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        lblAnswer.Text = txtNam.Text + "=>" + txtDate.Text + " Color " + txtColor.Text;
    }
}