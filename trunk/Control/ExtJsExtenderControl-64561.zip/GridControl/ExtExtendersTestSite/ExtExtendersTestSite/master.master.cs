using System;
using System.Web.UI;

public partial class master : MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
}