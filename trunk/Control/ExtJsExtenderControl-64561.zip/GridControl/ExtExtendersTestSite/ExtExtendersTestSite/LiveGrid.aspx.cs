using System;
using System.Web.UI;

public partial class LiveGrid : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        YuiGrid1.TotalRecords = Movie.GetMovieCount();
        YuiGrid1.DataBind();
    }
}