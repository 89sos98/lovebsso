using System.Web.UI;

#region Assembly Resource Attribute

[assembly: WebResource("ExtExtenders.ext-yui-adapter.js", "text/javascript", PerformSubstitution = true)]

#endregion

namespace ExtExtenders
{
    /// <summary>
    /// Class to include the js file
    /// </summary>
    public static class ext_yui_adapter
    {
    }
}