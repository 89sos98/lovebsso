﻿using System;
using System.Collections.Generic;
using System.Text;
using ExtExtenders.Helpers;
using System.Web.UI;
using System.Web.Script.Serialization;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
[assembly: WebResource("ExtExtenders.UploadDialog.UploadDialogBehavior.js", "text/javascript")]
[assembly: WebResource("ExtExtenders.UploadDialog.Ext.ux.UploadDialog.js", "text/javascript")]
[assembly: WebResource("ExtExtenders.UploadDialog.Ext.ux.UploadDialog.css", "text/css",PerformSubstitution=true)]
[assembly: WebResource("ExtExtenders.images.check.gif", "image/gif")]
[assembly: WebResource("ExtExtenders.images.done.gif", "image/gif")]
[assembly: WebResource("ExtExtenders.images.failed.gif", "image/gif")]
[assembly: WebResource("ExtExtenders.images.file-add.gif", "image/gif")]
[assembly: WebResource("ExtExtenders.images.file-remove.gif", "image/gif")]
[assembly: WebResource("ExtExtenders.images.file-uploading.gif", "image/gif")]
[assembly: WebResource("ExtExtenders.images.loading.gif", "image/gif")]
[assembly: WebResource("ExtExtenders.images.uncheck.gif", "image/gif")]
[assembly: WebResource("ExtExtenders.images.upload-start.gif", "image/gif")]
[assembly: WebResource("ExtExtenders.images.upload-stop.gif", "image/gif")]

namespace ExtExtenders {
    /// <summary>
    /// Control to upload multiple files without using flash
    /// </summary>
    [ToolboxData("<{0}:UploadDialog runat=\"server\"></{0}:UploadDialog>")]
    public class UploadDialog : ExtScriptWebControlBase, INamingContainer {
        /// <summary>
        /// Constructor
        /// </summary>
        public UploadDialog()
            : base(HtmlTextWriterTag.Div) {
            Width = 0;
            Height = 0;
          
        }
        /// <summary>
        /// Url where the files are going to be processed
        /// </summary>
        [DescribableProperty(), Description("Url where the files are going to be processed")]
        public string UploadUrl { get; set; }
        /// <summary>
        /// Extensions that the dialog is allowed to upload
        /// defaults to all ( Ex: jpg,gif)
        /// </summary>
        [Description("Extensions that are allowed to upload (default to all)")]
        public string Permitted_Extensions  { get; set; }
        /// <summary>
        /// If the upload of the files should start automatically
        /// </summary>
        [DescribableProperty(),Description("If the upload should start when any file is added")]
        public bool Upload_Autostart  { get; set; }
        /// <summary>
        /// Control that will open the dialog
        /// </summary>
        [DescribableProperty(), Description("Control that will open the dialog(optional)")]
        public string PopupControlId { get; set; }

    
        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.PreRender"></see> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnPreRender(EventArgs e) {
            base.OnPreRender(e);
          
            
            ClientScriptManager man = Page.ClientScript;
            man.RegisterClientScriptResource(GetType(), "ExtExtenders.UploadDialog.Ext.ux.UploadDialog.js");

            string resource = Page.ClientScript.GetWebResourceUrl(GetType(), "ExtExtenders.UploadDialog.Ext.ux.UploadDialog.css");


            var lnk = new HtmlLink { Href = resource };
            lnk.Attributes["rel"] = "stylesheet";
            lnk.Attributes["type"] = "text/css";

            Page.Header.Controls.Add(lnk);
           
        }

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns>The script descriptors for the control</returns>
        public override IEnumerable<ScriptDescriptor> GetScriptDescriptors() {
            var descriptor = new ScriptControlDescriptor(
                "ExtExtenders.UploadDialogBehavior", ClientID);
           

            Util.DescribeProperties(this, descriptor);
            if (!string.IsNullOrEmpty(Permitted_Extensions)) {
                descriptor.AddProperty("Permitted_Extensions", Permitted_Extensions.Split(','));
            }
           
            //descriptor.AddProperty("PostBackId",
            //    this.PostBackId);
            return new ScriptDescriptor[] { descriptor };
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns>The script references for the control</returns>
        public override IEnumerable<ScriptReference> GetScriptReferences() {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.UploadDialog.UploadDialogBehavior.js");

            return new[] { reference };
        }
    }
}
