﻿
Type.registerNamespace('ExtExtenders');

ExtExtenders.UploadDialogBehavior = function(element) {

    ExtExtenders.UploadDialogBehavior.initializeBase(this, [element]);
    this._Permitted_Extensions = [];
    this._PopupControlId = "";
}
ExtExtenders.UploadDialogBehavior.prototype = {
    initialize: function() {
        /// <summary>
        /// Initialize the behavior
        /// </summary>
        ExtExtenders.UploadDialogBehavior.callBaseMethod(this, 'initialize');
       
        var ElId = this.get_element().id;

        var dialog = new Ext.ux.UploadDialog.Dialog({
            url: this.get_UploadUrl(),
            reset_on_hide: true,
            allow_close_on_upload: false,
            upload_autostart: this.get_Upload_Autostart(),
            modal: true,
            permitted_extensions: this.get_Permitted_Extensions()
        });
        if (this._PopupControlId != "") {
            this._showHandler = Function.createDelegate(this, this.showDialog);
            $addHandler($get(this._PopupControlId), 'click', this._showHandler);
        }
        this.dialog = dialog;
    },
    get_Dialog: function() {
        return this.dialog;
    },
    showDialog: function(id) {
        this.dialog.show();
    },
    _onShow: function(e) {
        this.dialog.show();
        e.preventDefault();
        return false;

    },
    get_UploadUrl: function() {
        return this._UploadUrl;
    },
    set_UploadUrl: function(value) {
        this._UploadUrl = value;
    },
    get_Permitted_Extensions: function() {
        return this._Permitted_Extensions;
    },
    set_Permitted_Extensions: function(value) {
        this._Permitted_Extensions = value;
    },
    get_Upload_Autostart: function() {
        return this.Upload_Autostart;
    },
    set_Upload_Autostart: function(value) {
        this.Upload_Autostart=value;
    },
    get_PopupControlId: function() {
        return this._PopupControlId;
    },
    set_PopupControlId: function(value) {
        this._PopupControlId = value;
    },
    dispose: function() {
        /// <summary>
        /// Dispose the behavior
        /// </summary>

        if (this._showHandler) {
            $removeHandler($get(this._PopupControlId), 'click', this._showHandler);
            this._showHandler = null;
        }

        ExtExtenders.UploadDialogBehavior.callBaseMethod(this, 'dispose');
    }


}
ExtExtenders.UploadDialogBehavior.registerClass('ExtExtenders.UploadDialogBehavior', Sys.UI.Control);
if (typeof (Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 
