using System.Web.UI;

#region Assembly Resource Attribute

[assembly: WebResource("ExtExtenders.gridExtension.js", "text/javascript")]

#endregion

namespace ExtExtenders
{
    /// <summary>
    /// Class to include the js
    /// </summary>
    public static class GridExtenstions
    {
    }
}