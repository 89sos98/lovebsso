using System;

namespace ExtExtenders
{
    /// <summary>
    /// Event delegate
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void CellEditedEventHandler(Object sender, GridCellEditedArgs e);

    /// <summary>
    /// Event delegate
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void SelectedRowEventHandler(Object sender, SelectedRowArgs e);

    /// <summary>
    /// Event delegate
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void RemovedRowEventHandler(Object sender, RemovedRowArgs e);

    /// <summary>
    /// Event delegate
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void DropedRowEventHandler(Object sender, DropRowsEventArgs e);

    /// <summary>
    /// Event delegate
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void GridContextMenuEventHandler(Object sender, GridContextMenuEventArgs e);

    /// <summary>
    /// Event delegate
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void PageIndexChangedEventHandler(Object sender, PageIndexChangedArgs e);
    /// <summary>
    /// Event for row data bound
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void RowDataBoundEventHandler(Object sender,RowDataBoundEventArgs e);
}