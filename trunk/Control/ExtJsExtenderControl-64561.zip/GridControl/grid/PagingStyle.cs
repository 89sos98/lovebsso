namespace ExtExtenders
{
    /// <summary>
    /// Paging style for the grid
    /// </summary>
    public enum PagingStyle
    {
        /// <summary>
        /// Set the pager as the numeric one
        /// </summary>
        NumberPaging = 0,
        /// <summary>
        /// The ExtJs nav toolbar
        /// </summary>
        NavBar = 1
    }
}