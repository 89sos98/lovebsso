using System;
using System.Collections.Generic;

namespace ExtExtenders
{
    /// <summary>
    /// YuiGrid created row event argument class.
    /// </summary>
    [Serializable]
    public class GridCellEditedArgs : EventArgs
    {
        /// <summary>
        /// The row  edited
        /// </summary>
        public Dictionary<string, object> Record { get; set; }

        /// <summary>
        /// The field (column)edited
        /// </summary>
        public string Field { get; set; }

        /// <summary>
        /// The current value of the cell
        /// </summary>
        public string Value { get; set; }
    }

    /// <summary>
    /// Class for the selected row index changed event
    /// </summary>
    public class SelectedRowArgs : EventArgs
    {
        /// <summary>
        ///  The row selected
        /// </summary>
        /// <value></value>
        public Dictionary<String, Object> SelectedRow { get; set; }
    }

    /// <summary>
    /// Class for the selected row index changed event
    /// </summary>
    public class RemovedRowArgs : EventArgs
    {
        /// <summary>
        ///  The row selected
        /// </summary>
        /// <value></value>
        public List<Dictionary<String, Object>> RowsRemoved { get; set; }
    }

    /// <summary>
    /// Class for the selected row index changed event
    /// </summary>
    public class DropRowsEventArgs : EventArgs
    {
        /// <summary>
        ///  The row(s) dropped 
        /// </summary>
        /// <value></value>
        public List<Dictionary<String, Object>> RowsDropped { get; set; }
    }
    /// <summary>
    /// Event arguments for the context menu clicked event
    /// </summary>
    public class GridContextMenuEventArgs : EventArgs
    {
        private Dictionary<String, Object> _Row;

        /// <summary>
        ///  The row selected
        /// </summary>
        /// <value></value>
        public Dictionary<String, Object> SelectedRow
        {
            get { return _Row; }
            set { _Row = value; }
        }
        private MenuItem _menuClicked;

        /// <summary>
        /// The menu item that was clicked
        /// </summary>
        /// <value>The menu clicked.</value>
        public MenuItem MenuClicked
        {
            get { return _menuClicked; }
            set { _menuClicked = value; }
        }
    }
    public class PageIndexChangedArgs : EventArgs
    {
        /// <summary>
        /// The row number of the first record of the page
        /// </summary>
        public int currentRecord { get; set; }
        /// <summary>
        /// Number of records per page
        /// </summary>
        public int pageSize { get; set; }
        /// <summary>
        /// The name of the column being sorted
        /// </summary>
        public string sortColumn { get; set; }
        /// <summary>
        /// The direction of the sort (asc or desc)
        /// </summary>
        public string sortDir { get; set; }

        /// <summary>
        /// All information sent to the event in a json format
        /// </summary>
        public string json { get; set; }
    }
    public class RowDataBoundEventArgs : EventArgs
    {
        /// <summary>
        /// The row  edited
        /// </summary>
        public object Row { get; set; }
    }
}