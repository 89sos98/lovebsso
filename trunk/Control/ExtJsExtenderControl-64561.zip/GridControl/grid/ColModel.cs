using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Script.Serialization;

namespace ExtExtenders
{
    /// <summary>
    /// The Type of the data being edited
    /// Attaches some auto javascript validations
    /// </summary>
    public enum DataType
    {
        /// <summary>
        /// The column being edited is a standart Text (default)
        /// </summary>
        Text = 0,
        /// <summary>
        /// The colum being edited has only numbers
        /// </summary>
        Numeric = 1,
        /// <summary>
        /// The column being edited is a date
        /// </summary>
        Date = 2,
        /// <summary>
        /// The colum being edited will display a textarea
        /// </summary>
        Multiline=3
    }

    /// <summary>
    /// Class to represent a grid column
    /// </summary>
    public class ColModel
    {
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        /// <summary>
        ///  If this column should be used as identity
        /// </summary>
        public bool IsIdentity { get; set; }
        /// <summary>
        /// (optional) Set the CSS text-align property of the column. Defaults to undefined. 
        /// </summary>
        /// <value>left|right|center|justify</value>
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public string align { get; set; }

        /// <summary>
        /// (optional) Set custom CSS for all table cells in the column (excluding headers). Defaults to undefined. 
        /// </summary>
        /// <value>CSS Class Name</value>
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public string css { get; set; }

        /// <summary>
        /// (optional) The name of the field in the grid's datasource from which to draw the column's value. If not specified, the column's index is used as an index into the Record's data Array. 
        /// </summary>
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public string dataIndex { get; set; }

        /// <summary>
        /// (optional) The name of the field in the grid's datasource from which to draw the expanded value
        /// </summary>
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public string expanderdataIndex { get; set; }
        /// <summary>
        /// (optional) the Header of the column expanded
        /// </summary>
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public string expanderHeader { get; set; }
        /// <summary>
        /// (optional) True if the column width cannot be changed. Defaults to false. 
        /// </summary>
        /// <value><c>true</c> if fixed; otherwise, <c>false</c>.</value>
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public bool? fixedWidth { get; set; }

        /// <summary>
        /// The header text to display in the Grid view. 
        /// </summary>
        /// <value>Text</value>
        [ScriptIgnore]
        [DefaultValue(""), NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public string header { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="T:ColModel"/> is hidden.
        /// </summary>
        /// <value><c>true</c> if hidden; otherwise, <c>false</c>.</value>
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public bool? hidden { get; set; }

        /// <summary>
        /// optional) True to hide the column. Defaults to false. 
        /// </summary>
        /// <value><c>true</c> if hideable; otherwise, <c>false</c>.</value>
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public bool? hideable { get; set; }

        /// <summary>
        /// (optional) Defaults to the column's initial ordinal position. A name which identifies this column. The id is used to create a CSS class name which is applied to all table cells (including headers) in that column.
        /// </summary>
        /// <value>A name which identifies this column.</value>
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public String id { get; set; }

        /// <summary>
        /// (optional) True to disable the column menu. Defaults to false. 
        /// </summary>
        /// <value><c>true</c> if no menu; otherwise, <c>false</c>.</value>
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public bool? menuDisabled { get; set; }

        /// <summary>
        /// (optional) A function used to generate HTML markup for a cell given the cell's data value. If not specified, the default renderer uses the raw data value. 
        /// </summary>
        /// <value>Javascript function.</value>
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public string renderer { get; set; }

        /// <summary>
        /// (optional) False to disable column resizing. Defaults to true. 
        /// </summary>
        /// <value><c>false</c> if not resizable; otherwise, <c>true</c>.</value>
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public bool? resizable { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="T:ColModel"/> is sort.
        /// </summary>
        /// <value><c>true</c> if sort; otherwise, <c>false</c>.</value>
        [ScriptIgnore]
        [DefaultValue(false), NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public bool? sortable { get; set; }

        /// <summary>
        /// (optional) A text string to use as the column header's tooltip. If Quicktips are enabled, this value will be used as the text of the quick tip, otherwise it will be set as the header's HTML title attribute. Defaults to ''. 
        /// </summary>
        /// <value>Text</value>
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public string toolTip { get; set; }

        /// <summary>
        /// (optional) The initial width in pixels of the column. 
        /// </summary>
        /// <value>Number of pixels.</value>
        [ScriptIgnore]
        [NotifyParentProperty(true), RefreshProperties(RefreshProperties.Repaint)]
        public int? width { get; set; }

        /// <summary>
        /// Indicates if a column is editable. Defaults to true if grid is editable.
        /// </summary>
        public bool? Editable { get; set; }

        /// <summary>
        /// The id of the control used 
        /// to edit this column
        /// </summary>
        [ScriptIgnore]
        public string EditControlId { get; set; }

        /// <summary>
        /// The dataType being edited
        /// </summary>
        [ScriptIgnore]
        public DataType DataType { get; set; }

        /// <summary>
        /// If the cell being edited is a date what format 
        /// it is
        /// </summary>
        [ScriptIgnore]
        public string DateFormat { get; set; }

        /// <summary>
        /// The MaxLenght of the column in the editor
        /// </summary>
        /// <value>Int</value>
        [ScriptIgnore]
        public int? maxLength { get; set; }

        /// <summary>
        /// Indicates if blank input is allowed in edit mode.
        /// </summary>
        /// <value><c>true</c> if [allow blank]; otherwise, <c>false</c>.</value>
        [ScriptIgnore]
        public bool? allowBlank { get; set; }

        /// <summary>
        /// Allows a user to specify a client side function that will be redored on edit of column.
        /// </summary>
        /// <value>Function name that returns an Ext.form.field element</value>
        [ScriptIgnore]
        public String Editor { get; set; }

        /// <summary>
        /// Gets key value pair collection of Editor related options.
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Browsable(false), MergableProperty(false)]
        public IDictionary<string, object> EditorOptions
        {
            get
            {
                var options = new Dictionary<string, object>();

                if (EditControlId != null)
                    options.Add("EditControlId", EditControlId);
                if (Editor != null)
                    options.Add("Editor", Editor);
                if (allowBlank != null)
                    options.Add("allowBlank", allowBlank);
                if (maxLength != null)
                    options.Add("maxLength", maxLength);
                if (DateFormat != null)
                    options.Add("DateFormat", DateFormat);

                options.Add("DataType", DataType);

                return options;
            }
        }

        /// <summary>
        /// Gets key value pair collection of column related options.
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Browsable(false), MergableProperty(false)]
        public IDictionary<string, object> ConfigOptions
        {
            get
            {
                var options = new Dictionary<string, object>();
                if (align != null)
                    options.Add("align", align);
                if (css != null)
                    options.Add("css", css);
                if (dataIndex != null)
                    options.Add("dataIndex", dataIndex);
                if (fixedWidth != null)
                    options.Add("fixed", fixedWidth);
                if (header != null)
                    options.Add("header", header);
                if (hidden != null)
                    options.Add("hidden", hidden);
                if (hideable != null)
                    options.Add("hideable", hideable);
                if (id != null)
                    options.Add("id", id);
                if (menuDisabled != null)
                    options.Add("menuDisabled", menuDisabled);
                if (!string.IsNullOrEmpty(renderer))
                    options.Add("renderer", renderer);
                if (resizable != null)
                    options.Add("resizable", resizable);
                if (sortable != null)
                    options.Add("sortable", sortable);
                if (toolTip != null)
                    options.Add("tooltip", toolTip);
                if (width != null)
                    options.Add("width", width);
                if (expanderdataIndex != null)
                    options.Add("expanderdataIndex", expanderdataIndex);
                if (expanderHeader !=null)
                    options.Add("expanderHeader",expanderHeader);
                if (IsIdentity)
                    options.Add("IsIdentity", IsIdentity);
                
                return options;
            }
        }
    }
}