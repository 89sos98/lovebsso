using System;

namespace ExtExtenders
{
    /// <summary>
    /// YuiGrid event args class.
    /// </summary>
    [Serializable]
    public class YuiGridEventArgs : EventArgs
    {
        /// <summary>
        /// Gets or sets the name of the event.
        /// </summary>
        /// <value>The name of the event.</value>
        public String EventName { get; set; }

        /// <summary>
        /// Gets or sets the arguments.
        /// </summary>
        /// <value>The arguments.</value>
        public String Arguments { get; set; }
    }
}