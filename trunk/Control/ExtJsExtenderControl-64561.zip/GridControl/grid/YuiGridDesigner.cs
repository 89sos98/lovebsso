// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Web.UI.Design.WebControls;

namespace ExtExtenders
{
    /// <summary>
    /// Simple read-only designer for the yui control
    /// </summary>
    [SuppressMessage("Microsoft.Security", "CA2117:AptcaTypesShouldOnlyExtendAptcaBaseTypes",
        Justification = "Security handled by base class")]
    public class YuiGridDesigner : DataBoundControlDesigner
    {
        /// <summary>
        /// Reference to the YuiGrid control we're designing
        /// </summary>
        private YuiGrid _component;

        /// <summary>
        /// Initialize to make sure we're attached to an YuiGrid control
        /// </summary>
        /// <param name="component">Component</param>
        [SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters",
            Justification = "Assembly is not localized")]
        [SuppressMessage("Microsoft.Security", "CA2116:AptcaMethodsShouldOnlyCallAptcaMethods",
            Justification = "Security handled by base class")]
        public override void Initialize(IComponent component)
        {
            _component = component as YuiGrid;
            if (_component == null)
                throw new ArgumentException("Component must be an YuiGrid control", "component");
            base.Initialize(component);
        }

        /// <summary>
        /// Provides the markup that is used to render the control at design time when an error has occurred.
        /// </summary>
        /// <param name="e">The <see cref="T:System.Exception"></see> that was thrown.</param>
        /// <returns>
        /// The markup used to render the control at design time when an error has occurred.
        /// </returns>
        protected override string GetErrorDesignTimeHtml(Exception e)
        {
            var html = new StringBuilder();

            html.Append("<div style='width:" + _component.Width + ";height:" + _component.Height + "'>");
            html.Append(e.ToString());
            html.Append("</div>");
            return html.ToString();
        }

        /// <summary>
        /// Generates the markup that is used to render the control at design time.
        /// </summary>
        /// <returns>
        /// The markup used to render the control at design time.
        /// </returns>
        public override string GetDesignTimeHtml()
        {
            var html = new StringBuilder();
            html.Append("<div style='width:" + _component.Width + ";height:" + _component.Height + "'>");
            html.Append("</div>");
            return html.ToString();
        }
    }
}