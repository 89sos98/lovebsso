using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ExtExtenders.Helpers;

[assembly: WebResource("ExtExtenders.GridControlBehavior.js", "text/javascript")]
[assembly: WebResource("ExtExtenders.LiveGrid.BufferedGrid.css", "text/css", PerformSubstitution = true)]
[assembly: WebResource("ExtExtenders.LiveGrid.BufferedGridDragZone.js", "text/javascript")]
[assembly: WebResource("ExtExtenders.LiveGrid.BufferedGridToolbar.js", "text/javascript")]
[assembly: WebResource("ExtExtenders.LiveGrid.BufferedGridView.js", "text/javascript")]
[assembly: WebResource("ExtExtenders.LiveGrid.BufferedJsonReader.js", "text/javascript")]
[assembly: WebResource("ExtExtenders.LiveGrid.BufferedRowSelectionModel.js", "text/javascript")]
[assembly: WebResource("ExtExtenders.LiveGrid.BufferedStore.js", "text/javascript")]
[assembly: WebResource("ExtExtenders.RowExpanderMin.js", "text/javascript")]
[assembly: WebResource("ExtExtenders.DialogEditor.js", "text/javascript")]
namespace ExtExtenders
{
    /// <summary>
    /// Control that represents an ExtJs Grid
    /// </summary>
    [ParseChildren(true)]
    [PersistChildren(true)]
    [ToolboxData("<{0}:YuiGrid runat=server></{0}:YuiGrid>")]
    [ToolboxBitmap(typeof (GridView))]
    [Designer(typeof (YuiGridDesigner))]
    public class YuiGrid : ExtScriptDataBoundControlBase, INamingContainer, IPostBackEventHandler, ICallbackEventHandler
    {
        /// <summary>
        /// The columns of the grid
        /// </summary>
        private List<ColModel> _Columns;


        /// <summary>
        /// For internal use 
        /// </summary>
        public List<string> _Events = new List<string>();

        private bool changedPage = false;
        #region Events

        /// <summary>
        /// Key for the cell edited 
        /// </summary>
        private static readonly Object CellEditedKey = new Object();

        /// <summary>
        /// Key for the rowcontextmenu event
        /// </summary>
        private static readonly Object RowContextMenuKey = new Object();

        /// <summary>
        /// Key for the row droped event
        /// </summary>
        private static readonly Object RowDropedKey = new Object();

        /// <summary>
        /// Key for the row removed event
        /// </summary>
        private static readonly Object RowRemovedKey = new Object();

        /// <summary>
        /// Key for the selectedrowindexchanged event
        /// </summary>
        private static readonly Object SelectedRowKey = new Object();

        /// <summary>
        /// Key for the pageindex changed event
        /// </summary>
        private static readonly Object PageIndexChangeKey = new Object();

        /// <summary>
        /// Key for the pageindex changed event
        /// </summary>
        private static readonly Object RowDataBoundKey = new Object();

        /// <summary>
        /// Event fired when a item on the row context menu is clicked
        /// </summary>
        public event RowDataBoundEventHandler RowDataBound
        {
            add { Events.AddHandler(RowDataBoundKey, value); }
            remove { Events.RemoveHandler(RowDataBoundKey, value); }
        }

        /// <summary>
        /// Event fired when a item on the row context menu is clicked
        /// </summary>
        public event GridContextMenuEventHandler RowContextMenuClicked
        {
            add { Events.AddHandler(RowContextMenuKey, value); }
            remove { Events.RemoveHandler(RowContextMenuKey, value); }
        }

        /// <summary>
        /// Event fired when a row(s) is droped on the grid
        /// </summary>
        public event DropedRowEventHandler RowDroped
        {
            add
            {
                _Events.Add("RowDroped");
                Events.AddHandler(RowDropedKey, value);
            }
            remove { Events.RemoveHandler(RowDropedKey, value); }
        }

        /// <summary>
        /// Event fired when a row(s) is removed from the grid
        /// </summary>
        public event RemovedRowEventHandler RowRemoved
        {
            add
            {
                _Events.Add("RowRemoved");
                Events.AddHandler(RowRemovedKey, value);
            }
            remove { Events.RemoveHandler(RowRemovedKey, value); }
        }

        /// <summary>
        /// Event fired when a cell is edited
        /// </summary>
        public event CellEditedEventHandler CellEdited
        {
            add
            {
                _Events.Add("CellEdited");
                Events.AddHandler(CellEditedKey, value);
            }
            remove { Events.RemoveHandler(CellEditedKey, value); }
        }

        /// <summary>
        /// Event fired when a row is selected
        /// </summary>
        public event SelectedRowEventHandler SelectedIndexChanged
        {
            add
            {
                _Events.Add("SelectedRow");
                if (Events != null) Events.AddHandler(SelectedRowKey, value);
            }
            remove { Events.RemoveHandler(SelectedRowKey, value); }
        }

        /// <summary>
        /// Event fired when a row is selected
        /// </summary>
        public event PageIndexChangedEventHandler PageIndexChanged
        {
            add
            {
                _Events.Add("PageIndexChanged");
                if (Events != null) Events.AddHandler(PageIndexChangeKey, value);
            }
            remove { Events.RemoveHandler(PageIndexChangeKey, value); }
        }
        #endregion

        #region Properties
        /// <summary>
        /// 
        /// </summary>
        //[Browsable(true), Category("ColumnConfig")]
        //public bool  { get; set; }
        private readonly Dictionary<string, object> _viewOptions = new Dictionary<string, object>();

        private string _Fields = String.Empty;

        /// <summary>
        /// Internaly used by the group grid
        /// </summary>
        private ExtDataContainer _JsonData;

        /// <summary>
        /// Name of the property within the DataSource that contains a record identifier value.
        /// </summary>
        [DescribableProperty]
        public string IdRecord { get; set; }

        /// <summary>
        /// If true data is loaded as the grid is
        /// scrolled
        /// </summary>
        [DescribableProperty]
        public bool EnableBufferData { get; set; }

        /// <summary>
        /// Page that will be used to process the data
        /// </summary>
        [DescribableProperty]
        public string ProcessingPage { get; set; }

        /// <summary>
        /// True to stripe the rows. Default is false. 
        /// </summary>
        [Browsable(true), Category("GridConfig")]
        public bool? stripeRows { get; set; }


        /// <summary>
        /// Enables inline editing
        /// </summary>
        [Description("If the grid is editable"), DescribableProperty]
        public bool EnableEdit { get; set; }

        /// <summary>
        /// The toolbar to appear on the top of the grid (optional)
        /// </summary>
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [Browsable(false)]
        public ToolBar TopToolBar { get; set; }

        /// <summary>
        /// Title for the grid
        /// </summary>
        [DescribableProperty]
        public string title { get; set; }

        /// <summary>
        /// Row context menu for the grid
        /// </summary>
        [Browsable(false)]
        public Menu RowContextMenu { get; set; }

        [Browsable(false)]
        private ExtDataContainer JsonData
        {
            get
            {
              
                return _JsonData;
            }
            set { _JsonData = value; }
        }


        /// <summary>
        /// Gets or sets a value indicating whether [auto post back].
        /// </summary>
        /// <value><c>true</c> if [auto post back]; otherwise, <c>false</c>.</value>
        [DescribableProperty]
        public bool AutoPostBack { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [auto generat columns].
        /// </summary>
        /// <value><c>true</c> if [auto generat columns]; otherwise, <c>false</c>.</value>
        [Browsable(true), Category("GridConfig"), Description("If the grid should auto-generate the columns")]
        public bool AutoGenerateColumns { get; set; }

        /// <summary>
        /// Name of the field to group the data
        /// </summary>
        [Browsable(true), Description("Field to group the data"), DescribableProperty]
        public string GroupingField { get; set; }

        /// <summary>
        /// Gets or sets the columns.
        /// </summary>
        /// <value>The columns.</value>
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Browsable(false), Bindable(true), MergableProperty(false), DescribableProperty]
        public List<ColModel> Columns
        {
            get
            {
                if (_Columns == null)
                {
                    _Columns = new List<ColModel>();
                }

                return _Columns;
            }
        }

        /// <summary>
        /// Prevent the Controls property from appearing in the editor (so
        /// that people will use the Columns collection instead)
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never)]
        public override ControlCollection Controls
        {
            get { return base.Controls; }
        }

        /// <summary>
        /// Gets or sets the fields.
        /// </summary>
        /// <value>The fields.</value>
        [Browsable(false), DescribableProperty]
        public string Fields
        {
            get
            {
                if (_Fields == String.Empty)
                    _Fields = GenerateFields();
                return _Fields;
            }
            set { _Fields = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [enable row sorting].
        /// </summary>
        /// <value><c>true</c> if [enable row sorting]; otherwise, <c>false</c>.</value>
        [Browsable(true), DescribableProperty, Category("GridConfig"),
         Description("If drag and drop row sorting is enabled")]
        public bool EnableRowSorting { get; set; }

        /// <summary>
        /// Gets or sets the size of the page.
        /// </summary>
        /// <value>The size of the page.</value>
        [Browsable(true), DescribableProperty, Category("GridConfig"), Description("Number of records in each page")]
        public int PageSize { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [enable paging].
        /// </summary>
        /// <value><c>true</c> if [enable paging]; otherwise, <c>false</c>.</value>
        [Browsable(true), DescribableProperty, Category("GridConfig")]
        public bool EnablePaging { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [select multiple].
        /// </summary>
        /// <value><c>true</c> if [select multiple]; otherwise, <c>false</c>.</value>
        [Browsable(true), DescribableProperty, Category("GridConfig"), Description("Enable multiple row selection")]
        public bool SelectMultiple { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether rows can be selected via checkbox column.
        /// </summary>
        /// <value><c>true</c> if [show selection checkbox column]; otherwise, <c>false</c>.</value>
        [Browsable(true), DescribableProperty, Category("GridConfig"), Description("Enable checkbox row selection")]
        public bool CheckboxSelection { get; set; }

        /// <summary>
        /// Gets or sets the web service method.
        /// </summary>
        /// <value>The web service method.</value>
        [Browsable(true), DescribableProperty, Category("GridConfig"),
         Description("Name of the webservice method to call")]
        public string WebServiceMethod { get; set; }

        /// <summary>
        /// Gets or sets the web service path.
        /// </summary>
        /// <value>The web service path.</value>
        [Browsable(true), DescribableProperty, Category("GridConfig"), Description("Path of the webservice to call")]
        public string WebServicePath { get; set; }

        /// <summary>
        /// Gets or sets the paging style.
        /// </summary>
        /// <value>The paging style.</value>
        [Browsable(true), DescribableProperty, Category("GridConfig"), Description("Page bar that will be draw")]
        public PagingStyle PagingStyle { get; set; }

        /// <summary>
        /// The total number of records when
        /// the grid is DataBound- needed to page 
        /// </summary>
        public int TotalRecords { get; set; }

        /// <summary>
        /// True to enable dragging of the selected rows of the GridPanel.
        /// </summary>
        /// <remarks>
        /// Setting this to true causes this GridPanel's GridView to create an instance of Ext.grid.GridDragZone. 
        /// This is available (only after the Grid has been rendered) as the GridView's dragZone property. 
        /// A cooperating DropZone must be created who's implementations of onNodeEnter, onNodeOver, onNodeOut and 
        /// onNodeDrop are able to process the data which is provided.
        /// </remarks>
        [Browsable(true), Category("GridConfig")]
        public bool? EnableDragDrop { get; set; }

        /// <summary>
        /// The id of a column in this grid that should expand to fill unused space. This id can not be 0. 
        /// </summary>
        [Browsable(true), Category("ColumnConfig")]
        public string AutoExpandColumnID { get; set; }

        /// <summary>
        /// The maximum width the autoExpandColumn can have (if enabled). Defaults to 1000. 
        /// </summary>
        [Browsable(true), Category("ColumnConfig")]
        public bool? AutoExpandMax { get; set; }

        /// <summary>
        /// The minimum width the autoExpandColumn can have (if enabled). defaults to 50. 
        /// </summary>
        [Browsable(true), Category("ColumnConfig")]
        public bool? AutoExpandMin { get; set; }

        /// <summary>
        /// True to use height:'auto', false to use fixed height. 
        /// Note: although many components inherit this config option, not all will function as expected with a height of 'auto'. (defaults to false). 
        /// </summary>
        [Browsable(true), Category("GridConfig")]
        public bool? AutoHeight { get; set; }

        /// <summary>
        /// The number of clicks on a cell required to display the cell's editor (defaults to 2) 
        /// </summary>
        [Browsable(true), Category("ColumnConfig")]
        public int? ClicksToEdit { get; set; }

        /// <summary>
        /// True to enable hiding of columns with the header context menu.
        /// </summary>
        [Browsable(true), Category("ColumnConfig")]
        public bool? EnableColumnHide { get; set; }

        /// <summary>
        ///  True to enable drag and drop reorder of columns.
        /// </summary>
        [Browsable(true), Category("ColumnConfig")]
        public bool? EnableColumnMove { get; set; }

        /// <summary>
        ///  False to turn off column resizing for the whole grid (defaults to true).
        /// </summary>
        [Browsable(true), Category("ColumnConfig")]
        public bool? EnableColumnResize { get; set; }

        /// <summary>
        /// True to enable the drop down button for menu in the headers. 
        /// </summary>
        [Browsable(true), Category("GridConfig")]
        public bool? EnableHdMenu { get; set; }

        /// <summary>
        /// True to hide the grid's header (defaults to false). 
        /// </summary>
        [Browsable(true), Category("ColumnConfig")]
        public bool? HideHeaders { get; set; }

        /// <summary>
        /// Sets the maximum height of the grid - ignored if autoHeight is not on. 
        /// </summary>
        [Browsable(true), Category("GridConfig")]
        public int? MaxHeight { get; set; }

        /// <summary>
        /// Default text to display in the grid body when no rows are available (defaults to ''). 
        /// </summary>
        [Browsable(true), Category("ViewConfig")]
        public String EmptyText { get; set; }

        /// <summary>
        /// Name of function to be called just prior to grid.render.
        /// </summary>
        [Browsable(true), Category("GridConfig")]
        public string OnClientPreRender { get; set; }

        /// <summary>
        /// Name of function to be called just prior to grid creation. Use this method to provide custom configuration options.
        /// </summary>
        [Browsable(true), Category("GridConfig")]
        public string OnClientInit { get; set; }

        /// <summary>
        /// Gets key value pair collection of grid view related options.
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Browsable(false), MergableProperty(false), DescribableProperty]
        public IDictionary<string, object> ViewOptions
        {
            get
            {
                if (!string.IsNullOrEmpty(EmptyText) && _viewOptions.Count == 0)
                    _viewOptions.Add("emptyText", EmptyText);
                return _viewOptions;
            }
        }


        /// <summary>
        /// Gets key value pair collection of grid config related options.
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Browsable(false), MergableProperty(false), DescribableProperty]
        public IDictionary<string, object> ConfigOptions
        {
            get
            {
                var options = new Dictionary<string, object>();
                if (EnableDragDrop != null)
                    options.Add("enableDragDrop", EnableDragDrop);
                if (AutoExpandColumnID != null)
                    options.Add("autoExpandColumn", AutoExpandColumnID);
                if (AutoExpandMax != null)
                    options.Add("autoExpandMax", AutoExpandMax);
                if (AutoExpandMin != null)
                    options.Add("autoExpandMin", AutoExpandMin);
                if (AutoHeight != null)
                    options.Add("autoHeight", AutoHeight);
                if (ClicksToEdit != null)
                    options.Add("clicksToEdit", ClicksToEdit);
                if (EnableColumnHide != null)
                    options.Add("enableColumnHide", EnableColumnHide);
                if (EnableColumnMove != null)
                    options.Add("enableColumnMove", EnableColumnMove);
                if (EnableColumnResize != null)
                    options.Add("enableColumnResize", EnableColumnResize);
                if (EnableHdMenu != null)
                    options.Add("enableHdMenu ", EnableHdMenu);
                if (HideHeaders != null)
                    options.Add("hideHeaders", HideHeaders);
                if (MaxHeight != null)
                    options.Add("maxHeight", MaxHeight);
                if (stripeRows != null)
                    options.Add("stripedRows", stripeRows);
               
              
                if (title != null)
                    options.Add("title", title);
                if (!Height.IsEmpty)
                    options.Add("height", Height.Value);
                if (!Width.IsEmpty)
                    options.Add("width", Width.Value);
                if (!String.IsNullOrEmpty(OnClientPreRender))
                    options.Add("onClientPreRender", OnClientPreRender);
                if (!String.IsNullOrEmpty(OnClientInit))
                    options.Add("onClientInit", OnClientInit);


                return options;
            }
        }

        #endregion

        #region Over Ridden Base Properties

        /// <summary>
        /// Override the TagKey property to render a div instead of a span
        /// </summary>
        /// <value></value>
        /// <returns>One of the <see cref="T:System.Web.UI.HtmlTextWriterTag"></see> enumeration values.</returns>
        protected override HtmlTextWriterTag TagKey
        {
            get { return HtmlTextWriterTag.Div; }
        }

        #endregion

        /// <summary>
        /// Default constructor that tells ASP.NET to render it as a DIV
        /// </summary>
        public YuiGrid():base()
        {
            //give the grid a default Width and Height so it is visible at design-time
            Width = 300;
            Height = 300;
            //string url = HttpContext.Current.Request.ServerVariables["SCRIPT_NAME"];
            //url = url.Substring(url.LastIndexOf("/")+1);
            //this.ProcessingPage = url;
        }

        #region ICallbackEventHandler Members

        /// <summary>
        /// Returns the results of a callback event that targets a control.
        /// </summary>
        /// <returns>The result of the callback.</returns>
        public string GetCallbackResult()
        {
            if (changedPage)
            {
               
                var ser = new JavaScriptSerializer();
                return ser.Serialize(JsonData);
                //.Replace(@"\/Date(", @"new Date(").Replace(@")\/", @")")
            }
            return null;
        }

        /// <summary>
        /// Processes a callback event that targets a control.
        /// </summary>
        /// <param name="eventArgument">A string that represents an event argument to pass to the event handler.</param>
        public void RaiseCallbackEvent(string eventArgument)
        {
            var jsSerialiser = new JavaScriptSerializer();
            var eventArgs = jsSerialiser.Deserialize<YuiGridEventArgs>(eventArgument);
            switch (eventArgs.EventName.ToLower())
            {
                case "selecteindexchanged":
                    OnSelectedIndexChanged(jsSerialiser.Deserialize<SelectedRowArgs>(eventArgs.Arguments));
                    break;
                case "celledited":
                    OnCellEdited(jsSerialiser.Deserialize<GridCellEditedArgs>(eventArgs.Arguments));
                    break;
                case "rowremoved":
                    OnRowRemoved(jsSerialiser.Deserialize<RemovedRowArgs>(eventArgs.Arguments));
                    break;
                case "rowdroped":
                    OnRowDroped(jsSerialiser.Deserialize<DropRowsEventArgs>(eventArgs.Arguments));
                    break;
                case "gridcontextmenu":
                    OnContextMenuClicked(jsSerialiser.Deserialize<GridContextMenuEventArgs>(eventArgs.Arguments));
                    break;

                case "pageindexchanged":
                    OnPageIndexChanged(jsSerialiser.Deserialize<PageIndexChangedArgs>(eventArgs.Arguments));
                    break;
                default:
                    //Do nothing
                    break;
            }
        }

        #endregion

        #region IPostBackEventHandler Members

        /// <summary>
        /// When implemented by a class, enables a server control to process an event raised when a form is posted to the server.
        /// </summary>
        /// <param name="eventArgument">A <see cref="T:System.String"></see> that represents an optional event argument to be passed to the event handler.</param>
        public void RaisePostBackEvent(string eventArgument)
        {
            RaiseCallbackEvent(eventArgument);
        }

        #endregion

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            var descriptor = new ScriptControlDescriptor(
                "ExtExtenders.GridControlBehavior", ClientID);

            Util.DescribeProperties(this, descriptor);

            var conv = new JavaScriptSerializer();
            descriptor.AddProperty("GridEvents", conv.Serialize(_Events));

            // If .Net Ajax Version 1 then return JsonData as a string else return as a JS object.
            if (ClientScriptProxy.IsWebExtentionsV1)
                descriptor.AddProperty("JsonData", conv.Serialize(JsonData));
            else
                descriptor.AddProperty("JsonData", JsonData);
            //toolbar has to be sended as Json
            if (TopToolBar != null)
            {
                descriptor.AddProperty("TopToolBar", TopToolBar.ToJson());
            }
            if (RowContextMenu != null)
            {
                descriptor.AddProperty("RowContextMenu",
                                       conv.Serialize(RowContextMenu));
            }

            return new ScriptDescriptor[] {descriptor};
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptReference> GetScriptReferences()
        {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.GridControlBehavior.js");

            return new[] {reference};
        }

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Load"></see> event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            Page.ClientScript.GetCallbackEventReference(this, "", "", "");
        }


        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.PreRender"></see> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            string resource = Page.ClientScript.GetWebResourceUrl(GetType(), "ExtExtenders.yui-ext.css");

            if (AutoHeight == true) Height = Unit.Empty;

            var lnk = new HtmlLink {Href = resource};
            lnk.Attributes["rel"] = "stylesheet";
            lnk.Attributes["type"] = "text/css";

            Page.Header.Controls.Add(lnk);
            if (EnableBufferData)
            {
                resource = Page.ClientScript.GetWebResourceUrl(GetType(), "ExtExtenders.LiveGrid.BufferedGrid.css");
                lnk = new HtmlLink {Href = resource};
                lnk.Attributes["rel"] = "stylesheet";
                lnk.Attributes["type"] = "text/css";
                Page.Header.Controls.Add(lnk);
            }
            else
            {
                resource = Page.ClientScript.GetWebResourceUrl(GetType(), "ExtExtenders.NumberedPaging.css");
                lnk = new HtmlLink {Href = resource};
                lnk.Attributes["rel"] = "stylesheet";
                lnk.Attributes["type"] = "text/css";
                Page.Header.Controls.Add(lnk);
            }


            //render the ext scripts
            ClientScriptProxy.RegisterClientScriptResource(this, typeof (YUI), "ExtExtenders.yui.js");
            ClientScriptProxy.RegisterClientScriptResource(this, typeof (YUI_ext), "ExtExtenders.yui-ext.js");
            ScriptManager.RegisterClientScriptResource(this, GetType(),
                                                          "ExtExtenders.RowExpanderMin.js");
            ClientScriptProxy.RegisterClientScriptResource(this, typeof (ext_yui_adapter),
                                                           "ExtExtenders.ext-yui-adapter.js");

            ClientScriptProxy.RegisterClientScriptResource(this, GetType(),
                                               "ExtExtenders.DialogEditor.js");
            if (EnableBufferData)
            {
                ScriptManager.RegisterClientScriptResource(this, GetType(),
                                                           "ExtExtenders.LiveGrid.BufferedGridView.js");
                ScriptManager.RegisterClientScriptResource(this, GetType(),
                                                           "ExtExtenders.LiveGrid.BufferedRowSelectionModel.js");
                ScriptManager.RegisterClientScriptResource(this, GetType(), "ExtExtenders.LiveGrid.BufferedStore.js");
                ScriptManager.RegisterClientScriptResource(this, GetType(),
                                                           "ExtExtenders.LiveGrid.BufferedGridToolbar.js");
                ScriptManager.RegisterClientScriptResource(this, GetType(),
                                                           "ExtExtenders.LiveGrid.BufferedJsonReader.js");
            }
            else
            {
                ClientScriptProxy.RegisterClientScriptResource(this, typeof (GridExtenstions),
                                                               "ExtExtenders.gridExtension.js");
               
            }
        }


        /// <summary>
        /// Autoes the generate.
        /// </summary>
        /// <param name="generateColumns">if set to <c>true</c> the columns of the grid are generated frm the datasource.</param>
        public void AutoGenerate(bool generateColumns)
        {
            if (generateColumns)
            {
                Columns.Clear(); //ignore if the user set the columns
            }
            PropertyDescriptorCollection propDes = null;
            Fields = string.Empty;


            if (propDes == null || propDes.Count == 0)
            {
                return;
            }
            string strFields = string.Empty;
            int colWidth = (int) Width.Value/propDes.Count - 10;
            foreach (PropertyDescriptor dc in propDes)
            {
                strFields += dc.DisplayName + ",";
                if (generateColumns)
                {
                    var mdl = new ColModel {header = dc.DisplayName, sortable = true, width = colWidth};
                    Columns.Add(mdl);
                }
            }
            strFields = strFields.Remove(strFields.Length - 1);
            Fields = strFields;
        }

        /// <summary>
        /// Generate columns and fields from data source
        /// </summary>
        /// <param name="data">Data bound to the control.</param>
        private void AutoGenerate(IEnumerable data)
        {
            if (data == null)
            {
                return;
            }

            Columns.Clear();

            PropertyDescriptorCollection propDes = null;
            foreach (object obj in data)
            {
                propDes = TypeDescriptor.GetProperties(obj);
                break;
            }


            if (propDes == null || propDes.Count == 0)
            {
                return;
            }

            int colWidth = (int) Width.Value/propDes.Count - 10;
            foreach (PropertyDescriptor dc in propDes)
            {
                Columns.Add(new ColModel
                                {
                                    dataIndex = dc.Name.ToUpper(),
                                    header = dc.DisplayName,
                                    sortable = true,
                                    width = colWidth
                                });
            }
        }

        /// <summary>
        /// Helper method that will generate a fields string based on the defined columns.
        /// </summary>
        /// <returns>Coma seperated fields list.</returns>
        private string GenerateFields()
        {
            var fields = new List<string>();
            foreach (ColModel col in Columns)
            {
                if (!fields.Contains(col.dataIndex))
                    fields.Add(col.dataIndex);
                if (!fields.Contains(col.expanderdataIndex) && ! string.IsNullOrEmpty(col.expanderdataIndex))
                    fields.Add(col.expanderdataIndex);
            }
            return String.Join(",", fields.ToArray());
        }

        /// <summary>
        /// When overridden in a derived class, binds data from the data source to the control.
        /// </summary>
        /// <param name="data">The <see cref="T:System.Collections.IEnumerable"></see> list of data returned from a <see cref="M:System.Web.UI.WebControls.DataBoundControl.PerformSelect"></see> method call.</param>
        protected override void PerformDataBinding(IEnumerable data)
        {
            if (DesignMode || data == null)
            {
                return;
            }

            // Call Base Method
            base.PerformDataBinding(data);

            // Auto Generate Columns if necessary
            if (AutoGenerateColumns)
                AutoGenerate(data);

            // Generate fields list based on defined columns
            Fields = GenerateFields();

            // Get subset of bound data (only properties contained in the Fields property.
            ICollection records = ParseData(data, Fields);

            // Set total rows to row count if no paging
            if (TotalRecords == 0)
                TotalRecords = records.Count;

            // Save the JsonData object.
            JsonData = new ExtDataContainer
                           {
                               Records = records,
                               TotalCount = TotalRecords
                           };
            
           
      
        }
        /// <summary>
        /// Parse data of the given IEnumerable object.
        /// </summary>
        /// <param name="enumerable">IEnumerable object to parse</param>
        /// <param name="fields">Columns to extract from Table</param>
        /// <returns>Returns a new collection containing only the subset of columns defined in fields</returns>
        private ICollection ParseData(IEnumerable enumerable, string fields)
        {
            // Create new container to hold result to be returned
            var list = new List<IDictionary<string, object>>();

            // Split filds string on , to get the defined columns array
            string[] columns = fields.Split(',');

            var ser = new JavaScriptSerializer();

            // Loop through each object in enumeration
            foreach (object obj in enumerable)
            {
                OnRowDataBound(new RowDataBoundEventArgs {Row= obj});
                // Create new container to hold object subset data
                // root is the base object and leaf is edge
                var root = new Dictionary<string, object>();
                Dictionary<string, object> leaf;

                // Loop through each column representing a distict piece of object data that should be retained.
                foreach (string column in columns)
                {
                    if (column == "")
                        continue;

                    // Reset Leaf
                    leaf = root;

                    // Split the column on '.'. Each propertied relates to an object property contained with in obj
                    // Example Movie.Director.FirstName
                    string[] properties = column.Split('.');

                    // Walk through the object properties to find the field that relates to the specified column
                    //object property = DataBinder.GetPropertyValue(obj, properties[0]);
                    object property = obj;

                    for (int i = 0; i < properties.Length - 1; i++)
                    {
                        // Reset property value to next level down in the object walk.
                        property = DataBinder.GetPropertyValue(property, properties[i]);

                        //property = ser.Serialize(property);

                        // If the root dictonary does not already contain a key of this property name then add it.
                        if (!leaf.ContainsKey(properties[i]))
                        {
                            leaf.Add(properties[i], new Dictionary<string, object>());
                        }

                        // Move leaf along with object walk
                        leaf = (Dictionary<string, object>)leaf[properties[i]];
                    }

                    //if(properties.Length > 1)
                    property = DataBinder.GetPropertyValue(property, properties[properties.Length - 1]);
                    
                    //property = ser.Serialize(property);

                    // Finally save the last property value in the root dictonary in the apropriate place.
                    leaf.Add(properties[properties.Length - 1], property);
                }

                // Add the subset object to the list.
                list.Add(root);
            }

            return list;
        }

        /// <summary>
        /// Called when [selected index changed].
        /// </summary>
        /// <param name="e">The e.</param>
        protected virtual void OnRowDataBound(RowDataBoundEventArgs e)
        {
            var eventHandler = (RowDataBoundEventHandler)Events[RowDataBoundKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }
        /// <summary>
        /// Called when [selected index changed].
        /// </summary>
        /// <param name="e">The e.</param>
        protected virtual void OnContextMenuClicked(GridContextMenuEventArgs e)
        {
            var eventHandler = (GridContextMenuEventHandler) Events[RowContextMenuKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }

        /// <summary>
        /// Called when [selected index changed].
        /// </summary>
        /// <param name="e">The e.</param>
        protected virtual void OnSelectedIndexChanged(SelectedRowArgs e)
        {
            var eventHandler = (SelectedRowEventHandler) Events[SelectedRowKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }

        /// <summary>
        /// Called when a cell is edited.
        /// </summary>
        /// <param name="e">The e.</param>
        protected virtual void OnCellEdited(GridCellEditedArgs e)
        {
            var eventHandler = (CellEditedEventHandler) Events[CellEditedKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }

        /// <summary>
        /// Called when a row is droped on the grid.
        /// </summary>
        /// <param name="e">The e.</param>
        protected virtual void OnRowDroped(DropRowsEventArgs e)
        {
            var eventHandler = (DropedRowEventHandler) Events[RowDropedKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }

        /// <summary>
        /// Called when a row is removed.
        /// </summary>
        /// <param name="e">The e.</param>
        protected virtual void OnRowRemoved(RemovedRowArgs e)
        {
            var eventHandler = (RemovedRowEventHandler) Events[RowRemovedKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }

        /// <summary>
        /// Called when a row is removed.
        /// </summary>
        /// <param name="e">The e.</param>
        protected virtual void OnPageIndexChanged(PageIndexChangedArgs e)
        {
            var eventHandler = (PageIndexChangedEventHandler)Events[PageIndexChangeKey];
            if (eventHandler != null)
            {
                changedPage = true;
                eventHandler(this, e);
            }
        }
    }
}