// README
//
// There are two steps to adding a property:
//
// 1. Create a member variable to store your property
// 2. Add the get_ and set_ accessors for your property.
//
// Remember that both are case sensitive!
//

Type.registerNamespace('ExtExtenders');

ExtExtenders.TreeEventArgs = function() {
   
    ExtExtenders.TreeEventArgs.initializeBase(this);

}

ExtExtenders.TreeEventArgs.prototype = {
  
    serialise : function(eventName,arguments){
    /// <summary>
    /// Method used to prepare an event to be fired
    /// </summary>
    /// <param name="eventName" type="string">
    /// Name of the event to be fired
    /// </param>
    /// <param name="arguments" type="object">
    /// Object containing the parameters to be passed
    /// </param>
        return Sys.Serialization.JavaScriptSerializer.serialize(
                {
                    EventName: eventName,
                    Arguments: Sys.Serialization.JavaScriptSerializer.serialize
                        (arguments)
                });
    } 
}

ExtExtenders.TreeEventArgs.registerClass('ExtExtenders.TreeEventArgs', Sys.EventArgs);

ExtExtenders.TreePaneBehavior = function(element) {

    ExtExtenders.TreePaneBehavior.initializeBase(this, [element]);
    Ext.QuickTips.init();
    this._animate = true;
    this._containerScroll=true;
    this._autoScroll=true;
    this._enableDD=true;
    this._lines=true;
    this._singleExpand=true;
    this._Loader="";
    this._rootVisible=true;
    this.oChildContextMenu="";
}

ExtExtenders.TreePaneBehavior.prototype = {

    initialize: function() {
        ExtExtenders.TreePaneBehavior.callBaseMethod(this, 'initialize');
        var id = this.get_element().id;

        var myTree = new Ext.tree.TreePanel({
            el: id,
            animate: this._animate,
            enableDD: this._enableDD,
            containerScroll: this._containerScroll,
            autoScroll: this._autoScroll,
            lines: this._lines,
            rootVisible: this._rootVisible,
            checkAllChilds: this._checkAllChilds
        });
        this.initTree(myTree);




    },
    initTree: function(myTree) {



        if (this._Loader != null && this._Loader != "") {

            myTree.loader = new Ext.tree.TreeLoader({ dataUrl: this._Loader });
        }
        if (this._Loader == null || this._Loader == "") {
            myTree.loader = new Ext.tree.TreeLoader({ dataUrl: location.href });
        }
        if (this._WebServicePath != null && this._WebServicePath != "") {
            myTree.loader = new Ext.tree.WebserviceTreeLoader({ _WebServicePath: this._WebServicePath, _WebServiceMethod: this._WebServiceMethod });
        }

        this._Tree = myTree;

        var nodes = eval(this._TreeNodes);

        if (nodes) {
            for (var i = 0; i < nodes.length; i++) {
                if (this._CheckBoxTree) {
                    nodes[i].checked = nodes[i].IsChecked;
                }
                if (nodes[i].leaf) {
                    //doesn't have any ajax children
                    tmpNode = new Ext.tree.TreeNode(nodes[i]);
                }
                else {
                    //has children
                    tmpNode = new Ext.tree.AsyncTreeNode(nodes[i]);
                }

                if (nodes[i].IsRoot || nodes[i].parentNodeId == null) {

                    myTree.setRootNode(tmpNode);

                    continue;
                }
                var pNode = myTree.getNodeById(nodes[i].parentNodeId);
                if (pNode) {
                    pNode.appendChild(tmpNode);

                }

            }
        }
        myTree.render();
        myTree.getRootNode().expand();
        if (this._Editable) {
            // add an inline editor for the nodes
            var ge = new Ext.tree.TreeEditor(myTree, {
                allowBlank: false,
                blankText: 'A name is required',
                selectOnFocus: true
            });
            myTree.Editor = ge;
            if (this.HasEvent("NodeEdited")) {
                ge.on("complete", this.raiseNodeEdited, this);
            }
        }
        this.Tree = myTree;
        if (this.HasEvent("NodeMoved")) {
            myTree.on("movenode", this.raiseNodeMoved, this);
        }
        if (this.HasEvent("NodeClicked")) {
            myTree.on("click", this.raiseClicked, this);
        }

        if (this.HasEvent("NodeDroped")) {
            myTree.on("nodedrop", this.raiseDroped, this);
        }
        if (this._CheckBoxTree) {
            if (this.HasEvent("NodeChecked")) {
                myTree.on("checkchange", this.raiseChecked, this);
            }
        }
        if (this._ContextMenu != null && this._ContextMenu != "") {
            this.oContextMenu = this.BuildContextMenu(this._ContextMenu);
            if (this._ChildContextMenu != null && this._ChildContextMenu != "") {
                this.oChildContextMenu = this.BuildContextMenu(this._ChildContextMenu);
            }
            myTree.on('contextmenu', this.ShowMenu, this);
        }

        //x-panel-body x-panel-body-noheader
    },

    HasEvent: function(eventName) {
        if (this._ev == null) {
            this._ev = eval(this.get_TreeEvents());
        }
        if (this._ev == null) {
            return false;
        }
        else {

            return this._ev.HasElement(eventName);
        }
    },
    ShowMenu: function(node) {
        this.selectedNode = node;
        if (this.oContextMenu == null || this.oContextMenu == "") {
            return;
        }
        //if a child context menu is defined and the node does not have children
        if (this.oChildContextMenu != "" && node.leaf) {
            this.oChildContextMenu.show(node.ui.getAnchor());
        }
        else {
            this.oContextMenu.show(node.ui.getAnchor());
        }
    },
    BuildContextMenu: function(menu) {

        var MenuTmp = eval('(' + menu + ')');
        var extMenuItems = [];
        if (MenuTmp == null) {
            return;
        }
       
        for (i = 0; i < MenuTmp.Items.length; i++) {
            var objTemp = {};
            var tmpItem = MenuTmp.Items[i];
            objTemp.text = tmpItem.Text;
            objTemp.id = tmpItem.Id;
            //copy all properties
            Ext.apply(objTemp, tmpItem);

            objTemp.DateSelected = new Date();
            if (tmpItem.OnClientClick != null && tmpItem.OnClientClick != "") {
                objTemp.handler = eval(tmpItem.OnClientClick);
                //objTemp.scope=this;
            }
            else {
                objTemp.handler = this.raiseMenuItemClicked;
                objTemp.scope = this;
            }
            extMenuItems.push(objTemp);
        }
        oContextMenu = new Ext.menu.Menu({ items: extMenuItems });
        return oContextMenu;

    },
    dispose: function() {
        // TODO: add your cleanup code here

        ExtExtenders.TreePaneBehavior.callBaseMethod(this, 'dispose');
    },
    get_Tree: function() {
        return this.Tree;
    },
    get_animate: function() {
        return this._animate;
    },

    set_animate: function(value) {
        this._animate = value;
    },
    get_containerScroll: function() {
        return this._containerScroll;
    },
    set_containerScroll: function(value) {
        this._containerScroll = value;
    },
    get_autoScroll: function() {
        return this._autoScroll;
    },
    set_autoScroll: function(value) {
        this._autoScroll = value;
    },
    get_enableDD: function() {
        return this._enableDD;
    },
    set_enableDD: function(value) {
        this._enableDD = value;
    },
    get_enableDrag: function() {
        return this._enableDrag;
    },
    set_enableDrag: function(value) {
        this._enableDrag = value;
    },
    get_enableDrop: function() {
        return this._enableDrop;
    },
    set_enableDrop: function(value) {
        this._enableDrop = value;
    },
    get_rootVisible: function() {
        return this._rootVisible;
    },
    set_rootVisible: function(value) {
        this._rootVisible = value;
    },
    get_ddGroup: function() {
        return this._ddGroup;
    },
    set_ddGroup: function(value) {
        this._ddGroup = value;
    },
    get_lines: function() {
        return this._lines;
    },
    set_lines: function(value) {
        this._lines = value;
    },
    get_singleExpand: function() {
        return this._singleExpand;
    },
    set_singleExpand: function(value) {
        this._singleExpand = value;
    },
    get_TreeNodes: function() {
        return this._TreeNodes;
    },
    set_TreeNodes: function(value) {
        this._TreeNodes = value;
    },
    get_Loader: function() {
        return this._Loader;
    },
    set_Loader: function(value) {
        this._Loader = value;
    },
    get_Tree: function() {
        return this._Tree;
    },
    set_ddAppendOnly: function(value) {
        this.ddAppendOnly = value;
    },
    get_ddAppendOnly: function() {
        return this._ddAppendOnly;
    },
    //WebServiceMethod
    get_WebServiceMethod: function() {
        return this._WebServiceMethod;
    },

    set_WebServiceMethod: function(value) {
        this._WebServiceMethod = value;
    },
    //WebServicePath
    get_WebServicePath: function() {
        return this._WebServicePath;
    },

    set_WebServicePath: function(value) {
        this._WebServicePath = value;
    },
    get_Editable: function() {
        return this._Editable;
    },
    set_Editable: function(value) {
        this._Editable = value;
    },
    get_AutoPostBack: function() {
        return this._AutoPostBack;
    },
    set_AutoPostBack: function(value) {
        this._AutoPostBack = value;
    },
    get_CheckBoxTree: function() {
        return this._CheckBoxTree;
    },
    set_CheckBoxTree: function(value) {
        this._CheckBoxTree = value;
    },
    get_ContextMenu: function() {
        return this._ContextMenu;
    },
    set_ContextMenu: function(value) {
        this._ContextMenu = value;
    },
    get_ChildContextMenu: function() {
        return this._ChildContextMenu;
    },
    set_ChildContextMenu: function(value) {
        this._ChildContextMenu = value;
    },
    get_checkAllChilds: function() {
        return this._checkAllChilds;
    },
    set_checkAllChilds: function(value) {
        this._checkAllChilds = value;
    },
    get_isRegion: function() {
        return this._isRegion;
    },
    set_isRegion: function(value) {
        this._isRegion = value;
    },
    get_UniqueID: function() {
        return this._UniqueID;
    },
    set_UniqueID: function(value) {
        this._UniqueID = value;
    },
    get_TreeEvents: function() {
        return this._TreeEvents;
    },
    set_TreeEvents: function(value) {
        this._TreeEvents = value;
    },
    invoke: function(args, onComplete$delegate, context, onError$delegate, async) {
        var callbackId = this.get_element().id;
        callbackId = callbackId.replace(/_/g, "$");
        if (callbackId.charAt(0) == '$')
           callbackId = '_' + callbackId.substring(1);
        if (this._AutoPostBack) {
            __doPostBack(callbackId, args);
        }
        else {
            WebForm_DoCallback(callbackId, args, onComplete$delegate, context, onError$delegate, async);
        }
    },
    // Events

    onCallbackError: function(result, context) {
    },
    raiseMenuItemClicked: function(item) {

        var node = this.selectedNode;
        var eventArgs = new ExtExtenders.TreeEventArgs();
        var arguments = new Object();
        arguments.NodeSelected = this.encodeNode(node);
        arguments.MenuClicked = this.encodeNode(item);
        this.invoke(eventArgs.serialise("ContextMenuClicked", arguments), null, this, this.onCallbackError, true);
    },
    raiseNodeMoved: function(tree, node, oldparent, newparent, index) {
        var eventArgs = new ExtExtenders.TreeEventArgs();
        var arguments = new Object();
        arguments.NodeMoved = this.encodeNode(node);
        arguments.OldParent = this.encodeNode(oldparent);
        arguments.NewParent = this.encodeNode(newparent);
        arguments.Index = index;

        this.invoke(eventArgs.serialise("NodeMoved", arguments), null, this, this.onCallbackError, true);
    },
    raiseNodeEdited: function(editor, newValue, oldValue) {
        var eventArgs = new ExtExtenders.TreeEventArgs();
        var arguments = new Object();
        arguments.NodeRenamed = this.encodeNode(editor.editNode);
        arguments.NewValue = newValue
        arguments.OldValue = oldValue;
        this.invoke(eventArgs.serialise("NodeEdited", arguments), null, this, this.onCallbackError, true);
    },
    raiseClicked: function(node, evnt) {
        var eventArgs = new ExtExtenders.TreeEventArgs();
        var arguments = new Object();
        node.isChecked = node.checked;
        arguments.NodeClicked = this.encodeNode(node);

        this.invoke(eventArgs.serialise("NodeClicked", arguments), null, this, this.onCallbackError, true);
    },
    raiseDroped: function(dropEvent) {
        var srcTree = dropEvent.source.tree.el.id;
        var targetTree = dropEvent.tree.el.id;
        var eventArgs = new ExtExtenders.TreeEventArgs();
        var arguments = new Object();
        if (srcTree == targetTree) {
            return;
        }
        arguments.DropedNode = this.encodeNode(dropEvent.dropNode);

        this.invoke(eventArgs.serialise("NodeDroped", arguments), null, this, this.onCallbackError, true);
    },
    raiseChecked: function(node, state) {
        this.currentNode = node;
        this.currentState = state;
        var eventArgs = new ExtExtenders.TreeEventArgs();
        var arguments = new Object();
        node.attributes.IsChecked = state;
        arguments.NodeChecked = this.encodeNode(node);
        if (this.get_checkAllChilds() === true && !node.isLeaf()) {
            if (!node.isExpanded()) {
                node.expand();
                node.on("expand", this.doCheck, this);
            }
            else {
                this.doCheck();
            }
        }
        var eventArgs = new ExtExtenders.TreeEventArgs();
        this.invoke(eventArgs.serialise("NodeChecked", arguments), null, this, this.onCallbackError, true);
    },
    doCheck: function() {

        var node = this.currentNode;
        var state = this.currentState;
        for (var i = 0; i < node.childNodes.length; i++) {
            ui = node.childNodes[i].getUI();
            if (ui.checkbox)
                ui.checkbox.checked = state;
        }
    },
    raiseNodeRemoved: function(node) {

        var eventArgs = new ExtExtenders.TreeEventArgs();
        var arguments = new Object();
        arguments.NodeClicked = this.encodeNode(node);

        var eventArgs = new ExtExtenders.TreeEventArgs();
        this.invoke(eventArgs.serialise("NodeRemoved", arguments), null, this, this.onCallbackError, true);
    },
    raiseNodeInserted: function(parent, newNode) {

        var eventArgs = new ExtExtenders.TreeEventArgs();
        var arguments = new Object();
        arguments.ParentNode = parent.attributes;
        arguments.NewNode = newNode.attributes;

        var eventArgs = new ExtExtenders.TreeEventArgs();
        this.invoke(eventArgs.serialise("NodeInserted", arguments), null, this, this.onCallbackError, true);
    },
    /*
    Node capable of being converted to json
    */
    encodeNode: function(node) {
        //returns an object with all properties.. including custom ones
        if (node.attributes) {
            return node.attributes;
        }
        else {
            var objRet = {};
            for (var p in node) {
                if (typeof (node[p]) != "object" && typeof (node[p]) != "function") {
                    objRet[p] = node[p];
                }
            }
            return objRet;
        }
    },
    /*
    Removes a node from the tree
    */
    removeNode: function() {
        var node = this.selectedNode;
        if (node.parentNode) {
            this.raiseNodeRemoved(node);

            var parent = node.parentNode;
            parent.removeChild(node);

        }

    },
    ///
    insertNode: function(newNode) {

        var parent = this.selectedNode;
        parent.appendChild(newNode);
        this.raiseNodeInserted(parent, newNode);
    },
    //helper-- shows a node editor 
    newNodeEditor: function(ok_func) {

        var id_dlg = Ext.id();
        var id_form = Ext.id();
        if (this.newDlg != null) {//only create once...
            this.newDlg.show();
            this.newNodeForm.getForm().reset();
            return;
        }
        var list = Ext.DomHelper.append(document.body,
            {
                tag: 'div', id: id_dlg, style: 'visibility:none',
                children: [
                { tag: 'div', cls: 'x-window-header', html: 'Create Node' },
                { tag: 'div', cls: 'x-window-body', id: id_form }
            ]
            });

        var dlg = new Ext.Window({
            el: id_dlg,
            height: 150,
            width: 300,
            resizable: false,
            modal: true,
            shadow: true,
            closeAction: 'hide'
        });

        var simple = new Ext.form.FormPanel({
            labelWidth: 75
        });



        simple.add(
            new Ext.form.TextField({
                fieldLabel: 'Text',
                name: 'text',
                width: 135,
                allowBlank: false
            }),
            new Ext.form.TextField({
                fieldLabel: 'Href',
                name: 'href',
                width: 135,
                allowBlank: true
            }),
            new Ext.form.TextField({
                fieldLabel: 'Target',
                name: 'target',
                width: 135,
                allowBlank: true
            })
        );
        simple.render(id_form);
        this.newNodeForm = simple;
        this.funcToCall = ok_func;
        this.newDlg = dlg;
        dlg.addButton('OK', this.onDialogOk, this);
        //dlg.addButton('Cancel', dlg.hide, dlg);
        dlg.show(this);
    },
    onDialogOk: function() {
        var form = this.newNodeForm.getForm();
        if (!form.isValid()) {
            return;
        }
        var form_values = form.getValues();
        this.newDlg.hide();
        this.funcToCall(form_values);
    }

}

ExtExtenders.TreePaneBehavior.registerClass('ExtExtenders.TreePaneBehavior', Sys.UI.Control);

if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 
