﻿/* 
©2006 Rodrigo Diniz 
www.rodrigodiniz.qsh.eu 
You may use this code in anyway you like but do not remove this copyright 

*/
//Filter Helper
Ext.grid.GridPanel.prototype.filter=function(filterCol,filterValue){
    this.clearSelection();
    this.filterCol=filterCol;
    this.filterValue=filterValue;
    var lastO= this.dataSource.lastOptions;
    this.dataSource.load({params:{start:0, limit:lastO.limit,'filtercol': filterCol,'filterValue':filterValue}});
  
}
Ext.grid.GridPanel.prototype.getAllRows=function(){
  var objArray= new Array();
  var dm=this.dataSource;
  var len= dm.getCount();
  var fields=dm.schema.fields
    for(var i = 0; i < len; i++){
        var node= dm.getNode(i);
        objRet= new Object();
        for(var j=0;j< fields.length;j++){
          objRet[fields[j]]=dm.getNamedValue(node,fields[j]);
        }
        objArray.push(objRet);
    } 
  return objArray;
}

/*
    NumberPagedToolbar 
    Extends Toolbar
       
*/
Ext.NumberPagingToolbar=Ext.extend(Ext.Toolbar, {
pageSize: 20,
paramNames : {start: 'start', limit: 'limit'},
initComponent : function(){
        Ext.NumberPagingToolbar.superclass.initComponent.call(this);
        this.cursor = 0;
        this.bind(this.store);
},
onLoad : function(store, r, o){
    
        if(!this.rendered){
            this.dsLoaded = [store, r, o];
            return;
        }
        
       if (!o.params){
        o=this.store.lastOptions;
       }
       
       this.cursor = o.params ? o.params[this.paramNames.start] : 0;
       var d = this.getPageData(), ap = d.activePage, ps = d.pages;
       this.sort=o.params.sort? o.params.sort:'';
       this.dir= o.params.dir?o.params.dir:'';
       this.renderNumbers();
    
  },
 bind : function(store){
        
        store = Ext.StoreMgr.lookup(store);
        store.on("load", this.onLoad, this);
        this.store = store;
},
//build the pager 
 onRender : function(ct, position){
     Ext.NumberPagingToolbar.superclass.onRender.call(this, ct, position);
 },
 renderNumbers:function() {
      
      var elFooter=this.getEl().dom;
      var dh = Ext.DomHelper;
      
      elFooter.innerHTML="";
      
      var d = this.getPageData();
      var startIndex= parseInt(this.cursor);
      var numberOfPages=d.pages;
      if(numberOfPages ==1){
            elFooter.innerHTML="";
            return;
      }
      var currentPage= Math.ceil(startIndex/this.pageSize)+1;//page number
      var start=currentPage;
  
     
      if(start<=5)
      {
            start=1;
      }
      else
      {
            for(var j=start-1;j> start-6;j--)
            {
	            if(j%5==0)
	            {
		            start=j;
		            break;
	            }
            }
        }
        tpl = new Ext.DomHelper.Template("<span class='pagination'> <ul>");
        var elPrin=tpl.append(elFooter);
        var i;
        for (i = start; i <= numberOfPages; i++)
        {
          
            if(i==start +6 ||(start==1&& i==6) )
            {
                el= dh.append(elPrin, {tag:'li',html:'&nbsp;',
                    children:[{tag:'a' ,href:'#',html:'...'}]                
                }, true);
                el.on("click",this.onClick.createDelegate(this, [(i-1)*this.pageSize]));	           
	            break;
            }
            if(start > 4 && i==start)
            {
	            el= dh.append(elPrin, {tag:'li',html:'&nbsp;',
                    children:[{tag:'a' ,href:'#',html:'...'}]                
                }, true);
                 el.on("click",this.onClick.createDelegate(this, [(start-1)*this.pageSize]));                
	            continue;
            }
            if (i != currentPage)
            {
                el= dh.append(elPrin, {tag:'li',html:'&nbsp;',
                    children:[{tag:'a' ,href:'#',html:i}]                
                }, true);
                el.on("click",this.onClick.createDelegate(this, [(i-1)*this.pageSize]));
	            
            }
            else
            {
                el= dh.append(elPrin, {tag:'li',html:i+'&nbsp;',cls:'startIndex'  }, true);
	            
            }
    		
        }  
        
       },
        //called on the page number click
        onClick:function(pageNum){
             var ds = this.store;
             ds.load({params:{start: pageNum, limit: this.pageSize,sort:this.sort,dir:this.dir,sort:this.sort}});
        }
      ,
       getPageData : function(){
      
        var total = this.store.getTotalCount();
        return {
            total : total,
            activePage : Math.ceil((this.cursor+this.pageSize)/this.pageSize),
            pages :  total < this.pageSize ? 1 : Math.ceil(total/this.pageSize)
        };
      }
    }
   
);

Ext.reg('numberedpaging', Ext.NumberPagingToolbar);
/*
 * 
 * Copyright(c) 2006-2007, Rodrigo Diniz
 * 
 * http://www.rodrigodiniz.qsh.eu
 * 
 */
Ext.data.WebserviceProxy = function(conn){
    
    Ext.data.WebserviceProxy.superclass.constructor.call(this);
    //this.conn = conn.events ? conn : new Ext.data.Connection(conn);
    Ext.apply(this,conn);
};

Ext.extend(Ext.data.WebserviceProxy, Ext.data.DataProxy, {
    getConnection : function(){
        return this.conn;;
    },
    
   load : function(params, reader, callback, scope, arg){
        //user context object to pass the parameters to response
        var userContext={callback:callback,reader:reader,arg:arg,scope:scope}
        Sys.Net.WebServiceProxy.invoke(this._WebservicePath, this._WebServiceMethod, false,params,Function.createDelegate(this, this.loadResponse), Function.createDelegate(this, this.loadResponse),userContext);

    },
 
     loadResponse : function(response,userContext){
        
        if(response._message){
            this.fireEvent("loadexception", response._message);
            userContext.callback.call(userContext.scope, null,userContext.arg, false);
            return;
        }

        var result;
        try {
            result = userContext.reader.read({responseText: response});
        }catch(e){
            this.fireEvent("loadexception",e);
            userContext.callback.call(userContext.scope, null,userContext.arg, false);
            return;
        }
        
        //call loadRecords
         userContext.callback.call(userContext.scope, result, userContext.arg, true);
    },
    
    update : function(dataSet){
        
    },
    
    updateResponse : function(dataSet){
        
    }
});
/*
 * DataSetReader Reader
 * Copyright(c) 2007, Rodrigo Diniz.
 * 
 * 
 */

Ext.data.DataSetReader= function(meta, recordType){
    Ext.data.DataSetReader.superclass.constructor.call(this, meta, recordType);
};
Ext.extend(Ext.data.DataSetReader, Ext.data.DataReader, {
    read : function(response){
      
        var doc = response.responseText.childNodes[response.responseText.childNodes.length-1]
        doc=doc.childNodes[doc.childNodes.length-1];
        if(!doc) {
            throw {message: "XmlReader.read: XML Document not available"};
        }
        return this.readRecords(doc);
    },
    
    readRecords : function(doc){
     
        this.xmlData = doc;
        var root = doc.documentElement || doc;
    	var q = Ext.DomQuery;
    	var recordType = this.recordType, fields = recordType.prototype.fields;
    	var sid = this.meta.id;
    	var totalRecords = 0;
        var records = [];
    
    	if(!this.meta.record){
    	    this.meta.record="Table";
    	}
    	var ns = q.select(this.meta.record,root);
        for(var i = 0, len = ns.length; i < len; i++) {
	        var n = ns[i];
	        var values = {};
	        var id = sid ? q.selectValue(sid, n) : undefined;
	        for(var j = 0, jlen = fields.length; j < jlen; j++){
	            var f = fields.items[j];
                var v = q.selectValue(f.mapping || f.name, n, f.defaultValue);
	            v = f.convert(v);
	            values[f.name] = v;
	        }
	        var record = new recordType(values, id);
	        record.node = n;
	        records[records.length] = record;
	    }
	    if(!this.meta.totalTable){
	        this.meta.totalTable="Table1";
	    }
	    var ns = q.select(this.meta.totalTable,root);
	    var n = ns[0];
	    if(n){
	        totalRecords=n.text;
	    }
	    
	    return {
	        records : records,
	        totalRecords : totalRecords || records.length
	    };
    }
});

//////////////////////////
// Check Column code 
// from ext\examples\grid\edit-grid.js
//////////////////////////
Ext.grid.CheckColumn = function(config){
    Ext.apply(this, config);
    if(!this.id){
        this.id = Ext.id();
    }
    this.renderer = this.renderer.createDelegate(this);
};

Ext.grid.CheckColumn.prototype ={
    init : function(grid){
        this.grid = grid;
        this.grid.on('render', function(){
            var view = this.grid.getView();
            view.mainBody.on('mousedown', this.onMouseDown, this);
        }, this);
    },

    onMouseDown : function(e, t){
        if(t.className && t.className.indexOf('x-grid3-cc-'+this.id) != -1){
            e.stopEvent();
            var index = this.grid.getView().findRowIndex(t);
            var record = this.grid.store.getAt(index);
            record.set(this.dataIndex, !record.data[this.dataIndex]);
        }
    },

    renderer : function(v, p, record){
        p.css += ' x-grid3-check-col-td'; 
        return '<div class="x-grid3-check-col'+(v?'-on':'')+' x-grid3-cc-'+this.id+'">&#160;</div>';
    }
};
