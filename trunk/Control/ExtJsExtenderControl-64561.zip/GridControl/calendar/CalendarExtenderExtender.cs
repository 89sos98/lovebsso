// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ExtExtenders.Helpers;

[assembly: WebResource("ExtExtenders.calendar.CalendarExtenderBehavior.js", "text/javascript")]

namespace ExtExtenders
{
    /// <summary>
    /// Class to extend a TextBox into a calendar popup
    /// </summary>
    [ToolboxBitmap(typeof (Calendar))]
    public class ExtCalendar : TextBox, IScriptControl
    {
        private ClientScriptProxy ClientScriptProxy;
        private ScriptManager sm;

        /// <summary>
        /// An array of days to disable, 0 based. For example, [0, 6] disables 
        /// Sunday and Saturday (defaults to null).
        /// </summary>
        public string disabledDays { get; set; }

        /// <summary>
        /// The message that appears when a date is disabled
        /// </summary>
        public string disabledDaysText { get; set; }

        /// <summary>
        /// An array of "dates" to disable, as strings. These strings will be used to build a dynamic regular expression so they are very powerful.
        /// Some examples:  * ["03/08/2003", "09/16/2003"] would disable those exact dates
        /// * ["03/08", "09/16"] would disable those days for every year
        ///* ["^03/08"] would only match the beginning (useful if you are using short years)
        ///* ["03/../2006"] would disable every day in March 2006
        ///* ["^03"] would disable every day in every March
        ///In order to support regular expressions, if you are using a date format that has "." in it, you will have to escape the dot when restricting dates. For example: ["03\\.08\\.03"].
        /// </summary>
        public string disabledDates { get; set; }

        /// <summary>
        ///  The tooltip text to display when the date falls on a
        /// disabled date (defaults to 'Disabled')
        /// </summary>
        public string disabledDatesText { get; set; }

        /// <summary>
        /// The default date format string which can be overriden for localization support. 
        /// The format must be valid according to Date.parseDate (defaults to 'm/d/y').
        /// </summary>
        public string format { get; set; }

        #region IScriptControl Members

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            var descriptor = new ScriptControlDescriptor(
                "ExtExtenders.CalendarExtenderBehavior", ClientID);

            Type t = GetType();
            //properties that will be serialized
            string[] propsToSerialize = {
                                            "disabledDays", "disabledDaysText", "disabledDates",
                                            "disabledDatesText", "format"
                                        };
            foreach (string prop in propsToSerialize)
            {
                PropertyInfo p = t.GetProperty(prop);
                if (p == null)
                {
                    throw new Exception(prop);
                }
                descriptor.AddProperty(p.Name, p.GetValue(this, null));
            }
            return new ScriptDescriptor[] {descriptor};
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ScriptReference> GetScriptReferences()
        {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.calendar.CalendarExtenderBehavior.js");

            return new[] {reference};
        }

        #endregion

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Init"/> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"/> object that contains the event data.</param>
        protected override void OnInit(EventArgs e)
        {
            ClientScriptProxy = ClientScriptProxy.Current;
            base.OnInit(e);
        }

        /// <summary>
        /// Raises the pre render event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.EventArgs"/> instance containing the event data.</param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            string resource = Page.ClientScript.GetWebResourceUrl(GetType(), "ExtExtenders.yui-ext.css");
            string csslink = "<link href='" + resource + "' rel='stylesheet' type='text/css' />";
            Page.Header.Controls.Add(new LiteralControl(csslink));

            //render the yui-ext scripts
            ClientScriptProxy.RegisterClientScriptResource(this, typeof (YUI), "ExtExtenders.yui.js");
            ClientScriptProxy.RegisterClientScriptResource(this, typeof (YUI_ext), "ExtExtenders.yui-ext.js");
            ClientScriptProxy.RegisterClientScriptResource(this, typeof (ext_yui_adapter),
                                                           "ExtExtenders.ext-yui-adapter.js");
            if (!DesignMode)
            {
                // Test for ScriptManager and register if it exists
                sm = ScriptManager.GetCurrent(Page);

                if (sm == null)
                    throw new HttpException("A ScriptManager control must exist on the current page.");

                sm.RegisterScriptControl(this);
            }
        }

        /// <summary>
        /// Renders the control to the specified HTML writer.
        /// </summary>
        /// <param name="writer">The <see cref="T:System.Web.UI.HtmlTextWriter"></see> object that receives the control content.</param>
        protected override void Render(HtmlTextWriter writer)
        {
            base.Render(writer);
            if (!DesignMode)
                sm.RegisterScriptDescriptors(this);
        }
    }
}