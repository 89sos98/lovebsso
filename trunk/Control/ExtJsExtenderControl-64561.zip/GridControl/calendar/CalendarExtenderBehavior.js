// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

// This behavior can be attached to a textbox to enable auto-complete/auto-suggest
// scenarios.
Type.registerNamespace('ExtExtenders');
ExtExtenders.CalendarExtenderBehavior = function(element) {

    ExtExtenders.CalendarExtenderBehavior.initializeBase(this, [element]);
   
}
ExtExtenders.CalendarExtenderBehavior.prototype = {
    initialize: function() {

        ExtExtenders.CalendarExtenderBehavior.callBaseMethod(this, 'initialize');
        var id = this.get_element().id;
        var objConfig = {};
        objConfig.fieldClass = document.getElementById(id).className;
        objConfig.focusClass = document.getElementById(id).className;
        if (this._disabledDaysText != null) {
            objConfig.disabledDaysText = this._disabledDaysText;
        }
        if (this._disabledDays != null) {
            objConfig.disabledDays = eval(this._disabledDays);
        }
        if (this._disabledDates != "") {
            objConfig.disabledDates = eval(this._disabledDates);
        }
        if (this._disabledDatesText != "") {
            objConfig.disabledDatesText = this._disabledDatesText;
        }
        objConfig.applyTo = id;
        var dtField = new Ext.form.DateField(objConfig);
        if (this._format != null && this._format != "") {
            dtField.format = this._format;
        }
        else {
            dtField.format = Ext.DatePicker.format;
        }

        dtField.render();
        this.DatePicker = dtField;
       
       
    },

    get_disabledDates: function() {

        return this._disabledDates;
    },
    set_disabledDates: function(value) {
        this._disabledDates = value;
    },

    get_disabledDatesText: function() {

        return this._disabledDatesText;
    },
    set_disabledDatesText: function(value) {
        this._disabledDatesText = value;
    },
    get_format: function() {

        return this._format;
    },
    set_format: function(value) {
        this._format = value;
    },
    get_disabledDays: function() {
        return this._disabledDays;
    },
    set_disabledDays: function(value) {
        this._disabledDays = value;
    },
    get_disabledDaysText: function() {
        return this._disabledDaysText;
    },
    set_disabledDaysText: function(value) {
        this._disabledDaysText = value;
    },
    get_Calendar: function() {
        return this.DatePicker;
    }

}
ExtExtenders.CalendarExtenderBehavior.registerClass('ExtExtenders.CalendarExtenderBehavior', Sys.UI.Control);
if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 