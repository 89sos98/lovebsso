using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using ExtExtenders.Helpers;

[assembly: WebResource("ExtExtenders.DropDown.DropDownExtenderBehavior.js", "text/javascript")]

namespace ExtExtenders
{
    /// <summary>
    /// Class to extend a DropDownList 
    /// </summary>
    [ToolboxBitmap(typeof (DropDownList))]
    public class ExtDropDownList : DropDownList, IScriptControl
    {
        private ScriptManager sm;
        /// <summary>
        /// The number of record of each page of the combo
        /// if this property is defined
        /// then the combo is paged
        /// </summary>
        [Description("The number of record of each page of the combo."),DescribableProperty]
        public int PageSize { get; set; }
        /// <summary>
        /// The total number of records (used for paging)
        /// </summary>
        [DescribableProperty]
        public int TotalRecords { get; set; }
        #region IScriptControl Members

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            var descriptor = new ScriptControlDescriptor(
                "ExtExtenders.DropDownExtenderBehavior", ClientID);


            descriptor.AddProperty("AutoPostBack", AutoPostBack);
            Util.DescribeProperties(this, descriptor);
            return new ScriptDescriptor[] {descriptor};
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ScriptReference> GetScriptReferences()
        {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.DropDown.DropDownExtenderBehavior.js");

            return new[] {reference};
        }

        #endregion

        /// <summary>
        /// Raises the pre render event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.EventArgs"/> instance containing the event data.</param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            string resource = Page.ClientScript.GetWebResourceUrl(GetType(), "ExtExtenders.yui-ext.css");
            string csslink = "<link href='" + resource + "' rel='stylesheet' type='text/css' />";
            Page.Header.Controls.Add(new LiteralControl(csslink));
            ClientScriptManager man = Page.ClientScript;
            //render the yui-ext scripts
            man.RegisterClientScriptResource(typeof (YUI), "ExtExtenders.yui.js");
            man.RegisterClientScriptResource(typeof (YUI_ext), "ExtExtenders.yui-ext.js");
            man.RegisterClientScriptResource(typeof (ext_yui_adapter), "ExtExtenders.ext-yui-adapter.js");
            if (!DesignMode)
            {
                // Test for ScriptManager and register if it exists
                sm = ScriptManager.GetCurrent(Page);

                if (sm == null)
                    throw new HttpException("A ScriptManager control must exist on the current page.");

                sm.RegisterScriptControl(this);
            }
        }
        /// <summary>
        /// Binds the specified data source to the control that is derived from the <see cref="T:System.Web.UI.WebControls.ListControl"/> class.
        /// </summary>
        /// <param name="dataSource">An <see cref="T:System.Collections.IEnumerable"/> that represents the data source.</param>
        /// <exception cref="T:System.ArgumentOutOfRangeException">
        /// The cached value of <see cref="P:System.Web.UI.WebControls.ListControl.SelectedIndex"/> is out of range.
        /// </exception>
        /// <exception cref="T:System.ArgumentException">
        /// The cached values of <see cref="P:System.Web.UI.WebControls.ListControl.SelectedIndex"/> and <see cref="P:System.Web.UI.WebControls.ListControl.SelectedValue"/> do not match.
        /// </exception>
        protected override void PerformDataBinding(System.Collections.IEnumerable dataSource)
        {
            if (PageSize==0)
            {
                base.PerformDataBinding(dataSource);
                return;
            }
            // If HttpProxy paging call, serialize new JsonData object and stop
            if (!string.IsNullOrEmpty(HttpContext.Current.Request["start"]))
            {
                var enu = dataSource.GetEnumerator();
                var items = new List<ComboItem>();
                while (enu.MoveNext())
                {
                    var current = enu.Current;
                    items.Add(new ComboItem
                    {
                        text = DataBinder.GetPropertyValue(current, DataTextField).ToString(),
                        value = DataBinder.GetPropertyValue(current, DataValueField).ToString()
                    });
                }
                
                var JsonData = new ExtDataContainer
                {
                    Records = items,
                    TotalCount = TotalRecords
                };
                HttpResponse Response = HttpContext.Current.Response;
                Response.Clear();
                var ser = new JavaScriptSerializer();
                Response.Write(ser.Serialize(JsonData));
                //.Replace(@"\/Date(", @"new Date(").Replace(@")\/", @")")
                Response.End();
            }
            
        }
        /// <summary>
        /// Renders the control to the specified HTML writer.
        /// </summary>
        /// <param name="writer">The <see cref="T:System.Web.UI.HtmlTextWriter"></see> object that receives the control content.</param>
        protected override void Render(HtmlTextWriter writer)
        {
            if (!DesignMode)
                sm.RegisterScriptDescriptors(this);
            base.Render(writer);
        }
    }
    /// <summary>
    /// 
    /// </summary>
    [ToolboxItem(false)]
    public class ComboItem
    {
        /// <summary>
        /// Gets or sets the text.
        /// </summary>
        /// <value>The text.</value>
        public string text { get; set; }
        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>The value.</value>
        public string value { get; set; }
    }
}