
Type.registerNamespace('ExtExtenders');
ExtExtenders.DropDownExtenderBehavior = function(element) {
  
    ExtExtenders.DropDownExtenderBehavior.initializeBase(this, [element]);

}
ExtExtenders.DropDownExtenderBehavior.prototype = {
    initialize: function() {

        ExtExtenders.DropDownExtenderBehavior.callBaseMethod(this, 'initialize');
        var id = this.get_element().id;
        var initialValue = this.get_element().value;
        var objConfig = {};
        objConfig.allowDomMove = false;
        objConfig.fieldClass = document.getElementById(id).className;
        objConfig.focusClass = document.getElementById(id).className;
        objConfig.typeAhead = true;
        objConfig.editable = true;
        objConfig.triggerAction = 'all';
        objConfig.transform = id;
        objConfig.mode = 'local';
        objConfig.forceSelection = true;
        objConfig.displayField = 'text';
        objConfig.valueField = 'value';

        if (this.get_PageSize() != 0) {
            objConfig.store = this.create_Store();
            objConfig.mode = 'remote';
            objConfig.pageSize = this.get_PageSize();
        }
        var ddField = new Ext.form.ComboBox(objConfig);
        ddField.setValue(initialValue);



        ddField.render();

        if (this.get_AutoPostBack() == true) {
            ddField.on("change", this.onchange, this);
            ddField.on("select", this.onchange, this);
        }
        this.Combo = ddField;
    },
    onchange: function() {

        var id = this.get_element().id;
        __doPostBack(id, '');
    },
    get_AutoPostBack: function() {
        return this._AutoPostBack;
    },
    set_AutoPostBack: function(value) {
        this._AutoPostBack = value;
    },
    get_DropDown: function() {
        return this.Combo;
    },
    set_PageSize: function(value) {
        this._PageSize = value;
    },
    get_PageSize: function() {
        return this._PageSize;
    },
    get_TotalRecords: function() {
        return this._TotalRecords;
    },
    set_TotalRecords: function(value) {
        this._TotalRecords = value;
    },
    create_Store: function() {
        var ds = new Ext.data.Store({
            proxy: new Ext.data.HttpProxy({
                url: location.href
            }),
            reader: new Ext.data.JsonReader({
                root: 'records',
                totalProperty: 'totalCount'
            }, ["text", "value"])
        });
        return ds;
    }

}
ExtExtenders.DropDownExtenderBehavior.registerClass('ExtExtenders.DropDownExtenderBehavior',Sys.UI.Control);
if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 