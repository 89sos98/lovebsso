using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Web.UI;

[assembly: WebResource("ExtExtenders.ModalUpdateProgress.ModalUpdateProgress.js", "text/javascript")]

namespace ExtExtenders
{
    /// <summary>
    /// Class to implement a modal update progress
    /// </summary>
    public class ModalUpdateProgress : UpdateProgress
    {
        private string _cancelControlID;
        

        /// <summary>
        /// Gets or sets the cancel control ID.
        /// </summary>
        /// <value>The cancel control ID.</value>
        [Category("Behavior"), DefaultValue(""),
         Description("The ID of the element that cancels the ModalUpdateProgress.")]
        public string CancelControlID
        {
            get
            {
                return _cancelControlID ?? string.Empty;
            }

            set { _cancelControlID = value; }
        }

        /// <summary>
        /// Gets the script manager.
        /// </summary>
        /// <value>The script manager.</value>
        private ScriptManager ScriptManager
        {
            get
            {
                var manager = ScriptManager.GetCurrent(Page);
                if (manager == null)
                {
                    throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
                                                                      "The control with ID '{0}' requires a ScriptManager on the page. The ScriptManager must appear before any controls that need it.",
                                                                      new object[] {ID}));
                }

                return manager;
            }
        }

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        protected override IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            if (((Page != null) && ScriptManager.SupportsPartialRendering) && Visible)
            {
                var desc = new ScriptControlDescriptor("ExtExtenders.ModalUpdateProgress", ClientID);
                string updatePanelClientID = null;
                if (!string.IsNullOrEmpty(AssociatedUpdatePanelID))
                {
                    var panel = NamingContainer.FindControl(AssociatedUpdatePanelID) as UpdatePanel ??
                                Page.FindControl(AssociatedUpdatePanelID) as UpdatePanel;

                    if (panel == null)
                    {
                        throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
                                                                          "No UpdatePanel found for AssociatedUpdatePanelID '{0}'.",
                                                                          new object[] {AssociatedUpdatePanelID}));
                    }

                    updatePanelClientID = panel.ClientID;
                }


                string cancelControlID = null;
                if (!string.IsNullOrEmpty(_cancelControlID))
                {
                    Control control = NamingContainer.FindControl(_cancelControlID) ??
                                      Page.FindControl(_cancelControlID);

                    if (control == null)
                    {
                        throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
                                                                          "No control found for CancelControlID '{0}'.",
                                                                          new object[] {_cancelControlID}));
                    }

                    cancelControlID = control.ClientID;
                }

                desc.AddProperty("associatedUpdatePanelId", updatePanelClientID);
                desc.AddProperty("cancelControlID", cancelControlID);
                yield return desc;
            }
        }

        /// <summary>
        /// Raises the pre render event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.EventArgs"/> instance containing the event data.</param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            string resource = Page.ClientScript.GetWebResourceUrl(GetType(), "ExtExtenders.yui-ext.css");
            string csslink = "<link href='" + resource + "' rel='stylesheet' type='text/css' />";
            Page.Header.Controls.Add(new LiteralControl(csslink));
            ClientScriptManager man = Page.ClientScript;
            //render the yui-ext scripts
            man.RegisterClientScriptResource(typeof (YUI), "ExtExtenders.yui.js");
            man.RegisterClientScriptResource(typeof (YUI_ext), "ExtExtenders.yui-ext.js");
            man.RegisterClientScriptResource(typeof (ext_yui_adapter), "ExtExtenders.ext-yui-adapter.js");
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        protected override IEnumerable<ScriptReference> GetScriptReferences()
        {
            yield return new ScriptReference("ExtExtenders.ModalUpdateProgress.ModalUpdateProgress.js", "ExtExtenders");
        }
    }
}