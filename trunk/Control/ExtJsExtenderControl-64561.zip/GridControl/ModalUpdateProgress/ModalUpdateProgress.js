// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

Type.registerNamespace('ExtExtenders');

ExtExtenders.ModalUpdateProgress = function(element) {
    /// <summary>
    /// The ModalUpdateProgress makes the target element BasicDialog
    /// </summary>
    /// <param name="element" type="Sys.UI.DomElement" domElement="true">
    /// DOM element associated with the behaviro
    /// </param>
    ExtExtenders.ModalUpdateProgress.initializeBase(this, [element]);
    
    // Properties
    this._MinimumWidth = 0;
    this._MinimumHeight = 0;
    
}
ExtExtenders.ModalUpdateProgress.prototype = {
    initialize : function() {
        /// <summary>
        /// Initialize the behavior
        /// </summary>
        ExtExtenders.ModalUpdateProgress.callBaseMethod(this, 'initialize');
        if (Sys.WebForms && Sys.WebForms.PageRequestManager) {
           this._pageRequestManager = Sys.WebForms.PageRequestManager.getInstance();
	    }
	    this._beginRequestHandlerDelegate = Function.createDelegate(this, this.beginRequest);
	    this._endRequestHandlerDelegate = Function.createDelegate(this, this.endRequest);
	    if (this._pageRequestManager !== null ) {
            this._pageRequestManager.add_beginRequest(this._beginRequestHandlerDelegate);
	        this._pageRequestManager.add_endRequest(this._endRequestHandlerDelegate);
	    }
        
        
    },
    get_cancelControlID:function(){
        return this._get_cancelControlID;
    },
    set_cancelControlID:function(value){
        this.cancelControlID=value;
    },
    beginRequest:function(){
        
        var basicId=this.get_element().id;
        var elBasic=Ext.get(basicId);
        var oldHtml=elBasic.dom.innerHTML;
         Ext.MessageBox.show({
           title: '         ',
           msg: oldHtml,
           width:240,
           closable:false
        });
    },
    endRequest:function(){
       Ext.MessageBox.hide();
    },
    dispose : function() {
        /// <summary>
        /// Dispose the behavior
        /// </summary>
       if (this._pageRequestManager !== null ) {
            this._pageRequestManager.remove_beginRequest(this._beginRequestHandlerDelegate);
    	    this._pageRequestManager.remove_endRequest(this._endRequestHandlerDelegate);
    	}
        
        ExtExtenders.ModalUpdateProgress.callBaseMethod(this, 'dispose');
    }
}
ExtExtenders.ModalUpdateProgress.registerClass('ExtExtenders.ModalUpdateProgress', Sys.UI._UpdateProgress);
if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 
