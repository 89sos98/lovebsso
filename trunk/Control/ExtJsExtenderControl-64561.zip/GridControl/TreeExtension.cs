using System.Web.UI;

#region Assembly Resource Attribute

[assembly: WebResource("ExtExtenders.TreeExtension.js", "text/javascript")]

#endregion

namespace ExtExtenders
{
    /// <summary>
    /// Class to include the js file
    /// </summary>
    public static class TreeExtension
    {
    }
}