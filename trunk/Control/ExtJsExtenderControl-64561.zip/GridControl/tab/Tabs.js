// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.


Type.registerNamespace("ExtExtenders");
ExtExtenders.TabContainer=function(element){
      ExtExtenders.TabContainer.initializeBase(this, [element]);
      
       
}
ExtExtenders.TabContainer.prototype={
         initialize : function() {
            ExtExtenders.TabContainer.callBaseMethod(this, "initialize");
           
            var tabItems=eval(this._Tabs);    
            var ElId=this.get_element().id;
            var objEl=Ext.get(ElId);
            var h=objEl.getHeight();
            var w=objEl.getWidth();
            var tabs;
            if(this._enableTabScroll){
                tabs = new Ext.TabPanel({
                        renderTo: ElId,
                        width:w,
                        height:h,
                        tabWidth:this._tabWidth,
                        items:tabItems,
                        enableTabScroll:this._enableTabScroll,
                        resizeTabs:this._resizeTabs
                    });
            }
            else{
                tabs = new Ext.TabPanel({
                        renderTo: ElId,
                        width:w,
                        height:h,
                        activeTab: this._ActiveTabIndex,
                        tabWidth:this._tabWidth,
                        items:tabItems,
                        resizeTabs:this._resizeTabs
                    });
            }
            this.TabPanel=tabs
        },
        get_ActiveTabIndex:function(){
            return this._ActiveTabIndex;
        },
        set_ActiveTabIndex:function(value){
            this._ActiveTabIndex=value;
        },
        get_autoPostBackId:function(){
            return this._autoPostBackId;
        },
        set_autoPostBackId:function(value){
            this._autoPostBackId=value;
        },
        get_clientStateField:function(){
            return this._clientStateField;
        },
        set_clientStateField:function(value){
            this._clientStateField=value;
        },
        get_TabCount:function(){
            return this._TabCount;
        },
        set_TabCount:function(value){
            this._TabCount=value;
        },
        get_Tabs:function(){
            return this._Tabs;
        },
        set_Tabs:function(value){
            this._Tabs=value;
        },
        get_enableTabScroll:function(){
            return this._enableTabScroll;
        },
        set_enableTabScroll:function(value){
            this._enableTabScroll=value;
        },
        get_tabWidth:function(){
            return this._tabWidth;
        },
        set_tabWidth:function(value){
            this._tabWidth=value;
        },
        get_resizeTabs:function(){
            return this._resizeTabs;
        },
        set_resizeTabs:function(value){
            this._resizeTabs=value;
        },
        removeTab:function(tabId){
            var tab=this.TabPanel.getItem(tabId);
            if(tab){
                this.TabPanel.remove(tab);
            }
        },
        enableTab:function(tabId){
            var tab=this.TabPanel.getItem(tabId);
            if(tab){
                tab.enable();
            }
        },
        disableTab:function(tabId){
            var tab=this.TabPanel.getItem(tabId);
            if(tab){
                tab.disable();
            }
        }
}
ExtExtenders.TabContainer.registerClass("ExtExtenders.TabContainer", Sys.UI.Control);
if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 
