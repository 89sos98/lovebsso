// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.


using System;
using System.Diagnostics.CodeAnalysis;
using System.Web.UI;

namespace ExtExtenders
{
    /// <summary>
    /// Collection of TabPanels
    /// </summary>
    [SuppressMessage("Microsoft.Design", "CA1035:ICollectionImplementationsHaveStronglyTypedMembers",
        Justification = "Unnecessary for this specialized class")]
    public class TabPanelCollection : ControlCollection
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="T:TabPanelCollection"/> class.
        /// </summary>
        /// <param name="owner">The ASP.NET server control that the control collection is created for.</param>
        /// <exception cref="T:System.ArgumentException">Occurs if the owner parameter is null. </exception>
        public TabPanelCollection(Control owner)
            : base(owner)
        {
        }

        /// <summary>
        /// Gets the <see cref="T:TabPanel"/> at the specified index.
        /// </summary>
        /// <value></value>
        public new TabPanel this[int index]
        {
            get { return (TabPanel) base[index]; }
        }

        /// <summary>
        /// Adds the specified <see cref="T:System.Web.UI.Control"></see> object to the collection.
        /// </summary>
        /// <param name="child">The <see cref="T:System.Web.UI.Control"></see> to add to the collection.</param>
        /// <exception cref="T:System.ArgumentNullException">Thrown if the child parameter does not specify a control. </exception>
        /// <exception cref="T:System.Web.HttpException">Thrown if the <see cref="T:System.Web.UI.ControlCollection"></see> is read-only. </exception>
        [SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters",
            Justification = "Assembly is not localized")]
        public override void Add(Control child)
        {
            if (!(child is TabPanel))
            {
                throw new ArgumentException("TabPanelCollection can only contain TabPanel controls.");
            }
            base.Add(child);
        }

        /// <summary>
        /// Adds the specified <see cref="T:System.Web.UI.Control"></see> object to the collection at the specified index location.
        /// </summary>
        /// <param name="index">The location in the array at which to add the child control.</param>
        /// <param name="child">The <see cref="T:System.Web.UI.Control"></see> to add to the collection.</param>
        /// <exception cref="T:System.ArgumentNullException">The child parameter does not specify a control. </exception>
        /// <exception cref="T:System.Web.HttpException">The <see cref="T:System.Web.UI.ControlCollection"></see> is read-only. </exception>
        /// <exception cref="T:System.ArgumentOutOfRangeException">The index parameter is less than zero or greater than the <see cref="P:System.Web.UI.ControlCollection.Count"></see> property. </exception>
        [SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters",
            Justification = "Assembly is not localized")]
        public override void AddAt(int index, Control child)
        {
            if (!(child is TabPanel))
            {
                throw new ArgumentException("TabPanelCollection can only contain TabPanel controls.");
            }
            base.AddAt(index, child);
        }
    }
}