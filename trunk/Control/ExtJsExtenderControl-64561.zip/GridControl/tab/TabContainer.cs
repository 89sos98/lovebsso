using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Globalization;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExtExtenders
{
    /// <summary>
    /// Control that acts as a container for the tabs
    /// </summary>
    [Designer("ExtExtenders.TabContainerDesigner, ExtExtenders")]
    [ParseChildren(typeof (TabPanel))]
    [ToolboxBitmap(typeof (TabContainer), "tab.Tabs.ico")]
    public class TabContainer : WebControl, IScriptControl
    {
        #region [ Fields ]

        private int _activeTabIndex = -1;
        private int _cachedActiveTabIndex = -1;
        private bool _initialized;
        private ScriptManager sm;

        #endregion

        #region [ Constructors ]

        /// <summary>
        /// Initializes a new TabContainer
        /// </summary>
        public TabContainer()
            : base(HtmlTextWriterTag.Div)
        {
            tabWidth = 135;
        }

        #endregion

        #region [ Properties ]

        /// <summary>
        /// Gets or sets the index of the active tab.
        /// </summary>
        /// <value>The index of the active tab.</value>
        [DefaultValue(-1)]
        [Category("Behavior")]
        public virtual int ActiveTabIndex
        {
            get
            {
                if (_cachedActiveTabIndex > -1)
                {
                    return _cachedActiveTabIndex;
                }
                if (Tabs.Count == 0)
                {
                    return -1;
                }
                return _activeTabIndex;
            }
            set
            {
                if (value < -1) throw new ArgumentOutOfRangeException("value");
                if (Tabs.Count == 0 && !_initialized)
                {
                    _cachedActiveTabIndex = value;
                }
                else
                {
                    if (value >= Tabs.Count)
                    {
                        throw new ArgumentOutOfRangeException("value");
                    }
                    if (ActiveTabIndex != value)
                    {
                        if (ActiveTabIndex != -1 && ActiveTabIndex < Tabs.Count)
                        {
                            Tabs[ActiveTabIndex].Active = false;
                        }
                        _activeTabIndex = value;
                        _cachedActiveTabIndex = -1;
                        if (ActiveTabIndex != -1 && ActiveTabIndex < Tabs.Count)
                        {
                            Tabs[ActiveTabIndex].Active = true;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// If the tabs are resizable
        /// </summary>
        public bool resizeTabs { get; set; }

        /// <summary>
        /// Gets the tabs.
        /// </summary>
        /// <value>The tabs.</value>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TabPanelCollection Tabs
        {
            get { return (TabPanelCollection) Controls; }
        }

        /// <summary>
        /// Gets or sets the active tab.
        /// </summary>
        /// <value>The active tab.</value>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TabPanel ActiveTab
        {
            get
            {
                int i = ActiveTabIndex;
                if (i < 0 || i >= Tabs.Count)
                {
                    return null;
                }
                EnsureActiveTab();
                return Tabs[i];
            }
            set
            {
                int i = Tabs.IndexOf(value);
                if (i < 0)
                {
                    throw new ArgumentOutOfRangeException("value");
                }
                ActiveTabIndex = i;
            }
        }

        /// <summary>
        /// Gets or sets the height of the Web server control.
        /// </summary>
        /// <value></value>
        /// <returns>A <see cref="T:System.Web.UI.WebControls.Unit"></see> that represents the height of the control. The default is <see cref="F:System.Web.UI.WebControls.Unit.Empty"></see>.</returns>
        /// <exception cref="T:System.ArgumentException">The height was set to a negative value.</exception>
        [DefaultValue(typeof (Unit), "")]
        [Category("Appearance")]
        [SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters",
            Justification = "Assembly is not localized")]
        public override Unit Height
        {
            get { return base.Height; }
            set
            {
                if (!value.IsEmpty && value.Type != UnitType.Pixel)
                {
                    throw new ArgumentOutOfRangeException("value", "Height must be set in pixels only, or Empty.");
                }
                base.Height = value;
            }
        }

        /// <summary>
        /// Gets or sets the width of the Web server control.
        /// </summary>
        /// <value></value>
        /// <returns>A <see cref="T:System.Web.UI.WebControls.Unit"></see> that represents the width of the control. The default is <see cref="F:System.Web.UI.WebControls.Unit.Empty"></see>.</returns>
        /// <exception cref="T:System.ArgumentException">The width of the Web server control was set to a negative value. </exception>
        [DefaultValue(typeof (Unit), "")]
        [Category("Appearance")]
        public override Unit Width
        {
            get { return base.Width; }
            set { base.Width = value; }
        }


        /// <summary>
        /// To enable AutoPostBack, we need to call an ASP.NET script method with the UniqueId
        /// on the client side.  To do this, we just use this property as the one to serialize and
        /// alias it's name.
        /// </summary>
        [SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member",
            Justification = "Following ASP.NET naming conventions...")]
        [SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "value",
            Justification = "Required for serialization")]
        public new string UniqueID
        {
            get { return base.UniqueID; }
            internal set
            {
                if (value == null) throw new ArgumentNullException("value");
                // need to add a setter for serialization to work properly.
            }
        }

        /// <summary>
        /// Width of each tab
        /// </summary>
        public int tabWidth { get; set; }

        /// <summary>
        /// Enables tab scrolling when there are a lot of tabs
        /// </summary>
        public bool enableTabScroll { get; set; }

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.PreRender"></see> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            string resource = Page.ClientScript.GetWebResourceUrl(GetType(), "ExtExtenders.yui-ext.css");
            string csslink = "<link href='" + resource + "' rel='stylesheet' type='text/css' />";
            Page.Header.Controls.Add(new LiteralControl(csslink));
            ClientScriptManager man = Page.ClientScript;
            //render the yui-ext scripts

            man.RegisterClientScriptResource(typeof (YUI), "ExtExtenders.yui.js");
            man.RegisterClientScriptResource(typeof (YUI_ext), "ExtExtenders.yui-ext.js");
            man.RegisterClientScriptResource(typeof (ext_yui_adapter), "ExtExtenders.ext-yui-adapter.js");
            if (!DesignMode)
            {
                // Test for ScriptManager and register if it exists
                sm = ScriptManager.GetCurrent(Page);

                if (sm == null)
                    throw new HttpException("A ScriptManager control must exist on the current page.");

                sm.RegisterScriptControl(this);
            }
        }

        /// <summary>
        /// Renders the control to the specified HTML writer.
        /// </summary>
        /// <param name="writer">The <see cref="T:System.Web.UI.HtmlTextWriter"></see> object that receives the control content.</param>
        protected override void Render(HtmlTextWriter writer)
        {
            base.Render(writer);
            if (!DesignMode)
                sm.RegisterScriptDescriptors(this);
        }

        #endregion

        #region [ Methods ]

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Init"></see> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            Page.RegisterRequiresControlState(this);

            _initialized = true;
            if (_cachedActiveTabIndex > -1)
            {
                ActiveTabIndex = _cachedActiveTabIndex;
            }
            else if (Tabs.Count > 0)
            {
                ActiveTabIndex = 0;
            }
        }


        /// <summary>
        /// Notifies the server control that an element, either XML or HTML, was parsed, and adds the element to the server control's <see cref="T:System.Web.UI.ControlCollection"></see> object.
        /// </summary>
        /// <param name="obj">An <see cref="T:System.Object"></see> that represents the parsed element.</param>
        protected override void AddParsedSubObject(object obj)
        {
            var objTabPanel = obj as TabPanel;
            if (null != objTabPanel)
            {
                Controls.Add(objTabPanel);
            }
            else if (!(obj is LiteralControl))
            {
                throw new HttpException(string.Format(CultureInfo.CurrentCulture,
                                                      "TabContainer cannot have children of type '{0}'.", obj.GetType()));
            }
        }

        /// <summary>
        /// Called after a child control is added to the <see cref="P:System.Web.UI.Control.Controls"></see> collection of the <see cref="T:System.Web.UI.Control"></see> object.
        /// </summary>
        /// <param name="control">The <see cref="T:System.Web.UI.Control"></see> that has been added.</param>
        /// <param name="index">The index of the control in the <see cref="P:System.Web.UI.Control.Controls"></see> collection.</param>
        protected override void AddedControl(Control control, int index)
        {
            ((TabPanel) control).SetOwner(this);
            base.AddedControl(control, index);
        }

        /// <summary>
        /// Called after a control is removed from the <see cref="P:System.Web.UI.Control.Controls"></see> collection of another control.
        /// </summary>
        /// <param name="control">The <see cref="T:System.Web.UI.Control"></see> that has been removed.</param>
        protected override void RemovedControl(Control control)
        {
            var controlTabPanel = control as TabPanel;
            if (controlTabPanel != null)
                if (control != null && controlTabPanel.Active && ActiveTabIndex < Tabs.Count)
                {
                    EnsureActiveTab();
                }
            if (controlTabPanel != null) controlTabPanel.SetOwner(null);
            base.RemovedControl(control);
        }

        /// <summary>
        /// Creates a new <see cref="T:System.Web.UI.ControlCollection"></see> object to hold the child controls (both literal and server) of the server control.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.Web.UI.ControlCollection"></see> object to contain the current server control's child server controls.
        /// </returns>
        protected override ControlCollection CreateControlCollection()
        {
            return new TabPanelCollection(this);
        }

        /// <summary>
        /// Creates the style object that is used internally by the <see cref="T:System.Web.UI.WebControls.WebControl"></see> class to implement all style related properties. This method is used primarily by control developers.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.Web.UI.WebControls.Style"></see> that is used to implement all style-related properties of the control.
        /// </returns>
        protected override Style CreateControlStyle()
        {
            var style = new TabContainerStyle(ViewState) {CssClass = "ajax__tab_xp"};
            return style;
        }


        /// <summary>
        /// Restores control-state information from a previous page request that was saved by the <see cref="M:System.Web.UI.Control.SaveControlState"></see> method.
        /// </summary>
        /// <param name="savedState">An <see cref="T:System.Object"></see> that represents the control state to be restored.</param>
        protected override void LoadControlState(object savedState)
        {
            var p = (Pair) savedState;
            if (p != null)
            {
                base.LoadControlState(p.First);
                ActiveTabIndex = (int) p.Second;
            }
            else
            {
                base.LoadControlState(null);
            }
        }

        /// <summary>
        /// Saves any server control state changes that have occurred since the time the page was posted back to the server.
        /// </summary>
        /// <returns>
        /// Returns the server control's current state. If there is no state associated with the control, this method returns null.
        /// </returns>
        protected override object SaveControlState()
        {
            var p = new Pair {First = base.SaveControlState(), Second = ActiveTabIndex};
            if (p.First == null && p.Second == null)
            {
                return null;
            }
            return p;
        }

        /// <summary>
        /// Adds HTML attributes and styles that need to be rendered to the specified <see cref="T:System.Web.UI.HtmlTextWriterTag"></see>. This method is used primarily by control developers.
        /// </summary>
        /// <param name="writer">A <see cref="T:System.Web.UI.HtmlTextWriter"></see> that represents the output stream to render HTML content on the client.</param>
        protected override void AddAttributesToRender(HtmlTextWriter writer)
        {
            Style.Remove(HtmlTextWriterStyle.Visibility);
            if (!ControlStyleCreated)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "x-tabs-top");
            }
            base.AddAttributesToRender(writer);
            //writer.AddStyleAttribute(HtmlTextWriterStyle.Visibility, "hidden");
        }

        /// <summary>
        /// Renders the contents of the control to the specified writer. This method is used primarily by control developers.
        /// </summary>
        /// <param name="writer">A <see cref="T:System.Web.UI.HtmlTextWriter"></see> that represents the output stream to render HTML content on the client.</param>
        protected override void RenderContents(HtmlTextWriter writer)
        {
            Page.VerifyRenderingInServerForm(this);
            if (!Height.IsEmpty)
                writer.AddStyleAttribute(HtmlTextWriterStyle.Height, Height.ToString());
            if (!Width.IsEmpty)
                writer.AddStyleAttribute(HtmlTextWriterStyle.Width, Width.ToString());

            RenderChildren(writer);
        }

        private void EnsureActiveTab()
        {
            if (_activeTabIndex < 0 || _activeTabIndex >= Tabs.Count)
            {
                _activeTabIndex = 0;
            }

            for (var i = 0; i < Tabs.Count; i++)
            {
                Tabs[i].Active = i == ActiveTabIndex;
            }
        }

        #endregion

        #region [ TabContainerStyle ]

        private sealed class TabContainerStyle : Style
        {
            public TabContainerStyle(StateBag state)
                : base(state)
            {
            }

            protected override void FillStyleAttributes(CssStyleCollection attributes, IUrlResolutionService urlResolver)
            {
                base.FillStyleAttributes(attributes, urlResolver);

                attributes.Remove(HtmlTextWriterStyle.BackgroundColor);
                attributes.Remove(HtmlTextWriterStyle.BackgroundImage);
            }
        }

        #endregion

        #region IScriptControl Members

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            var descriptor = new ScriptControlDescriptor(
                "ExtExtenders.TabContainer", ClientID);

            Type t = GetType();
            //properties that will be serialized
            string[] propsToSerialize = {
                                            "resizeTabs", "ActiveTabIndex", "tabWidth", "enableTabScroll"
                                        };
            foreach (string prop in propsToSerialize)
            {
                PropertyInfo p = t.GetProperty(prop);
                if (p == null)
                {
                    throw new Exception(prop);
                }
                descriptor.AddProperty(p.Name, p.GetValue(this, null));
            }

            #region Tabs

            descriptor.AddProperty("TabCount", Tabs.Count);
            var sb = new StringBuilder();
            sb.Append("[");
            TabPanel tab;
            for (int i = 0; i < Tabs.Count; i++)
            {
                tab = Tabs[i];
                sb.Append("{");
                sb.Append("id:'" + tab.ClientID + "',");
                sb.Append("disabled:" + (!tab.Enabled).ToString().ToLower() + ",");
                sb.Append("closable:" + tab.closable.ToString().ToLower() + ",");
                sb.Append("contentEl:'" + tab.ClientID + "',");
                if (!string.IsNullOrEmpty(tab.iconCls))
                {
                    sb.Append("iconCls:'" + tab.iconCls + "',");
                }
                if (!string.IsNullOrEmpty(tab.DynamicContentPath))
                {
                    if (tab.DynamicContentPath.IndexOf(".aspx") == -1)
                    {
                       
                        sb.Append("autoLoad:'" + tab.DynamicContentPath + "',");
                    }
                    else
                    {
                        sb.Append("html:'<iframe src=\"" + tab.DynamicContentPath + "\" style=\"width:100%;height:100%\"></iframe>',");
                    }
                }
                sb.Append("title:'" + Tabs[i].HeaderText + "'");
                sb.Append("}");
                if (i < Tabs.Count - 1)
                {
                    sb.Append(",");
                }
            }
            sb.Append("]");
            descriptor.AddProperty("Tabs", sb.ToString());

            #endregion

            return new ScriptDescriptor[] {descriptor};
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ScriptReference> GetScriptReferences()
        {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.tab.Tabs.js");

            return new[] {reference};
        }

        #endregion
    }
}