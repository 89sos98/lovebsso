// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.


using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExtExtenders
{
    /// <summary>
    /// Class that represents a TabPanel
    /// </summary>
    [ParseChildren(true)]
    [ToolboxBitmap(typeof (TabPanel), "Tab.Tabs.ico")]
    [Designer(typeof (TabPanelDesigner))]
    public class TabPanel : WebControl
    {
        #region [ Fields ]

        private ITemplate _contentTemplate;
        private Control _headerControl;
        private ITemplate _headerTemplate;

        #endregion

        #region [ Constructors ]

        /// <summary>
        /// Initializes a new instance of the <see cref="T:TabPanel"/> class.
        /// </summary>
        public TabPanel()
            : base(HtmlTextWriterTag.Div)
        {
        }

        #endregion

        #region [ Properties ]

        /// <summary>
        /// Gets or sets the header text.
        /// </summary>
        /// <value>The header text.</value>
        [DefaultValue("")]
        [Category("Appearance")]
        public string HeaderText
        {
            get { return (string) (ViewState["HeaderText"] ?? string.Empty); }
            set { ViewState["HeaderText"] = value; }
        }

        /// <summary>
        /// Gets or sets the header template.
        /// </summary>
        /// <value>The header template.</value>
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateInstance(TemplateInstance.Single)]
        [Browsable(false)]
        [MergableProperty(false)]
        public ITemplate HeaderTemplate
        {
            get { return _headerTemplate; }
            set { _headerTemplate = value; }
        }

        /// <summary>
        /// Gets or sets the content template.
        /// </summary>
        /// <value>The content template.</value>
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateInstance(TemplateInstance.Single)]
        [Browsable(false)]
        [MergableProperty(false)]
        public ITemplate ContentTemplate
        {
            get { return _contentTemplate; }
            set { _contentTemplate = value; }
        }

        /// <summary>
        /// Path of the Page or generic Handler that will be used to
        /// load dynamic content
        /// </summary>
        [DefaultValue("")]
        [Category("Behavior")]
        [UrlProperty]
        public string DynamicContentPath
        {
            get { return (string) (ViewState["DynamicContentPath"] ?? string.Empty); }
            set { ViewState["DynamicContentPath"] = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the Tabis enabled.
        /// </summary>
        /// <value></value>
        /// <returns>true if tab is enabled; otherwise, false. The default is true.</returns>
        [DefaultValue(true)]
        [Category("Behavior")]
        public override bool Enabled
        {
            get { return base.Enabled; }
            set { base.Enabled = value; }
        }

        /// <summary>
        /// If the tab is closable
        /// </summary>
        public bool closable { get; set; }

        /// <summary>
        /// The css class for the icon of the tab
        /// </summary>
        public string iconCls { get; set; }

        internal bool Active { get; set; }

        #endregion

        #region [ Methods ]

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Init"></see> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        [SuppressMessage("Microsoft.Reliability", "CA2000:DisposeObjectsBeforeLosingScope",
            Justification = "Local c is handed off to Controls collection")]
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            if (_headerTemplate != null)
            {
                _headerControl = new Control();
                _headerTemplate.InstantiateIn(_headerControl);
                Controls.Add(_headerControl);
            }
            if (_contentTemplate != null)
            {
                var c = new Control();
                _contentTemplate.InstantiateIn(c);
                Controls.Add(c);
            }
        }


        /// <summary>
        /// Renders the specified writer.
        /// </summary>
        /// <param name="writer">The writer.</param>
        protected override void Render(HtmlTextWriter writer)
        {
            if (_headerControl != null)
            {
                _headerControl.Visible = false;
            }

            writer.AddAttribute(HtmlTextWriterAttribute.Id, ClientID);
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "x-hide-display");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);
            RenderChildren(writer);
            writer.RenderEndTag();
        }


        internal void SetOwner(TabContainer owner)
        {
        }

        #endregion
    }
}