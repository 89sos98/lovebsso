// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

using System.Collections.Generic;
using System.Web.UI;
using ExtExtenders.Helpers;

[assembly: WebResource("ExtExtenders.BasicDialog.BasicDialogControlBehavior.js", "text/javascript")]

namespace ExtExtenders
{
    /// <summary>
    /// Class to Extend any control into a BasicDialog element
    /// </summary>
    public class BasicDialogExtender : ExtScriptWebControlBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="T:BasicDialogControlExtender"/> class.
        /// </summary>
        public BasicDialogExtender():base(HtmlTextWriterTag.Div)
        {
            Closable = true;
            Collapsible = true;
            Constraintoviewport = true;
        }

        /// <summary>
        /// The title of the Dialog
        /// </summary>
        [DescribableProperty]
        public string Title { get; set; }

        /// <summary>
        /// Control that will be transformed into
        /// a basic dialog
        /// </summary>
        [DescribableProperty]
        public string PopupControlID { get; set; }

        /// <summary>
        /// Gets or sets the target control ID.
        /// </summary>
        /// <value>The target control ID.</value>
        public string TargetControlID { get; set; }

        /// <summary>
        /// If the basic dialog is closable,defaults to true
        /// </summary>
        [DescribableProperty]
        public bool Closable { get; set; }

        /// <summary>
        /// False to remove the built-in top-right 
        /// corner collapse button (defaults to true)
        /// </summary>
        [DescribableProperty]
        public bool Collapsible { get; set; }

        /// <summary>
        /// True to keep the dialog constrained within
        /// the visible viewport boundaries (defaults to true)
        /// </summary>
        [DescribableProperty]
        public bool Constraintoviewport { get; set; }

        /// <summary>
        /// True to show the dialog modally, preventing user interaction 
        /// with the rest of the page (defaults to false)
        /// </summary>
        [DescribableProperty]
        public bool Modal { get; set; }

        /// <summary>
        /// Gets or sets the minimum width of the BasicDialog.
        /// </summary>
        /// <value>The minimum width.</value>
        [DescribableProperty]
        public int MinimumWidth { get; set; }

        /// <summary>
        /// Gets or sets the minimum height.
        /// </summary>
        /// <value>The minimum height.</value>
        [DescribableProperty]
        public int MinimumHeight { get; set; }

        /// <summary>
        /// If the control is also draggable 
        /// </summary>
        [DescribableProperty]
        public bool Draggable { get; set; }

        ///<summary>
        /// If the dialog is also resizable
        /// </summary>
        [DescribableProperty]
        public bool Resizable { get; set; }

        [DescribableProperty]
        public string Url { get; set; }
        #region IScriptControl Members

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            Control c;
            if(!string.IsNullOrEmpty(TargetControlID)){
                   c=FindControl(TargetControlID);
            }
            else
	        {
                c= this;
	        }
            var descriptor = new ScriptControlDescriptor(
                "ExtExtenders.BasicDialogControlBehavior", c.ClientID);

            Util.DescribeProperties(this, descriptor);
            if (!string.IsNullOrEmpty(PopupControlID))
            {
                descriptor.AddProperty("PopupControlID", FindControl(PopupControlID).ClientID);
            }
            return new ScriptDescriptor[] {descriptor};
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<ScriptReference> GetScriptReferences()
        {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.BasicDialog.BasicDialogControlBehavior.js");

            return new[] {reference};
        }

        #endregion
    }
}