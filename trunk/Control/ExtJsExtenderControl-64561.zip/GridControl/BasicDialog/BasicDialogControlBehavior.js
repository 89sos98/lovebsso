// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

Type.registerNamespace('ExtExtenders');

ExtExtenders.BasicDialogControlBehavior = function(element) {
    /// <summary>
    /// The BasicDialogControlBehavior makes the target element BasicDialog
    /// </summary>
    /// <param name="element" type="Sys.UI.DomElement" domElement="true">
    /// DOM element associated with the behaviro
    /// </param>
    ExtExtenders.BasicDialogControlBehavior.initializeBase(this, [element]);
    
    // Properties
    this._MinimumWidth = 0;
    this._MinimumHeight = 0;
    
}
ExtExtenders.BasicDialogControlBehavior.prototype = {
    initialize: function() {
        /// <summary>
        /// Initialize the behavior
        /// </summary>
        ExtExtenders.BasicDialogControlBehavior.callBaseMethod(this, 'initialize');
        var ElId = this.get_element().id; //targetControlId

        //element that will become the basic dialog
        var basicId = this.get_PopupControlID();
        var elBasic = Ext.get(basicId);
        if (elBasic) {
            var oldHtml = elBasic.dom.innerHTML;
            elBasic.dom.innerHTML = "";
            //add title
            var dh = Ext.DomHelper;
            dh.append(basicId, { tag: 'div', cls: 'x-window-header', html: this.get_Title() });
            //add body
            dh.append(basicId, { tag: 'div', cls: 'x-window-body', html: oldHtml });
        }
        var url = this.get_Url();
        if (url == null || url == "") {
            var dlg = new Ext.Window({
                el: basicId,
                minHeight: this._MinimumWidth,
                minWidth: this._MinimumHeight,
                modal: this._Modal,
                draggable: this._Draggable,
                resizable: this._Resizable,
                closable: this._Closable,
                closeAction: 'hide',
                plain: true,
                renderTo: document.forms[0].id,
                allowDomMove: false,
                constraintoviewport: this._Constraintoviewport
            });
        }
        else {
            var dlg = new Ext.Window({
                html: "<iframe src='" + url + "' style='width:100%;height:100%'></iframe>",
                minHeight: this._MinimumWidth,
                minWidth: this._MinimumHeight,
                modal: this._Modal,
                draggable: this._Draggable,
                resizable: this._Resizable,
                closable: this._Closable,
                closeAction: 'hide',
                plain: true,
                allowDomMove: false,
                constraintoviewport: this._Constraintoviewport,
                el: ElId,
                renderTo: document.body
            });
        }

        this.dialog = dlg;
        if (ElId != null && ElId != "") {
            this._showHandler = Function.createDelegate(this, this._onShow);
            $addHandler(this.get_element(), 'click', this._showHandler);
        }


    },
    _onShow: function(e) {
        this.dialog.show();
        this.dialog.anchorTo(Ext.getBody(), "c-c");
        e.preventDefault();
        return false;

    },

    get_Dialog: function() {
        return this.dialog;
    },
    get_Title: function() {
        return this._Title;
    },
    set_Title: function(value) {
        this._Title = value;
    },
    get_MinimumWidth: function() {
        /// <value type="Number" integer="true">
        /// Minimum width of the BasicDialog element
        /// </value>
        return this._MinimumWidth;
    },
    set_MinimumWidth: function(value) {
        if (this._MinimumWidth != value) {
            this._MinimumWidth = value;
            this.raisePropertyChanged('MinimumWidth');
        }
    },

    get_MinimumHeight: function() {
        /// <value type="Number" integer="true">
        /// Minimum height of the BasicDialog element
        /// </value>
        return this._MinimumHeight;
    },
    set_MinimumHeight: function(value) {
        if (this._MinimumHeight != value) {
            this._MinimumHeight = value;
            this.raisePropertyChanged('MinimumHeight');
        }
    },
    get_Draggable: function() {
        return this._Draggable;
    },
    set_Draggable: function(value) {
        this._Draggable = value;
    },
    get_Resizable: function() {
        return this._Resizable;
    },
    set_Resizable: function(value) {
        this._Resizable = value;
    },
    get_Modal: function() {
        return this._Modal;
    },
    set_Modal: function(value) {
        this._Modal = value;
    },
    get_Closable: function() {
        return this._Closable;
    },
    set_Closable: function(value) {
        this._Closable = value;
    },
    get_Constraintoviewport: function() {
        return this._Constraintoviewport;
    },
    set_Constraintoviewport: function(value) {
        this._Constraintoviewport = value;
    },
    get_PopupControlID: function() {
        return this._PopupControlID;
    },
    set_PopupControlID: function(value) {
        this._PopupControlID = value;
    },
    get_Collapsible: function() {
        return this._Collapsible;
    },
    set_Collapsible: function(value) {
        this._Collapsible = value;
    },
    get_Url: function() {
        return this._Url;
    },
    set_Url: function(value) {
        this._Url = value;
    },
    dispose: function() {
        /// <summary>
        /// Dispose the behavior
        /// </summary>
        if (this._okHandler && $get(this._OkControlID)) {
            $removeHandler($get(this._OkControlID), 'click', this._okHandler);
            this._okHandler = null;
        }
        if (this._showHandler) {
            $removeHandler(this.get_element(), 'click', this._showHandler);
            this._showHandler = null;
        }

        ExtExtenders.BasicDialogControlBehavior.callBaseMethod(this, 'dispose');
    }
}
ExtExtenders.BasicDialogControlBehavior.registerClass('ExtExtenders.BasicDialogControlBehavior', Sys.UI.Control);
if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 
