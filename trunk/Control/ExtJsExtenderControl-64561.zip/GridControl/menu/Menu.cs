using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace ExtExtenders
{
    /// <summary>
    /// Class that represents an Ext Menu
    /// should be associated with other classes like the Tree
    /// </summary>
    [ToolboxItem(false)]
    public class Menu
    {
        private List<MenuItem> _Items;

        /// <summary>
        /// Items of the menu
        /// </summary>
        public List<MenuItem> Items
        {
            get
            {
                if (_Items == null)
                {
                    _Items = new List<MenuItem>();
                }
                return _Items;
            }
        }

        /// <summary>
        /// Helper to add an item to a menu
        /// </summary>
        /// <param name="text">The text.</param>
        /// <returns></returns>
        public MenuItem AddItem(string text)
        {
            var it = new MenuItem {Text = text,DateSelected =DateTime.Now};
            Items.Add(it);
            return it;
        }

        /// <summary>
        /// Helper to add an item to a menu
        /// </summary>
        /// <param name="text">The text.</param>
        /// <param name="cls">The css class to use for the icon.</param>
        /// <returns></returns>
        public MenuItem AddIconItem(string text, string cls)
        {
            var it = new MenuItem {Text = text, iconCls = cls,DateSelected =DateTime.Now};
            Items.Add(it);
            return it;
        }

        /// <summary>
        /// Helper to add a menu item
        /// </summary>
        /// <param name="text"></param>
        /// <param name="clientClick"></param>
        public MenuItem AddItem(string text, string clientClick)
        {
            var it = new MenuItem {Text = text, OnClientClick = clientClick,DateSelected =DateTime.Now};
            Items.Add(it);
            return it;
        }

        /// <summary>
        /// Add an item of an specied type
        /// </summary>
        /// <param name="text"></param>
        /// <param name="type"></param>
        public MenuItem AddItem(string text, MenuType type)
        {
            var it = new MenuItem {Text = text, ItemType = type,DateSelected =DateTime.Now};
            Items.Add(it);
            return it;
        }

        /// <summary>
        /// Add an item of an specied type
        /// </summary>
        /// <param name="text">The text.</param>
        /// <param name="type">The type.</param>
        /// <param name="clientClick">The client function to call.</param>
        public MenuItem AddItem(string text, MenuType type, string clientClick)
        {
            var it = new MenuItem {Text = text, ItemType = type, OnClientClick = clientClick,DateSelected =DateTime.Now};
            Items.Add(it);
            return it;
        }

        /// <summary>
        /// Adds a separator
        /// </summary>
        public void AddSeparador()
        {
            var it = new MenuItem {ItemType = MenuType.Separator,DateSelected =DateTime.Now};
            Items.Add(it);
        }
    }
}