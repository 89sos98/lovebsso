using System;
using System.ComponentModel;

namespace ExtExtenders
{
    /// <summary>
    /// Enum to define the type of the menuitem
    /// </summary>
    public enum MenuType
    {
        /// <summary>
        /// The menu has a checkbox and a text
        /// </summary>
        CheckItem = 0,
        /// <summary>
        /// The menu displays a color picker
        /// </summary>
        ColorItem = 1,
        /// <summary>
        /// default menu
        /// </summary>
        TextItem = 2,
        /// <summary>
        /// The item is separator
        /// </summary>
        Separator = 3,
        /// <summary>
        /// The menu displays a date picker
        /// </summary>
        DateItem = 4,
        /// <summary>
        /// The menu is used to point to an url
        /// </summary>
        URL = 5
    }

    /// <summary>
    ///  Represents a menu item
    /// </summary>
    [ToolboxItem(false)]
    public class MenuItem
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="T:MenuItem"/> class.
        /// </summary>
        public MenuItem()
        {
            ItemType = MenuType.TextItem;
            DateSelected = DateTime.Now;
        }

        /// <summary>
        /// Gets or sets a value indicating whether the menu is checked(Check item menu only).
        /// </summary>
        /// <value>
        /// 	<c>true</c> if the menu is checked; otherwise, <c>false</c>.
        /// </value>
        public bool IsChecked { get; set; }

        /// <summary>
        /// The date selected on the menu (only DateItem)
        /// </summary>
        public DateTime DateSelected { get; set; }

        /// <summary>
        /// The color selected on the menu (only ColorItem)
        /// </summary>
        public string ColorSelected { get; set; }

        /// <summary>
        /// Gets or sets the text of the menu.
        /// </summary>
        /// <value>The text.</value>
        public string Text { get; set; }

        /// <summary>
        /// The path to an icon to display in 
        /// this menu item defaults to no icon
        /// </summary>
        public string icon { get; set; }

        /// <summary>
        /// The id of the menu
        /// </summary>
        /// <value>The id.</value>
        public string Id { get; set; }

        /// <summary>
        /// Name of the javascript function to be fired 
        /// on the item click(optional)
        /// </summary>
        public string OnClientClick { get; set; }

        /// <summary>
        /// The type of the menu item
        /// </summary>
        public MenuType ItemType { get; set; }

        /// <summary>
        /// The css class to use to display the icon
        /// </summary>
        public string iconCls { get; set; }

        /// <summary>
        /// SubMenu for a menu item
        /// </summary>
        public Menu SubMenu { get; set; }

        /// <summary>
        /// If the menu is disabled
        /// </summary>
        public bool disabled { get; set; }

        ///<summary>
        /// The link for the menu
        ///</summary>
        public string url { get; set; }

        ///<summary>
        /// The target frame for the menu
        ///</summary>
        public string target { get; set; }
    }
}