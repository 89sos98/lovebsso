using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExtExtenders.Helpers
{
    /// <summary>
    /// Base class for which WebControl type extenders are derived
    /// </summary>
    public abstract class ExtScriptWebControlBase : WebControl, IScriptControl, IControlResolver
    {
        #region Private Member Data

        private readonly Dictionary<string, Control> _findControlHelperCache = new Dictionary<string, Control>();
        private ClientScriptProxy ClientScriptProxy;
        private ScriptManager sm;

        #endregion

       /// <summary>
        /// Class constructor
        /// </summary>
        /// <param name="objTag"></param>
        public ExtScriptWebControlBase(HtmlTextWriterTag objTag)
            : base(objTag)
        {
        }

        /// <summary>
        /// Gets a reference to this controls ID for postback/callback purposes
        /// </summary>
        [Browsable(false)]
        public string PostBackIDReference
        {
            get
            {
                bool bLegacyRendering = !DesignMode && (GetXhtmlConformanceMode() == XhtmlConformanceMode.Legacy);

                string strID = UniqueID;
                if (bLegacyRendering && ((strID != null) && (strID.IndexOf(':') >= 0)))
                    strID = strID.Replace(':', '$');
                return strID;
            }
        }

        #region IControlResolver Members

        /// <summary>
        /// Finds the control using the ID specified
        /// </summary>
        /// <param name="controlId">The ID of the control to find</param>
        /// <returns>The control</returns>
        public Control ResolveControl(string controlId)
        {
            return FindControl(controlId);
        }

        #endregion

        #region IScriptControl Members

        /// <summary>
        /// Abstract method used to get the script descriptors
        /// </summary>
        /// <returns>ScriptDescriptor collection</returns>
        public abstract IEnumerable<ScriptDescriptor> GetScriptDescriptors();

        /// <summary>
        /// Abstract method to get script references
        /// </summary>
        /// <returns>Script references</returns>
        public abstract IEnumerable<ScriptReference> GetScriptReferences();

        #endregion

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Init"/> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"/> object that contains the event data.</param>
        protected override void OnInit(EventArgs e)
        {
            ClientScriptProxy = ClientScriptProxy.Current;
            base.OnInit(e);
        }

        /// <summary>
        /// Called when the ExtenderControlBase fails to locate a control referenced by a TargetControlID.
        /// In this event, user code is given an opportunity to find the control.
        /// </summary>
        [SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase",
            Justification = "Following ASP.NET AJAX pattern")]
        public event ResolveControlEventHandler ResolveControlID;

        /// <summary>
        /// Overrides FindControl.  Calls FindControlHelper.
        /// </summary>
        /// <param name="id">The ID of the control to find</param>
        /// <returns>The control</returns>
        public override Control FindControl(string id)
        {
            // Use FindControlHelper so that more complete searching and OnResolveControlID will be used
            return FindControlHelper(id);
        }

        #region Protected Methods

        /// <summary>
        /// Overrides OnPreRender.  Registers scripts common to the ExtExtenders library
        /// </summary>
        /// <param name="e">The event arguments</param>
        protected override void OnPreRender(EventArgs e)
        {
            string resource = Page.ClientScript.GetWebResourceUrl(GetType(), "ExtExtenders.yui-ext.css");
            string csslink = "<link href='" + resource + "' rel='stylesheet' type='text/css' />";
            Page.Header.Controls.Add(new LiteralControl(csslink));

            //render the yui-ext scripts
            ClientScriptProxy.RegisterClientScriptResource(this, typeof (YUI), "ExtExtenders.yui.js");
            ClientScriptProxy.RegisterClientScriptResource(this, typeof (YUI_ext), "ExtExtenders.yui-ext.js");
            ClientScriptProxy.RegisterClientScriptResource(this, typeof (ext_yui_adapter),
                                                           "ExtExtenders.ext-yui-adapter.js");
            if (!DesignMode)
            {
                // Test for ScriptManager and register if it exists
                sm = ScriptManager.GetCurrent(Page);

                if (sm == null)
                    throw new HttpException("A ScriptManager control must exist on the current page.");

                sm.RegisterScriptControl(this);
            }

            base.OnPreRender(e);
        }

        /// <summary>
        /// Overrides Render().  Registers script descriptors.
        /// </summary>
        /// <param name="writer">The HtmlTextWriter</param>
        protected override void Render(HtmlTextWriter writer)
        {
            if (!DesignMode)
                sm.RegisterScriptDescriptors(this);
            base.Render(writer);
        }


        /// <summary>
        /// This helper automates locating a control by ID.
        /// 
        /// It calls FindControl on the NamingContainer, then the Page.  If that fails,
        /// it fires the resolve event.
        /// </summary>
        /// <param name="id">The ID of the control to find</param>
        /// <returns>The control</returns>
        protected Control FindControlHelper(string id)
        {
            Control c;
            if (_findControlHelperCache.ContainsKey(id))
            {
                c = _findControlHelperCache[id];
            }
            else
            {
                c = base.FindControl(id); // Use "base." to avoid calling self in an infinite loop
                Control nc = NamingContainer;
                while ((null == c) && (null != nc))
                {
                    c = nc.FindControl(id);
                    nc = nc.NamingContainer;
                }
                if (null == c)
                {
                    // props MAY be null, but we're firing the event anyway to let the user
                    // do the best they can
                    var args = new ResolveControlEventArgs(id);

                    OnResolveControlID(args);
                    c = args.Control;
                }
                if (null != c)
                {
                    _findControlHelperCache[id] = c;
                }
            }
            return c;
        }

        /// <summary>
        /// Fired when the extender can not locate it's target control. This may happen if the target control is in a different naming container.
        /// By handling this event, user code can locate the target and return it via the ResolveControlEventArgs.Control property.
        /// </summary>
        /// <param name="e"></param>
        [SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase",
            Justification = "Following ASP.NET AJAX pattern")]
        protected virtual void OnResolveControlID(ResolveControlEventArgs e)
        {
            if (ResolveControlID != null)
            {
                ResolveControlID(this, e);
            }
        }

        /// <summary>
        /// Gets the XHTML conformance mode
        /// </summary>
        /// <returns></returns>
        protected static XhtmlConformanceMode GetXhtmlConformanceMode()
        {
            var objConformanceSection =
                (XhtmlConformanceSection) ConfigurationManager.GetSection("system.web/xhtmlConformance");
            if (objConformanceSection != null)
                return objConformanceSection.Mode;
            throw new Exception("Unable to determine XhtmlCOnformanceMode");
        }

        #endregion
    }
}