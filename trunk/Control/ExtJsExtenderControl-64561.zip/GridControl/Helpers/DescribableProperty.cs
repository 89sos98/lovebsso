﻿using System;
using System.Reflection;
using System.Web.UI;

namespace ExtExtenders.Helpers
{
    /// <summary>
    /// Class to make code more clean
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
    public class DescribableProperty : Attribute
    {
    }

    /// <summary>
    /// Internal 
    /// </summary>
    public static class Util
    {
        /// <summary>
        /// Describes a propery to the javascript 
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="descriptor"></param>
        public static void DescribeProperties(object obj, ScriptControlDescriptor descriptor)
        {
            Type t = obj.GetType();
            PropertyInfo[] info = t.GetProperties();

            foreach (PropertyInfo f in info)
            {
                var props = (DescribableProperty[]) f.GetCustomAttributes(typeof (DescribableProperty), true);
                if (props != null && props.Length > 0)
                {
                    descriptor.AddProperty(f.Name, f.GetValue(obj, null));
                }
            }
        }
    }
}