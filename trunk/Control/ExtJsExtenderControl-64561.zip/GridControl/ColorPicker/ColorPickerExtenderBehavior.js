// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

// This behavior can be attached to a textbox to enable auto-complete/auto-suggest
// scenarios.
Type.registerNamespace('ExtExtenders');
ExtExtenders.ColorPickerExtenderBehavior = function(element) {
   
    ExtExtenders.ColorPickerExtenderBehavior.initializeBase(this, [element]);
      
}
ExtExtenders.ColorPickerExtenderBehavior.prototype = {
    initialize: function() {
    
        ExtExtenders.ColorPickerExtenderBehavior.callBaseMethod(this, 'initialize');
        var id=this.get_element().id;
        var objConfig={};
        objConfig.showHexValue= this._showHexValue;
        objConfig.applyTo=id;
        var dtField= new Ext.form.ColorField(objConfig);
        dtField.render();
       
    },
    
    get_showHexValue: function() {
       
        return this._showHexValue;
    },
    set_showHexValue: function(value) {
        this._showHexValue = value;
    }
    
  
    
}
ExtExtenders.ColorPickerExtenderBehavior.registerClass('ExtExtenders.ColorPickerExtenderBehavior', Sys.UI.Control);
if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 