// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ExtExtenders.Helpers;

[assembly: WebResource("ExtExtenders.ColorPicker.ColorPickerExtenderBehavior.js", "text/javascript")]
[assembly: WebResource("ExtExtenders.images.color-trigger.gif", "img/gif")]

namespace ExtExtenders
{
    /// <summary>
    /// Class to extend a TextBox into a ColorPicker popup
    /// </summary>
    [ToolboxBitmap("ExtExtenders.images.color-trigger.gif")]
    public class ColorPicker : TextBox, IScriptControl
    {
        private ClientScriptProxy ClientScriptProxy;
        private ScriptManager sm;

        /// <summary>
        /// If the textbox is going to show the color or
        /// the hexadecimal code 
        /// </summary>
        public bool showHexValue { get; set; }

        #region IScriptControl Members

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            var descriptor = new ScriptControlDescriptor(
                "ExtExtenders.ColorPickerExtenderBehavior", ClientID);

            descriptor.AddProperty("showHexValue",
                                   showHexValue);

            return new ScriptDescriptor[] {descriptor};
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ScriptReference> GetScriptReferences()
        {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.ColorPicker.ColorPickerExtenderBehavior.js");

            return new[] {reference};
        }

        #endregion

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Init"/> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"/> object that contains the event data.</param>
        protected override void OnInit(EventArgs e)
        {
            ClientScriptProxy = ClientScriptProxy.Current;
            base.OnInit(e);
        }

        /// <summary>
        /// Raises the pre render event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.EventArgs"/> instance containing the event data.</param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            string resource = Page.ClientScript.GetWebResourceUrl(GetType(), "ExtExtenders.yui-ext.css");
            string csslink = "<link href='" + resource + "' rel='stylesheet' type='text/css' />";
            Page.Header.Controls.Add(new LiteralControl(csslink));
            ClientScriptManager man = Page.ClientScript;
            //render the yui-ext scripts
            ClientScriptProxy.RegisterClientScriptResource(this, typeof (YUI), "ExtExtenders.yui.js");
            ClientScriptProxy.RegisterClientScriptResource(this, typeof (YUI_ext), "ExtExtenders.yui-ext.js");
            man.RegisterClientScriptResource(typeof (ext_yui_adapter), "ExtExtenders.ext-yui-adapter.js");
            man.RegisterClientScriptResource(GetType(), "ExtExtenders.ColorPicker.ColorPicker.js");
            if (!DesignMode)
            {
                // Test for ScriptManager and register if it exists
                sm = ScriptManager.GetCurrent(Page);

                if (sm == null)
                    throw new HttpException("A ScriptManager control must exist on the current page.");

                sm.RegisterScriptControl(this);
            }
        }

        /// <summary>
        /// Renders the control to the specified HTML writer.
        /// </summary>
        /// <param name="writer">The <see cref="T:System.Web.UI.HtmlTextWriter"></see> object that receives the control content.</param>
        protected override void Render(HtmlTextWriter writer)
        {
            if (!DesignMode)
                sm.RegisterScriptDescriptors(this);
            base.Render(writer);
        }
    }
}