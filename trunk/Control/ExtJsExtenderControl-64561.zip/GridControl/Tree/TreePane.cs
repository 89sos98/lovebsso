// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using ExtExtenders.Helpers;

[assembly: WebResource("ExtExtenders.TreePaneBehavior.js", "text/javascript")]

namespace ExtExtenders
{
    /// <summary>
    /// Control that represents a ExtJs TreePane
    /// </summary>
    [ParseChildren(true)]
    [PersistChildren(false)]
    [ToolboxData("<{0}:TreePane runat=\"server\"></{0}:TreePane>")]
    [ToolboxBitmap(typeof (TreeView))]
    [Designer(typeof (TreePaneDesigner))]
    public class TreePane : ExtScriptWebControlBase, INamingContainer, IPostBackEventHandler, ICallbackEventHandler
    {
        /// <summary>
        /// For internal use 
        /// </summary>
        private readonly List<string> _Events = new List<string>();

        private readonly JavaScriptSerializer conv;

        /// <summary>
        /// The columns of the grid
        /// </summary>
        private List<TreeNode> _Columns;

        #region EventKeys

        /// <summary>
        /// Key for the contextMenu clicked event
        /// </summary>
        private static readonly Object ContextMenuKey = new Object();

        /// <summary>
        /// Key for the nodechecked event
        /// </summary>
        private static readonly Object NodeCheckedKey = new Object();

        /// <summary>
        /// Key for the node clicked event
        /// </summary>
        private static readonly Object NodeClickedKey = new Object();

        /// <summary>
        /// Key for the node edited event
        /// </summary>
        private static readonly Object NodeEditedKey = new Object();

        /// <summary>
        /// key for the node inserted event
        /// </summary>
        private static readonly Object NodeInsertedKey = new Object();

        /// <summary>
        /// Move event key.
        /// </summary>
        private static readonly Object NodeMovedKey = new Object();

        /// <summary>
        /// key for the node removed event
        /// </summary>
        private static readonly Object NodeRemovedKey = new Object();

        private static readonly Object NodeDropedKey = new Object();
        #endregion

        #region Events
        /// <summary>
        /// Occurs when [node droped].
        /// </summary>
        public event NodeDropedHandler NodeDroped
        {
            add {
                _Events.Add("NodeDroped");
                Events.AddHandler(NodeDropedKey,value);
            }
            remove {
               Events.RemoveHandler(NodeDropedKey,value);
            }
        }

       

        /// <summary>
        /// Event handler for the node inserted
        /// </summary>
        public event NodeInsertedHandler NodeInserted
        {
            add
            {
                _Events.Add("NodeInserted");
                Events.AddHandler(NodeInsertedKey, value);
            }
            remove { Events.RemoveHandler(NodeInsertedKey, value); }
        }

        /// <summary>
        /// Event to be fired when a node is removed
        /// </summary>
        public event NodeRemovedHandler NodeRemoved
        {
            add
            {
                _Events.Add("NodeRemoved");
                Events.AddHandler(NodeRemovedKey, value);
            }
            remove { Events.RemoveHandler(NodeRemovedKey, value); }
        }

        /// <summary>
        /// Event fired when a context-menu is clicked
        /// </summary>
        public event ContextMenuClickedHandler ContextMenuClicked
        {
            add
            {
                _Events.Add("ContextMenuClicked");
                Events.AddHandler(ContextMenuKey, value);
            }
            remove { Events.RemoveHandler(ContextMenuKey, value); }
        }

        /// <summary>
        /// Event fired when a row is moved
        /// </summary>
        public event TreeEventHandler NodeMoved
        {
            add
            {
                _Events.Add("NodeMoved");
                Events.AddHandler(NodeMovedKey, value);
            }
            remove { Events.RemoveHandler(NodeMovedKey, value); }
        }

        /// <summary>
        /// Event fired when a node is edited
        /// </summary>
        public event NodeEditedEventHandler NodeEdited
        {
            add
            {
                _Events.Add("NodeEdited");
                Events.AddHandler(NodeEditedKey, value);
            }
            remove { Events.RemoveHandler(NodeEditedKey, value); }
        }

        /// <summary>
        /// Event fired when a node is clicked
        /// </summary>
        public event NodeClickedEventHandler NodeClicked
        {
            add
            {
                _Events.Add("NodeClicked");
                Events.AddHandler(NodeClickedKey, value);
            }
            remove { Events.RemoveHandler(NodeClickedKey, value); }
        }

        /// <summary>
        /// Event fired when a node is checked
        /// </summary>
        public event NodeCheckedEventHandler NodeChecked
        {
            add
            {
                _Events.Add("NodeChecked");
                Events.AddHandler(NodeCheckedKey, value);
            }
            remove { Events.RemoveHandler(NodeCheckedKey, value); }
        }

        #endregion

        /// <summary>
        /// Let ASP.NET know to render a div
        /// </summary>
        public TreePane()
            : base(HtmlTextWriterTag.Div)
        {
            conv = new JavaScriptSerializer();
            rootVisible = true;
        }

        #region Properties

        /// <summary>
        /// true to enable animated expand/collapse
        /// </summary>
        [DescribableProperty]
        public bool animate { get; set; }

        /// <summary>
        /// If the tree is rendered as a tree with checkboxes
        /// </summary>
        [DescribableProperty]
        public bool CheckBoxTree { get; set; }

        /// <summary>
        /// If the tree is a checkboxTree and this property is true
        /// when a node is checked all of his childs will be checked (if loaded)
        /// </summary>
        [DescribableProperty]
        public bool checkAllChilds { get; set; }

        /// <summary>
        /// Gets or sets the context menu.
        /// </summary>
        /// <value>The context menu.</value>
        [Browsable(false), Description("The tree context menu")]
        public Menu ContextMenu { get; set; }

        /// <summary>
        /// Gets or sets the context menu.
        /// </summary>
        /// <value>The context menu.</value>
        [Browsable(false), Description("The tree context menu")]
        public Menu ChildContextMenu { get; set; }

        /// <summary>
        /// true to register this container with ScrollManager
        /// </summary>
        [DescribableProperty]
        public bool containerScroll { get; set; }

        /// <summary>
        /// true to register this automatic scroll
        /// </summary>
        [DescribableProperty]
        public bool autoScroll { get; set; }

        /// <summary>
        /// True if the tree should only allow append drops (use for trees which are sorted)
        /// </summary>
        [DescribableProperty]
        public bool ddAppendOnly { get; set; }

        /// <summary>
        /// The DD group this TreePanel belongs to
        /// </summary>
        [DescribableProperty]
        public string ddGroup { get; set; }

        /// <summary>
        /// true to enable drag and drop
        /// </summary>
        [DescribableProperty]
        public bool enableDD { get; set; }

        /// <summary>
        /// true to enable just drag
        /// </summary>
        [DescribableProperty]
        public bool enableDrag { get; set; }

        /// <summary>
        /// true to enable just drop
        /// </summary>
        [DescribableProperty]
        public bool enableDrop { get; set; }

        /// <summary>
        /// false to disable tree lines (defaults to true)
        /// </summary>
        [DescribableProperty]
        public bool lines { get; set; }

        /// <summary>
        /// false to hide the root node (defaults to true)
        /// </summary>
        [DescribableProperty]
        public bool rootVisible { get; set; }

        /// <summary>
        /// Name of the page that will load ajax nodes
        /// </summary>
        [DescribableProperty]
        public string Loader { get; set; }

        /// <summary>
        /// Name of the webserice method to call
        /// </summary>
        [DescribableProperty]
        public string WebServiceMethod { get; set; }

        /// <summary>
        /// Path of the webservice
        /// </summary>
        [DescribableProperty]
        public string WebServicePath { get; set; }

        /// <summary>
        /// If the tree has an editor attached to it
        /// </summary>
        [DescribableProperty]
        public bool Editable { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [auto post back].
        /// </summary>
        /// <value><c>true</c> if [auto post back]; otherwise, <c>false</c>.</value>
        [DescribableProperty]
        public bool AutoPostBack { get; set; }


        /// <summary>
        /// Gets or sets the tree nodes.
        /// </summary>
        /// <value>The tree nodes.</value>
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public List<TreeNode> TreeNodes
        {
            get
            {
                if (_Columns == null)
                {
                    _Columns = new List<TreeNode>();
                }
                return _Columns;
            }
        }

        #endregion

        #region ICallbackEventHandler Members

        /// <summary>
        /// Returns the results of a callback event that targets a control.
        /// </summary>
        /// <returns>The result of the callback.</returns>
        public string GetCallbackResult()
        {
            return null;
        }

        /// <summary>
        /// Processes a callback event that targets a control.
        /// </summary>
        /// <param name="eventArgument">A string that represents an event argument to pass to the event handler.</param>
        public void RaiseCallbackEvent(string eventArgument)
        {
            var jsSerialiser = new JavaScriptSerializer();
            var eventArgs = jsSerialiser.Deserialize<TreeEventArgs>(eventArgument);
            switch (eventArgs.EventName.ToLower())
            {
                case "nodemoved":
                    OnNodeMoved(jsSerialiser.Deserialize<NodeMoveEventArgs>(eventArgs.Arguments));
                    break;
                case "nodeedited":
                    OnNodeEdited(jsSerialiser.Deserialize<NodeEditedEventArgs>(eventArgs.Arguments));
                    break;
                case "nodeclicked":
                    OnNodeClicked(jsSerialiser.Deserialize<NodeClickedEventArgs>(eventArgs.Arguments));
                    break;
                case "nodechecked":
                    OnNodeChecked(jsSerialiser.Deserialize<NodeCheckedEventArgs>(eventArgs.Arguments));
                    break;
                case "contextmenuclicked":
                    OnContextMenuClicked(jsSerialiser.Deserialize<TreeContextMenuEventArgs>(eventArgs.Arguments));
                    break;
                case "nodeinserted":
                    OnNodeInserted(jsSerialiser.Deserialize<NodeInsertedEventArgs>(eventArgs.Arguments));
                    break;
                case "noderemoved":
                    OnNodeRemoved(jsSerialiser.Deserialize<NodeClickedEventArgs>(eventArgs.Arguments));
                    break;
                case "nodedroped":
                    OnNodeDroped(jsSerialiser.Deserialize<NodeDropedEventArgs>(eventArgs.Arguments));
                    break;
                default:
                    //Do nothing
                    break;
            }
        }

        #endregion

        #region IPostBackEventHandler Members

        /// <summary>
        /// When implemented by a class, enables a server control to process an event raised when a form is posted to the server.
        /// </summary>
        /// <param name="eventArgument">A <see cref="T:System.String"></see> that represents an optional event argument to be passed to the event handler.</param>
        public void RaisePostBackEvent(string eventArgument)
        {
            RaiseCallbackEvent(eventArgument);
        }

        #endregion

        #region Events
        /// <summary>
        /// Raises the <see cref="E:NodeDroped"/> event.
        /// </summary>
        /// <param name="e">The <see cref="ExtExtenders.NodeDropedEventArgs"/> instance containing the event data.</param>
        protected virtual void OnNodeDroped(NodeDropedEventArgs e)
        {
            var eventHandler = (NodeDropedHandler)Events[NodeDropedKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }
        /// <summary>
        /// Raises the node inserted event.
        /// </summary>
        /// <param name="e">The <see cref="T:ExtExtenders.NodeInsertedEventArgs"/> instance containing the event data.</param>
        protected virtual void OnNodeInserted(NodeInsertedEventArgs e)
        {
            var eventHandler = (NodeInsertedHandler) Events[NodeInsertedKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }

        /// <summary>
        /// Raises the node removed event.
        /// </summary>
        /// <param name="e">The <see cref="T:ExtExtenders.NodeInsertedEventArgs"/> instance containing the event data.</param>
        protected virtual void OnNodeRemoved(NodeClickedEventArgs e)
        {
            var eventHandler = (NodeRemovedHandler) Events[NodeRemovedKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }

        /// <summary>
        /// Raises the context menu clicked event.
        /// </summary>
        /// <param name="e">The <see cref="T:ExtExtenders.TreeContextMenuEventArgs"/> instance containing the event data.</param>
        protected virtual void OnContextMenuClicked(TreeContextMenuEventArgs e)
        {
            var eventHandler = (ContextMenuClickedHandler) Events[ContextMenuKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }

        /// <summary>
        /// Raises the node moved event.
        /// </summary>
        /// <param name="e">The <see cref="T:ExtExtenders.NodeMoveEventArgs"/> instance containing the event data.</param>
        protected virtual void OnNodeMoved(NodeMoveEventArgs e)
        {
            var eventHandler = (TreeEventHandler) Events[NodeMovedKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }

        /// <summary>
        /// Raises the node edited event.
        /// </summary>
        /// <param name="e">The <see cref="T:ExtExtenders.NodeEditedEventArgs"/> instance containing the event data.</param>
        protected virtual void OnNodeEdited(NodeEditedEventArgs e)
        {
            var eventHandler = (NodeEditedEventHandler) Events[NodeEditedKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }

        /// <summary>
        /// Raises the node clicked event.
        /// </summary>
        /// <param name="e">The <see cref="T:ExtExtenders.NodeClickedEventArgs"/> instance containing the event data.</param>
        protected virtual void OnNodeClicked(NodeClickedEventArgs e)
        {
            var eventHandler = (NodeClickedEventHandler) Events[NodeClickedKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }

        /// <summary>
        /// Raises the node checked event.
        /// </summary>
        /// <param name="e">The <see cref="T:ExtExtenders.NodeClickedEventArgs"/> instance containing the event data.</param>
        protected virtual void OnNodeChecked(NodeCheckedEventArgs e)
        {
            var eventHandler = (NodeCheckedEventHandler) Events[NodeCheckedKey];
            if (eventHandler != null)
            {
                eventHandler(this, e);
            }
        }

        #endregion

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Load"></see> event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            Page.ClientScript.GetCallbackEventReference(this, "", "", "");
        }

        /// <summary>
        /// Gets the node specified
        /// </summary>
        /// <param name="id">The id.</param>
        /// <returns></returns>
        public TreeNode GetNodeById(string id)
        {
            foreach (TreeNode n in _Columns)
            {
                if (n.id == id)
                {
                    return n;
                }
            }
            return null;
        }

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.PreRender"></see> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            HttpRequest Request = HttpContext.Current.Request;
            HttpResponse Response = HttpContext.Current.Response;


            ClientScriptManager man = Page.ClientScript;
            //render the yui-ext scripts


            man.RegisterClientScriptResource(GetType(), "ExtExtenders.TreeExtension.js");

            if (!string.IsNullOrEmpty(Request["node"]))
            {
                Response.Clear();
                var nodes = new List<TreeNode>();
                for (int i = 0; i < _Columns.Count; i++)
                {
                    if (_Columns[i].parentNodeId == Request["node"])
                    {
                        nodes.Add(_Columns[i]);
                    }
                }
                var ser = new JavaScriptSerializer();
                var serNodes = ser.Serialize(nodes);
                if (CheckBoxTree)
                {
                    serNodes = serNodes.Replace("IsChecked", "checked");
                }
                Response.Write(serNodes);
                //
                Response.End();
            }
        }

        /// <summary>
        /// Gets the script descriptors.
        /// </summary>
        /// <returns>The script descriptors for the control</returns>
        public override IEnumerable<ScriptDescriptor> GetScriptDescriptors()
        {
            var descriptor = new ScriptControlDescriptor(
                "ExtExtenders.TreePaneBehavior", ClientID);

            Util.DescribeProperties(this,descriptor);

            descriptor.AddProperty("ContextMenu",
                                   conv.Serialize(ContextMenu));

            descriptor.AddProperty("ChildContextMenu",
                           conv.Serialize(ChildContextMenu));

            descriptor.AddProperty("TreeNodes",
                                   conv.Serialize(TreeNodes));
            descriptor.AddProperty("TreeEvents", conv.Serialize(_Events));

            //descriptor.AddProperty("PostBackId",
            //    this.PostBackId);
            return new ScriptDescriptor[] {descriptor};
        }

        /// <summary>
        /// Gets the script references.
        /// </summary>
        /// <returns>The script references for the control</returns>
        public override IEnumerable<ScriptReference> GetScriptReferences()
        {
            var reference = new ScriptReference();
            if (Page != null)
                reference.Path = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                     "ExtExtenders.TreePaneBehavior.js");

            return new[] {reference};
        }
    }
}