// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Diagnostics.CodeAnalysis;
using System.Web.UI.Design;

namespace ExtExtenders
{
    /// <summary>
    /// Simple read-only designer for the Accordion control
    /// </summary>
    [SuppressMessage("Microsoft.Security", "CA2117:AptcaTypesShouldOnlyExtendAptcaBaseTypes",
        Justification = "Security handled by base class")]
    public class TreePaneDesigner : ControlDesigner
    {
        /// <summary>
        /// The verb collection for the smart tags
        /// </summary>
        private readonly DesignerVerbCollection dvc = new DesignerVerbCollection();

        /// <summary>
        /// Reference to the tree control we're designing
        /// </summary>
        private TreePane _tree;

        /// <summary>
        /// Initializes a new instance of the <see cref="T:TreePaneDesigner"/> class.
        /// </summary>
        public TreePaneDesigner()
        {
            dvc.Add(new DesignerVerb("Is CheckBoxTree?", SetCheckBoxTree));
        }

        /// <summary>
        /// Gets the action list collection for the control designer.
        /// </summary>
        /// <value></value>
        /// <returns>A <see cref="T:System.ComponentModel.Design.DesignerActionListCollection"></see> that contains the <see cref="T:System.ComponentModel.Design.DesignerActionList"></see> items for the control designer.</returns>
        public override DesignerActionListCollection ActionLists
        {
            get
            {
                DesignerActionListCollection actionLists = base.ActionLists ?? new DesignerActionListCollection();
                actionLists.Add(new TreePaneDesignerActionList(this));
                return actionLists;
            }
        }

        /// <summary>
        /// Gets the verbs.
        /// </summary>
        /// <value>The verbs.</value>
        public override DesignerVerbCollection Verbs
        {
            get { return dvc; }
        }

        /// <summary>
        /// Initialize to make sure we're attached to an accordion control
        /// </summary>
        /// <param name="component">Component</param>
        [SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters",
            Justification = "Assembly is not localized")]
        [SuppressMessage("Microsoft.Security", "CA2116:AptcaMethodsShouldOnlyCallAptcaMethods",
            Justification = "Security handled by base class")]
        public override void Initialize(IComponent component)
        {
            _tree = component as TreePane;
            if (_tree == null)
                throw new ArgumentException("Component must be an TreePane control", "component");
            base.Initialize(component);
        }

        /// <summary>
        /// Gets a property by its name
        /// </summary>
        /// <param name="propName">Name of the prop.</param>
        /// <returns></returns>
        private PropertyDescriptor GetPropertyByName(String propName)
        {
            PropertyDescriptor prop = TypeDescriptor.GetProperties(_tree)[propName];
            if (null == prop)
                throw new ArgumentException(
                    "Matching Target property not found!",
                    propName);
            return prop;
        }

        /// <summary>
        /// Sets the check box tree.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="T:System.EventArgs"/> instance containing the event data.</param>
        public void SetCheckBoxTree(Object sender, EventArgs e)
        {
            var _checked = (bool) GetPropertyByName("CheckBoxTree").GetValue(_tree);
            GetPropertyByName("CheckBoxTree").SetValue(_tree, !_checked);
        }
    }
}