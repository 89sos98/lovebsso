using System;

namespace ExtExtenders
{
    /// <summary>
    /// Class that represents an ExtJs TreeNode
    /// </summary>
    [Serializable]
    public class TreeNode
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TreeNode"/> class.
        /// </summary>
        public TreeNode()
        {
            href = "#";
        }

        /// <summary>
        /// Text of the node
        /// </summary>
        public string text { get; set; }

        /// <summary>
        /// If the node is draggabe
        /// </summary>
        public bool draggable { get; set; }

        /// <summary>
        /// Node id
        /// </summary>
        public string id { get; set; }

        /// <summary>
        /// If it has children then leaf=false
        /// </summary>
        public bool leaf { get; set; }

        /// <summary>
        /// Css class to render a different icon to a node
        /// </summary>
        public string cls { get; set; }

        /// <summary>
        /// If this is the root node
        /// </summary>
        public bool IsRoot { get; set; }

        /// <summary>
        /// Id of the parent node
        /// </summary>
        public string parentNodeId { get; set; }

        /// <summary>
        ///  URL of the link used for the node (defaults to #)
        /// </summary>
        public string href { get; set; }

        /// <summary>
        /// target frame for the link
        /// </summary>
        public string hrefTarget { get; set; }

        /// <summary>
        /// The path to an icon for the node. The preferred way to do this is to use
        /// the cls or iconCls attributes and add the icon via a CSS background image.
        /// </summary>
        public string icon { get; set; }

        /// <summary>
        /// If a node is checked (only if tree is checkbox tree)
        /// </summary>
        public bool IsChecked { get; set; }

        /// <summary>
        /// Gets or sets the type of the node.
        /// </summary>
        /// <value>The type of the node.</value>
        public string NodeType { get; set; }

        /// <summary>
        /// The quick tip config for the node
        /// </summary>
        public string qtipCfg { get; set; }

        /// <summary>
        /// private
        /// </summary>
        public bool childrenRendered { get; set; }
    }
}