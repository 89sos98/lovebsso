using System;

namespace ExtExtenders
{
    /// <summary>
    /// Event handler for the tree
    /// </summary>
    /// <param name="sender">The treepanel</param>
    /// <param name="e">Arguments for the event</param>
    public delegate void TreeEventHandler(Object sender, NodeMoveEventArgs e);

    /// <summary>
    /// Event handler fired when a node is edited
    /// </summary>
    /// <param name="sender">The treepanel</param>
    /// <param name="e">Arguments of the event</param>
    public delegate void NodeEditedEventHandler(Object sender, NodeEditedEventArgs e);

    /// <summary>
    /// Event handler for the node clicked
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void NodeClickedEventHandler(Object sender, NodeClickedEventArgs e);

    /// <summary>
    /// Event handler for the node checked event
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void NodeCheckedEventHandler(Object sender, NodeCheckedEventArgs e);

    /// <summary>
    /// Event handler for the context menu clicked
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void ContextMenuClickedHandler(Object sender, TreeContextMenuEventArgs e);

    /// <summary>
    /// Event handler for the node inserted
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void NodeInsertedHandler(Object sender, NodeInsertedEventArgs e);

    /// <summary>
    /// Event handler for the node removed
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void NodeRemovedHandler(Object sender, NodeClickedEventArgs e);
   
    /// <summary>
    /// Event handler for the node droped
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void NodeDropedHandler(Object sender, NodeDropedEventArgs e);
}