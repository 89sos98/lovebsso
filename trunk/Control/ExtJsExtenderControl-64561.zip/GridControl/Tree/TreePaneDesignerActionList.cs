using System;
using System.ComponentModel;
using System.ComponentModel.Design;

namespace ExtExtenders
{
    /// <summary>
    /// Class to include smart tags in the tree
    /// </summary>
    public class TreePaneDesignerActionList : DesignerActionList
    {
        private readonly TreePaneDesigner _parent;

        private readonly TreePane dtc;

        private readonly DesignerActionUIService designerActionUISvc;

        /// <summary>
        /// Initializes a new instance of the <see cref="T:TreePaneDesignerActionList"/> class.
        /// </summary>
        /// <param name="designer">The designer.</param>
        public TreePaneDesignerActionList(TreePaneDesigner designer) : base(designer.Component)
        {
            _parent = designer;
            dtc = _parent.Component as TreePane;
            designerActionUISvc =
                GetService(typeof (DesignerActionUIService))
                as DesignerActionUIService;
        }

        ///<summary>
        ///</summary>
        public DesignerActionUIService DesignerActionUISvc
        {
            get { return designerActionUISvc; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [check box tree].
        /// </summary>
        /// <value><c>true</c> if [check box tree]; otherwise, <c>false</c>.</value>
        public bool CheckBoxTree
        {
            get { return dtc.CheckBoxTree; }
            set { GetPropertyByName("CheckBoxTree").SetValue(dtc, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [check box tree].
        /// </summary>
        /// <value><c>true</c> if [check box tree]; otherwise, <c>false</c>.</value>
        public bool EnableDragAndDrop
        {
            get { return dtc.enableDD; }
            set { GetPropertyByName("enableDD").SetValue(dtc, value); }
        }

        /// <summary>
        /// Returns the collection of <see cref="T:System.ComponentModel.Design.DesignerActionItem"></see> objects contained in the list.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.ComponentModel.Design.DesignerActionItem"></see> array that contains the items in this list.
        /// </returns>
        public override DesignerActionItemCollection GetSortedActionItems()
        {
            var actionItems = new DesignerActionItemCollection
                                  {
                                      new DesignerActionPropertyItem("CheckBoxTree", "CheckBoxTree"),
                                      new DesignerActionPropertyItem("EnableDragAndDrop", "EnableDragAndDrop")
                                  };

            return actionItems;
        }

        /// <summary>
        /// Gets a property on the target control 
        /// </summary>
        /// <param name="propName">Name of the prop.</param>
        /// <returns></returns>
        private PropertyDescriptor GetPropertyByName(String propName)
        {
            var prop = TypeDescriptor.GetProperties(_parent.Component)[propName];
            if (null == prop)
                throw new ArgumentException(
                    "Matching Target property not found!",
                    propName);
            return prop;
        }
    }
}