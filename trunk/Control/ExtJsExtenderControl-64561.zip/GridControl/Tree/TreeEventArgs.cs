using System;

namespace ExtExtenders
{
    /// <summary>
    /// Event arguments for the TreeNode events
    /// </summary>
    public class TreeEventArgs : EventArgs
    {
        /// <summary>
        /// Gets or sets the name of the event.
        /// </summary>
        /// <value>The name of the event.</value>
        public string EventName { get; set; }

        /// <summary>
        /// Gets or sets the arguments.
        /// </summary>
        /// <value>The arguments.</value>
        public string Arguments { get; set; }
    }

    /// <summary>
    /// Class for node movement arguments
    /// </summary>
    public class NodeMoveEventArgs : EventArgs
    {
        /// <summary>
        /// Id of the Node moved
        /// </summary>
        public TreeNode NodeMoved { get; set; }

        /// <summary>
        /// The id of the old parent of the moved node
        /// </summary>
        public TreeNode OldParent { get; set; }

        /// <summary>
        /// The id of new parent of the node moved
        /// </summary>
        public TreeNode NewParent { get; set; }

        /// <summary>
        /// Position of the node related to the parent
        /// </summary>
        public int Index { get; set; }
    }

    /// <summary>
    /// Class for node edited arguments
    /// </summary>
    public class NodeEditedEventArgs : EventArgs
    {
        /// <summary>
        /// Id of the node renamed
        /// </summary>
        public TreeNode NodeRenamed { get; set; }

        /// <summary>
        /// New value of the edited node
        /// </summary>
        public string NewValue { get; set; }

        /// <summary>
        /// Old value of the node
        /// </summary>
        public string OldValue { get; set; }
    }

    /// <summary>
    /// Class for the node clicked event
    /// </summary>
    public class NodeClickedEventArgs : EventArgs
    {
        /// <summary>
        /// Gets or sets the id of the node clicked.
        /// </summary>
        /// <value>The id of the node clicked.</value>
        public TreeNode NodeClicked { get; set; }
    }

    /// <summary>
    /// Class for the node checked event
    /// </summary>
    public class NodeCheckedEventArgs : EventArgs
    {
        /// <summary>
        /// Gets or sets the nodes checked.
        /// </summary>
        /// <value>The nodes checked.</value>
        public TreeNode NodeChecked { get; set; }
    }

    /// <summary>
    /// Event arguments for the context menu clicked event
    /// </summary>
    public class TreeContextMenuEventArgs : EventArgs
    {
        /// <summary>
        /// The node that showed the menu
        /// </summary>
        /// <value>The node selected.</value>
        public TreeNode NodeSelected { get; set; }

        /// <summary>
        /// The menu item that was clicked
        /// </summary>
        /// <value>The menu clicked.</value>
        public MenuItem MenuClicked { get; set; }
    }

    /// <summary>
    /// Class for the node inserted event
    /// </summary>
    public class NodeInsertedEventArgs : EventArgs
    {
        /// <summary>
        /// The parent node of the new node
        /// </summary>
        public TreeNode ParentNode { get; set; }

        /// <summary>
        /// The node that was inserted
        /// </summary>
        public TreeNode NewNode { get; set; }
    }
    /// <summary>
    /// Class for the node droped event args
    /// </summary>
    public class NodeDropedEventArgs:EventArgs
    {
        /// <summary>
        /// The node that was dropped
        /// </summary>
        public TreeNode DropedNode { get; set; }
    }


}