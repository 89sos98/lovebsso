﻿///A class to help edit records in a new window instead of
/// inline editing
DialogEditor = function(config) {
    Ext.QuickTips.init();
    
    Ext.apply(this, config);
    this.addEvents({
         //fires when the save button is clicked
        "save": true,
        //fires when the form is created usefull for manipulating the screen
        "form_criated": true
    });

}
Ext.extend(DialogEditor, Ext.util.Observable, {
    show: function(row_data) {

        this.source_grid = this.Extender.get_Grid();

        if (this.win == null) {
            this.BuildWindow();
        }

        if (row_data) {
            this.SetEditMode(row_data.data);
        }
        else {

            var columns = this.Extender.get_Columns();
            for (var i = 0; i < columns.length; i++) {
                var nome = columns[i].ConfigOptions.dataIndex;
                var el = this.formulario.findById(nome);
                if (!columns[i].ConfigOptions.hidden) {
                    el.setValue('')
                }
                else {
                    if (columns[i].ConfigOptions.IsIdentity)
                        el.setValue('-1')
                }

            }
        }
        this.win.show();
    },
    BuildWindow: function() {


        var formulario = this.BuildForm();
        this.formulario = formulario;

        var grid = this.source_grid;
        var win = new Ext.Window({
            layout: 'form',
            width: this.width,
            height: this.height,
            closeAction: 'hide',
            frame: true,
            modal: true,
            plain: true,
            items: formulario,
            title: this.title,
            stateful: false,
            buttons: [{
                text: 'Save',
                scope: this,
                handler: function() {
                    if (formulario.getForm().isValid()) {
                        var columns = grid.colModel.config;
                        var record = new Object();
                        for (var i = 0; i < columns.length; i++) {
                            var nome = columns[i].dataIndex;
                            record[nome] = formulario.findById(nome).getValue()
                        }
                        this.fireEvent("save", record);
                        win.hide();
                    }
                }
            }, {
                text: 'Cancel',
                handler: function() {

                    win.hide();
                }
}]
            });
            this.win = win;
        },
        BuildForm: function() {

            var columns = this.Extender.get_Columns();

            var simple = new Ext.FormPanel({ bodyStyle: 'padding:5px 5px 0', labelWidth: 75, frame: true });

            for (var i = 0; i < columns.length; i++) {
                simple.add(this.CreateEditor(columns[i]));
            }
            return simple;
        },
        SetValueToField: function(fieldId, value) {

            var elementos = this.formulario;
            var el = elementos.findById(fieldId);
            el.setValue(value);
        },
        SetDataStore: function(fieldId, data) {

            var elementos = this.formulario;
            var el = elementos.findById(fieldId);
            el.store.loadData(data);
        },
        SetEditMode: function(row_data) {

            var elementos = this.formulario;
            var columns = this.source_grid.colModel.config;
            var i = 0;
            for (o in row_data) {
               
                var el = elementos.findById(o);
                if (el != null) {

                    var rawValue = row_data[o];
                    if (el.strategy) {
                        rawValue = row_data[o].dateFormat(el.strategy.format);
                    }
                    if (rawValue != '0') {
                        el.setValue(rawValue);
                    }


                }
            }
            this.fireEvent("form_criated", this);
        },
        getId: function(objCol) {
            if (this.useIds) {
                return objCol.id;
            }
            else {
                return objCol.dataIndex;
            }
        },
        CreateEditor: function(objCol) {
            var editor;
            var options = objCol.EditorOptions;
            objCol = objCol.ConfigOptions;
            var fm = Ext.form;


            var Elid = objCol.dataIndex;

            //using a combobox
            if (options.EditControlId != "" && options.EditControlId != null) {
                var elem = Ext.getDom(options.EditControlId);
                if (elem == null || elem.tagName != 'SELECT')
                    throw Error.create(String.format('EditControlID "{0}" is not a SELECT element.'), objCol.EditControlId);
                editor = new fm.ComboBox({
                    id: Elid,
                    typeAhead: true,
                    triggerAction: 'all',
                    transform: options.EditControlId,
                    forceSelection: true,
                    lazyRender: true,
                    fieldLabel: objCol.header
                });
                return editor;

            }
            if (objCol.hidden) {
                return new fm.Hidden({ id: Elid })
            }


            switch (options.DataType) {
                case 0:
                    editor = new fm.TextField({
                        id: Elid,
                        fieldLabel: objCol.header,
                        allowBlank: options.allowBlank,
                        maxLength: options.maxLength,
                        width: objCol.width,
                        readOnly: options.readOnly

                    })
                    break;
                case 1:
                    editor = new fm.NumberField({
                        id: Elid,
                        allowBlank: options.allowBlank,
                        maxLength: options.maxLength,
                        allowNegative: false,
                        fieldLabel: objCol.header
                    })
                    break;


                case 2:
                    editor = new fm.DateField({
                        id: Elid,
                        fieldLabel: objCol.header,
                        allowBlank: options.allowBlank,
                        format: options.DateFormat,
                        width: objCol.width

                    })
                    break;
                case 3:
                    editor = new fm.TextArea({
                        id: Elid,
                        fieldLabel: objCol.header,
                        allowBlank: options.allowBlank,
                        maxLength: options.maxLength
                    });
                    break;

            }
            return editor;
        }

    }

);