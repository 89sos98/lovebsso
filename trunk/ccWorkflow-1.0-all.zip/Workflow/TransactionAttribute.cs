using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Workflow
{
    public enum TransactionOption
    {
        None,
        Required,
    }

    [AttributeUsage(AttributeTargets.Method)]
    public class TransactionAttribute : Attribute
    {
        private TransactionOption value;

        public TransactionAttribute(TransactionOption value)
        {
            this.value = value;
        }

        public TransactionOption Value
        {
            get { return value; }
        }
    }
}
