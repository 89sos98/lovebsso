#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;

using log4net;

using CchenSoft.Workflow.Spi;
using CchenSoft.Workflow.Config;
using CchenSoft.Workflow.Query;
using CchenSoft.Workflow.Loader;
using CchenSoft.Workflow.Util;
using CchenSoft.Common.Utils;

namespace CchenSoft.Workflow
{
    public class AbstractWorkflow : IWorkflow
    {
        //~ Static fields/initializers /////////////////////////////////////////////

        private static ILog log = LogManager.GetLogger(typeof(AbstractWorkflow));

        //~ Instance fields ////////////////////////////////////////////////////////

        protected IWorkflowContext context;
        private IWorkflowStore store;
        private WorkflowDescriptor descriptor;
        private long entryId;

        //private ThreadLocal stateCache = new ThreadLocal();
        [ThreadStatic]
        private static Hashtable stateCache;

        private TypeResolver typeResolver;
        private IVariableResolver variableResolver;

        //~ Constructors ///////////////////////////////////////////////////////////

        public AbstractWorkflow(IWorkflowContext context, WorkflowDescriptor descriptor, IConfiguration config)
        {
            this.context = context;
            this.descriptor = descriptor;

            stateCache = new Hashtable();

            store = config.WorkflowStore;
            variableResolver = config.VariableResolver;
            typeResolver = config.TypeResolver;
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public int[] GetAvailableActions()
        {
            return GetAvailableActions(new Hashtable());
        }

        /**
         * Get the available actions for the specified workflow instance.
         * @ejb.interface-method
         * @param id The workflow instance id.
         * @param inputs The inputs map to pass on to conditions
         * @return An array of action id's that can be performed on the specified entry.
         * descriptor is no longer available or has become invalid.
         */
        public int[] GetAvailableActions(IDictionary inputs)
        {
            try
            {
                IWorkflowEntry entry = store.FindEntry(entryId);

                if (entry == null)
                {
                    throw new ArgumentException("No such workflow id " + entryId);
                }

                if (entry.State != WorkflowEntryState.ACTIVATED)
                {
                    return new int[0];
                }

                List<int> l = new List<int>();
                Hashtable transientVars = (inputs == null) ? new Hashtable() : new Hashtable(inputs);
                ICollection<IStep> currentSteps = store.FindCurrentSteps(entryId);

                PopulateTransientMap(entry, transientVars, descriptor.Registers, 0, currentSteps);

                // get global actions
                foreach (ActionDescriptor action in descriptor.GlobalActions)
                {
                    RestrictionDescriptor restriction = action.Restriction;
                    ConditionsDescriptor conditions = null;

                    transientVars["actionId"] = action.Id;

                    if (restriction != null)
                    {
                        conditions = restriction.ConditionsDescriptor;
                    }

                    //todo verify that 0 is the right currentStepId
                    if (PassesConditions(descriptor.GlobalConditions, transientVars, 0) 
                        && PassesConditions(conditions, transientVars, 0))
                    {
                        l.Add(action.Id);
                    }
                }

                // get normal actions
                foreach (IStep step in currentSteps)
                {
                    l.AddRange(GetAvailableActionsForStep(step, transientVars));
                }

                return l.ToArray();
            }
            catch (Exception e)
            {
                log.Error("Error checking available actions", e);

                return new int[0];
            }
        }

        public IList<IStep> GetCurrentSteps()
        {
            try
            {
                return store.FindCurrentSteps(entryId);
            }
            catch (StoreException e)
            {
                log.Error("Error checking current steps for instance #" + entryId, e);

                return new List<IStep>(0);
            }
        }

        public int GetEntryState()
        {
            try
            {
                return store.FindEntry(entryId).State;
            }
            catch (StoreException e)
            {
                log.Error("Error checking instance state for instance #" + entryId, e);
            }

            return WorkflowEntryState.UNKNOWN;
        }

        public IList<IStep> GetHistorySteps()
        {
            try
            {
                return store.FindHistorySteps(entryId);
            }
            catch (StoreException e)
            {
                log.Error("Error getting history steps for instance #" + entryId, e);
            }

            return new List<IStep>(0);
        }

        public IList GetSecurityPermissions()
        {
            return GetSecurityPermissions(null);
        }

        public IList GetSecurityPermissions(IDictionary inputs)
        {
            try
            {
                IWorkflowEntry entry = store.FindEntry(entryId);

                Hashtable transientVars = (inputs == null) ? new Hashtable() : new Hashtable(inputs);
                ICollection<IStep> currentSteps = store.FindCurrentSteps(entryId);
                PopulateTransientMap(entry, transientVars, descriptor.Registers, 0, currentSteps);

                ArrayList s = new ArrayList();

                foreach (IStep step in currentSteps)
                {
                    int stepId = step.StepId;

                    StepDescriptor xmlStep = descriptor.GetStep(stepId);

                    foreach (PermissionDescriptor security in xmlStep.Permissions)
                    {
                        // to have the permission, the condition must be met or not specified
                        // securities can't have restrictions based on inputs, so it's null
                        if (security.Restriction != null)
                        {
                            if (PassesConditions(security.Restriction.ConditionsDescriptor, transientVars, xmlStep.Id))
                            {
                                s.Add(security.Name);
                            }
                        }
                    }
                }

                return s;
            }
            catch (Exception e)
            {
                log.Error("Error getting security permissions for instance #" + entryId, e);
            }

            return new ArrayList(0);
        }

        /**
         * Returns a workflow definition object associated with the given name.
         *
         * @param workflowName the name of the workflow
         * @return the object graph that represents a workflow definition
         */
        public WorkflowDescriptor Descriptor
        {
            get { return descriptor; }
        }

        public long WorkflowId
        {
            get { return entryId; }
            set { entryId = value; }
        }

        public string WorkflowName
        {
            get { return descriptor.Name; }
        }


        public bool CanInitialize(int initialAction)
        {
            return CanInitialize(initialAction, null);
        }

        private class MockWorkflowEntry : IWorkflowEntry
        {
            private int id;
            private string workflowName;
            private bool initialized;
            private int state;

            public MockWorkflowEntry(int id, string workflowName, bool initialized, int state)
            {
                this.id = id;
                this.workflowName = workflowName;
                this.initialized = initialized;
                this.state = state;
            }

            #region WorkflowEntry ��Ա

            public long Id
            {
                get { return id; }
            }

            public bool Initialized
            {
                get { return initialized; }
            }

            public int State
            {
                get { return state; }
            }

            public string WorkflowName
            {
                get { return workflowName; }
            }

            #endregion
        }

        /**
         * @param workflowName the name of the workflow to check
         * @param initialAction The initial action to check
         * @param inputs the inputs map
         * @return true if the workflow can be initialized
         */
        public bool CanInitialize(int initialAction, IDictionary inputs)
        {
            string mockWorkflowName = descriptor.Name;
            IWorkflowEntry mockEntry = new MockWorkflowEntry(0, mockWorkflowName, false, WorkflowEntryState.CREATED);

            Hashtable transientVars = new Hashtable();

            if (inputs != null)
            {
                transientVars = new Hashtable(inputs);
            }

            try
            {
                PopulateTransientMap(mockEntry, transientVars, new List<RegisterDescriptor>(), initialAction, new List<IStep>());

                ActionDescriptor actionDescriptor = descriptor.GetInitialAction(initialAction);

                if (actionDescriptor == null)
                {
                    throw new InvalidActionException("Invalid Initial Action #" + initialAction);
                }

                RestrictionDescriptor restriction = actionDescriptor.Restriction;
                ConditionsDescriptor conditions = null;

                if (restriction != null)
                {
                    conditions = restriction.ConditionsDescriptor;
                }

                return PassesConditions(conditions, transientVars, 0);
            }
            catch (InvalidActionException e)
            {
                log.Error(e.Message);

                return false;
            }
            catch (WorkflowException e)
            {
                log.Error("Error checking canInitialize", e);

                return false;
            }
        }

        public bool CanModifyEntryState(int newState)
        {
            try
            {
                IWorkflowEntry entry = store.FindEntry(entryId);
                int currentState = entry.State;
                bool result = false;

                switch (newState)
                {
                    case WorkflowEntryState.COMPLETED:

                        if (currentState == WorkflowEntryState.ACTIVATED)
                        {
                            result = true;
                        }

                        break;

                    case WorkflowEntryState.CREATED:
                        result = false;
                        break;

                    case WorkflowEntryState.ACTIVATED:

                        if ((currentState == WorkflowEntryState.CREATED) 
                            || (currentState == WorkflowEntryState.SUSPENDED))
                        {
                            result = true;
                        }

                        break;

                    case WorkflowEntryState.SUSPENDED:

                        if (currentState == WorkflowEntryState.ACTIVATED)
                        {
                            result = true;
                        }

                        break;

                    case WorkflowEntryState.KILLED:

                        if ((currentState == WorkflowEntryState.CREATED) 
                            || (currentState == WorkflowEntryState.ACTIVATED) 
                            || (currentState == WorkflowEntryState.SUSPENDED))
                        {
                            result = true;
                        }

                        break;

                    default:
                        result = false;

                        break;
                }

                return result;
            }
            catch (StoreException e)
            {
                log.Error("Error checking state modifiable for instance #" + entryId, e);
            }

            return false;
        }

        public void ChangeEntryState(int newState)
        {
            IWorkflowEntry entry = store.FindEntry(entryId);

            if (entry.State == newState)
            {
                return;
            }

            if (CanModifyEntryState(newState))
            {
                if ((newState == WorkflowEntryState.KILLED) 
                    || (newState == WorkflowEntryState.COMPLETED))
                {
                    IList<IStep> currentSteps = GetCurrentSteps();

                    if (currentSteps.Count > 0)
                    {
                        CompleteEntry(null, currentSteps, newState);
                    }
                }

                store.SetEntryState(entry.Id, newState);
            }
            else
            {
                string msg = string.Format("Can't transition workflow instance #{0}. Current state is {1}, requested state is {1}", entryId, entry.State);
                throw new InvalidEntryStateException(msg);
            }

            if (log.IsDebugEnabled)
            {
                log.Debug(entry.Id + " : State is now : " + entry.State);
            }
        }

        [Transaction(TransactionOption.Required)]
        public void DoAction(int actionId, IDictionary inputs)
        {
            IWorkflowEntry entry = store.FindEntry(entryId);

            if (entry.State != WorkflowEntryState.ACTIVATED)
            {
                return;
            }

            IList<IStep> currentSteps = store.FindCurrentSteps(entryId);
            ActionDescriptor action = null;

            Hashtable transientVars = new Hashtable();

            if (inputs != null)
            {
                transientVars = new Hashtable(inputs);
            }

            PopulateTransientMap(entry, transientVars, descriptor.Registers, actionId, currentSteps);

            bool validAction = false;

            //check global actions
            foreach (ActionDescriptor actionDesc in descriptor.GlobalActions)
            {
                if (actionDesc.Id == actionId)
                {
                    action = actionDesc;

                    if (IsActionAvailable(action, transientVars, 0))
                    {
                        validAction = true;
                    }
                }
            }

            foreach (IStep step in currentSteps)
            {
                StepDescriptor s = descriptor.GetStep(step.StepId);

                foreach (ActionDescriptor actionDesc in s.Actions)
                {
                    if (actionDesc.Id == actionId)
                    {
                        action = actionDesc;

                        if (IsActionAvailable(action, transientVars, s.Id))
                        {
                            validAction = true;
                        }
                    }
                }
            }

            if (!validAction)
            {
                throw new InvalidActionException("Action " + actionId + " is invalid");
            }

            //transition the workflow, if it wasn't explicitly finished, check for an implicit finish
            if (!TransitionWorkflow(entry, currentSteps, action, transientVars, inputs))
            {
                CheckImplicitFinish(action);
            }

            context.Update();
        }

        public void ExecuteTriggerFunction(int triggerId)
        {
            IWorkflowEntry entry = store.FindEntry(entryId);

            if (entry == null)
            {
                log.Warn("Cannot execute trigger #" + triggerId + " on non-existent workflow id#" + entryId);

                return;
            }

            Hashtable transientVars = new Hashtable();
            PopulateTransientMap(entry, transientVars, descriptor.Registers, 0, store.FindCurrentSteps(entryId));
            ExecuteFunction(descriptor.GetTriggerFunction(triggerId), transientVars);
        }

        [Transaction(TransactionOption.Required)]
        public long Initialize(int initialAction, IDictionary inputs)
        {
            IWorkflowEntry entry = store.CreateEntry(descriptor.Name);
            entryId = entry.Id;

            if (context.Model != null)
            {
                context.Model.WorkflowId = entryId;
            }

            Hashtable transientVars = new Hashtable();

            if (inputs != null)
            {
                transientVars = new Hashtable(inputs);
            }

            PopulateTransientMap(entry, transientVars, descriptor.Registers, initialAction, new List<IStep>());

            if (!CanInitialize(initialAction, transientVars))
            {
                throw new InvalidRoleException("You are restricted from initializing this workflow");
            }

            ActionDescriptor action = descriptor.GetInitialAction(initialAction);

            TransitionWorkflow(entry, new List<IStep>(), action, transientVars, inputs);
            context.Update();

            // now clone the memory PS to the real PS
            //PropertySetManager.clone(ps, store.getPropertySet(entryId));
            return entryId;
        }

        protected IList<int> GetAvailableActionsForStep(IStep step, IDictionary transientVars)
        {
            List<int> l = new List<int>();
            StepDescriptor s = descriptor.GetStep(step.StepId);

            if (s == null)
            {
                log.Warn("getAvailableActionsForStep called for non-existent step Id #" + step.StepId);

                return l;
            }

            IList<ActionDescriptor> actions = s.Actions;

            if ((actions == null) || (actions.Count == 0))
            {
                return l;
            }

            foreach (ActionDescriptor action in actions)
            {
                RestrictionDescriptor restriction = action.Restriction;
                ConditionsDescriptor conditions = null;

                transientVars["actionId"] = action.Id;

                if (restriction != null)
                {
                    conditions = restriction.ConditionsDescriptor;
                }

                if (PassesConditions(descriptor.GlobalConditions, transientVars, s.Id) 
                    && PassesConditions(conditions, transientVars, s.Id))
                {
                    l.Add(action.Id);
                }
            }

            return l;
        }

        protected int[] GetAvailableAutoActions(long id, IDictionary inputs)
        {
            try
            {
                IWorkflowEntry entry = store.FindEntry(id);

                if (entry == null)
                {
                    throw new ArgumentException("No such workflow id " + id);
                }

                if (entry.State != WorkflowEntryState.ACTIVATED)
                {
                    log.Debug("--> state is " + entry.State);

                    return new int[0];
                }

                List<int> l = new List<int>();
                Hashtable transientVars = (inputs == null) ? new Hashtable() : new Hashtable(inputs);
                ICollection<IStep> currentSteps = store.FindCurrentSteps(id);

                PopulateTransientMap(entry, transientVars, descriptor.Registers, 0, currentSteps);

                // get global actions
                foreach (ActionDescriptor action in descriptor.GlobalActions)
                {
                    transientVars["actionId"] = action.Id;

                    if (action.AutoExecute)
                    {
                        if (IsActionAvailable(action, transientVars, 0))
                        {
                            l.Add(action.Id);
                        }
                    }
                }

                // get normal actions
                foreach (IStep step in currentSteps)
                {
                    l.AddRange(GetAvailableAutoActionsForStep(step, transientVars));
                }

                return l.ToArray();
            }
            catch (Exception e)
            {
                log.Error("Error checking available actions", e);

                return new int[0];
            }
        }

        /**
         * Get just auto action availables for a step
         */
        protected IList<int> GetAvailableAutoActionsForStep(IStep step, IDictionary transientVars)
        {
            List<int> l = new List<int>();
            StepDescriptor s = descriptor.GetStep(step.StepId);

            if (s == null)
            {
                log.Warn("getAvailableAutoActionsForStep called for non-existent step Id #" + step.StepId);

                return l;
            }

            IList<ActionDescriptor> actions = s.Actions;

            if ((actions == null) || (actions.Count == 0))
            {
                return l;
            }

            foreach (ActionDescriptor action in actions)
            {
                transientVars["actionId"] = action.Id;

                //check auto
                if (action.AutoExecute)
                {
                    if (IsActionAvailable(action, transientVars, s.Id))
                    {
                        l.Add(action.Id);
                    }
                }
            }

            return l;
        }

        protected void CheckImplicitFinish(ActionDescriptor action)
        {
            IWorkflowEntry entry = store.FindEntry(entryId);

            IList<IStep> currentSteps = store.FindCurrentSteps(entryId);

            bool isCompleted = true;

            foreach (IStep step in currentSteps)
            {
                StepDescriptor stepDes = descriptor.GetStep(step.StepId);

                // if at least on current step have an available action
                if (stepDes.Actions.Count > 0)
                {
                    isCompleted = false;
                }
            }

            if (isCompleted)
            {
                CompleteEntry(action, currentSteps, WorkflowEntryState.COMPLETED);
            }
        }

        /**
         * Mark the specified entry as completed, and move all current steps to history.
         */
        protected void CompleteEntry(ActionDescriptor action, IList<IStep> currentSteps, int state)
        {
            store.SetEntryState(entryId, state);

            for (int i=0; i<currentSteps.Count; i++)
            {
                IStep step = currentSteps[i];
                string oldStatus = (action != null) ? action.UnconditionalResult.OldStatus : "Finished";
                store.MarkFinished(step, (action != null) ? action.Id : (-1), DateTime.Now, oldStatus, context.Caller);
                store.MoveToHistory(step);
            }
        }

        /**
         * Executes a function.
         *
         * @param function the function to execute
         * @param transientVars the transientVars given by the end-user
         * @param ps the persistence variables
         */
        protected void ExecuteFunction(FunctionDescriptor function, IDictionary transientVars)
        {
            if (function != null)
            {
                string type = function.Type;

                IDictionary args = function.Args;

                IDictionaryEnumerator iter = args.GetEnumerator();
                while (iter.MoveNext())
                {
                    DictionaryEntry mapEntry = (DictionaryEntry)iter.Current;
                    mapEntry.Value = variableResolver.TranslateVariables((string)mapEntry.Value, transientVars);
                }

                IFunctionProvider provider = typeResolver.GetFunction(type, args);

                if (provider == null)
                {
                    string message = "Could not load FunctionProvider class";
                    throw new WorkflowException(message);
                }

                provider.Execute(transientVars, args);
            }
        }

        protected bool PassesCondition(ConditionDescriptor conditionDesc, IDictionary transientVars, int currentStepId)
        {
            string type = conditionDesc.Type;

            IDictionary args = conditionDesc.Args;

            IDictionaryEnumerator iter = args.GetEnumerator();
            while (iter.MoveNext())
            {
                DictionaryEntry entry = (DictionaryEntry)iter.Current;
                entry.Value = variableResolver.TranslateVariables((string)entry.Value, transientVars);
            }

            if (currentStepId != -1)
            {
                Object stepId = args["stepId"];

                if ((stepId != null) && stepId.Equals("-1"))
                {
                    args["stepId"] = currentStepId.ToString();
                }
            }

            ICondition condition = typeResolver.GetCondition(type, args);

            if (condition == null)
            {
                throw new WorkflowException("Could not load condition: " + type);
            }

            try
            {
                bool passed = condition.PassesCondition(transientVars, args);

                if (conditionDesc.Negate)
                {
                    passed = !passed;
                }

                return passed;
            }
            catch (Exception e)
            {
                if (e is WorkflowException)
                {
                    throw (WorkflowException)e;
                }

                throw new WorkflowException("Unknown exception encountered when checking condition " + condition, e);
            }
        }

        protected bool PassesConditions(string conditionType, IList<BaseConditionDescriptor> conditions, 
            IDictionary transientVars, int currentStepId)
        {
            if ((conditions == null) || (conditions.Count == 0))
            {
                return true;
            }

            bool and = "AND".Equals(conditionType);
            bool or = !and;

            foreach (BaseConditionDescriptor descriptor in conditions)
            {
                bool result;

                if (descriptor is ConditionsDescriptor)
                {
                    ConditionsDescriptor conditionsDescriptor = (ConditionsDescriptor)descriptor;
                    result = PassesConditions(conditionsDescriptor.Type, conditionsDescriptor.Conditions, transientVars, currentStepId);
                }
                else
                {
                    result = PassesCondition((ConditionDescriptor)descriptor, transientVars, currentStepId);
                }

                if (and && !result)
                {
                    return false;
                }
                else if (or && result)
                {
                    return true;
                }
            }

            if (and)
            {
                return true;
            }
            else if (or)
            {
                return false;
            }
            else
            {
                return false;
            }
        }

        protected bool PassesConditions(ConditionsDescriptor descriptor, IDictionary transientVars, int currentStepId)
        {
            if (descriptor == null)
            {
                return true;
            }

            return PassesConditions(descriptor.Type, descriptor.Conditions, transientVars, currentStepId);
        }

        protected void PopulateTransientMap(IWorkflowEntry entry, IDictionary transientVars, 
            IList<RegisterDescriptor> registers, int actionId, ICollection<IStep> currentSteps)
        {
            transientVars["context"] = context;
            transientVars["caller"] = context.Caller;
            transientVars["model"] = context.Model;
            transientVars["entry"] = entry;
            transientVars["store"] =  store;
            transientVars["descriptor"] = descriptor;

            if (actionId != 0)
            {
                transientVars["actionId"] = actionId;
            }

            transientVars["currentSteps"] = currentSteps;

            // now talk to the registers for any extra objects needed in scope
            foreach (RegisterDescriptor register in registers)
            {
                IDictionary args = register.Args;

                IRegister r = typeResolver.GetRegister(register.Type, args);

                if (r == null)
                {
                    string message = "Could not load register class";
                    throw new WorkflowException(message);
                }

                try
                {
                    transientVars[register.VariableName] = r.RegisterVariable(context, entry, args);
                }
                catch (Exception e)
                {
                    if (e is WorkflowException)
                    {
                        throw (WorkflowException)e;
                    }

                    throw new WorkflowException("An unknown exception occured while registering variable using register " + r, e);
                }
            }
        }

        /**
         * @return true if the instance has been explicitly completed is this transition, false otherwise
         */
        protected bool TransitionWorkflow(IWorkflowEntry entry, IList<IStep> currentSteps, 
            ActionDescriptor action, IDictionary transientVars, IDictionary inputs)
        {
            if (stateCache != null)
            {
                stateCache.Clear();
            }

            IStep step = GetCurrentStep(action.Id, currentSteps, transientVars);

            if (action.Validators.Count > 0)
            {
                VerifyInputs(entry, action.Validators, transientVars);
            }

            //we're leaving the current step, so let's execute its post-functions
            //check if we actually have a current step
            if (step != null)
            {
                if (transientVars.Contains("appendText"))
                    ReflectUtil.SetProperty(step, "appendText", transientVars["appendText"]);

                IList<FunctionDescriptor> stepPostFunctions = descriptor.GetStep(step.StepId).PostFunctions;

                foreach (FunctionDescriptor function in stepPostFunctions)
                {
                    ExecuteFunction(function, transientVars);
                }
            }

            // preFunctions
            IList<FunctionDescriptor> preFunctions = action.PreFunctions;

            foreach (FunctionDescriptor function in preFunctions)
            {
                ExecuteFunction(function, transientVars);
            }

            // check each conditional result
            IList<ConditionalResultDescriptor> conditionalResults = action.ConditionalResults;
            IList<FunctionDescriptor> extraPreFunctions = null;
            IList<FunctionDescriptor> extraPostFunctions = null;
            ResultDescriptor[] theResults = new ResultDescriptor[1];

            foreach (ConditionalResultDescriptor conditionalResult in conditionalResults)
            {
                if (PassesConditions(null, conditionalResult.Conditions, transientVars, (step != null) ? step.StepId : (-1)))
                {
                    //if (evaluateExpression(conditionalResult.getCondition(), entry, wf.getRegisters(), null, transientVars)) {
                    theResults[0] = conditionalResult;

                    if (conditionalResult.Validators.Count > 0)
                    {
                        VerifyInputs(entry, conditionalResult.Validators, transientVars);
                    }

                    extraPreFunctions = conditionalResult.PreFunctions;
                    extraPostFunctions = conditionalResult.PostFunctions;

                    break;
                }
            }

            // use unconditional-result if a condition hasn't been met
            if (theResults[0] == null)
            {
                theResults[0] = action.UnconditionalResult;
                VerifyInputs(entry, theResults[0].Validators, transientVars);
                extraPreFunctions = theResults[0].PreFunctions;
                extraPostFunctions = theResults[0].PostFunctions;
            }

            if (log.IsDebugEnabled)
            {
                log.Debug("theResult=" + theResults[0].Step + ' ' + theResults[0].Status);
            }

            if ((extraPreFunctions != null) && (extraPreFunctions.Count > 0))
            {
                // run any extra pre-functions that haven't been run already
                foreach (FunctionDescriptor function in extraPreFunctions)
                {
                    ExecuteFunction(function, transientVars);
                }
            }

            // go to next step
            if (theResults[0].Split != 0)
            {
                // the result is a split request, handle it correctly
                SplitDescriptor splitDesc = descriptor.GetSplit(theResults[0].Split);
                IList<ResultDescriptor> results = splitDesc.Results;
                List<FunctionDescriptor> splitPreFunctions = new List<FunctionDescriptor>();
                List<FunctionDescriptor> splitPostFunctions = new List<FunctionDescriptor>();

                //check all results in the split and verify the input against any validators specified
                //also build up all the pre and post functions that should be called.
                foreach (ResultDescriptor resultDescriptor in results)
                {
                    if (resultDescriptor.Validators.Count > 0)
                    {
                        VerifyInputs(entry, resultDescriptor.Validators, new Hashtable(transientVars));
                    }

                    splitPreFunctions.AddRange(resultDescriptor.PreFunctions);
                    splitPostFunctions.AddRange(resultDescriptor.PostFunctions);
                }

                // now execute the pre-functions
                foreach (FunctionDescriptor function in splitPreFunctions)
                {
                    ExecuteFunction(function, transientVars);
                }

                if (!action.Finish)
                {
                    // now make these steps...
                    bool moveFirst = true;

                    theResults = new List<ResultDescriptor>(results).ToArray();

                    foreach (ResultDescriptor resultDescriptor in results )
                    {
                        IStep moveToHistoryStep = null;

                        if (moveFirst)
                        {
                            moveToHistoryStep = step;
                        }

                        long[] previousIds = null;

                        if (step != null)
                        {
                            previousIds = new long[] { step.Id };
                        }

                        CreateNewCurrentStep(resultDescriptor, entry, action.Id, moveToHistoryStep, previousIds, transientVars);
                        moveFirst = false;
                    }
                }

                // now execute the post-functions
                foreach (FunctionDescriptor function in splitPostFunctions)
                {
                    ExecuteFunction(function, transientVars);
                }
            }
            else if (theResults[0].Join != 0)
            {
                // this is a join, finish this step...
                JoinDescriptor joinDesc = descriptor.GetJoin(theResults[0].Join);
                step = store.MarkFinished(step, action.Id, DateTime.Now, theResults[0].OldStatus, context.Caller);
                store.MoveToHistory(step);

                // ... now check to see if the expression evaluates
                // (get only current steps that have a result to this join)
                IList<IStep> joinSteps = new List<IStep>();
                joinSteps.Add(step);

                //currentSteps = store.findCurrentSteps(id); // shouldn't need to refresh the list
                foreach (IStep currentStep in currentSteps)
                {
                    if (currentStep.Id != step.Id)
                    {
                        StepDescriptor stepDesc = descriptor.GetStep(currentStep.StepId);

                        if (stepDesc.ResultsInJoin(theResults[0].Join))
                        {
                            joinSteps.Add(currentStep);
                        }
                    }
                }

                //we also need to check history steps that were finished before this one
                //that might be part of the join
                IList<IStep> historySteps = store.FindHistorySteps(entry.Id);

                foreach (IStep historyStep in historySteps)
                {
                    if (historyStep.Id != step.Id)
                    {
                        StepDescriptor stepDesc = descriptor.GetStep(historyStep.StepId);

                        if (stepDesc.ResultsInJoin(theResults[0].Join))
                        {
                            joinSteps.Add(historyStep);
                        }
                    }
                }

                JoinNodes jn = new JoinNodes(joinSteps);
                transientVars["jn"] = jn;

                //todo verify that 0 is the right value for currentstep here
                if (PassesConditions(null, joinDesc.Conditions, transientVars, 0))
                {
                    // move the rest without creating a new step ...
                    ResultDescriptor joinresult = joinDesc.Result;

                    if (joinresult.Validators.Count > 0)
                    {
                        VerifyInputs(entry, joinresult.Validators, transientVars);
                    }

                    // now execute the pre-functions
                    foreach (FunctionDescriptor function in joinresult.PreFunctions)
                    {
                        ExecuteFunction(function, transientVars);
                    }

                    long[] previousIds = new long[joinSteps.Count];
                    int i = 1;

                    foreach (IStep currentStep in joinSteps)
                    {
                        if (currentStep.Id != step.Id)
                        {
                            //if this is already a history step (eg, for all join steps completed prior to this one),
                            //we don't move it, since it's already history.
                            if (!historySteps.Contains(currentStep))
                            {
                                store.MoveToHistory(currentStep);
                            }

                            previousIds[i] = currentStep.Id;
                            i++;
                        }
                    }

                    if (!action.Finish)
                    {
                        // ... now finish this step normally
                        previousIds[0] = step.Id;
                        theResults[0] = joinDesc.Result;

                        //we pass in null for the current step since we've already moved it to history above
                        CreateNewCurrentStep(joinDesc.Result, entry, action.Id, null, previousIds, transientVars);
                    }

                    // now execute the post-functions
                    foreach (FunctionDescriptor function in joinresult.PostFunctions)
                    {
                        ExecuteFunction(function, transientVars);
                    }
                }
            }
            else
            {
                // normal finish, no splits or joins
                long[] previousIds = null;

                if (step != null)
                {
                    previousIds = new long[] { step.Id };
                }

                if (!action.Finish)
                {
                    CreateNewCurrentStep(theResults[0], entry, action.Id, step, previousIds, transientVars);
                }
            }

            // postFunctions (BOTH)
            if (extraPostFunctions != null)
            {
                foreach (FunctionDescriptor function in extraPostFunctions)
                {
                    ExecuteFunction(function, transientVars);
                }
            }

            foreach (FunctionDescriptor function in action.PostFunctions)
            {
                ExecuteFunction(function, transientVars);
            }

            //if executed action was an initial action then workflow is activated
            if ((descriptor.GetInitialAction(action.Id) != null) && (entry.State != WorkflowEntryState.ACTIVATED))
            {
                ChangeEntryState(WorkflowEntryState.ACTIVATED);
            }

            //if it's a finish action, then we halt
            if (action.Finish)
            {
                CompleteEntry(action, GetCurrentSteps(), WorkflowEntryState.COMPLETED);

                return true;
            }

            //get available autoexec actions
            int[] availableAutoActions = GetAvailableAutoActions(entry.Id, inputs);

            //we perform the first autoaction that applies, not all of them.
            if (availableAutoActions.Length > 0)
            {
                DoAction(availableAutoActions[0], inputs);
            }

            return false;
        }

        /**
         * Validates input against a list of ValidatorDescriptor objects.
         *
         * @param entry the workflow instance
         * @param validators the list of ValidatorDescriptors
         * @param transientVars the transientVars
         * @param ps the persistence variables
         */
        protected void VerifyInputs(IWorkflowEntry entry, IList<ValidatorDescriptor> validators, 
            IDictionary transientVars)
        {
            foreach (ValidatorDescriptor input in validators)
            {
                if (input != null)
                {
                    string type = input.Type;
                    IDictionary args = input.Args;

                    IDictionaryEnumerator iter = args.GetEnumerator();
                    while (iter.MoveNext())
                    {
                        DictionaryEntry mapEntry = (DictionaryEntry)iter.Current;
                        mapEntry.Value = variableResolver.TranslateVariables((string)mapEntry.Value, transientVars);
                    }

                    IValidator validator = typeResolver.GetValidator(type, args);

                    if (validator == null)
                    {
                        string message = "Could not load validator class";
                        throw new WorkflowException(message);
                    }

                    try
                    {
                        validator.Validate(transientVars, args);
                    }
                    catch (InvalidInputException e)
                    {
                        throw e;
                    }
                    catch (Exception e)
                    {
                        if (e is WorkflowException)
                        {
                            throw (WorkflowException)e;
                        }

                        string message = "An unknown exception occured executing Validator " + validator;
                        throw new WorkflowException(message, e);
                    }
                }
            }
        }

        /**
         * check if an action is available or not
         * @param action The action descriptor
         * @return true if the action is available
         */
        private bool IsActionAvailable(ActionDescriptor action, IDictionary transientVars, int stepId)
        {
            if (action == null)
            {
                return false;
            }

            WorkflowDescriptor wf = GetWorkflowDescriptorForAction(action);

            if (stateCache != null && !stateCache.ContainsKey(action))
            {
                RestrictionDescriptor restriction = action.Restriction;
                ConditionsDescriptor conditions = null;

                if (restriction != null)
                {
                    conditions = restriction.ConditionsDescriptor;
                }

                bool result = PassesConditions(wf.GlobalConditions, transientVars, stepId) 
                            && PassesConditions(conditions, transientVars, stepId);
                stateCache.Add(action, result);
            }

            return (bool)stateCache[action];
        }

        private IStep GetCurrentStep(int actionId, IList<IStep> currentSteps, IDictionary transientVars)
        {
            if (currentSteps.Count == 1)
            {
                return (IStep)currentSteps[0];
            }

            foreach (IStep step in currentSteps)
            {
                ActionDescriptor action = descriptor.GetStep(step.StepId).GetAction(actionId);

                //$AR init
                if (IsActionAvailable(action, transientVars, step.StepId))
                {
                    return step;
                }

                //$AR end
            }

            return null;
        }

        private WorkflowDescriptor GetWorkflowDescriptorForAction(ActionDescriptor action)
        {
            AbstractDescriptor objWfd = action;

            while (!(objWfd is WorkflowDescriptor))
            {
                objWfd = objWfd.Parent;
            }

            WorkflowDescriptor wf = (WorkflowDescriptor)objWfd;

            return wf;
        }

        private IStep CreateNewCurrentStep(ResultDescriptor theResult, IWorkflowEntry entry, 
            int actionId, IStep currentStep, long[] previousIds, IDictionary transientVars)
        {
            int nextStep = theResult.Step;

            if (nextStep == -1)
            {
                if (currentStep != null)
                {
                    nextStep = currentStep.StepId;
                }
                else
                {
                    throw new StoreException("Illegal argument: requested new current step same as current step, but current step not specified");
                }
            }

            if (log.IsDebugEnabled)
            {
                log.Debug(string.Format("Outcome: stepId={0}, status={1}, owner={2}, actionId={3}, currentStep={4}",
                    nextStep, theResult.Status, theResult.Owner, actionId, (currentStep != null) ? currentStep.StepId : 0));
            }

            if (previousIds == null)
            {
                previousIds = new long[0];
            }

            string owner = theResult.Owner;

            if (owner != null)
            {
                Object o = variableResolver.TranslateVariables(owner, transientVars);
                owner = (o != null) ? o.ToString() : null;
            }

            string oldStatus = theResult.OldStatus;
            oldStatus = variableResolver.TranslateVariables(oldStatus, transientVars).ToString();

            string status = theResult.Status;
            status = variableResolver.TranslateVariables(status, transientVars).ToString();

            if (currentStep != null)
            {
                store.MarkFinished(currentStep, actionId, DateTime.Now, oldStatus, context.Caller);
                store.MoveToHistory(currentStep);

                //store.moveToHistory(actionId, new Date(), currentStep, oldStatus, context.getCaller());
            }

            // construct the start date and optional due date
            DateTime startDate = DateTime.Now;
            DateTime? dueDate = null;

            if ((theResult.DueDate != null) && (theResult.DueDate.Length > 0))
            {
                Object dueDateObject = variableResolver.TranslateVariables(theResult.DueDate, transientVars);

                if (dueDateObject is DateTime)
                {
                    dueDate = (DateTime)dueDateObject;
                }
                else if (dueDateObject is string)
                {
                    long offset = 0;

                    try
                    {
                        offset = Convert.ToInt64((string)dueDateObject);
                    }
                    catch (FormatException e)
                    {
                    }

                    if (offset > 0)
                    {
                        dueDate = new DateTime(startDate.Ticks + offset);
                    }
                }
                else if (dueDateObject is long)
                {
                    long offset = (long)dueDateObject;

                    if (offset > 0)
                    {
                        dueDate = new DateTime(startDate.Ticks + offset);
                    }
                }
            }

            IStep newStep = store.CreateCurrentStep(entry.Id, nextStep, owner, startDate, dueDate, status, previousIds);
            transientVars["createdStep"] = newStep;

            if ((previousIds != null) && (previousIds.Length == 0) && (currentStep == null))
            {
                // At this point, it must be a brand new workflow, so we'll overwrite the empty currentSteps
                // with an array of just this current step
                IList currentSteps = new ArrayList();
                currentSteps.Add(newStep);
                transientVars["currentSteps"] = currentSteps;
            }

            WorkflowDescriptor descriptor = (WorkflowDescriptor)transientVars["descriptor"];
            StepDescriptor step = descriptor.GetStep(nextStep);

            if (step == null)
            {
                throw new WorkflowException("step #" + nextStep + " does not exist");
            }

            foreach (FunctionDescriptor function in step.PreFunctions)
            {
                ExecuteFunction(function, transientVars);
            }

            return newStep;

        }
    }
}
