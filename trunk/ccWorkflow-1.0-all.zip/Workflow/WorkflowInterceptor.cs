#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Castle.Core.Interceptor;
using CchenSoft.Workflow.Config;
using CchenSoft.Workflow.Spi;

namespace CchenSoft.Workflow
{
    public class WorkflowInterceptor : IInterceptor
    {
        private IConfiguration config;

        public WorkflowInterceptor(IConfiguration config)
        {
            this.config = config;
        }

        #region IInterceptor ��Ա

        public void Intercept(IInvocation invocation)
        {
            object[] attrs = invocation.MethodInvocationTarget.GetCustomAttributes(typeof(TransactionAttribute), false);
            if (attrs.Length == 0)
            {
                invocation.Proceed();
            }
            else
            {
                TransactionAttribute attr = (TransactionAttribute)attrs[0];
                if (TransactionOption.Required == attr.Value)
                {
                    int flag = config.WorkflowStore.BeginTransaction();
                    if (flag != 0)
                    {
                        try
                        {
                            invocation.Proceed();
                            config.WorkflowStore.CommitTransaction();
                        }
                        catch (Exception ex)
                        {
                            config.WorkflowStore.RollbackTransaction();
                            throw ex;
                        }
                    }
                    else
                    {
                        // in other transaction.
                        invocation.Proceed();
                    }
                }
            }            
        }

        #endregion
    }
}
