#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using CchenSoft.Workflow.Spi;
using CchenSoft.Workflow.Loader;
using CchenSoft.Workflow.Config;
namespace CchenSoft.Workflow.Basic
{
    /**
     * A basic workflow implementation which does not read in
     * the current user from any context, but allows one to be
     * specified via the constructor. Also does not support rollbacks.
     */
    public class BasicWorkflow : AbstractWorkflow
    {
        //~ Constructors ///////////////////////////////////////////////////////////

        //public BasicWorkflow(string caller)
        //{
        //    base.context = new BasicWorkflowContext(caller);
        //}

        //public BasicWorkflow(string caller, IUserManager manager)
        //{
        //    base.context = new BasicWorkflowContext(caller, manager);
        //}

        public BasicWorkflow(IWorkflowContext context, WorkflowDescriptor descriptor, IConfiguration config)
            : base(context, descriptor, config)
        {
            //base.context = new BasicWorkflowContext(caller, manager);
        }

    }
}
