#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using CchenSoft.Workflow.Spi;
using System;

namespace CchenSoft.Workflow.Basic
{
    public class BasicWorkflowContext : IWorkflowContext
    {
        //~ Instance fields ////////////////////////////////////////////////////////

        private string caller;
        private IUserManager userManager;

        //~ Constructors ///////////////////////////////////////////////////////////

        public BasicWorkflowContext(string caller)
        {
            this.caller = caller;
        }

        public BasicWorkflowContext(string caller, IUserManager userManager)
        {
            this.caller = caller;
            this.userManager = userManager;
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public IUserManager UserManager
        {
            get { return userManager; }
        }

        public IWorkflowModel Model
        {
            get { return null; }
        }

        public string Caller
        {
            get { return caller; }
        }

        public void Update()
        {
        }
    }
}
