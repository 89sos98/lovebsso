#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Web.Services;
using CchenSoft.Workflow.Loader;
using CchenSoft.Workflow.Basic;
using CchenSoft.Workflow.Query;
using System.Collections;
using CchenSoft.Workflow.Config;
using CchenSoft.Workflow.PropertySet;
using System.Collections.Generic;
using CchenSoft.Workflow.Spi;
namespace CchenSoft.Workflow.Soap
{

    /**
     * Soap enabled Wrapper around a BasicWorkflow
     */
    [WebService]
    public class BasicSOAPWorkflow : WebService, IWorkflow
    {
        //~ Methods ////////////////////////////////////////////////////////////////

        [WebMethod]
        public int[] GetAvailableActions(long id)
        {
            return new BasicWorkflow(getRemoteUser()).GetAvailableActions(id);
        }

        [WebMethod]
        public int[] GetAvailableActions(long id, IDictionary inputs)
        {
            return new BasicWorkflow(getRemoteUser()).GetAvailableActions(id, inputs);
        }

        [WebMethod]
        public IList<IStep> GetCurrentSteps(long id)
        {
            return new BasicWorkflow(getRemoteUser()).GetCurrentSteps(id);
        }

        [WebMethod]
        public int GetEntryState(long id)
        {
            return new BasicWorkflow(getRemoteUser()).GetEntryState(id);
        }

        [WebMethod]
        public IList<IStep> GetHistorySteps(long id)
        {
            return new BasicWorkflow(getRemoteUser()).GetHistorySteps(id);
        }

        [WebMethod]
        public IPropertySet GetPropertySet(long id)
        {
            return new BasicWorkflow(getRemoteUser()).GetPropertySet(id);
        }

        [WebMethod]
        public IList GetSecurityPermissions(long id)
        {
            return new BasicWorkflow(getRemoteUser()).GetSecurityPermissions(id, null);
        }

        [WebMethod]
        public IList GetSecurityPermissions(long id, IDictionary inputs)
        {
            return new BasicWorkflow(getRemoteUser()).GetSecurityPermissions(id, inputs);
        }

        [WebMethod]
        public WorkflowDescriptor GetWorkflowDescriptor(string workflowName)
        {
            return new BasicWorkflow(getRemoteUser()).GetWorkflowDescriptor(workflowName);
        }

        [WebMethod]
        public string GetWorkflowName(long id)
        {
            return new BasicWorkflow(getRemoteUser()).GetWorkflowName(id);
        }

        [WebMethod]
        public string[] GetWorkflowNames()
        {
            return new BasicWorkflow(getRemoteUser()).GetWorkflowNames();
        }

        [WebMethod]
        public bool CanInitialize(string workflowName, int initialState)
        {
            return new BasicWorkflow(getRemoteUser()).CanInitialize(workflowName, initialState);
        }

        [WebMethod]
        public bool CanInitialize(string workflowName, int initialAction, IDictionary inputs)
        {
            return new BasicWorkflow(getRemoteUser()).CanInitialize(workflowName, initialAction, inputs);
        }

        [WebMethod]
        public bool CanModifyEntryState(long id, int newState)
        {
            return new BasicWorkflow(getRemoteUser()).CanModifyEntryState(id, newState);
        }

        [WebMethod]
        public void ChangeEntryState(long id, int newState)
        {
            new BasicWorkflow(getRemoteUser()).ChangeEntryState(id, newState);
        }

        [WebMethod]
        public void DoAction(long id, int actionId, IDictionary inputs)
        {
            new BasicWorkflow(getRemoteUser()).DoAction(id, actionId, inputs);
        }

        [WebMethod]
        public void ExecuteTriggerFunction(long id, int triggerId)
        {
            new BasicWorkflow(getRemoteUser()).ExecuteTriggerFunction(id, triggerId);
        }

        [WebMethod]
        public long Initialize(string workflowName, int initialState, IDictionary inputs)
        {
            return new BasicWorkflow(getRemoteUser()).Initialize(workflowName, initialState, inputs);
        }

        [WebMethod]
        public IList<long> Query(WorkflowQuery query)
        {
            return new BasicWorkflow(getRemoteUser()).Query(query);
        }

        [WebMethod]
        public IList<long> Query(WorkflowExpressionQuery query)
        {
            return new BasicWorkflow(getRemoteUser()).Query(query);
        }

        [WebMethod]
        public bool RemoveWorkflowDescriptor(string workflowName)
        {
            return new BasicWorkflow(getRemoteUser()).RemoveWorkflowDescriptor(workflowName);
        }

        [WebMethod]
        public bool SaveWorkflowDescriptor(string workflowName, WorkflowDescriptor descriptor, bool replace)
        {
            return new BasicWorkflow(getRemoteUser()).SaveWorkflowDescriptor(workflowName, descriptor, replace);
        }

        protected string getRemoteUser()
        {
            return Context.Request.UserHostName;
        }
    }
}
