#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Xml;

namespace CchenSoft.Workflow.Loader
{
    public class DescriptorFactory
    {
        //~ Static fields/initializers /////////////////////////////////////////////

        private static DescriptorFactory factory = new DescriptorFactory();

        //~ Constructors ///////////////////////////////////////////////////////////

        public DescriptorFactory()
        {
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public static void SetFactory(DescriptorFactory factory)
        {
            DescriptorFactory.factory = factory;
        }

        public static DescriptorFactory GetFactory()
        {
            return factory;
        }

        public ActionDescriptor CreateActionDescriptor()
        {
            return new ActionDescriptor();
        }

        public ActionDescriptor CreateActionDescriptor(XmlElement action)
        {
            return new ActionDescriptor(action);
        }

        public ConditionDescriptor CreateConditionDescriptor()
        {
            return new ConditionDescriptor();
        }

        public ConditionDescriptor CreateConditionDescriptor(XmlElement function)
        {
            return new ConditionDescriptor(function);
        }

        public ConditionalResultDescriptor CreateConditionalResultDescriptor()
        {
            return new ConditionalResultDescriptor();
        }

        public ConditionalResultDescriptor CreateConditionalResultDescriptor(XmlElement element)
        {
            return new ConditionalResultDescriptor(element);
        }

        public ConditionsDescriptor CreateConditionsDescriptor()
        {
            return new ConditionsDescriptor();
        }

        public ConditionsDescriptor CreateConditionsDescriptor(XmlElement element)
        {
            return new ConditionsDescriptor(element);
        }

        public FunctionDescriptor CreateFunctionDescriptor()
        {
            return new FunctionDescriptor();
        }

        public FunctionDescriptor CreateFunctionDescriptor(XmlElement function)
        {
            return new FunctionDescriptor(function);
        }

        public JoinDescriptor CreateJoinDescriptor(XmlElement join)
        {
            return new JoinDescriptor(join);
        }

        public JoinDescriptor CreateJoinDescriptor()
        {
            return new JoinDescriptor();
        }

        public PermissionDescriptor CreatePermissionDescriptor()
        {
            return new PermissionDescriptor();
        }

        public PermissionDescriptor CreatePermissionDescriptor(XmlElement permission)
        {
            return new PermissionDescriptor(permission);
        }

        public RegisterDescriptor CreateRegisterDescriptor(XmlElement register)
        {
            return new RegisterDescriptor(register);
        }

        public RegisterDescriptor CreateRegisterDescriptor()
        {
            return new RegisterDescriptor();
        }

        public ResultDescriptor CreateResultDescriptor()
        {
            return new ResultDescriptor();
        }

        public ResultDescriptor CreateResultDescriptor(XmlElement element)
        {
            return new ResultDescriptor(element);
        }

        public SplitDescriptor CreateSplitDescriptor()
        {
            return new SplitDescriptor();
        }

        public SplitDescriptor CreateSplitDescriptor(XmlElement split)
        {
            return new SplitDescriptor(split);
        }

        public StepDescriptor CreateStepDescriptor()
        {
            return new StepDescriptor();
        }

        public StepDescriptor CreateStepDescriptor(XmlElement step)
        {
            return new StepDescriptor(step);
        }

        public StepDescriptor CreateStepDescriptor(XmlElement step, AbstractDescriptor parent)
        {
            return new StepDescriptor(step, parent);
        }

        public ValidatorDescriptor CreateValidatorDescriptor()
        {
            return new ValidatorDescriptor();
        }

        public ValidatorDescriptor CreateValidatorDescriptor(XmlElement validator)
        {
            return new ValidatorDescriptor(validator);
        }

        public WorkflowDescriptor CreateWorkflowDescriptor(XmlElement root)
        {
            return new WorkflowDescriptor(root);
        }

        public WorkflowDescriptor CreateWorkflowDescriptor()
        {
            return new WorkflowDescriptor();
        }
    }
}
