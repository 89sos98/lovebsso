#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

    using System.Collections;
    using System.Xml;
    using System;

namespace CchenSoft.Workflow.Loader
{
    /**
     * A validator is a helper used to verify values in the input map that is
     * provided to every action call.
     */
    public class ValidatorDescriptor : AbstractDescriptor
    {
        //~ Instance fields ////////////////////////////////////////////////////////

        protected Hashtable args = new Hashtable();
        protected string name;
        protected string type;

        //~ Constructors ///////////////////////////////////////////////////////////

        /**
         * @deprecated use {@link DescriptorFactory} instead
         */
        public ValidatorDescriptor()
        {
        }

        /**
         * @deprecated use {@link DescriptorFactory} instead
         */
        public ValidatorDescriptor(XmlElement validator)
        {
            Init(validator);
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public IDictionary Args
        {
            get { return args; }
        }

        public string Name
        {
            get { return name; }
            set { this.name = value; }
        }

        public string Type
        {
            get { return type; }
            set { this.type = value; }
        }

        public override void WriteXML(XmlTextWriter writer, int indent)
        {
            XMLUtil.printIndent(writer, indent++);
            //writer.println("<validator " + (hasId() ? ("id=\"" + getId() + "\" ") : "") + ((name != null) ? ("name=\"" + XMLUtil.encode(getName()) + "\" ") : "") + "type=\"" + type + "\">");
            writer.WriteStartElement("validator");
            if (HasId())
                writer.WriteAttributeString("id", Id.ToString());
            if (name != null)
                writer.WriteAttributeString("name", XMLUtil.Encode(name));
            writer.WriteAttributeString("type", type);

            foreach (object key in args.Keys)
            {
                XMLUtil.printIndent(writer, indent);
                writer.WriteStartElement("arg");
                writer.WriteAttributeString("name", key.ToString());

                if ("beanshell".Equals(type) || "bsf".Equals(type))
                {
                    writer.WriteCData(args[key].ToString());
                }
                else
                {
                    writer.WriteString(XMLUtil.Encode(args[key]));
                }

                writer.WriteEndElement(); // ("</arg>");
            }

            XMLUtil.printIndent(writer, --indent);
            writer.WriteEndElement(); // ("</validator>");
        }

        protected void Init(XmlElement validator)
        {
            type = XMLUtil.GetAttributeValue(validator, "type");
            name = XMLUtil.GetAttributeValue(validator, "name");

            try
            {
                Id = (Convert.ToInt32(XMLUtil.GetAttributeValue(validator, "id")));
            }
            catch (FormatException e)
            {
            }

            this.args = new Hashtable();

            XmlNodeList nodes = validator.SelectNodes("arg");

            for (int l = 0; l < args.Count; l++)
            {
                XmlElement arg = (XmlElement)nodes[l];
                this.args.Add(XMLUtil.GetAttributeValue(arg, "name"), arg.InnerText);
            }
        }
    }
}
