#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Collections;
using System.Xml;
using System;

namespace CchenSoft.Workflow.Loader
{

    /**
     * Desrives a function that can be applied to a workflow step.
     */
    public class FunctionDescriptor : AbstractDescriptor
    {
        //~ Instance fields ////////////////////////////////////////////////////////

        protected Hashtable args = new Hashtable();

        /**
         * The name field helps the editor identify the condition template used.
         */
        protected string name;
        protected string type;

        //~ Constructors ///////////////////////////////////////////////////////////

        /**
         * @deprecated use {@link DescriptorFactory} instead
         */
        public FunctionDescriptor()
        {
        }

        /**
         * @deprecated use {@link DescriptorFactory} instead
         */
        public FunctionDescriptor(XmlElement function)
        {
            Init(function);
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public IDictionary Args
        {
            get { return args; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Type
        {
            get { return type; }
            set { this.type = value; }
        }

        public override void WriteXML(XmlTextWriter writer, int indent)
        {
            XMLUtil.printIndent(writer, indent++);
            //writer.println("<function " + (hasId() ? ("id=\"" + getId() + "\" ") : "") + (((name != null) && (name.length() > 0)) ? ("name=\"" + XMLUtil.encode(getName()) + "\" ") : "") + "type=\"" + type + "\">");
            writer.WriteStartElement("function");
            if (HasId())
                writer.WriteAttributeString("id", Id.ToString());
            if ((name != null) && (name.Length > 0))
                writer.WriteAttributeString("name", XMLUtil.Encode(name));

            writer.WriteAttributeString("type", type);

            foreach (object key in args.Keys)
            {
                XMLUtil.printIndent(writer, indent);
                writer.WriteStartElement("arg");
                writer.WriteAttributeString("name", key.ToString());

                if ("beanshell".Equals(type) || "bsf".Equals(type))
                {
                    writer.WriteCData(args[key].ToString());
                }
                else
                {
                    writer.WriteString(XMLUtil.Encode(args[key]));
                }

                writer.WriteEndElement(); //("</arg>");
            }

            XMLUtil.printIndent(writer, --indent);
            writer.WriteEndElement(); //("</function>");
        }

        protected void Init(XmlElement function)
        {
            type = XMLUtil.GetAttributeValue(function, "type");

            try
            {
                Id = (Convert.ToInt32(XMLUtil.GetAttributeValue(function, "id")));
            }
            catch (FormatException e)
            {
            }

            name = XMLUtil.GetAttributeValue(function, "name");

            XmlNodeList args = function.SelectNodes("arg");

            for (int l = 0; l < args.Count; l++)
            {
                XmlElement arg = (XmlElement)args[l];
                this.args.Add(XMLUtil.GetAttributeValue(arg, "name"), arg.InnerText);
            }
        }
    }
}
