#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Collections;
using System.Xml;
using System;

namespace CchenSoft.Workflow.Loader
{
    public class RegisterDescriptor : AbstractDescriptor
    {
        //~ Instance fields ////////////////////////////////////////////////////////

        protected Hashtable args = new Hashtable();
        protected string type;
        protected string variableName;

        //~ Constructors ///////////////////////////////////////////////////////////

        /**
         * @deprecated use {@link DescriptorFactory} instead
         */
        public RegisterDescriptor()
        {
        }

        /**
         * @deprecated use {@link DescriptorFactory} instead
         */
        public RegisterDescriptor(XmlElement register)
        {
            Init(register);
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public IDictionary Args
        {
            get { return args; }
        }

        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        public string VariableName
        {
            get { return variableName; }
            set { variableName = value; }
        }

        public override void WriteXML(XmlTextWriter writer, int indent)
        {
            XMLUtil.printIndent(writer, indent++);
            //writer.println("<register " + (hasId() ? ("id=\"" + getId() + "\" ") : "") + "type=\"" + type + "\" variable-name=\"" + variableName + "\">");
            writer.WriteStartElement("register");
            if (HasId())
                writer.WriteAttributeString("id", Id.ToString());
            writer.WriteAttributeString("type", type);
            writer.WriteAttributeString("variable-name", variableName);

            foreach (object key in args.Keys)
            {
                XMLUtil.printIndent(writer, indent);
                writer.WriteStartElement("arg");
                writer.WriteAttributeString("name", key.ToString());

                if ("beanshell".Equals(type) || "bsf".Equals(type))
                {
                    writer.WriteCData(args[key].ToString());
                }
                else
                {
                    writer.WriteString(XMLUtil.Encode(args[key]));
                }

                writer.WriteEndElement(); // ("</arg>");
            }

            XMLUtil.printIndent(writer, --indent);
            writer.WriteEndElement(); // ("</register>");
        }

        protected void Init(XmlElement register)
        {
            this.type = XMLUtil.GetAttributeValue(register, "type");
            this.variableName = XMLUtil.GetAttributeValue(register, "variable-name");

            try
            {
                Id = Convert.ToInt32(XMLUtil.GetAttributeValue(register, "id"));
            }
            catch (FormatException e)
            {
            }

            XmlNodeList args = register.SelectNodes("arg");

            for (int l = 0; l < args.Count; l++)
            {
                XmlElement arg = (XmlElement)args[l];
                this.args.Add(XMLUtil.GetAttributeValue(arg, "name"), arg.InnerText);
            }
        }
    }
}
