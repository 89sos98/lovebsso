#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Collections;
using System.Xml;
using System;
namespace CchenSoft.Workflow.Loader
{
    public class ConditionDescriptor : BaseConditionDescriptor
    {
        //~ Instance fields ////////////////////////////////////////////////////////

        protected Hashtable args = new Hashtable();

        /**
         * The name field helps the editor identify the condition template used.
         */
        protected string name;
        protected bool negate = false;

        //~ Constructors ///////////////////////////////////////////////////////////

        /**
         * @deprecated use {@link DescriptorFactory} instead
         */
        public ConditionDescriptor()
        {
        }

        /**
         * @deprecated use {@link DescriptorFactory} instead
         */
        public ConditionDescriptor(XmlElement function) : base(function)
        {
            Init(function);
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public IDictionary Args
        {
            get { return args; }
        }

        public string Name
        {
            set { name = value; }
            get { return name; }
        }


        public bool Negate
        {
            get { return negate; }
            set { negate = value; }
        }

        public override void Validate()
        {
        }

        public override void WriteXML(XmlTextWriter writer, int indent)
        {
            XMLUtil.printIndent(writer, indent++);
            writer.WriteStartElement("condition");

            //writer.println("<condition " + ( ? ("id=\"" + getId() + "\" ") : "") + () ? ("name=\"" +  + "\" ") : "") + (negate ? ("negate=\"true\" ") : "") + "type=\"" + type + "\">");

            if (HasId())
                writer.WriteAttributeString("id", Id.ToString());
            if ((name != null) && (name.Length > 0))
                writer.WriteAttributeString("name", name);
            if (negate)
                writer.WriteAttributeString("negate", "true");
            writer.WriteAttributeString("type", type);

            IEnumerator iter = args.Keys.GetEnumerator();

            foreach (object key in args.Keys)
            {
                XMLUtil.printIndent(writer, indent);
                writer.WriteStartElement("arg");
                writer.WriteAttributeString("name", key.ToString());

                if ("beanshell".Equals(type) || "bsf".Equals(type))
                {
                    writer.WriteCData(args[key].ToString());
                }
                else
                {
                    writer.WriteString(XMLUtil.Encode(args[key]));
                }

                writer.WriteEndElement(); // ("</arg>");
            }

            XMLUtil.printIndent(writer, --indent);
            writer.WriteEndElement(); //("</condition>");
        }

        protected void Init(XmlElement condition)
        {
            try
            {
                Id = (Convert.ToInt32(XMLUtil.GetAttributeValue(condition, "id")));
            }
            catch (FormatException e)
            {
            }

            string n = XMLUtil.GetAttributeValue(condition, "negate").ToLower();

            if ("true".Equals(n) || "yes".Equals(n))
            {
                negate = true;
            }
            else
            {
                negate = false;
            }

            name = XMLUtil.GetAttributeValue(condition, "name");

            XmlNodeList args = condition.SelectNodes("arg");

            for (int l = 0; l < args.Count; l++)
            {
                XmlElement arg = (XmlElement)args[l];
                this.args.Add(XMLUtil.GetAttributeValue(arg, "name"), arg.InnerText);
            }
        }
    }
}
