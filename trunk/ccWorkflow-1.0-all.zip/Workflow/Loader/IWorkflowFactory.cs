#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Collections.Specialized;

namespace CchenSoft.Workflow.Loader
{
    public interface IWorkflowFactory
    {
        //~ Methods ////////////////////////////////////////////////////////////////

        void SetLayout(string workflowName, object layout);

        object GetLayout(string workflowName);

        bool IsModifiable(string name);

        string Name { get; }

        NameValueCollection Properties { get; }

        WorkflowDescriptor GetWorkflow(string name);

        /**
         * Get a workflow descriptor given a workflow name.
         * @param name The name of the workflow to get.
         * @return The descriptor for the specified workflow.
         * @throws com.opensymphony.workflow.FactoryException if the specified workflow name does not exist or cannot be located.
         */
        WorkflowDescriptor GetWorkflow(string name, bool validate);

        /**
           * Get all workflow names in the current factory
           * @return An array of all workflow names
           * @throws com.opensymphony.workflow.FactoryException if the factory cannot determine the names of the workflows it has.
           */
        string[] GetWorkflowNames();

        void CreateWorkflow(string name);

        void Init(NameValueCollection p);

        void InitDone();

        bool RemoveWorkflow(string name);

        void RenameWorkflow(string oldName, string newName);

        void Save();

        /**
           * Save the workflow.
           * Is it the responsibility of the caller to ensure that the workflow is valid,
           * through the {@link WorkflowDescriptor#validate()} method. Invalid workflows will
           * be saved without being checked.
           * @param name The name of the workflow to same.
           * @param descriptor The descriptor for the workflow.
           * @param replace true if an existing workflow with this name should be replaced.
           * @return true if the workflow was saved.
           * @throws com.opensymphony.workflow.FactoryException if there was an error saving the workflow
           * @throws com.opensymphony.workflow.InvalidWorkflowDescriptorException if the descriptor specified is invalid
           */
        bool SaveWorkflow(string name, WorkflowDescriptor descriptor, bool replace);
    }
}
