#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Web;
using System.Xml;
using System.Text;

namespace CchenSoft.Workflow.Loader
{
    public class XMLUtil
    {
        //~ Methods ////////////////////////////////////////////////////////////////

        //public static Element getChildElement(Element parent, String childName) {
        //    NodeList children = parent.getChildNodes();
        //    int size = children.getLength();

        //    for (int i = 0; i < size; i++) {
        //        Node node = children.item(i);

        //        if (node.getNodeType() == Node.ELEMENT_NODE) {
        //            Element element = (Element) node;

        //            if (childName.equals(element.getNodeName())) {
        //                return element;
        //            }
        //        }
        //    }

        //    return null;
        //}

        //public static List getChildElements(Element parent, String childName) {
        //    NodeList children = parent.getChildNodes();
        //    List list = new ArrayList();
        //    int size = children.getLength();

        //    for (int i = 0; i < size; i++) {
        //        Node node = children.item(i);

        //        if (node.getNodeType() == Node.ELEMENT_NODE) {
        //            Element element = (Element) node;

        //            if (childName.equals(element.getNodeName())) {
        //                list.add(element);
        //            }
        //        }
        //    }

        //    return list;
        //}

        //public static String getChildText(Element parent, String childName) {
        //    Element child = getChildElement(parent, childName);

        //    if (child == null) {
        //        return null;
        //    }

        //    return getText(child);
        //}

        //public static String getText(Element node) {
        //    StringBuffer sb = new StringBuffer();
        //    NodeList list = node.getChildNodes();

        //    for (int i = 0; i < list.getLength(); i++) {
        //        Node child = list.item(i);

        //        switch (child.getNodeType()) {
        //        case Node.CDATA_SECTION_NODE:
        //        case Node.TEXT_NODE:
        //            sb.append(child.getNodeValue());
        //        }
        //    }

        //    return sb.toString();
        //}

        public static string Encode(object str)
        {
            if (str == null)
            {
                return "";
            }

            return HttpUtility.HtmlEncode(str.ToString());
        }

        public static string GetAttributeValue(XmlElement el, string name)
        {
            XmlAttribute attr = (XmlAttribute)el.Attributes.GetNamedItem(name);
            return attr != null ? attr.Value : "";
        }

        public static void printIndent(XmlTextWriter writer, int indent)
        {
            // does nothing.
        }
    }
}
