#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.IO;
using System.Xml;
using System.Text;

namespace CchenSoft.Workflow.Loader
{
    public abstract class AbstractDescriptor : IXMLizable
    {
        //~ Instance fields ////////////////////////////////////////////////////////

        private AbstractDescriptor parent;
        private bool hasId = false;
        private int entityId;
        private int id;

        //~ Methods ////////////////////////////////////////////////////////////////

        public int EntityId
        {
            set { entityId = value; }
            get { return entityId; }
        }

        public int Id
        {
            set
            {
                id = value;
                hasId = true;
            }
            get
            {
                return id;
            }
        }

        public AbstractDescriptor Parent
        {
            set { parent = value; }
            get { return parent; }
        }

        public string AsXML()
        {
            StreamWriter sw = new StreamWriter(new MemoryStream());
            XmlTextWriter writer = new XmlTextWriter(sw);
            this.WriteXML(writer, 0);
            writer.Close();

            return sw.ToString();
        }

        public abstract void WriteXML(XmlTextWriter writer, int indent);

        public bool HasId()
        {
            return hasId;
        }
    }
}
