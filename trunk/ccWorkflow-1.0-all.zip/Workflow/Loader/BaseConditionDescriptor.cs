#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Collections;
using System.Xml;
using System;
namespace CchenSoft.Workflow.Loader
{
    public abstract class BaseConditionDescriptor : AbstractDescriptor, IValidatable
    {

        /**
         * The name field helps the editor identify the condition template used.
         */
        protected string type;

        //~ Constructors ///////////////////////////////////////////////////////////

        /**
         * @deprecated use {@link DescriptorFactory} instead
         */
        public BaseConditionDescriptor()
        {
        }

        /**
         * @deprecated use {@link DescriptorFactory} instead
         */
        public BaseConditionDescriptor(XmlElement element)
        {
            type = XMLUtil.GetAttributeValue(element, "type");
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public string Type
        {
            set { type = value; }
            get { return type; }
        }

        public abstract void Validate();
    }
}
