#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Collections.Specialized;
namespace CchenSoft.Workflow.Loader
{
    /**
     * Abstract base class for all workflow factories.
     * A workflow factory is a factory class that is able
     * to provide workflow descriptors given a workflow name,
     * as well as save descriptors.
     */
    public abstract class AbstractWorkflowFactory : IWorkflowFactory
    {
        //~ Instance fields ////////////////////////////////////////////////////////

        protected NameValueCollection properties = new NameValueCollection();

        //~ Methods ////////////////////////////////////////////////////////////////

        /**
           * Get the configuration properties of this factory
           */
        public NameValueCollection Properties
        {
            get { return properties; }
        }

        public void Init(NameValueCollection p)
        {
            this.properties = p;
        }

        /**
         * Get a workflow descriptor given a workflow name.
         * @param name The name of the workflow to get.
         * @return The descriptor for the specified workflow.
         * @throws FactoryException if the specified workflow name does not exist or cannot be located.
         *
         */
        public WorkflowDescriptor GetWorkflow(string name)
        {
            return GetWorkflow(name, true);
        }

        /**
           * Invoked after the properties of the factory have been set.
           * Subclasses should override this method and add any specific
           * setup code required. For example, connecting to an external resource
           * or database.
           * @throws FactoryException if there was an error during initialization.
           */
        public abstract void InitDone();

        public abstract void SetLayout(string workflowName, object layout);

        public abstract object GetLayout(string workflowName);

        public abstract bool IsModifiable(string name);

        public abstract string Name { get; }

        public abstract WorkflowDescriptor GetWorkflow(string name, bool validate);

        public abstract string[] GetWorkflowNames();

        public abstract void CreateWorkflow(string name);

        public abstract bool RemoveWorkflow(string name);

        public abstract void RenameWorkflow(string oldName, string newName);

        public abstract void Save();

        public abstract bool SaveWorkflow(string name, WorkflowDescriptor descriptor, bool replace);


    }
}
