#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Collections;
using System.Collections.Generic;

namespace CchenSoft.Workflow.Loader
{
    public class ValidationHelper
    {
        //~ Methods ////////////////////////////////////////////////////////////////

        //public static void validate(IList<IValidatable> c)
        //{
        //    foreach (IValidatable obj in c)
        //    {
        //        obj.Validate();
        //    }
        //}

        //public static void validate(IValidatable[] c)
        //{
        //    foreach (IValidatable obj in c)
        //    {
        //        obj.Validate();
        //    }
        //}

        public static void Validate(ICollection<IValidatable> c)
        {
            foreach (IValidatable obj in c)
            {
                obj.Validate();
            }
        }
    }
}
