#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.IO;
using System.Xml;

namespace CchenSoft.Workflow.Loader
{

    public class WorkflowLoader
    {
        //~ Methods ////////////////////////////////////////////////////////////////

        /**
         * @deprecated please use {@link #load(java.io.InputStream, bool)} instead.
         */
        public static WorkflowDescriptor Load(Stream stream)
        {
            return Load(stream, null, true);
        }

        public static WorkflowDescriptor Load(Stream stream, bool validate)
        {
            return Load(stream, null, validate);
        }

        /**
         * Load a workflow descriptor from a URL
         */
        public static WorkflowDescriptor Load(Uri url, bool validate)
        {
            //return load(url.openStream(), url, validate);
            return null;
        }

        private static WorkflowDescriptor Load(Stream stream, Uri url, bool validate)
        {
            //DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            //dbf.setNamespaceAware(true);

            //dbf.setValidating(validate);

            //DocumentBuilder db;

            //try {
            //    db = dbf.newDocumentBuilder();
            //    db.setEntityResolver(new DTDEntityResolver());
            //} catch (ParserConfigurationException e) {
            //    throw new SAXException("Error creating document builder", e);
            //}

            //db.setErrorHandler(new WorkflowErrorHandler(url));

            //Document doc = db.parse(is);

            //Element root = (Element) doc.getElementsByTagName("workflow").item(0);

            //WorkflowDescriptor descriptor = DescriptorFactory.getFactory().createWorkflowDescriptor(root);

            //if (validate) {
            //    descriptor.validate();
            //}
            XmlDocument doc = new XmlDocument();
            doc.Load(stream);

            WorkflowDescriptor descriptor = DescriptorFactory.GetFactory().CreateWorkflowDescriptor((XmlElement)doc.DocumentElement);

            return descriptor;
        }

        //~ Inner Classes //////////////////////////////////////////////////////////

        //public static class AllExceptionsErrorHandler : ErrorHandler {
        //    private List exceptions = new ArrayList();

        //    public List getExceptions() {
        //        return exceptions;
        //    }

        //    public void error(SAXParseException exception) {
        //        addMessage(exception);
        //    }

        //    public void fatalError(SAXParseException exception) {
        //        addMessage(exception);
        //    }

        //    public void warning(SAXParseException exception) {
        //    }

        //    private void addMessage(SAXParseException exception) {
        //        exceptions.add(exception.getMessage() + " (line:" + exception.getLineNumber() + ((exception.getColumnNumber() > -1) ? (" col:" + exception.getColumnNumber()) : "") + ')');
        //    }
        //}

        //public static class WorkflowErrorHandler : ErrorHandler {
        //    private URL url;

        //    public WorkflowErrorHandler(final URL url) {
        //        this.url = url;
        //    }

        //    public void error(SAXParseException exception) throws SAXException {
        //        throw new SAXException(getMessage(exception));
        //    }

        //    public void fatalError(SAXParseException exception) throws SAXException {
        //        throw new SAXException(getMessage(exception));
        //    }

        //    public void warning(SAXParseException exception) throws SAXException {
        //    }

        //    private string getMessage(SAXParseException exception) {
        //        return exception.getMessage() + " (" + ((url != null) ? (" url=" + url + ' ') : "") + "line:" + exception.getLineNumber() + ((exception.getColumnNumber() > -1) ? (" col:" + exception.getColumnNumber()) : "") + ')';
        //    }
        //}
    }
}
