#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Collections;
using System;
using CchenSoft.Workflow.Spi;
using System.Collections.Generic;

namespace CchenSoft.Workflow
{
    public class JoinNodes
    {
        //~ Instance fields ////////////////////////////////////////////////////////

        private IList<IStep> steps;
        private DummyStep dummy = new DummyStep();

        //~ Constructors ///////////////////////////////////////////////////////////

        public JoinNodes(IList<IStep> steps)
        {
            this.steps = steps;
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public IStep GetStep(int stepId)
        {
            foreach (IStep step in steps)
            {
                if (step.StepId == stepId)
                {
                    return step;
                }
            }

            // no match, not ready to join ...
            // ... so return a dummy step that is always false
            return dummy;
        }

        //~ Inner Classes //////////////////////////////////////////////////////////

        private class DummyStep : IStep
        {
            public int ActionId
            {
                get { return -1; }
            }

            public string Caller
            {
                get { return null; }
            }

            public DateTime? DueDate
            {
                get { return null; }
            }

            public long EntryId
            {
                get { return -1; }
            }

            public DateTime? FinishDate
            {
                get { return null; }
            }

            public long Id
            {
                get { return -1; }
            }

            public string Owner
            {
                get { return null; }
            }

            public long[] PreviousStepIds
            {
                get { return new long[0]; }
            }

            public DateTime StartDate
            {
                get { return DateTime.Now;}
            }

            public string Status
            {
                get { return null; }
            }

            public int StepId
            {
                get { return -1; }
            }

            public string AppendText
            {
                get { return null; }
            }
        }
    }
}
