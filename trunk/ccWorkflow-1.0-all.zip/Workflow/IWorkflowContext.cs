#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using CchenSoft.Workflow.Spi;

namespace CchenSoft.Workflow
{
    /**
     * Interface to be implemented if a new ccWorkflow interaction is to be created (SOAP, EJB, Ofbiz, etc).
     */
    public interface IWorkflowContext
    {

        //~ Methods ////////////////////////////////////////////////////////////////

        /**
         * @return the workflow caller.
         */
        string Caller { get; }

        IWorkflowModel Model { get; }

        IUserManager UserManager { get; }

        void Update();
    }
}
