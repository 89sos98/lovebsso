#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using log4net;
using System.Collections;
using System;

namespace CchenSoft.Workflow
{
    public class TypeResolver
    {
        //~ Static fields/initializers /////////////////////////////////////////////

        private static ILog log = LogManager.GetLogger(typeof(TypeResolver));

        //~ Instance fields ////////////////////////////////////////////////////////

        protected Hashtable conditions = new Hashtable();
        protected Hashtable functions = new Hashtable();
        protected Hashtable registers = new Hashtable();
        protected Hashtable validators = new Hashtable();

        //~ Constructors ///////////////////////////////////////////////////////////

        public TypeResolver()
        {
            validators.Add("python", "CchenSoft.Workflow.Util.Python.PythonValidator, CchenSoft.Workflow");
            conditions.Add("python", "CchenSoft.Workflow.Util.Python.PythonCondition, CchenSoft.Workflow");
            registers.Add("python", "CchenSoft.Workflow.Util.Python.PythonRegister, CchenSoft.Workflow");
            functions.Add("python", "CchenSoft.Workflow.Util.Python.PythonFunctionProvider, CchenSoft.Workflow");
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public ICondition GetCondition(string type, IDictionary args)
        {
            string className = (string)conditions[type];

            if (className == null)
            {
                className = (string)args[WorkflowConstants.CLASS_NAME];
            }

            if (className == null)
            {
                throw new WorkflowException("No type or class.name argument specified to TypeResolver");
            }

            return (ICondition)loadObject(className);
        }

        public IFunctionProvider GetFunction(string type, IDictionary args)
        {
            string className = (string)functions[type];

            if (className == null)
            {
                className = (string)args[WorkflowConstants.CLASS_NAME];
            }

            if (className == null)
            {
                throw new WorkflowException("No type or class.name argument specified to TypeResolver");
            }

            return (IFunctionProvider)loadObject(className);
        }

        public IRegister GetRegister(string type, IDictionary args)
        {
            string className = (string)registers[type];

            if (className == null)
            {
                className = (string)args[WorkflowConstants.CLASS_NAME];
            }

            if (className == null)
            {
                throw new WorkflowException("No type or class.name argument specified to TypeResolver");
            }

            return (IRegister)loadObject(className);
        }

        public IValidator GetValidator(string type, IDictionary args)
        {
            string className = (string)validators[type];

            if (className == null)
            {
                className = (string)args[WorkflowConstants.CLASS_NAME];
            }

            if (className == null)
            {
                throw new WorkflowException("No type or class.name argument specified to TypeResolver");
            }

            return (IValidator)loadObject(className);
        }

        protected object loadObject(string clazz)
        {
            try
            {
                Type type = Type.GetType(clazz);
                if (type != null)
                    return Activator.CreateInstance(type);
                return null;
                //return ClassLoaderUtil.loadClass(clazz.trim(), getClass()).newInstance();
            }
            catch (Exception e)
            {
                log.Error("Could not load class '" + clazz + "'", e);

                return null;
            }
        }
    }
}
