#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Collections;
using CchenSoft.Workflow.Spi;

namespace CchenSoft.Workflow
{
    /**
     * Interface that must be implemented for workflow registers to behave properly.
     */

    public interface IRegister
    {
        //~ Methods ////////////////////////////////////////////////////////////////

        /**
         * Returns the object to bind to the variable map for this workflow instance.
         *
         * @param context The current workflow context
         * @param entry The workflow entry. Note that this might be null, for example in a pre function
         * before the workflow has been initialised
         * @param args Map of arguments as set in the workflow descriptor

         * @param ps
         * @return the object to bind to the variable map for this workflow instance
         */
        object RegisterVariable(IWorkflowContext context, IWorkflowEntry entry, IDictionary args);
    }
}
