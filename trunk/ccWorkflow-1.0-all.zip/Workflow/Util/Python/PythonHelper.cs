#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using IronPython.Hosting;
using Microsoft.Scripting.Hosting;
using System.Scripting;

namespace CchenSoft.Workflow.Util.Python
{
    public class PythonHelper
    {
        public static object ExecuteScript(string script, IDictionary vars)
        {
            // ȡ��scope
            ScriptScope scope = PythonEngine.CurrentEngine.CreateScope();

            foreach (string key in vars.Keys)
            {
                scope.SetVariable(key, vars[key]);
            }

            string[] lines = script.Split('\n');
            List<string> list = new List<string>();
            for (int i = 0; i < lines.Length; i++)
            {
                string s = lines[i].Trim();
                if (s != "")
                {
                    list.Add(s);
                }
            }

            object ret = null;
            if (list.Count == 1)
            {
                ScriptSource source = scope.Engine.CreateScriptSourceFromString(list[0]);
                ret = source.Execute(scope);
            }
            else if (list.Count > 1)
            {
                string newScript = string.Join("\n", list.ToArray());
                ScriptSource source = scope.Engine.CreateScriptSourceFromString(newScript, SourceCodeKind.Statements);
                ret = source.Execute(scope);
            }
            return ret;
        }
    }
}
