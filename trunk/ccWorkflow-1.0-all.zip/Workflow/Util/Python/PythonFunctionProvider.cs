#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using log4net;
using System.Collections;
using CchenSoft.Workflow.Spi;
using System;

namespace CchenSoft.Workflow.Util.Python
{
    public class PythonFunctionProvider : IFunctionProvider
    {
        //~ Static fields/initializers /////////////////////////////////////////////

        private static ILog log = LogManager.GetLogger(typeof(PythonFunctionProvider));

        //~ Methods ////////////////////////////////////////////////////////////////

        public void Execute(IDictionary transientVars, IDictionary args)
        {
            string script = (string)args[WorkflowConstants.BSH_SCRIPT];

            IWorkflowContext context = (IWorkflowContext)transientVars["context"];
            IWorkflowEntry entry = (IWorkflowEntry)transientVars["entry"];

            try
            {
                Hashtable vars = new Hashtable();

                vars.Add("entry", entry);
                vars.Add("context", context);
                vars.Add("transientVars", transientVars);
                vars.Add("model", context.Model);

                PythonHelper.ExecuteScript(script, vars);
            }
            catch (Exception ex)
            {
                if (ex.InnerException is WorkflowException)
                {
                    throw (WorkflowException)ex.InnerException;
                }
                else
                {
                    String message = "Evaluation error while running Python function script";
                    throw new WorkflowException(message, ex.InnerException);
                }
            }
            finally
            {
            }
        }
    }
}
