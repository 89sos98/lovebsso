#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using log4net;
using System.Collections;
using System;
using CchenSoft.Workflow.Spi;
using Microsoft.Scripting.Hosting;
using IronPython.Hosting;

namespace CchenSoft.Workflow.Util.Python
{
    public class PythonValidator : IValidator
    {
        //~ Static fields/initializers /////////////////////////////////////////////

        private static ILog log = LogManager.GetLogger(typeof(PythonValidator));

        //~ Methods ////////////////////////////////////////////////////////////////

        public void Validate(IDictionary transientVars, IDictionary args)
        {
            try
            {
                string script = (string)args[WorkflowConstants.BSH_SCRIPT];

                IWorkflowContext context = (IWorkflowContext)transientVars["context"];
                IWorkflowEntry entry = (IWorkflowEntry)transientVars["entry"];

                Hashtable vars = new Hashtable();

                vars.Add("entry", entry);
                vars.Add("context", context);
                vars.Add("transientVars", transientVars);
                vars.Add("model", context.Model);

                object o = PythonHelper.ExecuteScript(script, vars);

                if (o != null)
                {
                    throw new InvalidInputException(o);
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException is WorkflowException)
                {
                    throw (WorkflowException)ex.InnerException;
                }
                else
                {
                    throw new WorkflowException("Unexpected exception in python validator script:" + ex.Message, ex);
                }
            }
            finally
            {
            }
        }
    }
}

