#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Collections;
using CchenSoft.Workflow.Spi;
using System;
using System.Collections.Generic;

namespace CchenSoft.Workflow.Util
{

    /**
     * <p>
     * A simple utility condition that returns true if the the current user (caller)
     * is the step owner.
     * </p>
     *
     * <p>
     * This condition may be used to deny the owner of the step by negating the
     * condition in the workflow descriptor with <code>negate='true'</code>.
     * <p>
     *
     * <p>
     * Looks at ALL current steps unless a step id is given in the optional argument
     * "stepId".
     * </p>
     *
     * <p>
     * The implementation was originally contained in AllowOwnerOfStepCondition by
     * Pat Lightbody.
     * </p>
     */
    public class IsUserOwnerCondition : ICondition
    {
        //~ Methods ////////////////////////////////////////////////////////////////

        // ////////////////////////////////////////////////////////////////
        public bool PassesCondition(IDictionary transientVars, IDictionary args)
        {
            int stepId = 0;
            string stepIdVal = (string)args["stepId"];

            if (stepIdVal != null)
            {
                try
                {
                    stepId = Convert.ToInt32(stepIdVal);
                }
                catch (Exception ex)
                {
                }
            }

            IWorkflowContext context = (IWorkflowContext)transientVars["context"];
            IWorkflowEntry entry = (IWorkflowEntry)transientVars["entry"];
            IWorkflowStore store = (IWorkflowStore)transientVars["store"];
            IList<IStep> currentSteps = store.FindCurrentSteps(entry.Id);

            if (stepId == 0)
            {
                foreach (IStep step in currentSteps)
                {
                    if ((step.Owner != null) && context.Caller.Equals(step.Owner))
                    {
                        return true;
                    }
                }
            }
            else
            {
                foreach (IStep step in currentSteps)
                {
                    if (stepId == step.StepId)
                    {
                        if ((step.Owner != null) && context.Caller.Equals(step.Owner))
                        {
                            return true;
                        }
                    }
                }
            }

            return false;
        }
    }
}
