#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using CchenSoft.Workflow.Spi;
using System.Collections;
using System;
using log4net;

namespace CchenSoft.Workflow.Util
{
    public class LogRegister : IRegister
    {
        //~ Methods ////////////////////////////////////////////////////////////////

        public object RegisterVariable(IWorkflowContext context, IWorkflowEntry entry, IDictionary args)
        {
            string workflowname = "unknown";
            long workflow_id = -1;

            if (entry != null)
            {
                workflowname = entry.WorkflowName;
                workflow_id = entry.Id;
            }

            bool groupByInstance = false;
            string useInstance = (string)args["addInstanceId"];

            if (useInstance != null)
            {
                groupByInstance = Convert.ToBoolean(useInstance);
            }

            string categoryName = "OSWorkflow";

            if (args["Category"] != null)
            {
                categoryName = (string)args["Category"];
            }

            string category = categoryName + "." + workflowname;

            if (groupByInstance)
            {
                category += ("." + workflow_id);
            }

            ILog log = LogManager.GetLogger(category);

            return log;
        }
    }
}
