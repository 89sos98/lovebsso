#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Collections;

namespace CchenSoft.Workflow.Util
{
    /**
     * @deprecated Use IsUserOwnerCondition instead
     * @see com.opensymphony.workflow.util.IsUserOwnerCondition
     *
     * Simple utility condition that returns true if the owner is the caller. Looks
     * at ALL current steps unless a stepId is given in the optional argument
     * "stepId".
     */
    public class AllowOwnerOnlyCondition : ICondition
    {
        //~ Methods ////////////////////////////////////////////////////////////////

        // ////////////////////////////////////////////////////////////////
        public bool PassesCondition(IDictionary transientVars, IDictionary args)
        {
            IsUserOwnerCondition isOwnerCondition = new IsUserOwnerCondition();

            return isOwnerCondition.PassesCondition(transientVars, args);
        }
    }
}
