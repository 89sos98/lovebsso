#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;

namespace CchenSoft.Workflow
{

    public class WorkflowException : Exception
    {
        //~ Instance fields ////////////////////////////////////////////////////////

        //private Throwable rootCause;

        //~ Constructors ///////////////////////////////////////////////////////////

        public WorkflowException()
        {
        }

        public WorkflowException(string s)
            :
            base(s)
        {
        }

        public WorkflowException(string s, Exception innerException)
            :
            base(s, innerException)
        {
        }

        public WorkflowException(Exception innerException)
            : base(innerException.Message, innerException)
        {
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        //public Throwable getCause() {
        //    return rootCause;
        //}

        //public string getMessage() {
        //    StringBuffer sb = new StringBuffer();
        //    string msg = super.getMessage();

        //    if (msg != null) {
        //        sb.append(msg);

        //        if (rootCause != null) {
        //            sb.append(": ");
        //        }
        //    }

        //    if (rootCause != null) {
        //        sb.append("root cause: " + ((rootCause.getMessage() == null) ? rootCause.toString() : rootCause.getMessage()));
        //    }

        //    return sb.toString();
        //}

        //public Throwable getRootCause() {
        //    return rootCause;
        //}

        //public void printStackTrace() {
        //    super.printStackTrace();

        //    if (rootCause != null) {
        //        synchronized (System.err) {
        //            System.err.println("\nRoot cause:");
        //            rootCause.printStackTrace();
        //        }
        //    }
        //}

        //public void printStackTrace(PrintStream s) {
        //    super.printStackTrace(s);

        //    if (rootCause != null) {
        //        synchronized (s) {
        //            s.println("\nRoot cause:");
        //            rootCause.printStackTrace(s);
        //        }
        //    }
        //}

        //public void printStackTrace(PrintWriter s) {
        //    super.printStackTrace(s);

        //    if (rootCause != null) {
        //        synchronized (s) {
        //            s.println("\nRoot cause:");
        //            rootCause.printStackTrace(s);
        //        }
        //    }
        //}
    }
}
