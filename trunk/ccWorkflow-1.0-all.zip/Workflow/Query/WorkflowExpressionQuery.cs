#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

namespace CchenSoft.Workflow.Query
{
    /**
     * Workflow Query.
     * A workflow expression-based query is constructed by specifying a number of expressions in the query.
     * Currently queries can only have one operator act on them. Either the expressions are either evaluated
     * with an OR, whereby the first expression that passes results in inclusion of a result, or with an AND,
     * whereby all expressions must return true for a result to be included.
     */
    public class WorkflowExpressionQuery
    {
        //~ Static fields/initializers /////////////////////////////////////////////

        public const int SORT_NONE = 0;
        public const int SORT_ASC = 1;
        public const int SORT_DESC = -1;

        //~ Instance fields ////////////////////////////////////////////////////////

        private Expression expression = null;
        private int orderBy;
        private int sortOrder;

        //~ Constructors ///////////////////////////////////////////////////////////

        public WorkflowExpressionQuery()
        {
        }

        /**
         * Create a WorkflowExpressionQuery that consists of one expression.
         */
        public WorkflowExpressionQuery(Expression expression)
        {
            this.expression = expression;
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public Expression Expression
        {
            get { return expression; }
            set { this.expression = value; }
        }

        public int OrderBy
        {
            get { return orderBy; }
            set { this.orderBy = value; }
        }

        public int SortOrder
        {
            get { return sortOrder; }
            set { this.sortOrder = value; }
        }
    }
}
