#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

namespace CchenSoft.Workflow.Query
{

    /**
     * Field expressions are used when constructing a workflow query on the fields
     * of persistent workflow instances like (START_DATE, OWNER,....).
     * Field expressions have three attributes. These are:
     * <li>operator: This is the operator to apply on the expression.
     * <li>field: The workflow field to test agains
     * <li>Context: The context to search in, which can be one history, current steps, or a workflow instance.
     */
    public class FieldExpression : Expression
    {
        //~ Static fields/initializers /////////////////////////////////////////////

        // field operators

        /**
         * Constant for the equality operator.
         */
        public const int EQUALS = 1;

        /**
         * Constant for the less than operator.
         */
        public const int LT = 2;

        /**
         * Constant for the greater than operator.
         */
        public const int GT = 3;

        /**
         * Constant for the not equals operator.
         */
        public const int NOT_EQUALS = 5;

        // fields

        /**
         * Constant for the workflow owner field.
         */
        public const int OWNER = 1;

        /**
         * Constant for the workflow start date field.
         */
        public const int START_DATE = 2;

        /**
         * Constant for the workflow finish date field.
         */
        public const int FINISH_DATE = 3;

        /**
         * Constant for the workflow action field.
         */
        public const int ACTION = 4;

        /**
         * Constant for the workflow step field.
         */
        public const int STEP = 5;

        /**
         * Constant for the workflow caller field.
         */
        public const int CALLER = 6;

        /**
         * Constant for the workflow status field.
         */
        public const int STATUS = 7;

        /**
         * Constant for the workflow name field.
         */
        public const int NAME = 8;

        /**
        * Constant for the state field.
        */
        public const int STATE = 9;

        /**
        * Constant for the workflow due date field.
        */
        public const int DUE_DATE = 10;

        // field context

        /**
         * Constant for the history steps context.
         * Specifying this context means that the search
         * should be performed against the workflow steps.
         */
        public const int HISTORY_STEPS = 1;

        /**
         * Constant for the history steps context.
         * Specifying this context means that the search
         * should be performed against the workflow current steps.
         */
        public const int CURRENT_STEPS = 2;

        /**
         * Constant for the workflow entry context.
         * Specifying this context means that the search
         * should be performed against the workflow entries.
         */
        public const int ENTRY = 3;

        //~ Instance fields ////////////////////////////////////////////////////////

        private object value;
        private int context;
        private int field;
        private int operat;

        //~ Constructors ///////////////////////////////////////////////////////////

        public FieldExpression()
        {
        }

        public FieldExpression(int field, int context, int operat, object value)
        {
            this.context = context;
            this.operat = operat;
            this.field = field;
            this.value = value;
        }

        public FieldExpression(int field, int context, int operat, object value, bool negate)
            : this(field, context, operat, value)
        {
            
            base.negate = negate;
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public int Context
        {
            get { return context; }
            set { this.context = value; }
        }

        public int Field
        {
            get { return field; }
            set { this.field = value; }
        }

        public override bool IsNested()
        {
            return false;
        }

        public int Operator
        {
            get { return operat; }
            set { this.operat = value; }
        }

        public object Value
        {
            get { return value; }
            set { this.value = value; }
        }
    }
}
