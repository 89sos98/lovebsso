#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

namespace CchenSoft.Workflow.Query
{
    /**
     * @deprecated use {@link WorkflowExpressionQuery} instead
     */
    public class WorkflowQuery
    {
        //~ Static fields/initializers /////////////////////////////////////////////

        public const int EQUALS = 1;
        public const int LT = 2;
        public const int GT = 3;
        public const int BETWEEN = 4;
        public const int NOT_EQUALS = 5;
        public const int AND = 6;
        public const int OR = 7;
        public const int XOR = 8;
        public const int OWNER = 1;
        public const int START_DATE = 2;
        public const int FINISH_DATE = 3;
        public const int ACTION = 4;
        public const int STEP = 5;
        public const int CALLER = 6;
        public const int STATUS = 7;
        public const int HISTORY = 1;
        public const int CURRENT = 2;

        //~ Instance fields ////////////////////////////////////////////////////////

        private object value;
        private WorkflowQuery left;
        private WorkflowQuery right;
        private int field;
        private int operat;
        private int type;

        //~ Constructors ///////////////////////////////////////////////////////////

        public WorkflowQuery()
        {
        }

        public WorkflowQuery(WorkflowQuery left, int operat, WorkflowQuery right)
        {
            this.operat = operat;
            this.left = left;
            this.right = right;
        }

        public WorkflowQuery(int field, int type, int operat, object value)
        {
            this.type = type;
            this.operat = operat;
            this.field = field;
            this.value = value;
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public int Field
        {
            get { return field; }
        }

        public WorkflowQuery Left
        {
            get { return left; }
        }

        public int Operator
        {
            get { return operat; }
        }

        public WorkflowQuery Right
        {
            get { return right; }
        }

        public int Type
        {
            get
            {
                int qtype = type;

                if (qtype == 0)
                {
                    if (left != null)
                    {
                        qtype = left.Type;
                    }
                }

                return qtype;
            }
        }

        public object Value
        {
            get { return value; }
        }
    }
}
