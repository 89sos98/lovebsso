#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

namespace CchenSoft.Workflow.Query
{
    /**
     * Abstract base class for expressions used in a workflow query.
     * Expressions can be negate and/or nested. The default is not negate.
     * <p></p>
     * Expressions which are supported by all stores are {@link FieldExpression} and {@link NestedExpression}.
     * <p></p>
     * Store specific expressions like XPathExpression can be added.
     */
    public abstract class Expression
    {
        //~ Instance fields ////////////////////////////////////////////////////////

        protected bool negate = false;

        //~ Constructors ///////////////////////////////////////////////////////////

        protected Expression()
        {
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public bool Negate
        {
            get { return negate; }
        }

        abstract public bool IsNested();
    }
}
