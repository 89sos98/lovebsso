#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

namespace CchenSoft.Workflow.Query
{
    /**
     * Nested expressions are used when constructing a workflow query.
     * A nested expression consists of:
     * <li>one or more expressions: Each of them can again be a NestedExpression.
     * <li>operator: The operator used to evaluate the value of the nested expression
     *     from the specified sub expressions.
     */
    public class NestedExpression : Expression
    {
        //~ Static fields/initializers /////////////////////////////////////////////

        /**
        * Constant to specify that all the expressions specified must evaluate to true for
        * an item to be included in the search results.
        */
        public const int AND = 6;

        /**
         * Constant to specify that at least one of the expressions specified must evaluate to true
         * for an item to be included in the search results.
         */
        public const int OR = 7;

        //~ Instance fields ////////////////////////////////////////////////////////

        private Expression[] expressions = null;
        private int expressionOperator = AND;

        //~ Constructors ///////////////////////////////////////////////////////////

        public NestedExpression()
        {
        }

        /**
        * Create a NestedExpression that consists of multiple expressions.
        * @param expressions an array of expressions for this query.
        * @param operator {@link NestedExpression#AND} or {@link NestedExpression#OR}.
        */
        public NestedExpression(Expression[] expressions, int operat)
        {
            this.expressions = expressions;
            this.expressionOperator = operat;
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public Expression GetExpression(int index)
        {
            return expressions[index];
        }

        /**
         * Get the number of expressions in this query.
         */
        public int ExpressionCount
        {
            get { return expressions.Length; }
        }

        /**
         * @return {@link NestedExpression#AND} if all the expressions must match,
         * or {@link NestedExpression#OR} if only one must match.
         */
        public int ExpressionOperator
        {
            get { return this.expressionOperator; }
            set { this.expressionOperator = value; }
        }

        public void SetExpressions(Expression[] expressions)
        {
            this.expressions = expressions;
        }

        public override bool IsNested()
        {
            return true;
        }
    }
}
