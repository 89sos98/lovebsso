#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
namespace CchenSoft.Workflow.Spi
{
    /**
     * Interface for a step associated with a workflow instance.
     */
    public interface IStep
    {
        //~ Methods ////////////////////////////////////////////////////////////////

        /**
         * Returns the ID of the action associated with this step,
         * or 0 if there is no action associated.
         */
        int ActionId { get; }

        string Caller { get; }
        /**
         * Returns an optional date signifying when this step must be finished.
         */
        DateTime? DueDate { get; }

        /**
         * Returns the unique ID of the workflow entry.
         */
        long EntryId { get; }

        /**
         * Returns the date this step was finished, or null if it isn't finished.
         */
        DateTime? FinishDate { get; }

        /**
         * Returns the unique ID of this step.
         */
        long Id { get; }

        /**
         * Returns the owner of this step, or null if there is no owner.
         */
        string Owner { get; }

        /**
         * Returns the unique ID of the previous step, or 0 if this is the first step.
         */
        long[] PreviousStepIds { get; }

        /**
         * Returns the date that this step was created.
         */
        DateTime StartDate { get; }

        /**
         * Returns the status of this step.
         */
        string Status { get; }

        /**
         * Returns the ID of the step in the workflow definition.
         */
        int StepId { get; }

        /**
         * Append Text
         */
        string AppendText { get; }
    }
}
