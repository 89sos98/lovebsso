#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

namespace CchenSoft.Workflow.Spi
{
    /**
     * Interface for a workflow entry.
     */
    public class WorkflowEntryState
    {
        public const int CREATED = 0;
        public const int ACTIVATED = 1;
        public const int SUSPENDED = 2;
        public const int KILLED = 3;
        public const int COMPLETED = 4;
        public const int UNKNOWN = -1;
    }

    public interface IWorkflowEntry
    {
        //~ Static fields/initializers /////////////////////////////////////////////



        //~ Methods ////////////////////////////////////////////////////////////////

        /**
         * Returns the unique ID of the workflow entry.
         */
        long Id { get; }

        /**
         * Returns true if the workflow entry has been initialized.
         */
        bool Initialized { get; }

        int State { get; }

        /**
         * Returns the name of the workflow that this entry is an instance of.
         */
        string WorkflowName { get; }
    }
}
