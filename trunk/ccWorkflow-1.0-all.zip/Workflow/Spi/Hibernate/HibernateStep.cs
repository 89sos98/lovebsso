#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
namespace CchenSoft.Workflow.Spi.Hibernate
{
    /**
     * This abstract class provides all the implementation of the step interface
     * It is abstract because the current and historical steps are stored in seperate tables.
     * To split the history and current steps into two tables in hibernate, the easiest approach is to use
     * two separate classes.
     */
    public abstract class HibernateStep : IStep
    {
        //~ Instance fields ////////////////////////////////////////////////////////

        DateTime? dueDate;
        DateTime? finishDate;
        DateTime startDate;
        HibernateWorkflowEntry entry;
        IList previousSteps;
        string caller;
        string owner;
        string status;
        int actionId;
        int stepId;
        string appendText;
        long id = -1;

        //~ Constructors ///////////////////////////////////////////////////////////

        public HibernateStep()
        {
        }

        public HibernateStep(HibernateStep step)
        {
            this.actionId = step.ActionId;
            this.caller = step.Caller;
            this.finishDate = step.FinishDate;
            this.dueDate = step.DueDate;
            this.startDate = step.StartDate;

            //do not copy this value, it's for unsaved-value
            //this.id = step.getId();
            this.owner = step.Owner;
            this.status = step.Status;
            this.stepId = step.StepId;
            this.previousSteps = step.PreviousSteps;
            this.entry = step.Entry;
            this.appendText = step.AppendText;
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public int ActionId
        {
            set { actionId = value; }
            get { return actionId; }
        }

        public string Caller
        {
            set { caller = value; }
            get { return caller; }
        }

        public DateTime? DueDate
        {
            set { dueDate = value; }
            get { return dueDate; }
        }

        public HibernateWorkflowEntry Entry
        {
            set { entry = value; }
            get { return entry; }
        }

        public long EntryId
        {
            get { return entry.Id; }
        }

        public DateTime? FinishDate
        {
            set { finishDate = value; }
            get { return finishDate; }
        }

        public long Id
        {
            set { id = value; }
            get { return id; }
        }

        public string Owner
        {
            set { owner = value; }
            get { return owner; }
        }

        public long[] PreviousStepIds
        {
            get
            {
                if (previousSteps == null)
                {
                    return new long[0];
                }

                long[] previousStepIds = new long[previousSteps.Count];
                int i = 0;

                foreach (HibernateStep hibernateStep in previousSteps)
                {
                    previousStepIds[i] = hibernateStep.Id;
                    i++;
                }

                return previousStepIds;
            }
        }

        public IList PreviousSteps
        {
            set { previousSteps = value; }
            get { return previousSteps; }
        }

        public DateTime StartDate
        {
            set { startDate = value; }
            get { return startDate; }
        }

        public string Status
        {
            set { status = value; }
            get { return status; }
        }

        public int StepId
        {
            set { stepId = value; }
            get { return stepId; }
        }

        public string AppendText
        {
            set { appendText = value; }
            get { return appendText; }
        }
    }
}
