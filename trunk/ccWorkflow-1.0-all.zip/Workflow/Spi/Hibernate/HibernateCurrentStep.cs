#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

namespace CchenSoft.Workflow.Spi.Hibernate
{
    /**
     * This class exists to seperate the persistence of the Steps.
     *  By seperating out the Current Step from the Previous
     *  Step classes, they can be easily written into seperate tables.
     *  @see {@link HibernateHistoryStep}
     */
    public class HibernateCurrentStep : HibernateStep
    {
        //~ Constructors ///////////////////////////////////////////////////////////

        public HibernateCurrentStep()
        {
        }

        public HibernateCurrentStep(HibernateStep step) : base(step)
        {
        }
    }
}
