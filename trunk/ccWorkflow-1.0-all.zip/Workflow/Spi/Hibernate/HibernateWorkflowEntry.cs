#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Collections;
using System.Collections.Generic;
namespace CchenSoft.Workflow.Spi.Hibernate
{
    public class HibernateWorkflowEntry : IWorkflowEntry
    {
        //~ Instance fields ////////////////////////////////////////////////////////

        IList<IStep> currentSteps = new List<IStep>();
        IList<IStep> historySteps = new List<IStep>();
        string workflowName;
        long id = -1;
        private int state;
        private int version;

        //~ Methods ////////////////////////////////////////////////////////////////

        public IList<IStep> CurrentSteps
        {
            set { currentSteps = value; }
            get { return currentSteps; } 
        }

        public IList<IStep> HistorySteps
        {
            set { historySteps = value; }
            get { return historySteps; }
        }

        public long Id
        {
            set { id = value; }
            get { return id; }
        }

        public bool Initialized
        {
            get { return state > 0; }
        }

        public int State
        {
            set { state = value; }
            get { return state; }
        }

        public string WorkflowName
        {
            set { workflowName = value; }
            get { return workflowName; }
        }

        public void AddCurrentSteps(HibernateCurrentStep step)
        {
            step.Entry = this;
            currentSteps.Add(step);
        }

        public void AddHistorySteps(HibernateHistoryStep step)
        {
            step.Entry = this;
            historySteps.Add(step);
        }

        public void RemoveCurrentSteps(HibernateCurrentStep step)
        {
            currentSteps.Remove(step);
        }

        protected int Version
        {
            set { version = value; }
            get { return version; }
        }
    }
}
