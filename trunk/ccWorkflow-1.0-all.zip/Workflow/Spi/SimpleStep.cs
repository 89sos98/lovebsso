#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
namespace CchenSoft.Workflow.Spi
{
    /**
     * Simple implementation
     */
    public class SimpleStep : IStep
    {
        //~ Static fields/initializers /////////////////////////////////////////////

        //~ Instance fields ////////////////////////////////////////////////////////

        private DateTime? dueDate;
        private DateTime? finishDate;
        private DateTime startDate;
        private string caller;
        private string owner;
        private string status;
        private string appendText;
        private long[] previousStepIds;
        private int actionId;
        private int stepId;
        private long entryId;
        private long id;

        //~ Constructors ///////////////////////////////////////////////////////////

        public SimpleStep()
        {
        }

        public SimpleStep(long id, long entryId, int stepId, int actionId, string owner, DateTime startDate, DateTime? dueDate, DateTime? finishDate, string status, long[] previousStepIds, string caller)
        {
            this.id = id;
            this.entryId = entryId;
            this.stepId = stepId;
            this.actionId = actionId;
            this.owner = owner;
            this.startDate = startDate;
            this.finishDate = finishDate;
            this.dueDate = dueDate;
            this.status = status;
            this.previousStepIds = previousStepIds;
            this.caller = caller;
        }

        //~ Methods ////////////////////////////////////////////////////////////////

        public int ActionId
        {
            set { actionId = value; }
            get { return actionId; }
        }

        public string Caller
        {
            set { caller = value; }
            get { return caller; }
        }

        public DateTime? DueDate
        {
            set { dueDate = value; }
            get { return dueDate; }
        }

        public long EntryId
        {
            set { entryId = value; }
            get { return entryId; }
        }

        public DateTime? FinishDate
        {
            set { finishDate = value; }
            get { return finishDate; }
        }

        public long Id
        {
            set { id = value; }
            get { return id; }
        }

        public string Owner
        {
            set { owner = value; }
            get { return owner; }
        }

        public long[] PreviousStepIds
        {
            set { previousStepIds = value; }
            get { return previousStepIds; }
        }

        public DateTime StartDate
        {
            set { startDate = value; }
            get { return startDate; }
        }

        public string Status
        {
            set { status = value; }
            get { return status; }
        }

        public int StepId
        {
            set { stepId = value; }
            get { return stepId; }
        }

        public string AppendText
        {
            get { return appendText; }
            set { appendText = value; }
        }

        public override string ToString()
        {
            return "SimpleStep@" + stepId + "[owner=" + owner + ", actionId=" + actionId + ", status=" + status + "]";
        }
    }
}
