#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using Quartz;
using log4net;

namespace CchenSoft.Workflow.Timer
{
    public class WorkflowJob : IJob
    {
        //~ Static fields/initializers /////////////////////////////////////////////

        private static ILog log = LogManager.GetLogger(typeof(WorkflowJob));

        //~ Methods ////////////////////////////////////////////////////////////////

        public void Execute(JobExecutionContext jobExecutionContext)
        {
            //try {
            //    JobDataMap data = jobExecutionContext.getJobDetail().getJobDataMap();
            //    long id = data.getLong("entryId");
            //    int triggerId = data.getInt("triggerId");
            //    String username = data.getString("username");
            //    String password = data.getString("password");
            //    Context context = new Context();
            //    context.setProperty("authUser", username);
            //    context.setProperty("authPassword", password);

            //    Workflow wf = (Workflow) Registry.bind(System.getProperty("osworkflow.soap.url", "http://localhost/example/glue/oswf.wsdl"), Workflow.class, context);
            //    wf.executeTriggerFunction(id, triggerId);
            //} catch (RegistryException e) {
            //    log.error("Error using GLUE to make remote call", e);
            //    throw new JobExecutionException("Error using GLUE to make remote call", e, true);
            //} catch (WorkflowException e) {
            //    log.error("Error Executing trigger", e);

            //    //this cast is a fairly horrible hack, but it's more due to the fact that quartz is stupid enough to have wrapped exceptions
            //    //wrap Exception, instead of Throwable.
            //    throw new JobExecutionException("Error Executing trigger", (e.getRootCause() != null) ? (Exception) e.getRootCause() : e, true);
            //}
        }
    }
}
