#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Collections;

namespace CchenSoft.Workflow
{
    public interface IFunctionProvider
    {
        //~ Methods ////////////////////////////////////////////////////////////////

        /**
         * Execute this function
         * @param transientVars Variables that will not be persisted. These include inputs
         * given in the {@link Workflow#initialize} and {@link Workflow#doAction} method calls.
         * There are a number of special variable names:
         * <ul>
         * <li><code>entry</code>: (object type: {@link com.opensymphony.workflow.spi.WorkflowEntry})
         *  The workflow instance
         * <li><code>context</code>:
         * (object type: {@link com.opensymphony.workflow.WorkflowContext}). The workflow context.
         * <li><code>actionId</code>: The Integer ID of the current action that was take (if applicable).
         * <li><code>currentSteps</code>: A Collection of the current steps in the workflow instance.
         * <li><code>store</code>: The {@link com.opensymphony.workflow.spi.WorkflowStore}.
         * <li><code>descriptor</code>: The {@link com.opensymphony.workflow.loader.WorkflowDescriptor}.
         * </ul>
         * Also, any variable set as a {@link com.opensymphony.workflow.Register}), will also be
         * available in the transient map, no matter what. These transient variables only last through
         * the method call that they were invoked in, such as {@link Workflow#initialize}
         * and {@link Workflow#doAction}.
         * @param args The properties for this function invocation. Properties are created
         * from arg nested elements within the xml, an arg element takes in a name attribute
         * which is the properties key, and the CDATA text contents of the element map to
         * the property value.
         * @param ps The persistent variables that are associated with the current
         * instance of the workflow. Any change made to the propertyset are persisted to
         * the propertyset implementation's persistent store.
         */
        void Execute(IDictionary transientVars, IDictionary args);
    }
}
