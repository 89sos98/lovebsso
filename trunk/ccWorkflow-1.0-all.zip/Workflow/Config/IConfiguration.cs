#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System.Collections;
using System;
using CchenSoft.Workflow.Spi;
using CchenSoft.Workflow.Loader;

namespace CchenSoft.Workflow.Config
{
    /**
     * Configuration object that is responsible for all 'static' workflow information.
     * This includes loading of workflow configurations, setting up the workflow
     * descriptor factory, as well as proxying calls to the underlying descriptor
     * factory.
     */

    public interface IConfiguration
    {
        //~ Methods ////////////////////////////////////////////////////////////////

        /**
         * @return true if this factory has been initialised.
         * If the factory is not initialised, then {@link #load(java.net.URL)}
         * will be called.
         */
        bool IsInitialized();

        /**
         * Check if a particular workflow can be modified or not.
         * @param name The workflow name.
         * @return true if the workflow can be modified, false otherwise.
         */
        bool IsModifiable(string name);

        ///**
        // * Get the fully qualified class name of the persistence store.
        // */
        //string PersistenceClass { get; }

        ///**
        // * Get the persistence args for the persistence store.
        // * Note that this returns the actual args and not a copy,
        // * so modifications to the returned Map could potentially
        // * affect store behaviour.
        // */
        //IDictionary PersistenceArgs { get; }

        /**
         * Return the resolver to use for all variables specified in scripts
         */
        IVariableResolver VariableResolver { get; }

        TypeResolver TypeResolver { get; }

        /**
         * Get the named workflow descriptor.
         * @param name the workflow name
         * @throws FactoryException if there was an error looking up the descriptor or if it could not be found.
         */
        WorkflowDescriptor GetWorkflow(string name);

        /**
         * Get a list of all available workflow descriptor names.
         * @throws FactoryException if the underlying factory does not support this method
         * or if there was an error looking up workflow names.
         */
        string[] GetWorkflowNames();

        IWorkflowStore WorkflowStore { get; }

        /**
         * Load the specified configuration file.
         * @param url url to the configuration file.
         */
        void Load(string filename);

        /**
         * Remove the specified workflow.
         * @param workflow The workflow name of the workflow to remove.
         * @return true if the workflow was removed, false otherwise.
         * @throws FactoryException If the underlying workflow factory has an error removing the workflow,
         * or if it does not support the removal of workflows.
         */
        bool RemoveWorkflow(string workflow);

        bool SaveWorkflow(string name, WorkflowDescriptor descriptor, bool replace);
    }
}
