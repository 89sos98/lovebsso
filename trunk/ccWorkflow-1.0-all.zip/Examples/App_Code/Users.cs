﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// Users 的摘要说明
/// </summary>
public class Users
{
    private static IDictionary<string, string> users;
    private static IDictionary<string, IList<string>> groups;

    static Users()
    {
        users = new Dictionary<string, string>();
        groups = new Dictionary<string, IList<string>>();

        users.Add("user1", "111111");
        users.Add("user2", "222222");
        users.Add("manage1", "222222");

        IList<string> group1Users = new List<string>();
        group1Users.Add("user1");
        group1Users.Add("user2");

        IList<string> group2Users = new List<string>();
        group2Users.Add("manage1");

        groups.Add("employee", group1Users);
        groups.Add("manager", group2Users);
    }

    public static bool SignIn(string username, string passwd)
    {
        if (users.ContainsKey(username))
            return (users[username].Equals(passwd));
        return false;
    }

    public static bool IsUserInGroup(string username, string group)
    {
        if (groups.ContainsKey(group))
        {
            return groups[group].Contains(username);
        }

        throw new Exception("group not exists, " + group);
    }
}
