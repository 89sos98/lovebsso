﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// BasePage 的摘要说明
/// </summary>
public class BasePage : Page
{
    protected string username;

    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);

        username = (string)Session["username"];
        if (string.IsNullOrEmpty(username))
            Response.Redirect("default.aspx");
    }
}
