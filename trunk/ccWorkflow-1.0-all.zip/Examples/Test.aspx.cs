﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CchenSoft.Workflow;
using CchenSoft.Workflow.Basic;
using CchenSoft.Workflow.Loader;
using CchenSoft.Workflow.Spi;
using System.Collections.Generic;
using CchenSoft.Common.Utils;

public partial class test : BasePage
{
    WorkflowDescriptor wd;
    IWorkflow wf;

    protected void Page_Load(object sender, EventArgs e)
    {
        IWorkflowContext context = new BasicWorkflowContext(username, new MyUserManager());
        WorkflowManager manager = new WorkflowManager(context);
        wf = manager.GetWorkflow(RequestUtil.GetInt32("id"));
        wd = wf.Descriptor;

        if (!IsPostBack)
        {
            int[] actions = wf.GetAvailableActions(null);
            rptAction.DataSource = actions;

            List<IStep> steps = new List<IStep>();
            steps.AddRange(wf.GetCurrentSteps());
            steps.AddRange(wf.GetHistorySteps());
            rptWorkflow.DataSource = steps;

            rptAction.DataBind();
            rptWorkflow.DataBind();
        }
    }

    protected void rptAction_ItemCommand(object sender, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.Equals("DoAction"))
        {
            int action = Convert.ToInt32((string)e.CommandArgument);

            //IPropertySet ps = wf.GetPropertySet();
            //if (!string.IsNullOrEmpty(txtName1.Text))
            //    ps.SetString(txtName1.Text, txtValue1.Text);
            //if (!string.IsNullOrEmpty(txtName2.Text))
            //    ps.SetString(txtName2.Text, txtValue2.Text);

            wf.DoAction(action, null);
        }
        Response.Redirect(Request.Url.ToString());
    }

    protected void rptAction_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item ||
            e.Item.ItemType == ListItemType.AlternatingItem)
        {
            int action = (int)e.Item.DataItem;

            ActionDescriptor ad = wd.GetAction(action);

            LinkButton lnkAction = (LinkButton)e.Item.FindControl("lnkAction");
            lnkAction.Text = ad.Name;
            lnkAction.CommandArgument = action.ToString();
            //hlnkAction.NavigateUrl = string.Format("test.aspx?id={0}&do={1}", workflowId, action);
        }
    }

    protected void rptWorkflow_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item ||
            e.Item.ItemType == ListItemType.AlternatingItem)
        {
            IStep step = (IStep)e.Item.DataItem;

            ActionDescriptor ad = wd.GetAction(step.ActionId);
            StepDescriptor sd = wd.GetStep((int)step.StepId);

            ((Label)e.Item.FindControl("lblStep")).Text = sd.Name + " " + step.Id;
            ((Label)e.Item.FindControl("lblAction")).Text = (ad == null) ? "NONE" : ad.Name;
            ((Label)e.Item.FindControl("lblStatus")).Text = step.Status;
            ((Label)e.Item.FindControl("lblOwner")).Text = step.Owner;
            ((Label)e.Item.FindControl("lblStartDate")).Text = step.StartDate.ToString();
            ((Label)e.Item.FindControl("lblFinishDate")).Text = step.FinishDate.ToString();

            long[] prevIds = step.PreviousStepIds;
            string str = "";
            for (int i = 0; i < prevIds.Length; i++)
                str += prevIds[i] + ",";
            ((Label)e.Item.FindControl("lblPreviousSteps")).Text = prevIds != null ? str : "NONE";        
            

        }
    }
}
