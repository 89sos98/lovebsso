﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CchenSoft.Workflow;
using CchenSoft.Workflow.Basic;

public partial class NewWorkflow : BasePage
{
    public long WorkflowId;

    protected void Page_Load(object sender, EventArgs e)
    {
        IWorkflowContext context = new BasicWorkflowContext(username);
        WorkflowManager manager = new WorkflowManager(context);
        IWorkflow wf = manager.CreateWorkflow("example", 100, null);
        WorkflowId = wf.WorkflowId;
    }
}
