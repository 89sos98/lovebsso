﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        if (Users.SignIn(txtUsername.Text, txtPassword.Text))
        {
            Session["username"] = txtUsername.Text;
            Response.Redirect("nav.aspx");
        }
        else
        {
            Response.Write("用户名或密码错误！请查看Users.cs文件");
        }
    }
}
