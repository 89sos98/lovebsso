﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CchenSoft.Workflow;
using CchenSoft.Workflow.Basic;
using CchenSoft.Workflow.Query;

public partial class Underway : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        IWorkflowContext context = new BasicWorkflowContext(username, new MyUserManager());
        WorkflowManager manager = new WorkflowManager(context);

        WorkflowQuery queryLeft = new WorkflowQuery(WorkflowQuery.OWNER, WorkflowQuery.CURRENT, WorkflowQuery.EQUALS, username);
        WorkflowQuery queryRight = new WorkflowQuery(WorkflowQuery.STATUS, WorkflowQuery.CURRENT, WorkflowQuery.EQUALS, "Underway");
        WorkflowQuery query = new WorkflowQuery(queryLeft, WorkflowQuery.AND, queryRight);
        rptWorkflow.DataSource = manager.Query(query);
        rptWorkflow.DataBind();
    }

    protected void rptWorkflow_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item ||
            e.Item.ItemType == ListItemType.AlternatingItem)
        {
            long workflowId = (long)e.Item.DataItem;

            HyperLink hlnkWorkflow = (HyperLink)e.Item.FindControl("hlnkWorkflow");
            hlnkWorkflow.Text = workflowId.ToString();
            hlnkWorkflow.NavigateUrl = string.Format("test.aspx?id={0}", workflowId);
        }
    }
}
