﻿#region 版权声明
/**
 * 版权声明：LumaQQ.NET是基于LumaQQ分析的QQ协议，将其部分代码进行修改和翻译为.NET版本，并且继续使用LumaQQ的开源协议。
 * 本人没有对其核心协议进行改动， 也没有与腾讯公司的QQ软件有直接联系，请尊重LumaQQ作者Luma的著作权和版权声明。
 * 同时在使用此开发包前请自行协调好多方面关系，本人不享受和承担由此产生的任何权利以及任何法律责任。
 * 
 * 作者：阿不
 * 博客：http://hjf1223.cnblogs.com
 * Email：hjf1223 AT gmail.com
 * LumaQQ：http://lumaqq.linuxsir.org 
 * LumaQQ - Java QQ Client
 * 
 * Copyright (C) 2004 luma <stubma@163.com>
 * 
 * LumaQQ - For .NET QQClient
 * Copyright (C) 2008 阿不<hjf1223 AT gmail.com>
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

using LumaQQ.NET.Net;
using LumaQQ.NET.Events;
using LumaQQ.NET.Packets;
using LumaQQ.NET.Entities;
using LumaQQ.NET.Threading;
using LumaQQ.NET.Packets.In;
using LumaQQ.NET.Packets.Out;
using LumaQQ.NET.Packets.Out._08;
using LumaQQ.NET.Packets.In._08;
namespace LumaQQ.NET
{

    /// <summary>
    /// 好友管理
    /// <remark>abu 2008-03-11 </remark>
    /// </summary>
    public class FriendManager
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FriendManager"/> class.
        /// </summary>
        private FriendManager() { }
        /// <summary>
        /// Initializes a new instance of the <see cref="FriendManager"/> class.
        /// </summary>
        /// <param name="client">The client.</param>
        internal FriendManager(QQClient client)
        {
            this.QQClient = client;
        }
        /// <summary>
        /// 	<remark>abu 2008-03-11 </remark>
        /// </summary>
        /// <value></value>
        public QQClient QQClient { get; private set; }
        /// <summary>
        /// 	<remark>abu 2008-03-11 </remark>
        /// </summary>
        /// <value></value>
        public QQUser QQUser { get { return QQClient.QQUser; } }

        /// <summary>搜索所有的在线用户
        /// Searches the user.
        /// </summary>
        /// <param name="page">The page.</param>
        public void SearchUser(int page)
        {
            SearchUser(page, "", "", "");
        }
        /// <summary>自定义搜索用户
        /// Searches the user.
        /// </summary>
        /// <param name="page">The page.</param>
        /// <param name="qq">The qq.</param>
        /// <param name="nick">The nick.</param>
        /// <param name="email">The email.</param>
        public void SearchUser(int page, string qq, string nick, string email)
        {
            SearchUserPacket packet = new SearchUserPacket(QQUser);
            packet.Page = page.ToString();
            packet.QQStr = qq;
            packet.Nick = nick;
            packet.Email = email;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }

        /// <summary>下载好友分组
        /// Downloads the group friend.
        /// </summary>
        /// <param name="beginFrom">The begin from.起始好友号 如果是第一个包，起始好友号为0</param>
        public void DownloadGroupFriends(int beginFrom)
        {
            DownloadGroupFriendPacket packet = new DownloadGroupFriendPacket(QQUser);
            packet.BeginFrom = beginFrom;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }
        /// <summary>上传分组名称
        /// Uploads the group.
        /// </summary>
        /// <param name="groups">The groups.</param>
        public void UploadGroupName(List<string> groups)
        {
            GroupDataOpPacket packet = new GroupDataOpPacket(QQUser);
            packet.Type = _08QQ.SubCMD_Group.QQ_SUB_CMD_UPLOAD_GROUP_NAME;
            packet.Groups = groups;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }

        /// <summary>下载分组名称
        /// Downloads the group.
        /// </summary>
        public void DownloadGroupName()
        {
            GroupDataOpPacket packet = new GroupDataOpPacket(QQUser);
            packet.Type = _08QQ.SubCMD_Group.QQ_SUB_CMD_DOWNLOAD_GROUP_NAME;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }

        /// <summary>得到用户属性
        /// Gets the user property.
        /// </summary>
        /// <param name="startPosition">The start position.</param>
        public void GetUserProperty(ushort startPosition)
        {
            UserPropertyOpPacket packet = new UserPropertyOpPacket(QQUser);
            packet.StartPosition = startPosition;
            packet.SubCommand = _08QQ.SubCMD_Property.QQ_SUB_CMD_GET_USER_PROPERTY;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }

        /// <summary>得到好友等级
        /// Gets the friend level.
        /// </summary>
        /// <param name="friends">The friends.</param>
        public void GetFriendLevel(List<int> friends)
        {
            FriendLevelOpPacket packet = new FriendLevelOpPacket(QQUser);
            packet.Friends = friends;
            packet.SubCommand = _08QQ.SubCMD_Friend_Level.QQ_SUB_CMD_GET_FRIEND_LEVEL;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }

        /// <summary>根据QQ号码读取个性签名
        /// Gets the signature.
        /// </summary>
        /// <param name="qq">The qq.</param>
        public void GetSignature(int qq)
        {
            List<Signature> list = new List<Signature>();
            Signature sig = new Signature();
            sig.QQ = qq;
            list.Add(sig);
            GetSignature(list);
        }
        /// <summary>读取个性签名
        /// <remarks>在得到好友的个性签名时，QQ的做法是对所有的QQ号排个序，每次最多请求33个</remarks>
        /// Gets the signature.
        /// </summary>
        /// <param name="sigs">The sigs.</param>
        public void GetSignature(List<Signature> sigs)
        {
            _08SignatureOpPacket packet = new _08SignatureOpPacket(QQUser);
            packet.SubCommand = _08QQ.SubCMD_Signature.QQ_SUB_CMD_GET_SIGNATURE;
            packet.Signatures = sigs;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }

        /// <summary>下载好友备注信息
        /// Downloads the friend remark.
        /// </summary>
        /// <param name="qq">The qq.</param>
        public void DownloadFriendRemark(int qq)
        {
            FriendDataOpPacket packet = new FriendDataOpPacket(QQUser);
            packet.SubCommand = _08QQ.SubCMD_Friend_OP.QQ_SUB_CMD_DOWNLOAD_FRIEND_REMARK;
            packet.QQ = qq;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }
        /// <summary>批量下载好友备注信息
        /// Batches the download friend remark.
        /// </summary>
        /// <param name="page">The page.页号</param>
        public void BatchDownloadFriendRemark(int page)
        {
            FriendDataOpPacket packet = new FriendDataOpPacket(QQUser);
            packet.SubCommand = _08QQ.SubCMD_Friend_OP.QQ_SUB_CMD_BATCH_DOWNLOAD_FRIEND_REMARK;
            packet.Page = page;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }
        /// <summary>上传好友备信息
        /// Uploads the friend remark.
        /// </summary>
        /// <param name="qq">The qq.</param>
        /// <param name="remark">The remark.</param>
        public void UploadFriendRemark(int qq, FriendRemark remark)
        {
            FriendDataOpPacket packet = new FriendDataOpPacket(QQUser);
            packet.Remark = remark;
            packet.QQ = qq;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }
        /// <summary> 把好友从服务器端的好友列表中删除
        /// Removes the friend from list.
        /// </summary>
        /// <param name="qq">The qq.</param>
        public void RemoveFriendFromList(int qq)
        {
            FriendDataOpPacket packet = new FriendDataOpPacket(QQUser);
            packet.SubCommand = _08QQ.SubCMD_Friend_OP.QQ_SUB_CMD_REMOVE_FRIEND_FROM_LIST;
            packet.QQ = qq;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }
        /// <summary>
        /// 添加好友到服务器端的好友列表中
        /// </summary>
        /// <param name="group">The group.好友的组号，我的好友组是0，然后是1，2，...</param>
        /// <param name="qq">The qq.</param>
        public void AddFriendToList(int group, int qq)
        {
            UploadGroupFriendPacket packet = new UploadGroupFriendPacket(QQUser);
            packet.AddFriend(group, qq);
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }
        /// <summary>添加一个好友
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        /// <param name="qq">The qq.</param>
        public void AddFriend(int qq)
        {
            AddFriendExPacket packet = new AddFriendExPacket(QQUser);
            packet.To = qq;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name, false);
        }
        /// <summary>删除一个好友
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        /// <param name="qq">The qq.</param>
        public void DeleteFriend(int qq)
        {
            DeleteFriendPacket packet = new DeleteFriendPacket(QQUser);
            packet.To = qq;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }
        /// <summary> 把某人的好友列表中的自己删除
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        /// <param name="qq">The qq.</param>
        public void RemoveSelfFrom(int qq)
        {
            RemoveSelfPacket packet = new RemoveSelfPacket(QQUser);
            packet.RemoveFrom = qq;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }

        /// <summary> 如果要加的人需要认证，用这个方法发送验证请求
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        /// <param name="qq">The qq.</param>
        /// <param name="message">The message.</param>
        public void SendAddFriendAuth(int qq, string message)
        {
            _08AuthorizePacket packet = new _08AuthorizePacket(QQUser);
            packet.To = qq;
            packet.Message = message;
            packet.PuzzleAuthInfo = QQUser.AuthToken;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }

        /// <summary>改变自身状态
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        /// <param name="status">The status.</param>
        /// <param name="showFakeCam">if set to <c>true</c> [show fake cam].</param>
        public void ChangeStatus(_08QQ.Status status, bool showFakeCam)
        {
            QQUser.Status = status;
            ChangeStatusPacket packet = new ChangeStatusPacket(QQUser);
            packet.ShowFakeCam = showFakeCam;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }

        /// <summary>如果我要同意一个人加我为好友的请求，用这个方法发送同意消息
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        /// <param name="qq">The qq.</param>
        public void ApprovedAddMe(int qq)
        {
            AddFriendAuthResponsePacket packet = new AddFriendAuthResponsePacket(QQUser);
            packet.To = qq;
            packet.Action = _08QQ.Add_Friend_Auth_Type.QQ_MY_AUTH_APPROVE;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }
        /// <summary>如果我要拒绝一个人加我为好友的请求，用这个方法发送拒绝消息
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        /// <param name="qq">The qq.</param>
        /// <param name="message">The message.</param>
        public void RejectAddMe(int qq, string message)
        {
            AddFriendAuthResponsePacket packet = new AddFriendAuthResponsePacket(QQUser);
            packet.To = qq;
            packet.Message = message;
            packet.Action = _08QQ.Add_Friend_Auth_Type.QQ_MY_AUTH_REJECT;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }
        /// <summary>得到一个用户的详细信息
        /// 	<remark>abu 2008-03-11 </remark>
        /// </summary>
        /// <param name="qq">The qq.</param>
        public void GetUserInfo(int qq)
        {
            GetUserInfoPacket packet = new GetUserInfoPacket(QQUser);
            packet.QQ = qq;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }

        /// <summary>请求在线好友列表
        /// 	<remark>abu 2008-03-11 </remark>
        /// </summary>
        public void GetOnlineFriend()
        {
            GetOnlineFriend(0);
        }

        /// <summary>请求在线好友列表
        /// 	<remark>abu 2008-03-11 </remark>
        /// </summary>
        /// <param name="startPosition">The start position.</param>
        private void GetOnlineFriend(int startPosition)
        {
            _08GetOnlineOpPacket packet = new _08GetOnlineOpPacket(QQUser);
            packet.StartPosition = startPosition;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }

        /// <summary>请求取得好友名单
        /// 	<remark>abu 2008-03-11 </remark>
        /// </summary>
        public void GetFriendList()
        {
            GetFriendList(0);
        }

        /// <summary>请求取得好友名单
        /// 	<remark>abu 2008-03-11 </remark>
        /// </summary>
        /// <param name="position">The position.</param>
        private void GetFriendList(int startPosition)
        {
            GetFriendListPacket packet = new GetFriendListPacket(QQUser);
            packet.StartPosition = (ushort)startPosition;
            QQClient.PacketManager.SendPacket(packet, QQPort.Main.Name);
        }
        #region events
        #region 搜索QQ用户事件

        /// <summary>搜索好友回复事件
        /// Occurs when [search user successed].
        /// </summary>
        public event EventHandler<QQEventArgs<SearchUserPacket, SearchUserReplyPacket>> SearchUserSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:SearchUserSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.SearchUserReplyPacket,LumaQQ.NET.Packets.Out.SearchUserPacket&gt;"/> instance containing the event data.</param>
        internal void OnSearchUserSuccessfully(QQEventArgs<SearchUserPacket, SearchUserReplyPacket> e)
        {
            if (SearchUserSuccessfully != null)
            {
                SearchUserSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>搜索好友回复事件
        /// Occurs when [search user successed].
        /// </summary>
        public event EventHandler<QQEventArgs<AdvancedSearchUserPacket, AdvancedSearchUserReplyPacket>> AdvancedSearchUserOK;
        internal void OnAdvancedSearchUserOK(QQEventArgs<AdvancedSearchUserPacket, AdvancedSearchUserReplyPacket> e)
        {
            if (AdvancedSearchUserOK != null)
            {
                AdvancedSearchUserOK(this.QQClient, e);
            }
        }

        public event EventHandler<QQEventArgs<AdvancedSearchUserPacket, AdvancedSearchUserReplyPacket>> AdvancedSearchUserEnd;
        internal void OnAdvancedSearchUserEnd(QQEventArgs<AdvancedSearchUserPacket, AdvancedSearchUserReplyPacket> e)
        {
            if (AdvancedSearchUserEnd != null)
            {
                AdvancedSearchUserEnd(this.QQClient, e);
            }
        }

        #endregion

        #region 分组名称事件
        /// <summary>上传分组名称成功
        /// Occurs when [upload group names successed].
        /// </summary>
        public event EventHandler<QQEventArgs<GroupDataOpPacket, GroupDataOpReplyPacket>> UploadGroupNamesSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:UploadGroupNamesSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.GroupDataOpReplyPacket,LumaQQ.NET.Packets.Out.GroupDataOpPacket&gt;"/> instance containing the event data.</param>
        internal void OnUploadGroupNamesSuccessfully(QQEventArgs<GroupDataOpPacket, GroupDataOpReplyPacket> e)
        {
            if (UploadGroupNamesSuccessfully != null)
            {
                UploadGroupNamesSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>上传分组名称失败
        /// Occurs when [upload group names failed].
        /// </summary>
        public event EventHandler<QQEventArgs<GroupDataOpPacket, GroupDataOpReplyPacket>> UploadGroupNamesFailed;
        internal void OnUploadGroupNamesFailed(QQEventArgs<GroupDataOpPacket, GroupDataOpReplyPacket> e)
        {
            if (UploadGroupNamesFailed != null)
            {
                UploadGroupNamesFailed(this.QQClient, e);
            }
        }

        /// <summary>下载分组名称成功
        /// Occurs when [download group names successed].
        /// </summary>
        public event EventHandler<QQEventArgs<GroupDataOpPacket, GroupDataOpReplyPacket>> DownloadGroupNamesSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:DownloadGroupNamesSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.GroupDataOpReplyPacket,LumaQQ.NET.Packets.Out.GroupDataOpPacket&gt;"/> instance containing the event data.</param>
        internal void OnDownloadGroupNamesSuccessfully(QQEventArgs<GroupDataOpPacket, GroupDataOpReplyPacket> e)
        {
            if (DownloadGroupNamesSuccessfully != null)
            {
                DownloadGroupNamesSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>下载分名称失败
        /// Occurs when [download group names failed].
        /// </summary>
        public event EventHandler<QQEventArgs<GroupDataOpPacket, GroupDataOpReplyPacket>> DownloadGroupNamesFailed;
        internal void OnDownloadGroupNamesFailed(QQEventArgs<GroupDataOpPacket, GroupDataOpReplyPacket> e)
        {
            if (DownloadGroupNamesFailed != null)
            {
                DownloadGroupNamesFailed(this.QQClient, e);
            }
        }
        #endregion

        #region 下载分组好友
        /// <summary>下载分组好友成功
        /// Occurs when [download group friend successed].
        /// </summary>
        public event EventHandler<QQEventArgs<DownloadGroupFriendPacket, DownloadGroupFriendReplyPacket>> DownloadGroupFriendSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:DownloadGroupFriendSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.DownloadGroupFriendReplyPacket,LumaQQ.NET.Packets.Out.DownloadGroupFriendPacket&gt;"/> instance containing the event data.</param>
        internal void OnDownloadGroupFriendSuccessfully(QQEventArgs<DownloadGroupFriendPacket, DownloadGroupFriendReplyPacket> e)
        {
            if (DownloadGroupFriendSuccessfully != null)
            {
                DownloadGroupFriendSuccessfully(this.QQClient, e);
            }
        }
        /// <summary>下载分组好友失败
        /// Occurs when [download group friend failed].
        /// </summary>
        public event EventHandler<QQEventArgs<DownloadGroupFriendPacket, DownloadGroupFriendReplyPacket>> DownloadGroupFriendFailed;
        /// <summary>
        /// Raises the <see cref="E:DownloadGroupFriendFailed"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.DownloadGroupFriendReplyPacket,LumaQQ.NET.Packets.Out.DownloadGroupFriendPacket&gt;"/> instance containing the event data.</param>
        internal void OnDownloadGroupFriendFailed(QQEventArgs<DownloadGroupFriendPacket, DownloadGroupFriendReplyPacket> e)
        {
            if (DownloadGroupFriendFailed != null)
            {
                DownloadGroupFriendFailed(this.QQClient, e);
            }
        }
        #endregion

        #region 读取用户属性
        /// <summary>读取用户属性成功
        /// Occurs when [get user property successed].
        /// </summary>
        public event EventHandler<QQEventArgs<UserPropertyOpPacket, UserPropertyOpReplyPacket>> GetUserPropertySuccessfully;
        /// <summary>
        /// Raises the <see cref="E:GetUserPropertySuccess"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.UserPropertyOpReplyPacket,LumaQQ.NET.Packets.Out.UserPropertyOpPacket&gt;"/> instance containing the event data.</param>
        internal void OnGetUserPropertySuccess(QQEventArgs<UserPropertyOpPacket, UserPropertyOpReplyPacket> e)
        {
            if (GetUserPropertySuccessfully != null)
            {
                GetUserPropertySuccessfully(this.QQClient, e);
            }
        }
        #endregion

        #region 读取好友等级
        /// <summary>读取好友等级成功
        /// Occurs when [get friend level successed].
        /// </summary>
        public event EventHandler<QQEventArgs<FriendLevelOpPacket, FriendLevelOpReplyPacket>> GetFriendLevelSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:GetFriendLevelSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.FriendLevelOpReplyPacket,LumaQQ.NET.Packets.Out.FriendLevelOpPacket&gt;"/> instance containing the event data.</param>
        internal void OnGetFriendLevelSuccessfully(QQEventArgs<FriendLevelOpPacket, FriendLevelOpReplyPacket> e)
        {
            if (GetFriendLevelSuccessfully != null)
            {
                GetFriendLevelSuccessfully(this.QQClient, e);
            }
        }

        #endregion

        #region 好友个性签名信息
        /// <summary>读取个性签名成功
        /// Occurs when [get signature successed].
        /// </summary>
        public event EventHandler<QQEventArgs<_08SignatureOpPacket, _08SignatureOpReplyPacket>> GetSignatureSuccessfully;
        internal void OnGetSignatureSuccessfully(QQEventArgs<_08SignatureOpPacket, _08SignatureOpReplyPacket> e)
        {
            if (GetSignatureSuccessfully != null)
            {
                GetSignatureSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>读取个性签名失败
        /// Occurs when [get signature failed].
        /// </summary>
        public event EventHandler<QQEventArgs<_08SignatureOpPacket, _08SignatureOpReplyPacket>> GetSignatureFailed;
        internal void OnGetSignatureFailed(QQEventArgs<_08SignatureOpPacket, _08SignatureOpReplyPacket> e)
        {
            if (GetSignatureFailed != null)
            {
                GetSignatureFailed(this.QQClient, e);
            }
        }
        #endregion

        #region 好友备注信息操作
        /// <summary>上传好友备注信息成功
        /// Occurs when [upload friend remark successed].
        /// </summary>
        public event EventHandler<QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket>> UploadFriendRemarkSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:UploadFriendRemarkSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.FriendDataOpReplyPacket,LumaQQ.NET.Packets.Out.FriendDataOpPacket&gt;"/> instance containing the event data.</param>
        internal void OnUploadFriendRemarkSuccessfully(QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket> e)
        {
            if (UploadFriendRemarkSuccessfully != null)
            {
                UploadFriendRemarkSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>上传好友备注信息失败
        /// Occurs when [upload friend remark failed].
        /// </summary>
        public event EventHandler<QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket>> UploadFriendRemarkFailed;
        /// <summary>
        /// Raises the <see cref="E:UploadFriendRemarkFailed"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.FriendDataOpReplyPacket,LumaQQ.NET.Packets.Out.FriendDataOpPacket&gt;"/> instance containing the event data.</param>
        internal void OnUploadFriendRemarkFailed(QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket> e)
        {
            if (UploadFriendRemarkFailed != null)
            {
                UploadFriendRemarkFailed(this.QQClient, e);
            }
        }

        /// <summary>下载好友备注信息成功
        /// Occurs when [download friend remark successed].
        /// </summary>
        public event EventHandler<QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket>> DownloadFriendRemarkSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:DownloadFriendRemarkSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.FriendDataOpReplyPacket,LumaQQ.NET.Packets.Out.FriendDataOpPacket&gt;"/> instance containing the event data.</param>
        internal void OnDownloadFriendRemarkSuccessfully(QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket> e)
        {
            if (DownloadFriendRemarkSuccessfully != null)
            {
                DownloadFriendRemarkSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>下载好友备注信息失败
        /// Occurs when [download friend remark failed].
        /// </summary>
        public event EventHandler<QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket>> DownloadFriendRemarkFailed;
        /// <summary>
        /// Raises the <see cref="E:DownloadFriendRemarkFailed"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.FriendDataOpReplyPacket,LumaQQ.NET.Packets.Out.FriendDataOpPacket&gt;"/> instance containing the event data.</param>
        internal void OnDownloadFriendRemarkFailed(QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket> e)
        {
            if (DownloadFriendRemarkFailed != null)
            {
                DownloadFriendRemarkFailed(this.QQClient, e);
            }
        }

        /// <summary>成批下载好友信息成功
        /// Occurs when [batch download friend remark successed].
        /// </summary>
        public event EventHandler<QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket>> BatchDownloadFriendRemarkSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:BatchDownloadFriendRemarkSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.FriendDataOpReplyPacket,LumaQQ.NET.Packets.Out.FriendDataOpPacket&gt;"/> instance containing the event data.</param>
        internal void OnBatchDownloadFriendRemarkSuccessfully(QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket> e)
        {
            if (BatchDownloadFriendRemarkSuccessfully != null)
            {
                BatchDownloadFriendRemarkSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>成批下载好友信息失败
        /// Occurs when [batch download friend remark failed].
        /// </summary>
        public event EventHandler<QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket>> BatchDownloadFriendRemarkFailed;
        /// <summary>
        /// Raises the <see cref="E:BatchDownloadFriendRemarkFailed"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.FriendDataOpReplyPacket,LumaQQ.NET.Packets.Out.FriendDataOpPacket&gt;"/> instance containing the event data.</param>
        internal void OnBatchDownloadFriendRemarkFailed(QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket> e)
        {
            if (BatchDownloadFriendRemarkFailed != null)
            {
                BatchDownloadFriendRemarkFailed(this.QQClient, e);
            }
        }

        /// <summary>从服务器端好友列表中移除好友成功
        /// Occurs when [remove friend from list successed].
        /// </summary>
        public event EventHandler<QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket>> RemoveFriendFromListSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:RemoveFriendFromListSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.FriendDataOpReplyPacket,LumaQQ.NET.Packets.Out.FriendDataOpPacket&gt;"/> instance containing the event data.</param>
        internal void OnRemoveFriendFromListSuccessfully(QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket> e)
        {
            if (RemoveFriendFromListSuccessfully != null)
            {
                RemoveFriendFromListSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>从服务器端好友列表中移除好友失败
        /// Occurs when [remove friend from list failed].
        /// </summary>
        public event EventHandler<QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket>> RemoveFriendFromListFailed;
        /// <summary>
        /// Raises the <see cref="E:RemoveFriendFromListFailed"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.FriendDataOpReplyPacket,LumaQQ.NET.Packets.Out.FriendDataOpPacket&gt;"/> instance containing the event data.</param>
        internal void OnRemoveFriendFromListFailed(QQEventArgs<FriendDataOpPacket, FriendDataOpReplyPacket> e)
        {
            if (RemoveFriendFromListFailed != null)
            {
                RemoveFriendFromListFailed(this.QQClient, e);
            }
        }

        #endregion

        /// <summary>取得在线好友列表
        /// 	<remark>abu 2008-03-11 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<_08GetOnlineOpPacket, _08GetOnlineOpReplyPacket>> GetOnlineFriendSuccessfully;
        /// <summary>
        /// Called when [get online friend successed].
        /// </summary>
        /// <param name="e">The e.</param>
        internal void OnGetOnlineFriendSuccessfully(QQEventArgs<_08GetOnlineOpPacket, _08GetOnlineOpReplyPacket> e)
        {
            foreach (FriendOnlineEntry online in e.InPacket.OnlineFriends)
            {
                QQUser.Friends.SetFriendOnline(online.Status.QQ, online);
            }
            if (!e.InPacket.Finished)
            {
                GetOnlineFriend(e.InPacket.Position + 1);
            }
            if (GetOnlineFriendSuccessfully != null)
            {
                GetOnlineFriendSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>得到好友列表事件
        /// <remarks>获得好友列表及在线状态的顺序是：
        /// 先得到所有的好友列表，根据TheEnd判断是否已经得到所有的好友。
        /// 得到所有的好友列表后，才能去获取在线好友列表。</remarks>
        /// 	<remark>abu 2008-03-11 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<GetFriendListPacket, GetFriendListReplyPacket>> GetFriendListSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:GetFriendListSuccess"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.GetFriendListReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnGetFriendListSuccessfully(QQEventArgs<GetFriendListPacket, GetFriendListReplyPacket> e)
        {
            foreach (QQFriend friend in e.InPacket.Friends)
            {
                QQUser.Friends.Add(friend.QQ, new FriendInfo(friend));
            }
            if (!e.InPacket.Finished)
            {
                GetFriendList(e.InPacket.Position + 1);
            }
            if (GetFriendListSuccessfully != null)
            {
                GetFriendListSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>得到用户详细信息回复事件 
        /// 	<remark>abu 2008-03-11 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<GetUserInfoPacket, GetUserInfoReplyPacket>> GetUserInfoSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:GetUserInfoSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.GetUserInfoReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnGetUserInfoSuccessfully(QQEventArgs<GetUserInfoPacket, GetUserInfoReplyPacket> e)
        {
            //如果QQ号码等于自己则更新自己的详细信息
            if (QQUser.QQ == e.InPacket.ContactInfo.QQ)
            {
                QQUser.ContactInfo = e.InPacket.ContactInfo;
            }
            if (GetUserInfoSuccessfully != null)
            {
                GetUserInfoSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>收到好友的状态发生变化
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<FriendChangeStatusPacket>> FriendChangeStatus;
        /// <summary>
        /// Raises the <see cref="E:FriendChangeStatus"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.FriendChangeStatusPacket&gt;"/> instance containing the event data.</param>
        internal void OnFriendChangeStatus(QQEventArgs<FriendChangeStatusPacket> e)
        {
            if (FriendChangeStatus != null)
            {
                FriendChangeStatus(this.QQClient, e);
            }
        }

        #region 改变自身状态的回复事件

        /// <summary>改变自身状态成功
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<ChangeStatusPacket, ChangeStatusReplyPacket>> ChangeStatusSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:ChangeStatusSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.ChangeStatusReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnChangeStatusSuccessfully(QQEventArgs<ChangeStatusPacket, ChangeStatusReplyPacket> e)
        {
            if (ChangeStatusSuccessfully != null)
            {
                ChangeStatusSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>
        /// 改变自身状态失败
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<ChangeStatusPacket, ChangeStatusReplyPacket>> ChangeStatusFailed;
        /// <summary>
        /// Raises the <see cref="E:ChangeStatusFailed"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.ChangeStatusReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnChangeStatusFailed(QQEventArgs<ChangeStatusPacket, ChangeStatusReplyPacket> e)
        {
            if (ChangeStatusFailed != null)
            {
                ChangeStatusFailed(this.QQClient, e);
            }
        }
        #endregion

        #region 添加好友的回复事件

        /// <summary>好友添加成功
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<AddFriendExPacket, AddFriendExReplyPacket>> AddFriendSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:AddFriendSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.AddFriendExReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnAddFriendSuccessfully(QQEventArgs<AddFriendExPacket, AddFriendExReplyPacket> e)
        {
            if (AddFriendSuccessfully != null)
            {
                AddFriendSuccessfully(this.QQClient, e);
            }
        }
        /// <summary>
        /// 添加好友时，需要发送验证信息
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<AddFriendExPacket, AddFriendExReplyPacket>> AddFriendNeedAuth;
        /// <summary>
        /// Raises the <see cref="E:AddFriendNeedAuth"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.AddFriendExReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnAddFriendNeedAuth(QQEventArgs<AddFriendExPacket, AddFriendExReplyPacket> e)
        {
            if (AddFriendNeedAuth != null)
            {
                AddFriendNeedAuth(this.QQClient, e);
            }
        }

        /// <summary>
        /// 对方拒绝让你加为好友
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<AddFriendExPacket, AddFriendExReplyPacket>> AddFriendDenied;
        /// <summary>
        /// Raises the <see cref="E:AddFriendDeny"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.AddFriendExReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnAddFriendDenied(QQEventArgs<AddFriendExPacket, AddFriendExReplyPacket> e)
        {
            if (AddFriendDenied != null)
            {
                AddFriendDenied(this.QQClient, e);
            }
        }

        /// <summary>对方已经是好友
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<AddFriendExPacket, AddFriendExReplyPacket>> FriendAlready;
        /// <summary>
        /// Raises the <see cref="E:FriendAlready"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.AddFriendExReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnFriendAlready(QQEventArgs<AddFriendExPacket, AddFriendExReplyPacket> e)
        {
            if (FriendAlready != null)
            {
                FriendAlready(this.QQClient, e);
            }
        }

        /// <summary>添加好友失败
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<AddFriendExPacket, AddFriendExReplyPacket>> AddFriendFailed;
        /// <summary>
        /// Raises the <see cref="E:AddFriendFailed"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.AddFriendExReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnAddFriendFailed(QQEventArgs<AddFriendExPacket, AddFriendExReplyPacket> e)
        {
            if (AddFriendFailed != null)
            {
                AddFriendFailed(this.QQClient, e);
            }
        }

        /// <summary>认证信息发送成功
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<_08AuthorizePacket, _08AuthorizeReplyPacket>> SendAuthSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:SendAuthSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.AddFriendAuthResponseReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnSendAuthSuccessfully(QQEventArgs<_08AuthorizePacket, _08AuthorizeReplyPacket> e)
        {
            if (SendAuthSuccessfully != null)
            {
                SendAuthSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>发送认证信息失败
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<_08AuthorizePacket, _08AuthorizeReplyPacket>> SendAuthFailed;
        /// <summary>
        /// Raises the <see cref="E:SendAuthFailed"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.AddFriendAuthResponseReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnSendAuthFailed(QQEventArgs<_08AuthorizePacket, _08AuthorizeReplyPacket> e)
        {
            if (SendAuthFailed != null)
            {
                SendAuthFailed(this.QQClient, e);
            }
        }
        #endregion

        #region 把自己从好友的好友列表中删除的回复事件
        /// <summary>把自己从好友的好友列表中删除成功
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<RemoveSelfPacket, RemoveSelfReplyPacket>> RemoveSelfSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:RemoveSelfSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.RemoveSelfReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnRemoveSelfSuccessfully(QQEventArgs<RemoveSelfPacket, RemoveSelfReplyPacket> e)
        {
            if (RemoveSelfSuccessfully != null)
            {
                RemoveSelfSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>把自己从好友的好友列表中删除失败
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<RemoveSelfPacket, RemoveSelfReplyPacket>> RemoveSelfFailed;
        /// <summary>
        /// Raises the <see cref="E:RemoveSelfFailed"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.RemoveSelfReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnRemoveSelfFailed(QQEventArgs<RemoveSelfPacket, RemoveSelfReplyPacket> e)
        {
            if (RemoveSelfFailed != null)
            {
                RemoveSelfFailed(this.QQClient, e);
            }
        }

        #endregion

        #region 删除好友回复事件
        /// <summary>删除好友成功
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<DeleteFriendPacket, DeleteFriendReplyPacket>> DeleteFriendSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:DeleteFriendSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.DeleteFriendReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnDeleteFriendSuccessfully(QQEventArgs<DeleteFriendPacket, DeleteFriendReplyPacket> e)
        {
            if (DeleteFriendSuccessfully != null)
            {
                DeleteFriendSuccessfully(this.QQClient, e);
            }
        }
        /// <summary>删除好友失败
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<DeleteFriendPacket, DeleteFriendReplyPacket>> DeleteFriendFailed;
        /// <summary>
        /// Raises the <see cref="E:DeleteFriendFailed"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.DeleteFriendReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnDeleteFriendFailed(QQEventArgs<DeleteFriendPacket, DeleteFriendReplyPacket> e)
        {
            if (DeleteFriendFailed != null)
            {
                DeleteFriendFailed(this.QQClient, e);
            }
        }
        #endregion

        #region 处理对方发送过来的认证信息回复事件
        /// <summary>处理认证信息成功
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<AddFriendAuthResponsePacket, AddFriendAuthResponseReplyPacket>> ResponseAuthSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:ResponseAuthSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.Out.AddFriendAuthResponsePacket&gt;"/> instance containing the event data.</param>
        internal void OnResponseAuthSuccessfully(QQEventArgs<AddFriendAuthResponsePacket, AddFriendAuthResponseReplyPacket> e)
        {
            if (ResponseAuthSuccessfully != null)
            {
                ResponseAuthSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>处理认证信息失败
        /// 	<remark>abu 2008-03-12 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<AddFriendAuthResponsePacket, AddFriendAuthResponseReplyPacket>> ResponseAuthFailed;
        /// <summary>
        /// Raises the <see cref="E:ResponseAuthFailed"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.AddFriendAuthResponseReplyPacket&gt;"/> instance containing the event data.</param>
        internal void OnResponseAuthFailed(QQEventArgs<AddFriendAuthResponsePacket, AddFriendAuthResponseReplyPacket> e)
        {
            if (ResponseAuthFailed != null)
            {
                ResponseAuthFailed(this.QQClient, e);
            }
        }
        #endregion

        #region 处理上传分组好友列表回复事件
        /// <summary>
        /// Occurs when [upload group friend successed].事件在上传分组中的好友列表成功时发生
        /// </summary>
        public event EventHandler<QQEventArgs<UploadGroupFriendPacket, UploadGroupFriendReplyPacket>> UploadGroupFriendSuccessfully;
        /// <summary>
        /// Raises the <see cref="E:UploadGroupFriendSuccessfully"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.UploadGroupFriendReplyPacket,LumaQQ.NET.Packets.Out.UploadGroupFriendPacket&gt;"/> instance containing the event data.</param>
        internal void OnUploadGroupFriendSuccessfully(QQEventArgs<UploadGroupFriendPacket, UploadGroupFriendReplyPacket> e)
        {
            if (UploadGroupFriendSuccessfully != null)
            {
                UploadGroupFriendSuccessfully(this.QQClient, e);
            }
        }

        /// <summary>
        /// Occurs when [upload group friend failed].事件在下载分组中的好友列表成功时发生
        /// </summary>
        public event EventHandler<QQEventArgs<UploadGroupFriendPacket, UploadGroupFriendReplyPacket>> UploadGroupFriendFailed;
        /// <summary>
        /// Raises the <see cref="E:UploadGroupFriendFailed"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.UploadGroupFriendReplyPacket,LumaQQ.NET.Packets.Out.UploadGroupFriendPacket&gt;"/> instance containing the event data.</param>
        internal void OnUploadGroupFriendFailed(QQEventArgs<UploadGroupFriendPacket, UploadGroupFriendReplyPacket> e)
        {
            if (UploadGroupFriendFailed != null)
            {
                UploadGroupFriendFailed(this.QQClient, e);
            }
        }
        #endregion

        /// <summary>
        /// 好友个性签名改变
        /// 	<remark>abu 2008-03-15 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<ReceiveIMPacket>> SignatureChanged;
        /// <summary>
        /// Raises the <see cref="E:SignatureChanged"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.ReceiveIMPacket,LumaQQ.NET.Packets.OutPacket&gt;"/> instance containing the event data.</param>
        internal void OnSignatureChanged(QQEventArgs<ReceiveIMPacket> e)
        {
            if (SignatureChanged != null)
            {
                SignatureChanged(this.QQClient, e);
            }
        }

        /// <summary>
        /// 收到好友属性变化通知
        /// 	<remark>abu 2008-03-15 </remark>
        /// </summary>
        public event EventHandler<QQEventArgs<ReceiveIMPacket>> UserPropertyChanged;
        /// <summary>
        /// Raises the <see cref="E:UserPropertyChanged"/> event.
        /// </summary>
        /// <param name="e">The <see cref="LumaQQ.NET.Events.QQEventArgs&lt;LumaQQ.NET.Packets.In.ReceiveIMPacket,LumaQQ.NET.Packets.OutPacket&gt;"/> instance containing the event data.</param>
        internal void OnUserPropertyChanged(QQEventArgs<ReceiveIMPacket> e)
        {
            if (UserPropertyChanged != null)
            {
                UserPropertyChanged(this.QQClient, e);
            }
        }

        public event EventHandler<QQEventArgs<AuthQuestionOpPacket, AuthQuestionOpReplyPacket>> GetAuthQuestionSuccessfully;
        internal void OnGetAuthQuestionSuccessfully(QQEventArgs<AuthQuestionOpPacket, AuthQuestionOpReplyPacket> e)
        {
            if (GetAuthQuestionSuccessfully != null)
            {
                GetAuthQuestionSuccessfully(this.QQClient, e);
            }
        }

        public event EventHandler<QQEventArgs<AuthQuestionOpPacket, AuthQuestionOpReplyPacket>> GetAuthQuestionFailed;
        internal void OnGetAuthQuestionFailed(QQEventArgs<AuthQuestionOpPacket, AuthQuestionOpReplyPacket> e)
        {
            if (GetAuthQuestionFailed != null)
            {
                GetAuthQuestionFailed(this.QQClient, e);
            }
        }


        public event EventHandler<QQEventArgs<AuthQuestionOpPacket, AuthQuestionOpReplyPacket>> RightAnswer;
        internal void OnRightAnswer(QQEventArgs<AuthQuestionOpPacket, AuthQuestionOpReplyPacket> e)
        {
            if (RightAnswer != null)
            {
                RightAnswer(this.QQClient, e);
            }
        }

        public event EventHandler<QQEventArgs<AuthQuestionOpPacket, AuthQuestionOpReplyPacket>> WrongAnswer;
        internal void OnWrongAnswer(QQEventArgs<AuthQuestionOpPacket, AuthQuestionOpReplyPacket> e)
        {
            if (WrongAnswer != null)
            {
                WrongAnswer(this.QQClient, e);
            }
        }
        #endregion
    }
}
