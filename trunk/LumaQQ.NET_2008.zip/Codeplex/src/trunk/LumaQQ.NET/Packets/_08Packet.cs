﻿#region 版权声明
/**
 * 版权声明：LumaQQ.NET是基于LumaQQ分析的QQ协议，将其部分代码进行修改和翻译为.NET版本，并且继续使用LumaQQ的开源协议。
 * 本人没有对其核心协议进行改动， 也没有与腾讯公司的QQ软件有直接联系，请尊重LumaQQ作者Luma的著作权和版权声明。
 * 同时在使用此开发包前请自行协调好多方面关系，本人不享受和承担由此产生的任何权利以及任何法律责任。
 * 
 * 作者：阿不
 * 博客：http://hjf1223.cnblogs.com
 * Email：hjf1223 AT gmail.com
 * LumaQQ：http://lumaqq.linuxsir.org 
 * LumaQQ - Java QQ Client
 * 
 * Copyright (C) 2004 luma <stubma@163.com>
 * 
 * LumaQQ - For .NET QQClient
 * Copyright (C) 2008 阿不<hjf1223 AT gmail.com>
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using LumaQQ.NET.Utils;

namespace LumaQQ.NET.Packets
{
    /// <summary>
    /// 
    /// </summary>
    public abstract class _08Packet
    {
        /// <summary>
        /// 解密者.
        /// </summary>
        protected static Crypter crypter = new Crypter();

        /// <summary>
        /// 包体缓冲区，有back array，用来存放未加密时的包体，子类应该在putBody方法中
        /// 使用这个缓冲区。使用之前先执行clear() 
        /// </summary>
        protected static ByteBuffer bodyBuf = new ByteBuffer();


        /// <summary>
        /// 包命令, 0x03~0x04.
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <value></value>
        public _08QQ.Command Command { get; set; }

        /// <summary>源标志, 0x01~0x02.
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <value></value>
        public ushort Source { get; set; }

        /// <summary>包序号, 0x05~0x06.
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <value></value>
        public ushort Sequence { get; set; }
        /// <summary>
        /// 包头字节 
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <value></value>
        public _08QQ.HeaderFamily Header { get; set; }
        /// <summary>
        /// true表示这个包是一个重复包，重复包本来是不需要处理的，但是由于LumaQQ较常发生
        ///  消息确认包丢失的问题，所以，这里加一个字段来表示到来的消息包是重复的。目前这个
        ///  字段只对消息有效，姑且算个解决办法吧，虽然不是太好看
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <value></value>
        public bool IsDuplicated { get; set; }

        /// <summary>
        ///第一次解密失败后再次尝试的密钥
        /// </summary>
        /// <value>The fallback decrypt key.</value>
        public byte[] FallbackDecryptKey { get; set; }

        /// <summary>
        ///  解密密钥
        /// </summary>
        /// <value>The decrypt key.</value>
        public byte[] DecryptKey { get; set; }

        /// <summary>
        /// 加密密钥
        /// </summary>
        public byte[] EncryptKey { get; set; }
        /// <summary>
        /// QQUser
        /// 为了支持一个JVM中创建多个QQClient，包中需要保持一个QQUser的引用以
        /// 确定包的用户相关字段如何填写
        /// </summary>
        protected QQUser user;
        /**
         * true表示这个包是一个重复包，重复包本来是不需要处理的，但是由于LumaQQ较常发生
         * 消息确认包丢失的问题，所以，这里加一个字段来表示到来的消息包是重复的。目前这个
         * 字段只对消息有效，姑且算个解决办法吧，虽然不是太好看
         */
        protected bool duplicated = false;
        /**
         * 明文包体
         */
        protected byte[] bodyDecrypted;

        /// <summary>
        /// 构造一个指定参数的包
        /// </summary>
        /// <param name="header">包头 0x02</param>
        /// <param name="source"> 包源 0x113f</param>
        /// <param name="command">包命令.</param>
        /// <param name="sequence">包序号.</param>
        /// <param name="user">QQ用户对象</param>
        public _08Packet(_08QQ.HeaderFamily header, ushort source, _08QQ.Command command, ushort sequence, QQUser user)
        {
            this.user = user;
            this.Source = source;
            this.Command = command;
            this.Sequence = sequence;
            if (this.PacketName == "Touch Login _08Packet")
            {
                sequence = (char)0x0000;
            }
            this.Header = header;
            this.DateTime = DateTime.Now;
        }
        protected _08Packet(ByteBuffer buf, QQUser user)
            : this(buf, buf.Length - buf.Position, user)
        {
        }
        protected _08Packet(ByteBuffer buf, int length, QQUser user)
        {
            this.user = user;
            // 解析头部
            ParseHeader(buf);
            // 检查QQ号
            if (!ValidateHeader())
            {
                throw new PacketParseException("包头有误，抛弃该包: " + this.ToString());
            }
            // 得到包体
            byte[] body = GetBodyBytes(buf, length);
            bodyDecrypted = DecryptBody(body);
            if (bodyDecrypted == null)
                throw new PacketParseException("包内容解析出错，抛弃该包: " + ToString());
            // 包装到ByteBuffer
            ByteBuffer tempBuf = new ByteBuffer(bodyDecrypted);
            try
            {
                ParseBody(tempBuf);
            }
            catch (Exception e)
            {
                throw new PacketParseException(e.Message, e);
            }
            ParseTail(buf);
            this.DateTime = DateTime.Now;
        }
        /// <summary> 构造一个包对象，什么字段也不填，仅限于子类使用
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        protected _08Packet()
        {
            this.DateTime = DateTime.Now;
        }
        /// <summary>得到UDP形式包的总长度，不考虑TCP形式
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="bodyLength">包体长度.</param>
        /// <returns>包长度</returns>
        protected abstract int GetLength(int bodyLength);

        /// <summary>校验头部
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <returns></returns>
        protected abstract bool ValidateHeader();

        /// <summary>包头长度
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <returns>包头长度</returns>
        protected abstract int GetHeaderLength();

        /// <summary>
        /// 包尾长度
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <returns>包尾长度</returns>
        protected abstract int GetTailLength();

        /// <summary>
        /// 将包头部转化为字节流, 写入指定的ByteBuffer对象.
        /// <remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="buf">The buf.</param>
        protected abstract void PutHead(ByteBuffer buf);

        /// <summary>初始化包体
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="buf">The buf.</param>
        protected abstract void PutBody(ByteBuffer buf);

        /// <summary>得到包体的字节数组
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="buf">The buf.</param>
        /// <param name="length">包总长度</param>
        /// <returns>包体字节数组</returns>
        protected abstract byte[] GetBodyBytes(ByteBuffer buf, int length);

        /// <summary>
        /// 标识这个包属于哪个协议族
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <returns></returns>
        public abstract _08QQ.ProtocolFamily GetFamily();

        /// <summary>
        /// 将包尾部转化为字节流, 写入指定的ByteBuffer对象.
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="buf">The buf.</param>
        protected abstract void PutTail(ByteBuffer buf);

        /// <summary>
        ///  加密包体
        /// </summary>
        /// <param name="b">未加密的字节数组</param>
        /// <returns>加密的包体</returns>
        protected virtual byte[] EncryptBody(byte[] b)
        {
            // get start
            int start = GetEncryptStart();
            if (start == -1)
            {
                return b;
                // get length
            }
            int length = GetEncryptLength();
            if (length == -1)
            {
                length = b.Length - start;
                //System.out.println("登陆包的密匙2为：" +  Util.convertByteToHexString(getEncryptKey(b)));
                // encrypt
            }
            byte[] enc = crypter.Encrypt(b, start, length, GetEncryptKey(b));

            // 出错?
            if (enc == null)
            {
                return b;
                // 组装返回结果
            }
            byte[] ret = enc;
            if (b.Length - length > 0)
            {
                ret = new byte[b.Length - length + enc.Length];
                Array.Copy(b, 0, ret, 0, start);
                Array.Copy(enc, 0, ret, start, enc.Length);
                Array.Copy(b, start + length, ret, start + enc.Length, b.Length - start - length);
            }

            return ret;
        }

        /// <summary>
        /// 解密包体
        /// </summary>
        /// <param name="body">包体字节数组</param>
        /// <returns>解密的包体字节数组</returns>
        protected byte[] DecryptBody(byte[] body)
        {
            // 得到解密起始
            int start = GetDecryptStart();
            if (start == -1) // 没有加密
            {
                return body;
                // 得到解密长度
            }
            int length = GetDecryptLength();
            if (length == -1)
            {
                length = body.Length - start;
                // 第一次解密
            }
            byte[] dec = crypter.Decrypt(body, start, length, GetDecryptKey(body));

            // 第二次解密
            if (dec == null)
            {
                dec = crypter.Decrypt(body, start, length, GetFallbackDecryptKey(body));
                // 出错?
            }
            if (dec == null)
            {
                return null;
                // 如果start大于0
            }
            byte[] ret = dec;
            if (body.Length - length > 0)
            {
                ret = new byte[dec.Length + body.Length - length];
                Array.Copy(body, 0, ret, 0, start);
                Array.Copy(dec, 0, ret, start, dec.Length);
                Array.Copy(body, start + length, ret, start + dec.Length, body.Length - start - length);
            }

            return ret;
        }

        public virtual byte[] GetFallbackDecryptKey(byte[] body)
        {
            return this.FallbackDecryptKey;
        }

        /// <summary>
        /// 解密的密文长度，-1表示一直到包体结束
        /// </summary>
        /// <returns></returns>
        protected virtual int GetDecryptLength()
        {
            return -1;
        }

        /// <summary>
        /// 解密的起始位置，这个位置相对于包体来说，-1表示此包没有加密
        /// </summary>
        /// <returns></returns>
        protected virtual int GetDecryptStart()
        {
            return 0;
        }
        /// <summary>
        /// 加密的起始位置，这个位置是相对于包体的第一个字节来说的，-1表示此包不需要加密
        /// </summary>
        /// <returns></returns>
        protected virtual int GetEncryptStart()
        {
            return 0;
        }
        /// <summary>
        /// 需要加密的明文长度，如果为-1，表示加密到包体结束为止
        /// </summary>
        /// <returns></returns>
        protected virtual int GetEncryptLength()
        {
            return -1;
        }

        public virtual byte[] GetDecryptKey(byte[] body)
        {
            return this.DecryptKey;
        }

        public virtual byte[] GetEncryptKey(byte[] body)
        {
            return this.EncryptKey;
        }

        /// <summary>从buf的当前未知解析包尾
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="buf">The buf.</param>
        protected abstract void ParseTail(ByteBuffer buf);

        /// <summary>解析包体，从buf的开头位置解析起
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="buf">The buf.</param>
        protected abstract void ParseBody(ByteBuffer buf);


        /// <summary>从buf的当前位置解析包头
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="buf">The buf.</param>
        protected abstract void ParseHeader(ByteBuffer buf);


        /// <summary>
        /// 包的描述性名称
        /// </summary>
        /// <value>The name of the packet.</value>
        public virtual string PacketName { get; private set; }

        /// <summary>
        /// 包的接收时间或发送时间
        /// 	<remark>abu 2008-03-13 </remark>
        /// </summary>
        /// <value></value>
        public DateTime DateTime { get; set; }

        /// <summary>
        /// Gets or sets the name of the port.
        /// </summary>
        /// <value>The name of the port.</value>
        public string PortName { get; set; }
        #region override object
        public override string ToString()
        {
            return "包名: " + PacketName + " 包序号: " + (int)this.Sequence;
        }
        public override bool Equals(object obj)
        {
            if (obj is _08Packet)
            {
                _08Packet packet = (_08Packet)obj;
                return Header == packet.Header && Command == packet.Command && Sequence == packet.Sequence;
            }
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return Hash(Sequence, (ushort)Command);
        }


        /// <summary>
        /// 得到hash值
        /// <remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="sequence">The sequence.</param>
        /// <param name="command">The command.</param>
        /// <returns></returns>
        public static int Hash(ushort sequence, ushort command)
        {
            return (sequence << 16) | (ushort)command;
        }
        #endregion
    }
}
