﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumaQQ.NET.Packets.In._08
{
    public class _08FirstLoginReplyPacket : _08BasicInPacket
    {
        public _08FirstLoginReplyPacket(ByteBuffer buf, int length, QQUser user)
            : base(buf, length, user)
        {
        }
        public override string PacketName
        {
            get
            {
                return "07 First Login Reply _08Packet";
            }
        }
        public override byte[] GetDecryptKey(byte[] body)
        {
            return user.PasswordKey;
        }
        public override byte[] GetFallbackDecryptKey(byte[] body)
        {
            return user.LoginKey;
        }
        protected override void ParseBody(ByteBuffer buf)
        {
            buf.GetByteArray(10);//如果正确的话
        }
    }
}
