﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LumaQQ.NET.Packets.In
{
    public class UploadGroupFriendReplyPacket : _08BasicInPacket
    {
        public _08QQ.ReplyCode ReplyCode { get; private set; }
        public UploadGroupFriendReplyPacket(ByteBuffer buf, int length, QQUser user)
            : base(buf, length, user)
        {
        }
        public override string PacketName
        {
            get
            {
                return "Upload Group Friend Reply _08Packet";
            }
        }
        protected override void ParseBody(ByteBuffer buf)
        {
            ReplyCode = (_08QQ.ReplyCode)buf.Get();
        }
    }
}
