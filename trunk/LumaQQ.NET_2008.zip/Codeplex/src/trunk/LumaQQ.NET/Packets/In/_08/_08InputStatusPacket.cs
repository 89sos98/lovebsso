﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumaQQ.NET.Packets.In._08
{
    /**
 * 用户输入状态包
 *
 * @author seraph 2008-4-5
 */
    public class _08InputStatusPacket : _08BasicInPacket
    {
        public int UserQQ { get; private set; }
        public int FriendQQ { get; private set; }
        public int Flag { get; private set; }

        public _08InputStatusPacket(ByteBuffer buf, int length, QQUser user)
            : base(buf, length, user)
        {
        }
        protected override void ParseBody(ByteBuffer buf)
        {
            //System.out.println("*********************执行到了这里");
            //好友的QQ号
            FriendQQ = buf.GetInt();
            UserQQ = buf.GetInt();
            buf.GetInt();//位置4字节
            Flag = buf.GetInt();//位置4字节
            buf.GetInt();//位置4字节
            buf.GetInt();//还是好友QQ
        }
    }
}
