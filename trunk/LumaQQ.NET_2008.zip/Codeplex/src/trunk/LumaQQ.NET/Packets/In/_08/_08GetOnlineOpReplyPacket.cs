﻿using System;
using System.Collections.Generic;
using System.Text;
using LumaQQ.NET.Entities;

namespace LumaQQ.NET.Packets.In._08
{
    /**
 * <pre>
 * 得到在线好友列表的应答包，格式为
 * 1. 头部
 * 2. 在线好友是否已经全部得到，1字节
 * 3. 31字节的FriendStatus结构
 * 4. 2个未知字节
 * 5. 1个字节扩展标志
 * 6. 1个字节通用标志
 * 7. 2个未知字节
 * 8. 1个未知字节
 * 9. 如果有更多在线好友，重复2-8部分
 * 10. 尾部
 * <p/>
 * 这个回复包最多返回30个在线好友，如果有更多，需要继续请求
 * </pre>
 *
 * @author luma
 */
    public class _08GetOnlineOpReplyPacket : _08BasicInPacket
    {
        public bool Finished { get; private set; }
        public int Position { get; private set; }
        public List<FriendOnlineEntry> OnlineFriends { get; private set; }

        public _08GetOnlineOpReplyPacket(ByteBuffer buf, int length, QQUser user)
            : base(buf, length, user)
        {
        }
        public override string PacketName
        {
            get
            {
                return "Get Friend Online Reply _08Packet";
            }
        }
        protected override void ParseBody(ByteBuffer buf)
        {
            // 当前好友列表位置
            Finished = buf.Get() == _08QQ.QQ_POSITION_ONLINE_LIST_END;
            Position = 0;
            // 只要还有数据就继续读取下一个friend结构
            OnlineFriends = new List<FriendOnlineEntry>();
            while (buf.HasRemaining())
            {
                FriendOnlineEntry entry = new FriendOnlineEntry();
                entry.Read(buf);
                // 添加到List
                OnlineFriends.Add(entry);

                // 如果还有更多好友，计算position
                if (!Finished)
                    Position = Math.Max(Position, entry.Status.QQ);
            }

            Position++;
        }
    }
}
