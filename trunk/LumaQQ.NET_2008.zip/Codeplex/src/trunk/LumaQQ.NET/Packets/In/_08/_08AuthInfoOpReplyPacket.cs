﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumaQQ.NET.Packets.In._08
{
    /**
 * <pre>
 * 这个请求验证信息的应答包，格式是
 * <p/>
 * ************ 格式1，请求验证信息的回复包 **********
 * 头部
 * -------- 加密开始（会话密钥）--------
 * 子命令，1字节，0x01
 * 未知2字节，0x0001
 * 回复码，1字节
 * 验证信息长度，2字节
 * 验证信息
 * -------- 加密结束 ----------
 * 尾部
 * <p/>
 * ************ 格式2，提交验证信息的回复包 **********
 * 头部
 * -------- 加密开始（会话密钥）--------
 * 子命令，1字节，0x02
 * 未知2字节，0x0001
 * 回复码，1字节
 * 如果回复码是0x00, 继续
 * auth info length, 2 bytes
 * auth info
 * -------- 加密结束 ----------
 * 尾部
 * </pre>
 *
 * @author luma
 */
    public class _08AuthInfoOpReplyPacket : _08BasicInPacket
    {
        public _08QQ.SubCMD_Auth_Info SubCommand { get; private set; }
        public _08QQ.ReplyCode ReplyCode { get; private set; }
        public byte[] AuthInfo { get; private set; }
        public _08QQ.SubSubCMD_Auth_Info SubSubCommand { get; private set; }
        public string Message { get; private set; }
        public _08AuthInfoOpReplyPacket(ByteBuffer buf, int length, QQUser user)
            : base(buf, length, user)
        {
        }
        public override string PacketName
        {
            get
            {
                return "Get Auth Info Reply _08Packet";
            }
        }
        protected override void ParseBody(ByteBuffer buf)
        {
            int len = 0;
            SubCommand = (_08QQ.SubCMD_Auth_Info)buf.Get();
            SubSubCommand = (_08QQ.SubSubCMD_Auth_Info)buf.GetUShort();
            ReplyCode = (_08QQ.ReplyCode)buf.Get();
            switch (SubCommand)
            {
                case _08QQ.SubCMD_Auth_Info.QQ_SUB_CMD_GET_AUTH_INFO:
                    switch (ReplyCode)
                    {
                        case _08QQ.ReplyCode.QQ_REPLY_OK:
                            len = buf.GetUShort();
                            AuthInfo = buf.GetByteArray(len);
                            break;
                        case _08QQ.ReplyCode.QQ_REPLY_NEED_VERTIFY://需要验证码
                            len = buf.GetUShort();
                            AuthInfo = buf.GetByteArray(len);
                            Message = Utils.Util.GetString(AuthInfo);
                            System.Console.WriteLine(Message);
                            break;
                    }
                    break;
                case _08QQ.SubCMD_Auth_Info.QQ_SUB_CMD_GET_AUTH_INFO_NEED_VERTIFY:
                    if (ReplyCode == _08QQ.ReplyCode.QQ_REPLY_OK)
                    {
                        len = buf.GetUShort();
                        AuthInfo = buf.GetByteArray(len);
                        break;
                    }
                    break;
            }
        }
    }
}
