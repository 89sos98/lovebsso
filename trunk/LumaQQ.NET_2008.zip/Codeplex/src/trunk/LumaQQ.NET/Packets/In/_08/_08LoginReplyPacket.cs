﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumaQQ.NET.Packets.In._08
{
    /**
 * 登录回复包
 *
 * @author dream.seraph
 */
    public class _08LoginReplyPacket : _08BasicInPacket
    {
        public _08QQ.Reply_Login ReplyCode { get; private set; }
        public byte[] SessionKey { get; private set; }
        public byte[] IP { get; private set; }
        public ushort Port { get; private set; }
        public byte[] ServerIP { get; private set; }
        public ushort ServerPort { get; private set; }
        public long LoginTime { get; private set; }
        public byte[] LoginTimeRude { get; private set; }
        public long LastLoginTime { get; private set; }
        public string ReplyMessage { get; private set; }
        public byte[] ClientKey { get; private set; }
        public byte[] LastLoginIP { get; private set; }
        public byte[] RedirectIP { get; private set; }
        public int RedirectPort { get; private set; }
        /// <summary>
        /// 本地主机名
        /// </summary>
        /// <value>The local host.</value>
        public byte[] LocalHost { get; private set; }

        /// <summary>
        /// 认证令牌，用在一些需要认证身份的地方，比如网络硬盘
        /// </summary>
        /// <value>The autho token.</value>
        public byte[] AuthToken { get; private set; }
        /// <summary>
        ///用户的QQ号
        /// </summary>
        /// <value>The user QQ.</value>
        public byte[] UserQQ { get; private set; }

        public _08LoginReplyPacket(ByteBuffer buf, int length, QQUser user)
            : base(buf, length, user)
        {
        }
        public override string PacketName
        {
            get
            {
                return "07 Login Reply _08Packet";
            }
        }

        public override byte[] GetDecryptKey(byte[] body)
        {
            return user.PasswordKey;
        }
        public override byte[] GetFallbackDecryptKey(byte[] body)
        {
            return user.LoginKey;
        }
        protected override void ParseBody(ByteBuffer buf)
        {
            ReplyCode = (_08QQ.Reply_Login)buf.Get();//登陆类型码

            switch (ReplyCode)
            {
                case _08QQ.Reply_Login.QQ_REPLY_OK:
                    SessionKey = buf.GetByteArray(_08QQ.QQ_LENGTH_KEY);
                    // 用户QQ号
                    UserQQ = buf.GetByteArray(4);
                    // 用户IP
                    IP = buf.GetByteArray(4);
                    // 用户端口
                    Port = buf.GetUShort();
                    //127.0.0.1
                    LocalHost = buf.GetByteArray(4);
                    // 服务器的端口
                    ServerPort = buf.GetUShort();
                    //本次登录的原始时间
                    LoginTimeRude = buf.GetByteArray(4);
                    // 本次登陆时间，为什么要乘1000？因为这个时间乘以1000才对，-_-!...
                    LoginTime = Utils.Util.GetIntFromBytes(LoginTimeRude, 0, 4) * 1000L;
                    //跳过50个字节
                    buf.Position = buf.Position + 50;
                    ClientKey = buf.GetByteArray(32);
                    //跳过12个字节
                    buf.Position = buf.Position + 12;
                    //上次登录的IP
                    LastLoginIP = buf.GetByteArray(4);
                    //上次登录的时间
                    LastLoginTime = buf.GetInt() * 1000L;
                    break;
                case _08QQ.Reply_Login.QQ_REPLY_LOGIN_FAIL://好像再也没这段了,被0x05命令代替了？
                    // 登录失败，我们得到服务器发回来的消息	   

                    byte[] b = buf.GetByteArray(buf.Length - 1);
                    ReplyMessage = Utils.Util.GetString(b, _08QQ.QQ_CHARSET_DEFAULT);
                    break;
                case _08QQ.Reply_Login.QQ_REPLY_LOGIN_REDIRECT:
                    // 登陆重定向，可能是为了负载平衡
                    // 用户QQ号
                    buf.GetInt();
                    // 未知10字节，跳过
                    buf.Position = buf.Position + 10;
                    //重定向到的服务器IP
                    RedirectIP = buf.GetByteArray(4);
                    // 使用缺省端口
                    RedirectPort = user.Port;
                    break;
                case _08QQ.Reply_Login.QQ_LOGIN_FAIL://0x05登录失败

                    Console.WriteLine("登录失败，可能是因为上线高峰吧，管他呢，继续登录！");
                    break;
            }
        }
    }
}
