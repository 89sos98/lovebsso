﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumaQQ.NET.Packets.In._08
{
    /**
 * Touch的服务器返回包
 * 1. 1字节的包头即 0x02
 * 2. QQ版本号，目前是0x113f
 * 3. 验证码登陆 2字节 0x0091
 * 4. 包序号 2字节 一直都是 0x0000
 * 5. 加密包体 16字节 解密之后是两字节的0x0000
 * 6. 包尾：1字节 0x03
 * <p/>
 * 虽然至今未发现这个包有什么用处， 但是处理了总比忽略了好吧， 毕竟我不用花那么多的时间去写界面
 *
 * @author luna
 */
    public class _08TouchLoginReplyPacket : _08BasicInPacket
    {
        public ushort ReplyCode { get; private set; }
        public byte[] ServerIP { get; set; }
        public _08TouchLoginReplyPacket(ByteBuffer buf, int length, QQUser user)
            : base(buf, length, user)
        {
        }
        public override string PacketName
        {
            get
            {
                return "Touch Reply _08Packet";
            }
        }
        public override byte[] GetDecryptKey(byte[] body)
        {
            return user.PasswordKey;
        }
        public override byte[] GetFallbackDecryptKey(byte[] body)
        {
            return user.LoginTokenRandomKey;
        }
        protected override void ParseBody(ByteBuffer buf)
        {
            ReplyCode = buf.GetUShort();
            if (ReplyCode == (ushort)0x0001)
            {// 获取推荐服务器地址
                buf.Position = buf.Position + 9;
                ServerIP = buf.GetByteArray(4);
            }
        }
    }
}
