﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumaQQ.NET.Packets.In._08
{
    /**
 * 获得登陆令牌1
 * -----------------
 * 包格式
 * 1. 1字节的包头 0x02
 * 2. 2字节的QQ版本号 0x113f
 * 3. 2字节的命令字 0x0062
 * 4. 2字节的包序号 0x2679
 * 以下是包体：
 * 5. 2字节的登陆令牌1 长度 0x0018
 * 6. 24位令牌1 的内容
 * 7. 包尾 1字节 0x03
 *
 * @author luna
 */
    public class _08LoginToken1ReplyPacket : _08BasicInPacket
    {
        public ushort LoginTokenLength { get; private set; }
        public byte[] LoginToken1 { get; private set; }
        public _08LoginToken1ReplyPacket(ByteBuffer buf, int length, QQUser user)
            : base(buf, length, user)
        {
        }
        public override string PacketName
        {
            get
            {
                return "Login Token 1 Reply _08Packet";
            }
        }
        protected override int GetDecryptStart()
        {
            return -1;
        }
        protected override void ParseBody(ByteBuffer buf)
        {
            //System.out.println("Login Token 1 的Parserbody方法已经被执行");
            //buf.clear();
            //登陆令牌1长度
            LoginTokenLength = buf.GetUShort();
            //登陆令牌内容 //设置登陆令牌1
            LoginToken1 = buf.GetByteArray(24);
        }
    }
}
