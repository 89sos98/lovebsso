﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumaQQ.NET.Packets.In._08
{
    /**
 * <pre>
 * 发送验证消息的回复包
 * 1. 头部
 * 2. 子命令，1字节
 * 3. 要添加的QQ号，4字节
 * 4. 回复码，1字节
 * 5. 尾部
 * </pre>
 *
 * @author luma
 */
    public class _08AuthorizeReplyPacket : _08BasicInPacket
    {
        public _08QQ.SubCMD_Authorize SubCommand { get; private set; }
        public int To { get; private set; }
        public _08QQ.ReplyCode ReplyCode { get; private set; }

        public _08AuthorizeReplyPacket(ByteBuffer buf, int length, QQUser user)
            : base(buf, length, user)
        {
        }
        protected override void ParseBody(ByteBuffer buf)
        {
            SubCommand = (_08QQ.SubCMD_Authorize)buf.Get();
            To = buf.GetInt();
            ReplyCode = (_08QQ.ReplyCode)buf.Get();
        }
        public override string PacketName
        {
            get
            {
                return "Authorize Reply _08Packet";
            }
        }
    }
}
