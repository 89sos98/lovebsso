﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumaQQ.NET.Packets.In._08
{
    /**
 * <pre>
 * Keep Alive的应答包，格式为
 * 头部
 * ----------- 加密开始(会话密钥) --------
 * 回复码，1字节
 * 在线人数，4字节
 * 我的ip，4字节
 * 我的端口，2字节
 * 未知2字节
 * 当前时间，4字节
 * 未知4字节
 * 未知1字节
 * ----------- 加密结束 -----------
 * 尾部
 * </pre>
 *
 * @author luma
 */
    public class _08KeepAliveReplyPacket : _08BasicInPacket
    {
        public _08QQ.ReplyCode ReplyCode { get; private set; }
        public int Time { get; private set; }
        /// <summary>
        /// 在线人数
        /// </summary>
        /// <value>The onlines.</value>
        public int Onlines { get; private set; }
        public byte[] IP { get; private set; }
        public int Port { get; private set; }
        public _08KeepAliveReplyPacket(ByteBuffer buf, int length, QQUser user)
            : base(buf, length, user)
        {
        }
        public override string PacketName
        {
            get
            {
                return "Keep Alive Reply _08Packet";
            }
        }
        protected override void ParseBody(ByteBuffer buf)
        {
            ReplyCode = (_08QQ.ReplyCode)buf.Get();//应答是否成功
            Onlines = buf.GetInt();//在线人数
            IP = buf.GetByteArray(4);//我的ip
            Port = buf.GetUShort();//端口
            buf.GetUShort();//1个未知字节
            Time = buf.GetInt();//本次登录时间
            //增加了5个未知字节
            buf.GetByteArray(5);
        }
    }
}
