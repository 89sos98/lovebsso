﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumaQQ.NET.Packets.In._08
{
    /**
 * 1. 包头 1字节 0x02
 * 2. QQ版本 2字节 0x113f
 * 3. 命令字 2字节 0x00ba
 * 4. 包序号 2字节 0x2679
 * 5. 加密包体 48字节
 * 6. 包尾 1字节 0x03
 *
 * @author luna
 */
    public class _08LoginToken2ReplyPacket : _08BasicInPacket
    {
        public byte[] LoginToken2 { get; private set; }
        public _08QQ.SubCMD_GetLoginToken SubCommand { get; private set; }
        public _08QQ.Reply_LoginToken2 ReplyCode { get; private set; }
        public byte[] PuzzleData { get; private set; }
        public byte[] NextImageToken { get; private set; }
        public int FragmentIndex { get; private set; }
        public int NextFragmentIndex { get; private set; }
        public _08LoginToken2ReplyPacket(ByteBuffer buf, int length, QQUser user)
            : base(buf, length, user)
        {
        }
        public override string PacketName
        {
            get
            {
                return "Login Token 2 Reply _08Packet";
            }
        }
        public override byte[] GetDecryptKey(byte[] body)
        {
            return user.PasswordKey;
        }
        public override byte[] GetFallbackDecryptKey(byte[] body)
        {
            return user.LoginTokenRandomKey;
        }
        protected override void ParseBody(ByteBuffer buf)
        {
            SubCommand = (_08QQ.SubCMD_GetLoginToken)buf.Get();
            buf.GetChar();
            ReplyCode = (_08QQ.Reply_LoginToken2)buf.Get();
            ushort len = buf.GetUShort();
            LoginToken2 = buf.GetByteArray(len);
            switch (ReplyCode)
            {
                case _08QQ.Reply_LoginToken2.QQ_REPLY_LOGIN_NEED_VERIFY:
                    len = buf.GetUShort();
                    PuzzleData = buf.GetByteArray(len);
                    //下面俩字节
                    FragmentIndex = (buf.Get() & ((byte)0xFF));
                    NextFragmentIndex = (buf.Get() & ((byte)0xFF));

                    len = buf.GetUShort();
                    NextImageToken = buf.GetByteArray(len);
                    break;
            }
        }
    }
}
