﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumaQQ.NET.Packets.In._08
{
    /**
 * 登陆密匙返回包
 * ---------------------
 * 包格式：
 * 1. 包头 1字节 0x02
 * 2. 版本号 2字节 0x113f
 * 3. 命令字 2字节 0x00dd
 * 4. 包序号 2字节 0x2679， 一直没变过
 * 5. 硕大的加密包体,密匙是QQ密码的两次MD5
 * 6. 包尾 0x03
 *
 * @author luna
 */
    public class _08LoginKeyReplyPacket : _08BasicInPacket
    {
        /// <summary>
        /// 未知的5字节数据
        /// </summary>
        /// <value>The unknown5.</value>
        public byte[] Unknown5 { get; private set; }

        /// <summary>
        /// 32字节的的未知数据1
        /// </summary>
        /// <value>The unknown32_1.</value>
        public byte[] Unknown32_1 { get; private set; }

        /// <summary>
        /// 32字节的未知数据2
        /// </summary>
        /// <value>The unknown32_2.</value>
        public byte[] Unknown32_2 { get; private set; }

        public byte[] LoginToken { get; private set; }

        public byte[] Key { get; private set; }
        public byte[] ErrorMsg { get; private set; }
        public _08QQ.Reply_LoginKey ReplyCode { get; private set; }

        public _08LoginKeyReplyPacket(ByteBuffer buf, int length, QQUser user)
            : base(buf, length, user)
        {
        }
        public override string PacketName
        {
            get
            {
                return "Login key Reply _08Packet";
            }
        }
        public override byte[] GetDecryptKey(byte[] body)
        {
            return user.PasswordKey;
        }
        public override byte[] GetFallbackDecryptKey(byte[] body)
        {
            return user.LoginTokenRandomKey;
        }
        protected override void ParseBody(ByteBuffer buf)
        {
            buf.GetChar();
            ReplyCode = (_08QQ.Reply_LoginKey)buf.Get();
            buf.GetInt();
            ushort len = buf.GetUShort();
            Unknown32_1 = buf.GetByteArray(len);
            len = buf.GetUShort();
            Unknown32_2 = buf.GetByteArray(len);
            len = buf.GetUShort();
            switch (ReplyCode)
            {
                case _08QQ.Reply_LoginKey.QQ_REPLY_OK:
                    LoginToken = buf.GetByteArray(len);
                    Key = buf.GetByteArray(_08QQ.QQ_LENGTH_KEY);
                    break;
                case _08QQ.Reply_LoginKey.QQ_CMD_PASSWORD_ERROR:
                case _08QQ.Reply_LoginKey.QQ_CMD_NEED_ACTIVATE:
                    ErrorMsg = buf.GetByteArray(len);
                    break;
                default:
                    ErrorMsg = buf.GetByteArray(len);
                    break;
            }

        }
    }
}
