﻿#region 版权声明
/**
 * 版权声明：LumaQQ.NET是基于LumaQQ分析的QQ协议，将其部分代码进行修改和翻译为.NET版本，并且继续使用LumaQQ的开源协议。
 * 本人没有对其核心协议进行改动， 也没有与腾讯公司的QQ软件有直接联系，请尊重LumaQQ作者Luma的著作权和版权声明。
 * 同时在使用此开发包前请自行协调好多方面关系，本人不享受和承担由此产生的任何权利以及任何法律责任。
 * 
 * 作者：阿不
 * 博客：http://hjf1223.cnblogs.com
 * Email：hjf1223 AT gmail.com
 * LumaQQ：http://lumaqq.linuxsir.org 
 * LumaQQ - Java QQ Client
 * 
 * Copyright (C) 2004 luma <stubma@163.com>
 * 
 * LumaQQ - For .NET QQClient
 * Copyright (C) 2008 阿不<hjf1223 AT gmail.com>
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#endregion
using System;
using System.Collections.Generic;
using System.Text;

namespace LumaQQ.NET.Packets.In
{
    /// <summary>
    /**
   * <pre>
   * 认证问题操作的回复包
   * <p/>
   * ******** 格式1，得到认证问题的回复包 ********
   * 头部
   * ------- 加密开始，会话密钥 --------
   * 子命令，1字节，0x03
   * 未知2字节，0x0001
   * 回复码，1字节 （如果回复码为0x00，继续后面的部分）
   * 问题长度，1字节
   * 问题
   * ------- 加密结束 --------
   * 尾部
   * <p/>
   * ******** 格式2，回答问题的回复包 ********
   * 头部
   * ------- 加密开始，会话密钥 --------
   * 子命令，1字节，0x03
   * 未知2字节，0x0001
   * 回复码，1字节 （如果回复码为0x00，继续后面的部分）
   * 验证信息长度，2字节
   * 验证信息
   * ------- 加密结束 --------
   * 尾部
   * </pre>
   *
   * @author luma
   */
    /// </summary>
    public class AuthQuestionOpReplyPacket : _08BasicInPacket
    {
        public _08QQ.SubCMD_Auth_Question SubCommand { get; set; }
        public _08QQ.ReplyCode ReplyCode { get; set; }
        public byte[] AuthInfo { get; set; }
        public string Question { get; set; }

        public AuthQuestionOpReplyPacket(ByteBuffer buf, int length, QQUser user)
            : base(buf, length, user)
        {
        }
        protected override void ParseBody(ByteBuffer buf)
        {
            SubCommand = (_08QQ.SubCMD_Auth_Question)buf.Get();
            buf.GetChar();
            ReplyCode = (_08QQ.ReplyCode)buf.Get();
            switch (SubCommand)
            {
                case _08QQ.SubCMD_Auth_Question.QQ_SUB_CMD_GET_QUESTION:
                    if (ReplyCode == _08QQ.ReplyCode.QQ_REPLY_OK)
                    {
                        int len = buf.Get() & 0xFF;
                        Question = Utils.Util.GetString(buf, len);
                    }
                    break;
                case _08QQ.SubCMD_Auth_Question.QQ_SUB_CMD_ANSWER_QUESTION:
                    if (ReplyCode == _08QQ.ReplyCode.QQ_REPLY_OK)
                    {
                        int len = buf.GetChar();
                        AuthInfo = buf.GetByteArray(len);
                    }
                    break;
            }
        }

        public override string PacketName
        {
            get
            {
                return "Auth Question Op Reply _08Packet";
            }
        }
    }


}
