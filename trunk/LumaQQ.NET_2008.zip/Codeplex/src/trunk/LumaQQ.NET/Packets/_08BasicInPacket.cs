﻿#region 版权声明
/**
 * 版权声明：LumaQQ.NET是基于LumaQQ分析的QQ协议，将其部分代码进行修改和翻译为.NET版本，并且继续使用LumaQQ的开源协议。
 * 本人没有对其核心协议进行改动， 也没有与腾讯公司的QQ软件有直接联系，请尊重LumaQQ作者Luma的著作权和版权声明。
 * 同时在使用此开发包前请自行协调好多方面关系，本人不享受和承担由此产生的任何权利以及任何法律责任。
 * 
 * 作者：阿不
 * 博客：http://hjf1223.cnblogs.com
 * Email：hjf1223 AT gmail.com
 * LumaQQ：http://lumaqq.linuxsir.org 
 * LumaQQ - Java QQ Client
 * 
 * Copyright (C) 2004 luma <stubma@163.com>
 * 
 * LumaQQ - For .NET QQClient
 * Copyright (C) 2008 阿不<hjf1223 AT gmail.com>
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#endregion
using System;
using System.Collections.Generic;
using System.Text;

namespace LumaQQ.NET.Packets
{
    /// <summary>
    /// 基本协议族的输入包基类:
    ///  1. 包头标志，1字节，0x02
    ///  2. 服务器端版本代码, 2字节
    ///  3. 命令，2字节
    ///  4. 包序号，2字节
    ///  5. 包体
    ///  6. 包尾标志，1字节，0x03   
    /// 	在LumaQQ中，这边还定义了元数据。
    /// </summary>
    public abstract class _08BasicInPacket : _08InPacket
    {

        /// <summary>
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="command">The command.</param>
        /// <param name="user">The user.</param>
        public _08BasicInPacket(_08QQ.Command command, QQUser user)
            : base(_08QQ.HeaderFamily.QQ_HEADER_BASIC_FAMILY, _08QQ.QQ_SERVER_VERSION_0100, command, user) { }
        /// <summary>
        /// 构造一个指定参数的包.从buf的当前位置开始解析直到limit
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="buf">The buf.</param>
        /// <param name="user">The user.</param>
        public _08BasicInPacket(ByteBuffer buf, QQUser user) : base(buf, user) { }
        /// <summary>
        /// 构造一个InPacket，从buf的当前位置解析length个字节
        /// 	<remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="buf">The buf.</param>
        /// <param name="length">The length.</param>
        /// <param name="user">The user.</param>
        public _08BasicInPacket(ByteBuffer buf, int length, QQUser user) : base(buf, length, user) { }
        /// <summary>
        /// 从buf的当前位置解析包头
        /// <remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="buf">The buf.</param>
        protected override void ParseHeader(ByteBuffer buf)
        {
            if (!user.IsUdp)
                buf.GetChar();
            Header = (_08QQ.HeaderFamily)buf.Get();
            Source = buf.GetChar();
            Command = (_08QQ.Command)buf.GetUShort();
            Sequence = buf.GetChar();
        }
        protected override void PutHead(ByteBuffer buf)
        {
            if (!user.IsUdp)
                buf.PutUShort(0);
            buf.Put((byte)Header);
            buf.PutUShort(Source);
            buf.PutUShort((ushort)Command);
            buf.PutUShort(Sequence);
        }
        /// <summary>
        /// 从buf的当前未知解析包尾
        /// <remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="buf">The buf.</param>
        protected override void ParseTail(ByteBuffer buf)
        {
            buf.Get();
        }
        /// <summary>
        /// 初始化包体
        /// <remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="buf">The buf.</param>
        protected override void PutBody(ByteBuffer buf)
        {

        }
        /// <summary>
        /// 将包尾部转化为字节流, 写入指定的ByteBuffer对象.
        /// <remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="buf">The buf.</param>
        protected override void PutTail(ByteBuffer buf)
        {
            buf.Put((byte)_08QQ.TailFamily.QQ_TAIL_BASIC_FAMILY);
        }
        /// <summary>
        /// 包的描述性名称
        /// <remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <returns></returns>
        public override string PacketName
        {
            get
            {
                return "Unknown Incoming Packet - 0x" + Command.ToString("X");
            }
        }

        /// <summary>
        /// 得到包体的字节数组
        /// <remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="buf">The buf.</param>
        /// <param name="length">包总长度</param>
        /// <returns>包体字节数组</returns>
        protected override byte[] GetBodyBytes(ByteBuffer buf, int length)
        {
            // 得到包体长度
            int bodyLen = length - _08QQ.QQ_LENGTH_BASIC_FAMILY_IN_HEADER - _08QQ.QQ_LENGTH_BASIC_FAMILY_TAIL;
            if (!user.IsUdp) bodyLen -= 2;
            // 得到加密的包体内容
            byte[] body = buf.GetByteArray(bodyLen);
            return body;
        }
        /// <summary>
        /// 得到UDP形式包的总长度，不考虑TCP形式
        /// <remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <param name="bodyLength">包体长度.</param>
        /// <returns>包长度</returns>
        protected override int GetLength(int bodyLength)
        {
            return _08QQ.QQ_LENGTH_BASIC_FAMILY_IN_HEADER + _08QQ.QQ_LENGTH_BASIC_FAMILY_TAIL + bodyLength + (user.IsUdp ? 0 : 2);
        }
        /// <summary>
        /// 包头长度
        /// <remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <returns>包头长度</returns>
        protected override int GetHeaderLength()
        {
            return _08QQ.QQ_LENGTH_BASIC_FAMILY_IN_HEADER + (user.IsUdp ? 0 : 2);
        }
        /// <summary>
        /// 包尾长度
        /// <remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <returns>包尾长度</returns>
        protected override int GetTailLength()
        {
            return _08QQ.QQ_LENGTH_BASIC_FAMILY_TAIL;
        }

        /// <summary>
        /// 标识这个包属于哪个协议族
        /// <remark>abu 2008-02-18 </remark>
        /// </summary>
        /// <returns></returns>
        public override _08QQ.ProtocolFamily GetFamily()
        {
            return _08QQ.ProtocolFamily.QQ_PROTOCOL_FAMILY_BASIC;
        }
        public override byte[] GetDecryptKey(byte[] body)
        {
            return user.SessionKey;
        }
        public override byte[] GetEncryptKey(byte[] body)
        {
            return user.SessionKey;
        }
        public override byte[] GetFallbackDecryptKey(byte[] body)
        {
            return user.PasswordKey;
        }
    }
}
