﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Data.Odbc;
using System.Collections.Generic;
using System.Collections;
using System.Data.SQLite;
using System.Threading;
using System.Text;

namespace Core
{
	public class AccountImpl
	{
		static AccountImpl m_Instance = new AccountImpl();

		public static AccountImpl Instance
		{
			get { return m_Instance; }
		}

		// 缓存中的用户信息的数量
#		if DEBUG
		const int MAX_CACHE_COUNT = 2;
#		else
		const int MAX_CACHE_COUNT = 2000;
#		endif

		LinkedList<AccountInfo> m_List = new LinkedList<AccountInfo>();

		Hashtable m_UserInfoCache = new Hashtable();
		Hashtable m_UserInfoCacheByID = new Hashtable();

		object m_Lock = new object();

		string m_ConnectionString;

		private AccountImpl()
		{
		}

		public void Init()
		{
			string path = String.Format(@"{0}\App_Data\Lesktop.db", ServerImpl.Instance.BaseDirecotry);
			m_ConnectionString = string.Format(
				   "Data Source=\"{0}\";Pooling=False",
				   path
			);
		}

		private AccountInfo RefreshUserInfo(string userName)
		{
			string key = userName.ToUpper();
			SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
			SQLiteCommand cmd = new SQLiteCommand();
			cmd.Connection = conn;
			cmd.CommandText = string.Format(
				"select * from Users u where u.UpperName=?",
				userName
			);

			cmd.Parameters.Add("User", DbType.String).Value = userName.ToUpper();

			SQLiteDataAdapter ada = new SQLiteDataAdapter();
			ada.SelectCommand = cmd;

			DataTable dt = new DataTable();
			ada.Fill(dt);
			ada.Dispose();

			if (dt.Rows.Count > 0)
			{
				DataTable dtFriends = GetFriends(userName);
				List<FriendInfo> friends = new List<FriendInfo>(), managers = new List<FriendInfo>();
				/*if (String.Compare(userName, "sa", true) != 0 && (Int64)dt.Rows[0]["Type"] == 0)
				{
					friends.Add(new FriendInfo("sa", new DateTime(2009, 1, 1), 0, 0));
				}*/
				FriendInfo creator = null;
				foreach (DataRow row in dtFriends.Rows)
				{
					string name = row["Name"] as string;
					DateTime renewTime = (DateTime)row["RenewTime"];
					FriendInfo fi = new FriendInfo(name, renewTime, (Int64)row["Relationship"], (Int64)row["Type"]);
					friends.Add(fi);
					switch ((Int64)row["Relationship"])
					{
					case 2:
						managers.Add(fi);
						break;
					case 3:
						managers.Add(fi);
						creator = fi;
						break;
					}
				}


				if (m_UserInfoCache.ContainsKey(key))
				{
					AccountInfo info = m_UserInfoCache[key] as AccountInfo;
					info.Reset(
						dt.Rows[0]["Name"] as string,
						dt.Rows[0]["NickName"] as string,
						(Int64)dt.Rows[0]["Key"],
						(Int64)dt.Rows[0]["Type"],
						GetUserRoles(userName),
						friends.ToArray(),
						(Int64)dt.Rows[0]["Type"] == 1 ? managers.ToArray() : null,
						creator,
						dt.Rows[0]["EMail"] as String,
						dt.Rows[0]["InviteCode"] as String,
						((Int64)dt.Rows[0]["AcceptStrangerIM"]) != 0,
						((Int64)dt.Rows[0]["MsgFileLimit"]),
						((Int64)dt.Rows[0]["MsgImageLimit"]),
						((Int64)dt.Rows[0]["DiskSize"]),
						((Int64)dt.Rows[0]["IsTemp"]),
						((DateTime)dt.Rows[0]["RegisterTime"]),
						dt.Rows[0]["HomePage"] as string,
						dt.Rows[0]["Password"] as string,
						dt.Rows[0]
					);
					return info;
				}
				else
				{
					AccountInfo info = new AccountInfo(
						dt.Rows[0]["Name"] as string,
						dt.Rows[0]["NickName"] as string,
						(Int64)dt.Rows[0]["Key"],
						(Int64)dt.Rows[0]["Type"],
						GetUserRoles(userName),
						friends.ToArray(),
						(Int64)dt.Rows[0]["Type"] == 1 ? managers.ToArray() : null,
						creator,
						dt.Rows[0]["EMail"] as String,
						dt.Rows[0]["InviteCode"] as String,
						((Int64)dt.Rows[0]["AcceptStrangerIM"]) != 0,
						((Int64)dt.Rows[0]["MsgFileLimit"]),
						((Int64)dt.Rows[0]["MsgImageLimit"]),
						((Int64)dt.Rows[0]["DiskSize"]),
						((Int64)dt.Rows[0]["IsTemp"]),
						((DateTime)dt.Rows[0]["RegisterTime"]),
						dt.Rows[0]["HomePage"] as string,
						dt.Rows[0]["Password"] as string,
						dt.Rows[0]
					);

					if (m_List.Count >= MAX_CACHE_COUNT)
					{
						AccountInfo removeInfo = m_List.First.Value;
						m_UserInfoCache.Remove(removeInfo.Name.ToUpper());
						m_UserInfoCacheByID.Remove(removeInfo.ID);
						m_List.RemoveFirst();
					}

					m_UserInfoCache[key] = info;
					m_UserInfoCacheByID[info.ID] = info;
					m_List.AddLast(info.ListNode);

					return info;
				}
			}
			else
			{
				return null;
			}
		}

		public DataRowCollection GetAllUsers()
		{
			SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
			SQLiteCommand cmd = new SQLiteCommand();
			cmd.Connection = conn;
			cmd.CommandText = @"
				select Key, Name, Nickname, EMail, RegisterTime 
				from Users u 
				where u.Type = 0
				order by RegisterTime desc";

			SQLiteDataAdapter ada = new SQLiteDataAdapter();
			ada.SelectCommand = cmd;

			DataTable dt = new DataTable();
			ada.Fill(dt);
			ada.Dispose();

			return dt.Rows;
		}

		public DataRowCollection GetAllGroups()
		{
			SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
			SQLiteCommand cmd = new SQLiteCommand();
			cmd.Connection = conn;
			cmd.CommandText = @"
				select u.Key, u.Name, u.Nickname, u.EMail, u.RegisterTime, c.Key Creator
				from Users u, Users c, UserRelationShip ur 
				where u.Type = 1 and u.Key = ur.HostKey and c.Key = ur.GuestKey and ur.Relationship = 3
				order by u.RegisterTime desc";

			SQLiteDataAdapter ada = new SQLiteDataAdapter();
			ada.SelectCommand = cmd;

			DataTable dt = new DataTable();
			ada.Fill(dt);
			ada.Dispose();

			return dt.Rows;
		}

		private AccountInfo RefreshUserInfo(Int64 id)
		{
			SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
			SQLiteCommand cmd = new SQLiteCommand();
			cmd.Connection = conn;
			cmd.CommandText = "select * from Users u where u.Key=?";

			cmd.Parameters.Add("User", DbType.Int64).Value = id;

			SQLiteDataAdapter ada = new SQLiteDataAdapter();
			ada.SelectCommand = cmd;

			DataTable dt = new DataTable();
			ada.Fill(dt);
			ada.Dispose();

			if (dt.Rows.Count > 0)
			{
				string userName = dt.Rows[0]["Name"] as string;

				DataTable dtFriends = GetFriends(userName);
				List<FriendInfo> friends = new List<FriendInfo>(), managers = new List<FriendInfo>();
				/*if (String.Compare(userName, "sa", true) != 0 && (Int64)dt.Rows[0]["Type"] == 0)
				{
					friends.Add(new FriendInfo("sa", new DateTime(2009, 1, 1), 0, 0));
				}*/
				FriendInfo creator = null;
				foreach (DataRow row in dtFriends.Rows)
				{
					string name = row["Name"] as string;
					DateTime renewTime = (DateTime)row["RenewTime"];
					FriendInfo fi = new FriendInfo(name, renewTime, (Int64)row["Relationship"], (Int64)row["Type"]);
					friends.Add(fi);
					switch ((Int64)row["Relationship"])
					{
					case 2:
						managers.Add(fi);
						break;
					case 3:
						managers.Add(fi);
						creator = fi;
						break;
					}
				}


				if (m_UserInfoCache.ContainsKey(userName.ToUpper()))
				{
					AccountInfo info = m_UserInfoCache[userName.ToUpper()] as AccountInfo;
					info.Reset(
						dt.Rows[0]["Name"] as string,
						dt.Rows[0]["NickName"] as string,
						(Int64)dt.Rows[0]["Key"],
						(Int64)dt.Rows[0]["Type"],
						GetUserRoles(userName),
						friends.ToArray(),
						(Int64)dt.Rows[0]["Type"] == 1 ? managers.ToArray() : null,
						creator,
						dt.Rows[0]["EMail"] as String,
						dt.Rows[0]["InviteCode"] as String,
						((Int64)dt.Rows[0]["AcceptStrangerIM"]) != 0,
						((Int64)dt.Rows[0]["MsgFileLimit"]),
						((Int64)dt.Rows[0]["MsgImageLimit"]),
						((Int64)dt.Rows[0]["DiskSize"]),
						((Int64)dt.Rows[0]["IsTemp"]),
						((DateTime)dt.Rows[0]["RegisterTime"]),
						dt.Rows[0]["HomePage"] as string,
						dt.Rows[0]["Password"] as string,
						dt.Rows[0]
					);
					return info;
				}
				else
				{
					AccountInfo info = new AccountInfo(
						dt.Rows[0]["Name"] as string,
						dt.Rows[0]["NickName"] as string,
						(Int64)dt.Rows[0]["Key"],
						(Int64)dt.Rows[0]["Type"],
						GetUserRoles(userName),
						friends.ToArray(),
						(Int64)dt.Rows[0]["Type"] == 1 ? managers.ToArray() : null,
						creator,
						dt.Rows[0]["EMail"] as String,
						dt.Rows[0]["InviteCode"] as String,
						((Int64)dt.Rows[0]["AcceptStrangerIM"]) != 0,
						((Int64)dt.Rows[0]["MsgFileLimit"]),
						((Int64)dt.Rows[0]["MsgImageLimit"]),
						((Int64)dt.Rows[0]["DiskSize"]),
						((Int64)dt.Rows[0]["IsTemp"]),
						((DateTime)dt.Rows[0]["RegisterTime"]),
						dt.Rows[0]["HomePage"] as string,
						dt.Rows[0]["Password"] as string,
						dt.Rows[0]
					);

					if (m_List.Count >= MAX_CACHE_COUNT)
					{
						AccountInfo removeInfo=m_List.First.Value;
						m_UserInfoCache.Remove(removeInfo.Name.ToUpper());
						m_UserInfoCacheByID.Remove(removeInfo.ID);
						m_List.RemoveFirst();
					}

					m_UserInfoCache[userName.ToUpper()] = info;
					m_UserInfoCacheByID[info.ID] = info;
					m_List.AddLast(info.ListNode);

					return info;
				}
			}
			else
			{
				return null;
			}
		}

		private String[] GetGroupManagers(string name)
		{
			DataTable result = new DataTable();

			SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
			SQLiteCommand cmd = new SQLiteCommand();
			cmd.Connection = conn;
			cmd.CommandText =
				@"select 
					guest.Name as Name
				from 
					UserRelationship r,
					Users host,
					Users guest
				where 
					r.Relationship=2 and
					r.HostKey=host.Key and
					r.GuestKey=guest.Key and
					host.UpperName=?
				";

			cmd.Parameters.Add("user", DbType.String).Value = name.ToUpper();

			SQLiteDataAdapter ada = new SQLiteDataAdapter();
			ada.SelectCommand = cmd;

			ada.Fill(result);
			ada.Dispose();

			List<String> names = new List<string>();
			foreach (DataRow row in result.Rows) names.Add(row["Name"] as string);

			return names.ToArray();
		}

		private Int64 GetRelationship(string user1, string user2)
		{
			SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
			SQLiteCommand cmd = new SQLiteCommand();
			cmd.Connection = conn;
			cmd.CommandText = @"
				select *
				from Users host,Users guest,UserRelationship r
				where host.UpperName=? and guest.UpperName=? and r.HostKey=host.Key and r.GuestKey=guest.Key
			";

			cmd.Parameters.Add("User1", DbType.String).Value = user1.ToUpper();
			cmd.Parameters.Add("User2", DbType.String).Value = user2.ToUpper();

			DataTable result = new DataTable();

			SQLiteDataAdapter ada = new SQLiteDataAdapter();

			ada.SelectCommand = cmd;
			ada.Fill(result);
			ada.Dispose();

			return result.Rows.Count > 0 ? (Int64)result.Rows[0]["Relationship"] : -1;
		}

		public bool Validate(string userId, string password)
		{
			lock (m_Lock)
			{
				SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
				SQLiteCommand cmd = new SQLiteCommand();
				cmd.Connection = conn;
				cmd.CommandText = string.Format(
					"select * from Users where UpperName=? and Password=?",
					userId, password
				);

				cmd.Parameters.Add("User", DbType.String).Value = userId.ToUpper();
				cmd.Parameters.Add("Password", DbType.String).Value = Utility.MD5(password);

				SQLiteDataAdapter ada = new SQLiteDataAdapter();
				ada.SelectCommand = cmd;

				DataTable dt = new DataTable();
				ada.Fill(dt);
				ada.Dispose();

				return dt.Rows.Count > 0;
			}
		}

		public AccountInfo GetUserInfo(string user)
		{
			if (String.IsNullOrEmpty(user)) return null;
			lock (m_Lock)
			{
				string key = user.ToUpper();
				AccountInfo ai = null;
				if (m_UserInfoCache.ContainsKey(key))
				{
					ai = m_UserInfoCache[key] as AccountInfo;
					m_List.Remove(ai.ListNode);
					m_List.AddLast(ai.ListNode);
				}
				else
				{
					ai = RefreshUserInfo(user);
				}
				return ai;
			}
		}

		public AccountInfo GetUserInfo(Int64 userId)
		{
			lock (m_Lock)
			{
				AccountInfo ai = null;
				if (m_UserInfoCacheByID.ContainsKey(userId))
				{
					ai = m_UserInfoCacheByID[userId] as AccountInfo;
					m_List.Remove(ai.ListNode);
					m_List.AddLast(ai.ListNode);
				}
				else
				{
					ai = RefreshUserInfo(userId);
				}
				return ai;
			}
		}

		public String[] GetUserRoles(string userId)
		{
			lock (m_Lock)
			{
				SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
				SQLiteCommand cmd = new SQLiteCommand();
				cmd.Connection = conn;
				cmd.CommandText = string.Format(
					"select r.Name as RoleName from Users u,User_Role ur,Roles r where u.UpperName=? and u.Key=ur.UserKey and ur.RoleKey=r.Key",
					userId
				);

				cmd.Parameters.Add("User", DbType.String).Value = userId.ToUpper();

				SQLiteDataAdapter ada = new SQLiteDataAdapter();
				ada.SelectCommand = cmd;

				DataTable dt = new DataTable();
				ada.Fill(dt);
				ada.Dispose();

				List<string> names = new List<string>();
				foreach (DataRow row in dt.Rows) names.Add(row["RoleName"] as string);

				return names.ToArray();
			}
		}

		public void UpdateInviteCode(string name, string inviteCode)
		{
			lock (m_Lock)
			{
				SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
				SQLiteCommand cmd = new SQLiteCommand();
				cmd.Connection = conn;
				cmd.CommandText = "Update Users set InviteCode=? where UpperName=?";

				cmd.Parameters.Add("InvaiteCode", DbType.String).Value = inviteCode;
				cmd.Parameters.Add("Name", DbType.String).Value = name.ToUpper();

				conn.Open();
				try
				{
					cmd.ExecuteNonQuery();
				}
				finally
				{
					conn.Close();
				}
				RefreshUserInfo(name);
			}
		}

		public DataTable GetFriends(string user)
		{
			lock (m_Lock)
			{
				DataTable result = new DataTable();

				SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
				SQLiteCommand cmd = new SQLiteCommand();
				cmd.Connection = conn;
				cmd.CommandText =
				@"select 
					guest.Name as Name,
					guest.Type as Type,
					r.RenewTime as RenewTime,
					r.Relationship as Relationship
				from 
					UserRelationship r,
					Users host,
					Users guest
				where 
					r.HostKey=host.Key and
					r.GuestKey=guest.Key and
					host.UpperName=?
				";

				cmd.Parameters.Add("user", DbType.String).Value = user.ToUpper();

				SQLiteDataAdapter ada = new SQLiteDataAdapter();
				ada.SelectCommand = cmd;

				ada.Fill(result);
				ada.Dispose();

				return result;
			}
		}

		/// <summary>
		/// 更新用户信息
		/// </summary>
		/// <param name="name"></param>
		/// <param name="values"></param>
		public void UpdateUserInfo(string name, Hashtable values)
		{
			lock (m_Lock)
			{
				SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);

				conn.Open();
				try
				{
					if (values.ContainsKey("Password"))
					{
						if (!values.ContainsKey("PreviousPassword")) throw new Exception("原密码错误！");

						SQLiteCommand checkPwdCmd = new SQLiteCommand();
						checkPwdCmd.Connection = conn;
						checkPwdCmd.CommandText = "select Key from Users where UpperName = ? and Password = ?";

						checkPwdCmd.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
						checkPwdCmd.Parameters.Add("Password", DbType.String).Value = Utility.MD5(values["PreviousPassword"].ToString());

						object val = checkPwdCmd.ExecuteScalar();

						if (val == null) throw new Exception("原密码错误！");
					}

					StringBuilder cmdText = new StringBuilder();
					cmdText.Append("update Users set Name = Name");
					if (values.ContainsKey("Nickname")) cmdText.Append(",Nickname = ?");
					if (values.ContainsKey("Password")) cmdText.Append(",Password = ?");
					if (values.ContainsKey("EMail")) cmdText.Append(",EMail = ?");
					if (values.ContainsKey("InviteCode")) cmdText.Append(",InviteCode = ?");
					if (values.ContainsKey("AcceptStrangerIM")) cmdText.Append(",AcceptStrangerIM = ?");
					if (values.ContainsKey("MsgFileLimit")) cmdText.Append(",MsgFileLimit = ?");
					if (values.ContainsKey("MsgImageLimit")) cmdText.Append(",MsgImageLimit = ?");
					if (values.ContainsKey("HomePage")) cmdText.Append(",HomePage = ?");
					if (values.ContainsKey("HeadIMG")) cmdText.Append(",HeadIMG = ?");
					if (values.ContainsKey("Remark")) cmdText.Append(",Remark = ?");
					cmdText.Append(" where UpperName=?");
					if (values.ContainsKey("PreviousPassword")) cmdText.Append(" and Password = ?");
					SQLiteCommand cmd = new SQLiteCommand();
					cmd.Connection = conn;
					cmd.CommandText = cmdText.ToString();

					if (values.ContainsKey("Nickname")) cmd.Parameters.Add("Nickname", DbType.String).Value = values["Nickname"];
					if (values.ContainsKey("Password")) cmd.Parameters.Add("Password", DbType.String).Value = Utility.MD5(values["Password"] as string);
					if (values.ContainsKey("EMail")) cmd.Parameters.Add("EMail", DbType.String).Value = values["EMail"];
					if (values.ContainsKey("InviteCode")) cmd.Parameters.Add("InviteCode", DbType.String).Value = values["InviteCode"];

					if (values.ContainsKey("AcceptStrangerIM")) cmd.Parameters.Add("AcceptStrangerIM", DbType.Int64).Value = ((bool)values["AcceptStrangerIM"]) ? 1 : 0;
					if (values.ContainsKey("MsgFileLimit")) cmd.Parameters.Add("MsgFileLimit", DbType.Int64).Value = (Int64)(Double)values["MsgFileLimit"];
					if (values.ContainsKey("MsgImageLimit")) cmd.Parameters.Add("MsgImageLimit", DbType.Int64).Value = (Int64)(Double)values["MsgImageLimit"];

					if (values.ContainsKey("HomePage")) cmd.Parameters.Add("HomePage", DbType.String).Value = values["HomePage"];
					if (values.ContainsKey("HeadIMG")) cmd.Parameters.Add("HeadIMG", DbType.String).Value = values["HeadIMG"];
					if (values.ContainsKey("Remark")) cmd.Parameters.Add("Remark", DbType.String).Value = values["Remark"];

					cmd.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
					if (values.ContainsKey("PreviousPassword")) cmd.Parameters.Add("PreviousPassword", DbType.String).Value = Utility.MD5(values["PreviousPassword"] as string);

					cmd.ExecuteNonQuery();
				}
				finally
				{
					conn.Close();
				}

				RefreshUserInfo(name);
			}
		}

		/// <summary>
		/// 添加好友
		/// </summary>
		/// <param name="user"></param>
		/// <param name="friend"></param>
		/// <param name="index"></param>
		public void AddFriend(string user, string friend, int index)
		{
			lock (m_Lock)
			{
				if (GetRelationship(user, friend) == -1)
				{
					AddFriend(user, friend);
				}
			}
		}

		public void AddFriend(string user, string friend)
		{
			lock (m_Lock)
			{
				AccountInfo userInfo = AccountImpl.Instance.GetUserInfo(user);
				AccountInfo friendInfo = AccountImpl.Instance.GetUserInfo(friend);

				if (String.Compare(user, friend, true) != 0 && !userInfo.ContainsFriend(friend))
				{
					SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
					SQLiteCommand cmd = new SQLiteCommand();
					cmd.Connection = conn;
					cmd.CommandText = @"
						insert into UserRelationship (HostKey,GuestKey,Relationship,RenewTime)
						select host.Key as HostKey,guest.Key as GuestKey,0,? as Relationship
						from Users host,Users guest
						where (host.UpperName=? or host.UpperName=?) and (guest.UpperName=? or guest.UpperName=?) and host.Key<>guest.Key
					";

					cmd.Parameters.Add("RenewTime", DbType.DateTime).Value = DateTime.Now;
					cmd.Parameters.Add("Host1", DbType.String).Value = user.ToUpper();
					cmd.Parameters.Add("Client1", DbType.String).Value = friend.ToUpper();
					cmd.Parameters.Add("Host2", DbType.String).Value = user.ToUpper();
					cmd.Parameters.Add("Client2", DbType.String).Value = friend.ToUpper();

					conn.Open();
					try
					{
						cmd.ExecuteNonQuery();
					}
					finally
					{
						conn.Close();
					}

					RefreshUserInfo(user);
					RefreshUserInfo(friend);

				}
			}
		}

		/// <summary>
		/// 删除好友
		/// </summary>
		/// <param name="user"></param>
		/// <param name="friend"></param>
		public void DeleteFriend(string user, string friend)
		{
			lock (m_Lock)
			{
				if (GetRelationship(user, friend) != -1)
				{
					AccountInfo userInfo = GetUserInfo(user);
					AccountInfo friendInfo = GetUserInfo(friend);

					SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
					SQLiteCommand cmd = new SQLiteCommand();
					cmd.Connection = conn;
					cmd.CommandText = @"
						delete from UserRelationship
						where (HostKey=? and GuestKey=?) or (HostKey=? and GuestKey=?)
					";

					cmd.Parameters.Add("Host1", DbType.Int64).Value = userInfo.ID;
					cmd.Parameters.Add("Client1", DbType.Int64).Value = friendInfo.ID;
					cmd.Parameters.Add("Host2", DbType.Int64).Value = friendInfo.ID;
					cmd.Parameters.Add("Client2", DbType.Int64).Value = userInfo.ID;

					conn.Open();
					try
					{
						cmd.ExecuteNonQuery();
					}
					finally
					{
						conn.Close();
					}

					RefreshUserInfo(user);
					RefreshUserInfo(friend);

				}
			}
		}

		public void DeleteUser(String name)
		{
			AccountInfo info = GetUserInfo(name);
			Int64 id = info.ID;
			List<String> friends = new List<string>();
			foreach (string s in info.Friends) friends.Add(s);

			SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
			conn.Open();
			SQLiteTransaction tran = conn.BeginTransaction();
			try
			{
				SQLiteCommand cmd = new SQLiteCommand(
					@"delete from UserRelationship where HostKey = ? or GuestKey = ?;
					delete from Users where Key = ?;
					delete from User_Role where UserKey = ?"
				);
				cmd.Parameters.Add("P1", DbType.Int64).Value = id;
				cmd.Parameters.Add("P2", DbType.Int64).Value = id;
				cmd.Parameters.Add("P3", DbType.Int64).Value = id;
				cmd.Parameters.Add("P4", DbType.Int64).Value = id;
				cmd.Connection = conn;
				cmd.ExecuteNonQuery();

				tran.Commit();
			}
			catch
			{
				tran.Rollback();
				throw;
			}
			finally
			{
				conn.Close();
			}

			/*try
			{
				Core.IO.Directory.Delete(String.Format("/{0}", name));
			}
			catch
			{
			}*/

			foreach (string friend in friends)
			{
				RefreshUserInfo(friend);
			}
		}

		/// <summary>
		/// 删除群
		/// </summary>
		/// <param name="name"></param>
		/// <param name="creator"></param>
		public void DeleteGroup(String name, String creator)
		{
			AccountInfo info = GetUserInfo(name);
			List<String> members = new List<string>();
			foreach (string s in info.Friends) members.Add(s);

			lock (m_Lock)
			{

				SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
				conn.Open();
				SQLiteTransaction tran = conn.BeginTransaction();
				try
				{
					SQLiteCommand selectCmd = new SQLiteCommand(
						@"select Key from Users where UpperName=?", conn
					);
					selectCmd.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
					object key = selectCmd.ExecuteScalar();
					if (key == null) throw new Exception(String.Format("群 {0} 不存在！", name));

					SQLiteCommand deleteUR = new SQLiteCommand(
						@"delete from User_Role where UserKey=?", conn
					);
					deleteUR.Parameters.Add("Key", DbType.Int64).Value = key;
					deleteUR.ExecuteNonQuery();

					SQLiteCommand deleteRelationship = new SQLiteCommand(
						@"delete from UserRelationship where HostKey=? or GuestKey=?", conn
					);
					deleteRelationship.Parameters.Add("Key1", DbType.Int64).Value = key;
					deleteRelationship.Parameters.Add("Key2", DbType.Int64).Value = key;
					deleteRelationship.ExecuteNonQuery();

					SQLiteCommand deleteUser = new SQLiteCommand(
						@"delete from Users where Key=?", conn
					);
					deleteUser.Parameters.Add("Key", DbType.Int64).Value = key;
					deleteUser.ExecuteNonQuery();

					tran.Commit();
				}
				catch
				{
					tran.Rollback();
					throw;
				}
				finally
				{
					conn.Close();
				}

				foreach (string member in members)
				{
					RefreshUserInfo(member);
				}
			}
		}

		public string CreateTempraryUser()
		{
			lock (m_Lock)
			{
				SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
				conn.Open();
				try
				{
					SQLiteTransaction tran = conn.BeginTransaction();
					try
					{
						String name = "U";
						while (true)
						{
							name = String.Format("U{0}", ((new Random()).Next() + DateTime.Now.Ticks) % 1000000000 + 1000000000);
							SQLiteCommand selectCmd = new SQLiteCommand(
								@"select Key from Users where UpperName=?", conn
							);
							selectCmd.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
							object key = selectCmd.ExecuteScalar();
							if (key == null) break;
						}
						String nickname = "游客" + name;

						SQLiteCommand insertUser = new SQLiteCommand(
							@"
							insert into Users (Name,UpperName,Password,Nickname,Type,EMail,InviteCode,IsTemp,RegisterTime) values (?,?,?,?,?,?,?,1,?)
							", conn
						);
						insertUser.Parameters.Add("Name", DbType.String).Value = name;
						insertUser.Parameters.Add("UpperName", DbType.String).Value = name.ToUpper();
						insertUser.Parameters.Add("Password", DbType.String).Value = "";
						insertUser.Parameters.Add("Nickname", DbType.String).Value = nickname;
						insertUser.Parameters.Add("Type", DbType.Int64).Value = 0;
						insertUser.Parameters.Add("EMail", DbType.String).Value = "";
						insertUser.Parameters.Add("InviteCode", DbType.String).Value = Guid.NewGuid().ToString().ToUpper().Replace("-", "");
						insertUser.Parameters.Add("RegisterTime", DbType.DateTime).Value = DateTime.Now;
						insertUser.ExecuteNonQuery();

						SQLiteCommand insertUR = new SQLiteCommand(
							@"
							insert into User_Role (UserKey,RoleKey)
							select Key as UserKey,2 as RoleKey from Users where UpperName=?
							", conn
						);
						insertUR.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
						insertUR.ExecuteNonQuery();

						tran.Commit();

						return name;
					}
					catch
					{
						tran.Rollback();
						throw;
					}
				}
				finally
				{
					conn.Close();
				}
			}
		}

		public void CreateUser(String name, String nickname, String password, String email)
		{
			lock (m_Lock)
			{
				SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
				conn.Open();
				try
				{
					SQLiteTransaction tran = conn.BeginTransaction();
					try
					{
						SQLiteCommand selectCmd = new SQLiteCommand(
							@"select Key from Users where UpperName=?", conn
						);
						selectCmd.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
						object key = selectCmd.ExecuteScalar();
						if (key != null && key != DBNull.Value)
						{
							throw new Exception(String.Format("用户\"{0}\"已存在！", name));
						}

						SQLiteCommand insertUser = new SQLiteCommand(
							@"
							insert into Users (Name,UpperName,Password,Nickname,Type,EMail,InviteCode,IsTemp,RegisterTime) values (?,?,?,?,?,?,?,0,?)
							", conn
						);
						insertUser.Parameters.Add("Name", DbType.String).Value = name;
						insertUser.Parameters.Add("UpperName", DbType.String).Value = name.ToUpper();
						insertUser.Parameters.Add("Password", DbType.String).Value = Utility.MD5(password);
						insertUser.Parameters.Add("Nickname", DbType.String).Value = nickname;
						insertUser.Parameters.Add("Type", DbType.Int64).Value = 0;
						insertUser.Parameters.Add("EMail", DbType.String).Value = email;
						insertUser.Parameters.Add("InviteCode", DbType.String).Value = Guid.NewGuid().ToString().ToUpper().Replace("-", "");
						insertUser.Parameters.Add("RegisterTime", DbType.DateTime).Value = DateTime.Now;
						insertUser.ExecuteNonQuery();

						SQLiteCommand insertUR = new SQLiteCommand(
							@"
							insert into User_Role (UserKey,RoleKey)
							select Key as UserKey,2 as RoleKey from Users where UpperName=?;

							insert into UserRelationShip(HostKey, GuestKey,RelationShip,RenewTime)
							select u1.Key, u2.Key, 0, datetime('now','localtime') as RenewTime
							from Users u1, Users u2 
							where u1.Name='public' and u2.UpperName=?;

							insert into UserRelationShip(HostKey, GuestKey,RelationShip,RenewTime)
							select u2.Key, u1.Key, 0, datetime('now','localtime') as RenewTime
							from Users u1, Users u2 
							where u1.Name='public' and u2.UpperName=?;

							insert into UserRelationShip(HostKey, GuestKey,RelationShip,RenewTime)
							select u1.Key, u2.Key, 0, datetime('now','localtime') as RenewTime
							from Users u1, Users u2 
							where u1.Name='admin' and u2.UpperName=?;

							insert into UserRelationShip(HostKey, GuestKey,RelationShip,RenewTime)
							select u2.Key, u1.Key, 0, datetime('now','localtime') as RenewTime
							from Users u1, Users u2 
							where u1.Name='admin' and u2.UpperName=?;
							", conn
						);
						string upperName = name.ToUpper();
						insertUR.Parameters.Add("Name", DbType.String).Value = upperName;
						insertUR.Parameters.Add("Name1", DbType.String).Value = upperName;
						insertUR.Parameters.Add("Name2", DbType.String).Value = upperName;
						insertUR.Parameters.Add("Name3", DbType.String).Value = upperName;
						insertUR.Parameters.Add("Name4", DbType.String).Value = upperName;

						insertUR.ExecuteNonQuery();

						tran.Commit();
					}
					catch
					{
						tran.Rollback();
						throw;
					}
				}
				finally
				{
					conn.Close();
				}

				RefreshUserInfo("public");
				RefreshUserInfo("admin");
			}
		}

		/// <summary>
		/// 创建群
		/// </summary>
		/// <param name="creator"></param>
		/// <param name="name"></param>
		/// <param name="nickname"></param>
		public void CreateGroup(String creator, String name, String nickname)
		{
			lock (m_Lock)
			{
				SQLiteConnection conn = new SQLiteConnection(m_ConnectionString);
				conn.Open();
				SQLiteTransaction tran = conn.BeginTransaction();
				try
				{
					SQLiteCommand selectCmd = new SQLiteCommand(
						@"select Key from Users where UpperName=?", conn
					);
					selectCmd.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
					object key = selectCmd.ExecuteScalar();
					if (key != null && key != DBNull.Value)
					{
						throw new Exception(String.Format("群\"{0}\"已存在！", name));
					}

					SQLiteCommand insertUser = new SQLiteCommand(
						@"
						insert into Users (Name,UpperName,Password,Nickname,Type,EMail,InviteCode,IsTemp,RegisterTime) values (?,?,?,?,?,?,?,0,?)
						", conn
					);
					insertUser.Parameters.Add("Name", DbType.String).Value = name;
					insertUser.Parameters.Add("UpperName", DbType.String).Value = name.ToUpper();
					insertUser.Parameters.Add("Password", DbType.String).Value = "";
					insertUser.Parameters.Add("Nickname", DbType.String).Value = nickname;
					insertUser.Parameters.Add("Type", DbType.Int64).Value = 1;
					insertUser.Parameters.Add("EMail", DbType.String).Value = "";
					insertUser.Parameters.Add("InviteCode", DbType.String).Value = Guid.NewGuid().ToString().ToUpper().Replace("-", "");
					insertUser.Parameters.Add("RegisterTime", DbType.DateTime).Value = DateTime.Now;
					insertUser.ExecuteNonQuery();

					SQLiteCommand insertUR = new SQLiteCommand(
						@"
						insert into User_Role (UserKey,RoleKey)
						select Key as UserKey,2 as RoleKey from Users where UpperName=?
						", conn
					);
					insertUR.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
					insertUR.ExecuteNonQuery();

					SQLiteCommand insertRelationship = new SQLiteCommand(
						@"
						insert into UserRelationship (RenewTime,HostKey,GuestKey,Relationship)
						select ? as RenewTime,(select Key from Users where UpperName=?) as HostKey,(select Key from Users where UpperName=?) as GuestKey,3 as Relationship
						",
						conn
					);
					insertRelationship.Parameters.Add("RenewTime", DbType.DateTime).Value = DateTime.Now;
					insertRelationship.Parameters.Add("Host", DbType.String);
					insertRelationship.Parameters.Add("Guest", DbType.String);

					insertRelationship.Parameters["Host"].Value = name.ToUpper();
					insertRelationship.Parameters["Guest"].Value = creator.ToUpper();
					insertRelationship.ExecuteNonQuery();

					insertRelationship.Parameters["Host"].Value = creator.ToUpper();
					insertRelationship.Parameters["Guest"].Value = name.ToUpper();
					insertRelationship.ExecuteNonQuery();

					tran.Commit();
				}
				catch
				{
					tran.Rollback();
					throw;
				}
				finally
				{
					conn.Close();
				}

				RefreshUserInfo(creator);
			}
		}
	}

	public class AccountInfo : IRenderJson
	{
		object m_Lock = new object();

		private LinkedListNode<AccountInfo> m_ListNode;

		public LinkedListNode<AccountInfo> ListNode
		{
			get { return m_ListNode; }
		}

		private String m_Name, m_NickName;
		private Int64 m_ID, m_Type;
		private String[] m_Roles;
		private FriendInfo[] m_Friends;
		private FriendInfo m_Creator;
		private String m_EMail, m_InviteCode;
		private Int64 m_DiskSize;
		private bool m_IsTemp;
		private String m_Password;

		Hashtable m_FriendIndex = null;
		Hashtable m_Managers = null;

		bool m_AcceptStrangerIM;
		Int64 m_IMFileLimit, m_IMImageLimit;
		string m_HeadIMG;
		string m_Remark;

		DateTime m_RegisterTime = DateTime.Now;

		String m_HomePage = String.Empty;

		Details _detailsJson = null;

		public AccountInfo(
			String name, String nickname, Int64 id, Int64 type, String[] roles,
			FriendInfo[] friends, FriendInfo[] managers, FriendInfo creator,
			String email, String inviteCode,
			bool acceptStrangerIM, Int64 imf_limite, Int64 imimage_limit,
			Int64 diskSize, Int64 isTemp,
			DateTime registerTime,
			String homePage,
			string pwd,
			DataRow data
		)
		{
			_detailsJson = new Details(this);
			m_ListNode = new LinkedListNode<AccountInfo>(this);
			Reset(name, nickname, id, type, roles, friends, managers, creator, email, inviteCode, acceptStrangerIM, imf_limite, imimage_limit, diskSize, isTemp, registerTime, homePage, pwd, data);
		}

		public void Reset(
			String name, String nickname, Int64 id, Int64 type, String[] roles,
			FriendInfo[] friends, FriendInfo[] managers, FriendInfo creator,
			String email, String inviteCode,
			bool acceptStrangerIM, Int64 imf_limite, Int64 imimage_limit,
			Int64 diskSize, Int64 isTemp,
			DateTime registerTime,
			String homePage,
			string pwd,
			DataRow data
		)
		{
			lock (m_Lock)
			{
				m_FriendIndex = new Hashtable();
				m_Managers = new Hashtable();
				m_Name = name;
				m_NickName = nickname;
				m_ID = id;
				m_Type = type;
				m_Roles = roles;
				m_Friends = friends;
				m_Creator = creator;
				m_EMail = email;
				m_InviteCode = inviteCode;
				m_HeadIMG = data["HeadIMG"].ToString();
				m_Remark = data["Remark"].ToString();

				m_Password = pwd;

				m_AcceptStrangerIM = acceptStrangerIM;
				m_IMFileLimit = imf_limite;
				m_IMImageLimit = imimage_limit;

				m_IsTemp = (isTemp != 0);

				m_HomePage = homePage;

				m_DiskSize = diskSize;

				foreach (FriendInfo friend in friends)
				{
					m_FriendIndex.Add(friend.Name.ToUpper(), friend);
				}

				if (managers != null)
				{
					foreach (FriendInfo friend in managers)
					{
						m_Managers.Add(friend.Name.ToUpper(), friend);
					}
				}

				m_RegisterTime = registerTime;
			}
		}

		public String[] Friends
		{
			get
			{
				lock (m_Lock)
				{
					String[] array = new String[m_Friends.Length];
					for (int i = 0; i < m_Friends.Length; i++) array[i] = m_Friends[i].Name;
					return array;
				}
			}
		}

		public String[] Roles
		{
			get
			{
				lock (m_Lock)
				{
					String[] array = new String[m_Roles.Length];
					m_Roles.CopyTo(array, 0);
					return array;
				}
			}
		}

		public Boolean IsTemp
		{
			get
			{
				lock (m_Lock)
				{
					return m_IsTemp;
				}
			}
		}

		public String Creator
		{
			get
			{
				lock (m_Lock)
				{
					return m_Creator.Name;
				}
			}
		}

		public String HeadIMG
		{
			get
			{
				lock (m_Lock)
				{
					return m_HeadIMG;
				}
			}
		}

		public String Remark
		{
			get
			{
				lock (m_Lock)
				{
					return m_Remark;
				}
			}
		}

		public String[] Groups
		{
			get
			{
				lock (m_Lock)
				{
					List<String> groups = new List<string>();
					foreach (FriendInfo friend in m_Friends)
					{
						if (friend.PeerType == 1) groups.Add(friend.Name);
					}
					return groups.ToArray();
				}
			}
		}

		public Int64 Type
		{
			get
			{
				lock (m_Lock)
				{
					return m_Type;
				}
			}
		}

		public bool AcceptStrangerIM
		{
			get
			{
				lock (m_Lock)
				{
					return m_AcceptStrangerIM;
				}
			}
		}

		public Int64 MsgFileLimit
		{
			get
			{
				lock (m_Lock)
				{
					return m_IMFileLimit;
				}
			}
		}

		public Int64 MsgImageLimit
		{
			get
			{
				lock (m_Lock)
				{
					return m_IMImageLimit;
				}
			}
		}

		public String Nickname
		{
			get
			{
				lock (m_Lock)
				{
					return m_NickName;
				}
			}
		}

		public String EMail
		{
			get
			{
				lock (m_Lock)
				{
					return m_EMail;
				}
			}
		}

		public String Password
		{
			get
			{
				lock (m_Lock)
				{
					return m_Password;
				}
			}
		}

		public String HomePage
		{
			get
			{
				lock (m_Lock)
				{
					return m_HomePage;
				}
			}
		}

		public String Name
		{
			get
			{
				lock (m_Lock)
				{
					return m_Name;
				}
			}
		}

		public Int64 DiskSize
		{
			get
			{
				if (Type == 1)
				{
					return AccountImpl.Instance.GetUserInfo(m_Creator.Name).DiskSize;
				}
				else
				{
					lock (m_Lock)
					{
						return m_DiskSize * 1024 * 1024;
					}
				}
			}
		}

		public String InviteCode
		{
			get
			{
				lock (m_Lock)
				{
					return m_InviteCode;
				}
			}
		}

		public Int64 ID
		{
			get
			{
				lock (m_Lock)
				{
					return m_ID;
				}
			}
		}

		public DateTime RegisterTime
		{
			get
			{
				lock (m_Lock)
				{
					return m_RegisterTime;
				}
			}
		}

		public bool IsRole(string role)
		{
			lock (m_Lock)
			{
				foreach (string s in Roles)
				{
					if (s == role) return true;
				}
				return false;
			}
		}

		public bool ContainsFriend(string name)
		{
			lock (m_Lock)
			{
				return m_FriendIndex.ContainsKey(name.ToUpper());
			}
		}

		public bool ContainsMember(string name)
		{
			lock (m_Lock)
			{
				return m_FriendIndex.ContainsKey(name.ToUpper());
			}
		}

		public bool IsManagedBy(string name)
		{
			lock (m_Lock)
			{
				return Type == 1 && m_Managers.ContainsKey(name.ToUpper());
			}
		}

		public bool IsCreatedBy(string name)
		{
			lock (m_Lock)
			{
				return Type == 1 && String.Compare(name, m_Creator.Name, true) == 0;
			}
		}

		public DateTime GetGroupMemberRenewTime(string user)
		{
			lock (m_Lock)
			{
				string key = user.ToUpper();
				return (m_FriendIndex[key] as FriendInfo).RenewTime;
			}
		}

		void IRenderJson.RenderJson(StringBuilder builder)
		{
			Utility.RenderHashJson(
				builder,
				"ID", m_ID,
				"Name", m_Name,
				"Nickname", m_NickName,
				"Type", m_Type
			);
		}

		public class Details : IRenderJson
		{
			AccountInfo _info;
			public Details(AccountInfo info)
			{
				_info = info;
			}

			void IRenderJson.RenderJson(StringBuilder builder)
			{
				if (_info.Type == 0)
				{
					Utility.RenderHashJson(
						builder,
						"ID", _info.m_ID,
						"Name", _info.m_Name,
						"Nickname", _info.m_NickName,
						"Type", _info.m_Type,
						"EMail", _info.m_EMail,
						"InviteCode", _info.m_InviteCode,
						"HeadIMG", _info.m_HeadIMG,
						"HomePage", _info.m_HomePage,
						"Remark", _info.m_Remark
					);
				}
				else
				{
					Utility.RenderHashJson(
						builder,
						"ID", _info.m_ID,
						"Name", _info.m_Name,
						"Nickname", _info.m_NickName,
						"Type", _info.m_Type,
						"EMail", _info.m_EMail,
						"InviteCode", _info.m_InviteCode,
						"HeadIMG", _info.m_HeadIMG,
						"HomePage", _info.m_HomePage,
						"Remark", _info.m_Remark
					);
				}
			}
		}

		public Details DetailsJson
		{
			get { return _detailsJson; }
		}
	}

	public class FriendInfo
	{
		public String Name;
		public DateTime RenewTime;
		public Int64 Relationthip;
		public Int64 PeerType;

		public FriendInfo(string name, DateTime renewTime, Int64 relationthip, Int64 peerType)
		{
			Name = name;
			RenewTime = renewTime;
			Relationthip = relationthip;
			PeerType = peerType;
		}
	}
}
