﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Login : System.Web.UI.Page
{
	static string[] UserDirs = new string[] { "Config", "Home", "pub", "Temp" };

	protected void Page_Load(object sender, EventArgs e)
	{
		String sessionId = Guid.NewGuid().ToString().ToUpper();

		if (IsPostBack)
		{
			try
			{
				if (Request.Params["login"] != null)
				{
					HtmlInputText txtUser = FindControl("txtuser") as HtmlInputText;
					HtmlInputText txtPwd = FindControl("txtpwd") as HtmlInputText;

					if (Core.AccountImpl.Instance.Validate(txtUser.Value, txtPwd.Value))
					{

						foreach (string dir in UserDirs)
						{
							String path = String.Format("/{0}/{1}", txtUser.Value, dir);
							if (!Core.IO.Directory.Exists(path)) Core.IO.Directory.CreateDirectory(path);
						}

						(FindControl("status") as HtmlInputHidden).Value = "login";
						(FindControl("data") as HtmlInputHidden).Value = Core.Utility.RenderHashJson(
							"UserInfo", Core.AccountImpl.Instance.GetUserInfo(txtUser.Value).DetailsJson
						);

						Core.ServerImpl.Instance.Login(sessionId, Context, txtUser.Value, null);
					}
					else
					{
						throw new Exception("用户不存在或密码错误！");
					}
				}
				else if (Request.Params["register"] != null)
				{
					string user = Request.Params["txtuser_reg"];
					string nickname = Request.Params["txtnick_reg"];
					string pwd = Request.Params["txtpwd_reg"];
					string email = Request.Params["txtemail_reg"];

					if (Core.AccountImpl.Instance.GetUserInfo(user) != null) throw new Exception(string.Format("用户\"{0}\"已存在！", user));

					Core.AccountImpl.Instance.CreateUser(user, nickname, pwd, email);

					(FindControl("status") as HtmlInputHidden).Value = "login";
					(FindControl("data") as HtmlInputHidden).Value = Core.Utility.RenderHashJson(
						"UserInfo", Core.AccountImpl.Instance.GetUserInfo(user).DetailsJson
					);

					Core.ServerImpl.Instance.Login(sessionId, Context, user, null);
				}
			}
			catch (Exception ex)
			{
				(FindControl("status") as HtmlInputHidden).Value = "error";
				(FindControl("data") as HtmlInputHidden).Value = ex.Message;
			}
		}
		else
		{
			if (!String.IsNullOrEmpty(Core.ServerImpl.Instance.GetUserName(Context))
				 && Request.QueryString["auto"] != "false")
			{
				(FindControl("status") as HtmlInputHidden).Value = "login";
				(FindControl("data") as HtmlInputHidden).Value = Core.Utility.RenderHashJson(
					"UserInfo", Core.ServerImpl.Instance.GetCurrentUser(Context).DetailsJson
				);
			}
			else
			{
			}
		}

		(FindControl("sessionId") as HtmlInputHidden).Value = sessionId;
	}
}
