﻿using System;
using System.Collections;
using System.Data;
using System.Configuration;
using System.Web;
using System.Xml;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Core.IO;
using System.Threading;

namespace Core.Web
{
	class SendFileHandler : IHttpHandler
	{

		public SendFileHandler()
		{
		}

		void IHttpHandler.ProcessRequest(HttpContext context)
		{
			Exception error = null;

			HttpPostedFile file = context.Request.Files[0];

			String filename = Core.ServerImpl.Instance.GetFullPath(context, "Temp") + "/" + Guid.NewGuid().ToString();
			Core.IO.Directory.CreateDirectory(filename);
			filename += "/" + file.FileName;

			try
			{
				file.SaveAs(ServerImpl.Instance.MapPath(filename));
			}
			catch(Exception e)
			{
				error = e;
			}

			if (error == null) context.Response.Write(Core.Utility.RenderHashJson("Result", true, "Path", filename));
			else context.Response.Write(Core.Utility.RenderHashJson("Result", false, "Exception", error));
		}

		bool IHttpHandler.IsReusable
		{
			get { return true; }
		}
	}
}
