#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.WebFx
{
    public interface IAuthenticator
    {
        /// <summary>
        /// ��֤
        /// </summary>
        /// <param name="name"></param>
        /// <param name="passwd"></param>
        /// <returns></returns>
        bool Authenticate(string name, string passwd, bool persist);

        /// <summary>
        /// �ǳ�
        /// </summary>
        void SignOut();

        /// <summary>
        /// �Ƿ�����֤ͨ��
        /// </summary>
        bool Authenticated { get; }

        /// <summary>
        /// ��ʶ
        /// </summary>
        string Identity { get; }

        /// <summary>
        /// ��¼ҳ��
        /// </summary>
        string LoginUrl { get; }

        /// <summary>
        /// ���Ȩ��
        /// </summary>
        /// <param name="resource"></param>
        /// <param name="action"></param>
        void CheckPermission(string resource, int action);

    }
}
