﻿

using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;

namespace CchenSoft.WebFx.Service
{
    public interface IDataService : IService
    {
        T Load<T>(object id);

        object Insert(string statementName, object parameterObject);

        object QueryForObject(string statementName, object parameterObject);

        T QueryForObject<T>(string statementName, object parameterObject);

        int Update(string statementName, object parameterObject);

        int Delete(string statementName, object parameterObject);

        IList QueryForList(string statementName, object parameterObject);

        IList<T> QueryForList<T>(string statementName, object parameterObject);

        IList QueryForList(string statementName, object parameterObject, int skipResults, int maxResults);

        IList<T> QueryForList<T>(string statementName, object parameterObject, int skipResults, int maxResults);

        IDbDataParameter CreateParameter(string name, object value);

        DataSet QueryForDataSet(string statementName, object parameterObject);

        object BeginTransaction();

        void Commit(object obj);

        void Rollback(object obj);
    }
}
