﻿using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.WebFx.Utils;

namespace CchenSoft.WebFx.Config
{
    public class RefInfo
    {
        private object bean;
        private string property;
        private string refBean;

        public RefInfo(object bean, string property, string refBean)
        {
            this.bean = bean;
            this.property = property;
            this.refBean = refBean;
        }

        public void SetRef(Dictionary<string, object> beans)
        {
            if (beans.ContainsKey(refBean))
            {
                ReflectUtil.SetProperty(bean, property, beans[refBean]);
            }
        }
    }
}
