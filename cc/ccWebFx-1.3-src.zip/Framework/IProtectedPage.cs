using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.WebFx
{
    public interface IProtectedPage
    {
    }
}
