﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.WebFx.Attributes
{
    [AttributeUsage(AttributeTargets.Field)]
    public class BeanAttribute : Attribute
    {
        private string name;

        public BeanAttribute()
        {
        }

        public BeanAttribute(string name)
        {
            this.name = name;
        }

        public string Name
        {
            get { return name; }
        }
    }
}
