#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using CchenSoft.WebFx.Attributes;
using CchenSoft.WebFx.Config;

namespace CchenSoft.WebFx.Utils
{
    public class ReflectUtil
    {
        private static IDictionary<string, object[]> attrsByType = new Dictionary<string, object[]>();
        private static IDictionary<string, PropertyInfo> propsByType = new Dictionary<string, PropertyInfo>();

        public static void InjectBeans(object target)
        {
            FieldInfo[] fields = target.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic);
            for (int i = 0; i < fields.Length; i++)
            {
                FieldInfo fi = fields[i];
                object[] pis = fi.GetCustomAttributes(typeof(BeanAttribute), true);
                if (pis != null && pis.Length > 0)
                {
                    BeanAttribute ba = (BeanAttribute)pis[0];
                    string beanName = ba.Name;
                    if (string.IsNullOrEmpty(beanName))
                        beanName = fi.FieldType.Name;

                    fi.SetValue(target, Configuration.Instance.GetBean(beanName));
                }
            }
        }

        public static T[] GetCustomAttributes<T>(Type type)
        {
            string key = type + typeof(T).Name;
            if (!attrsByType.ContainsKey(key))
            {
                attrsByType[key] = type.GetCustomAttributes(typeof(T), false);
            }
            return ChangeType<T>(attrsByType[key]);
        }

        public static T[] GetCustomAttributes<T>(MethodInfo method)
        {
            string key = method + typeof(T).Name;

            if (!attrsByType.ContainsKey(key))
            {
                attrsByType[key] = method.GetCustomAttributes(typeof(T), false);
            }
            return ChangeType<T>(attrsByType[key]);
        }

        private static PropertyInfo GetPropertyInfo(Type type, string propertyName)
        {
            string key = type + propertyName;

            if (!propsByType.ContainsKey(key))
            {
                propsByType[key] = type.GetProperty(propertyName);
            }

            return propsByType[key];
        }

        public static object GetPropertyValue(object obj, string propertyName)
        {
            if (!string.IsNullOrEmpty(propertyName))
            {
                PropertyInfo pi = GetPropertyInfo(obj.GetType(), propertyName);
                if (pi != null)
                {
                    return pi.GetValue(obj, null);
                }
            }
            return null;
        }

        public static void SetPropertyValue(object obj, string propertyName, object propertyValue)
        {
            if (!string.IsNullOrEmpty(propertyName))
            {
                PropertyInfo pi = GetPropertyInfo(obj.GetType(), propertyName); 
                if (pi != null)
                {
                    pi.SetValue(obj, propertyValue, null);
                }
            }
        }

        public static bool SetProperty(object target, string property, object value)
        {
            if ((property == null) || (target == null))
            {
                return false;
            }

            // Split out property on dots ( "person.name.first" -> "person","name","first" -> getPerson().getName().getFirst() )
            string[] st = property.Split('.');

            if (st.Length == 0)
            {
                return false;
            }

            // Holder for Object at current depth along chain.
            object current = target;

            try
            {
                // Loop through properties in chain.
                for (int i = 0; i < st.Length; i++)
                {
                    string currentPropertyName = st[i];

                    if (i < st.Length - 1)
                    {
                        // This is a getter
                        current = InvokeProperty(current, currentPropertyName);
                    }
                    else
                    {
                        // Final property in chain, hence setter
                        try
                        {
                            Type cls = current.GetType();
                            PropertyInfo pi = cls.GetProperty(CreatePropertyName("", currentPropertyName));
                            pi.SetValue(current, value, null);
                            return true;
                        }
                        catch (Exception e)
                        {
                            return false;
                        }
                    }
                }

                // Return holder Object
                return true;
            }
            catch (Exception e)
            {
                // It is very likely that one of the properties returned null. If so, catch the exception and return null.
                return false;
            }
        }

        public static object GetProperty(object target, string property)
        {
            if ((property == null) || (target == null))
            {
                return null;
            }

            // Split out property on dots ( "person.name.first" -> "person","name","first" -> getPerson().getName().getFirst() )
            string[] st = property.Split('.');

            if (st.Length == 0)
            {
                return null;
            }

            // Holder for Object at current depth along chain.
            object result = target;

            try
            {
                // Loop through properties in chain.
                int i = 0;
                while (st.Length > 0)
                {
                    String currentPropertyName = st[i++];

                    // Assign to holder the next property in the chain.
                    result = InvokeProperty(result, currentPropertyName);
                }

                // Return holder Object
                return result;
            }
            catch (Exception e)
            {
                // It is very likely that one of the properties returned null. If so, catch the exception and return null.
                return null;
            }
        }

        private static T[] ChangeType<T>(object[] attrs)
        {
            T[] result = new T[attrs.Length];
            for (int i = 0; i < attrs.Length; i++)
                result[i] = (T)attrs[i];
            return result;
        }

        /**
         * Convert property name into Property name ( "something" -> "Something" )
         */
        private static string CreatePropertyName(string prefix, string propertyName)
        {
            return prefix + propertyName.ToUpper()[0] + propertyName.Substring(1);
        }

        /**
         * Invoke the method/field getter on the Object.
         * It tries (in order) obj.getProperty(), obj.isProperty(), obj.property(), obj.property.
         */
        private static object InvokeProperty(object obj, string property)
        {
            if (string.IsNullOrEmpty(property))
            {
                return null; // just in case something silly happens.
            }

            Type cls = obj.GetType();

            try
            {
                // First try object.getProperty()
                PropertyInfo pi = cls.GetProperty(CreatePropertyName("", property));
                //Method method = cls.getMethod(createMethodName(GET, property), cParams);

                return pi.GetValue(obj, null);
                //return method.invoke(obj, oParams);
            }
            catch (Exception e1)
            {

                return null;

            }
        }


    }
}
