#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Reflection;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace CchenSoft.WebFx.Utils
{
    public class FormUtil
    {
        public static void GetModel(object model, Control parent)
        {
            if (model != null)
            {
                foreach (Control c in parent.Controls)
                {
                    string propertyName;

                    if (c is HtmlInputControl)
                    {
                        propertyName = ((HtmlInputControl)c).Attributes["property"];
                        ReflectUtil.SetPropertyValue(model, propertyName, ((HtmlInputControl)c).Value);
                    }
                    else if (c is HtmlSelect)
                    {
                        propertyName = ((HtmlSelect)c).Attributes["property"];
                        ReflectUtil.SetPropertyValue(model, propertyName, ((HtmlSelect)c).Value);
                    }
                    else if (c is TextBox)
                    {
                        propertyName = ((TextBox)c).Attributes["property"];
                        ReflectUtil.SetPropertyValue(model, propertyName, ((TextBox)c).Text);
                    }
                    else if (c is ListControl)
                    {
                        propertyName = ((ListControl)c).Attributes["property"];
                        ReflectUtil.SetPropertyValue(model, propertyName, ((ListControl)c).SelectedValue);
                    }
                    else if (c is CheckBox)
                    {
                        propertyName = ((CheckBox)c).Attributes["property"];
                        ReflectUtil.SetPropertyValue(model, propertyName, ((CheckBox)c).Checked);
                    }
                }
            }
        }

        public static void SetModel(object model, Control parent)
        {
            if (model != null)
            {
                foreach (Control c in parent.Controls)
                {
                    string propertyName;

                    if (c is HtmlInputControl)
                    {
                        propertyName = ((HtmlInputControl)c).Attributes["property"];
                        ((HtmlInputControl)c).Value = ConvertUtil.ToString(ReflectUtil.GetPropertyValue(model, propertyName));
                    }
                    else if (c is HtmlSelect)
                    {
                        propertyName = ((HtmlSelect)c).Attributes["property"];
                        ((HtmlSelect)c).Value = ConvertUtil.ToString(ReflectUtil.GetPropertyValue(model, propertyName));
                    }
                    else if (c is TextBox)
                    {
                        propertyName = ((TextBox)c).Attributes["property"];
                        ((TextBox)c).Text = ConvertUtil.ToString(ReflectUtil.GetPropertyValue(model, propertyName));
                    }
                    else if (c is ListControl)
                    {
                        propertyName = ((DropDownList)c).Attributes["property"];
                        string itemValue = ConvertUtil.ToString(ReflectUtil.GetPropertyValue(model, propertyName));

                        ListItem li = ((ListControl)c).Items.FindByValue(itemValue);
                        if (li != null)
                            li.Selected = true;
                    }
                    else if (c is CheckBox)
                    {
                        propertyName = ((CheckBox)c).Attributes["property"];
                        ((CheckBox)c).Checked = ConvertUtil.ToBoolean(ReflectUtil.GetPropertyValue(model, propertyName));
                    }
                }
            }
        }
    }
}
