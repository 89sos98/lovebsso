﻿using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.WebFx.Utils;

namespace CchenSoft.WebFx.Interceptors
{
    public class InjectionInterceptor : IServiceInterceptor
    {
        #region IServiceInterceptor 成员

        public object Invoke(IServiceInvocation invocation)
        {
            ReflectUtil.InjectBeans(invocation.InvocationTarget);            
            return invocation.InvokeNext();
        }

        #endregion
    }
}
