#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.WebFx.Attributes;
using CchenSoft.WebFx.Interceptors;
using CchenSoft.WebFx.Config;
using CchenSoft.WebFx.Utils;

namespace CchenSoft.WebFx.Interceptors
{
    public class SecurityInterceptor : IServiceInterceptor
    {
        private IAuthenticator authenticator;

        public IAuthenticator Authenticator
        {
            set { authenticator = value; }
        }

        #region IServiceInterceptor ��Ա

        public object Invoke(IServiceInvocation invocation)
        {
            ResourceAttribute[] resAttrs = ReflectUtil.GetCustomAttributes<ResourceAttribute>(invocation.Method.ReflectedType);
            if (resAttrs.Length > 0)
            {
                string resource = resAttrs[0].Name;

                SecurityAttribute[] secAttrs = ReflectUtil.GetCustomAttributes<SecurityAttribute>(invocation.Method);
                if (secAttrs != null && secAttrs.Length > 0)
                {
                    for (int i = 0; i < resAttrs.Length; i++)
                    {
                        SecurityAttribute attr = secAttrs[i];
                        authenticator.CheckPermission(resource, attr.Action);
                    }
                }
            }

            return invocation.InvokeNext();
        }

        #endregion
    }
}
