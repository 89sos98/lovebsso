#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.WebFx.Attributes;
using CchenSoft.WebFx.Interceptors;
using CchenSoft.WebFx.Config;
using System.Web;
using System.Threading;
using System.Collections;
using CchenSoft.WebFx.Service;

namespace CchenSoft.WebFx.Interceptors
{
    public class ExceptionInterceptor : IServiceInterceptor
    {
        private IDictionary errorMap;

        public ExceptionInterceptor()
        {
            errorMap = new Hashtable();
        }

        public IDictionary ErrorMap
        {
            get { return errorMap; }
            set { errorMap = value; }
        }

        #region IServiceInterceptor ��Ա

        public object Invoke(IServiceInvocation invocation)
        {
            ILogService log = Configuration.Instance.GetService<ILogService>();
            Type runtimeType = invocation.Method.ReflectedType;
            try
            {
                return invocation.InvokeNext();
            }
            catch (ThreadAbortException ex)
            {
                //log.Warn(runtimeType, ex.Message);
            }
            catch (Exception ex)
            {
                log.Error(runtimeType, ex);   
                string errorName = ex.GetType().Name;
                string url = "";
                if (errorMap.Contains(errorName))
                {
                    url = (string)errorMap[errorName];
                }
                else
                {
                    url = (string)errorMap["default"];
                }

                if (!string.IsNullOrEmpty(url))
                {
                    HttpContext.Current.Session["exception"] = ex;
                    HttpContext.Current.Response.Redirect(url);
                    return null;
                }

                throw ex;
            }

            return null;
        }

        #endregion
    }
}
