#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.WebFx.Interceptors;
using CchenSoft.WebFx.Attributes;
using CchenSoft.WebFx.Config;
using CchenSoft.WebFx.Utils;
using CchenSoft.WebFx.Service;

namespace CchenSoft.WebFx.Interceptors
{
    public class LogInterceptor : IServiceInterceptor
    {
        private ILogService logService;

        public ILogService LogService
        {
            set { logService = value; }
        }

        #region IServiceInterceptor ��Ա

        public object Invoke(IServiceInvocation invocation)
        {
            LogAttribute[] attrs = ReflectUtil.GetCustomAttributes<LogAttribute>(invocation.Method);
            if (attrs != null && attrs.Length > 0)
            {
                object result = invocation.InvokeNext();

                string text = string.Format(attrs[0].Text, invocation.Args);

                logService.Info(invocation.Method.ReflectedType, text);

                return result;
            }

            return invocation.InvokeNext();
        }

        #endregion
    }
}
