﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Text;
using CchenSoft.WebFx.Samples.Service;
using CchenSoft.WebFx.Samples.Model;
using CchenSoft.WebFx.Attributes;
using CchenSoft.WebFx.Utils;

namespace CchenSoft.WebFx.Web
{
    [Resource(SystemResource.Name)]
    [Security(SystemAction.SetPermission)]
    public partial class RolePermission : Page, IProtectedPage
    {
        [Bean]
        private IRoleService roleService;

        private Role role;

        protected void Page_Load(object sender, EventArgs e)
        {
            int roleId = ConvertUtil.ToInt32(Request["RoleId"]);

            role = roleService.LoadRole(roleId);

            if (!IsPostBack)
            {
                if (role != null)
                {
                    lblName.Text = role.Name;

                    rptResource.DataSource = ResourceManager.Resources;
                    rptResource.DataBind();
                }
            }
        }

        protected void rptResource_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                    e.Item.ItemType == ListItemType.AlternatingItem)
            {
                string name = (string)e.Item.DataItem;

                ((Label)e.Item.FindControl("lblResource")).Text = name;

                CheckBoxList chklstAction = (CheckBoxList)e.Item.FindControl("chklstAction");

                string perms = roleService.GetRolePermissions(role.RoleId, name);

                string[] actions = ResourceManager.GetActionNames(name);
                for (int i = 0; i < actions.Length; i++)
                {
                    ListItem li = new ListItem(actions[i], i.ToString());
                    li.Selected = (!string.IsNullOrEmpty(perms)) && (perms.Length > i) && (perms[i] == '1');
                    chklstAction.Items.Add(li);
                }
            }
        }

        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (role != null)
            {
                foreach (RepeaterItem item in rptResource.Items)
                {
                    string resource = ((Label)item.FindControl("lblResource")).Text;

                    CheckBoxList chklstAction = (CheckBoxList)item.FindControl("chklstAction");

                    StringBuilder perms = new StringBuilder("".PadLeft(200, '0'));
                    foreach (ListItem li in chklstAction.Items)
                    {                        
                        if (li.Selected)
                        {
                            int action = ConvertUtil.ToInt32(li.Value);
                            perms[action] = '1';
                        }
                    }

                    roleService.UpdateResource(role.RoleId, resource, perms.ToString());
                }

                //JavaScript.Alert("权限设置成功！", this);
                //JavaScript.WriteJs("location.href='listrole.aspx';", this);
            }

            //Response.Redirect("ListRole.aspx");
        }
    }
}
