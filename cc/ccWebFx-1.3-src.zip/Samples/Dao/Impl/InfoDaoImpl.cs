#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using CchenSoft.WebFx.Samples.Model;
using CchenSoft.WebFx.Service;

namespace CchenSoft.WebFx.Samples.Dao.Impl
{
	/// <summary>
	/// Class1 ��ժҪ˵����
	/// </summary>
	public class InfoDaoImpl : IInfoDao
	{
        private IDataService dataService;

        public IDataService DataService
        {
            set { dataService = value; }
        }

		public void SaveInfo(Info info)
		{
    		dataService.Insert("InsertInfo",info);
		}

        public void UpdateInfo(Info info)
        {
            dataService.Update("UpdateInfo", info);
        }

        public IList<Info> GetInfos(int pageIndex, int pageSize, ref int count)
        {
            count = dataService.QueryForObject<int>("GetInfoCount", null);
            return dataService.QueryForList<Info>("SelectInfo", null, (pageIndex - 1) * pageSize, pageSize);
        }

        public Info LoadInfo(int id)
        {
            return dataService.QueryForObject<Info>("SelectInfo", id);
        }
	}
}
