#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.WebFx.Samples.Model;
using System.Collections;
using CchenSoft.WebFx.Service;

namespace CchenSoft.WebFx.Samples.Dao.Impl
{
    public class RoleDaoImpl : IRoleDao
    {
        private IDataService dataService;

        public IDataService DataService
        {
            set { dataService = value; }
        }

        public Role LoadRole(int roleId)
        {
            return dataService.QueryForObject<Role>("SelectRole", roleId);
        }

        public IList<Role> GetRoles()
        {
            return dataService.QueryForList<Role>("SelectRole", null);
        }

        public int SaveRole(Role role)
        {
            dataService.Insert("InsertRole", role);
            return 0;
        }

        public int UpdateRole(Role role)
        {
            return dataService.Update("UpdateRole", role);
        }

        public int DeleteRole(int roleId)
        {
            dataService.Delete("DeleteResource", roleId);
            return dataService.Delete("DeleteRole", roleId);
        }

        public IList<string> GetRoleUsers(int roleId)
        {
            return dataService.QueryForList<string>("GetRoleUsers", roleId);
        }

        public IList<Role> GetUserRoles(int userId)
        {
            return dataService.QueryForList<Role>("GetUserRoles", userId);
        }

        public int DeleteRoleUsers(int roleId)
        {
            return dataService.Delete("DeleteRoleUsers", roleId);
        }

        public int DeleteUserFromRole(int roleId, int userId)
        {
            Hashtable dict = new Hashtable();
            dict["roleId"] = roleId;
            dict["userId"] = userId;
            return dataService.Delete("DeleteUserFromRole", dict);
        }

        public int InsertUserToRole(int roleId, int userId)
        {
            Hashtable dict = new Hashtable();
            dict["roleId"] = roleId;
            dict["userId"] = userId;
            dataService.Insert("InsertUserToRole", dict);
            return 0;
        }

        public string GetRolePermissions(int roleId, string name)
        {
            Hashtable dict = new Hashtable();
            dict["roleId"] = roleId;
            dict["name"] = name;
            return dataService.QueryForObject<string>("GetRolePermissions", dict);
        }

        public IList<string> GetUserPermissions(string userId, string name)
        {
            Hashtable dict = new Hashtable();
            dict["userId"] = userId;
            dict["name"] = name;
            IList<string> result = dataService.QueryForList<string>("GetUserPermissions", dict);
            return result;
        }

        public int UpdateResource(int roleId, string name, string permissions)
        {
            Hashtable dict = new Hashtable();
            dict["roleId"] = roleId;
            dict["name"] = name;
            dict["permissions"] = permissions;

            int exists = CheckResourceExists(roleId, name);

            if (exists == 0)
                dataService.Insert("InsertResource", dict);                
            else
                dataService.Update("UpdateResource", dict);

            return 0;
        }

        private int CheckResourceExists(int roleId, string name)
        {
            Hashtable dict = new Hashtable();
            dict["roleId"] = roleId;
            dict["name"] = name;

            return dataService.QueryForObject<int>("CheckResourceExists", dict);
        }
    }
}
