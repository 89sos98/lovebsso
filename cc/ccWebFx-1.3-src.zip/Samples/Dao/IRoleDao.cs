#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.WebFx.Samples.Model;

namespace CchenSoft.WebFx.Samples.Dao
{
    public interface IRoleDao
    {
        IList<Role> GetRoles();

        int SaveRole(Role role);

        int UpdateRole(Role role);

        int DeleteRole(int roleId);

        IList<string> GetRoleUsers(int roleId);

        IList<Role> GetUserRoles(int userId);

        int DeleteRoleUsers(int roleId);

        int DeleteUserFromRole(int roleId, int userId);

        int InsertUserToRole(int roleId, int userId);

        string GetRolePermissions(int roleId, string name);

        int UpdateResource(int roleId, string name, string permissions);

        IList<string> GetUserPermissions(string userId, string name);

        Role LoadRole(int roleId);
    }
}
