#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using CchenSoft.WebFx.Config;
using CchenSoft.WebFx.Service;

namespace CchenSoft.WebFx.Samples.Service
{
	/// <summary>
	/// ServiceLocator ��ժҪ˵����
	/// </summary>
	public class ServiceLocator
	{
        private static IInfoService _infoservice;
        private static ICacheService _cacheservice;
        private static IRoleService _roleservice;
        private static IUserService _userservice;
        private static ILogService _logservice;
        private static IDataService _dataservice;

        static ServiceLocator()
		{
		}

        public static IDataService DataService
        {
            get
            {
                if (_dataservice == null)
                {
                    _dataservice = Configuration.Instance.GetService<IDataService>();
                }
                return _dataservice;
            }
        }

        public static IInfoService InfoService
		{
			get
			{
				if(_infoservice==null)
				{
                    _infoservice = Configuration.Instance.GetService<IInfoService>();
				}
				return _infoservice;
			}
		}

        public static ICacheService CacheService
        {
            get
            {
                if (_cacheservice == null)
                {
                    _cacheservice = Configuration.Instance.GetService<ICacheService>();
                }
                return _cacheservice;
            }
        }

        public static IRoleService RoleService
        {
            get
            {
                if (_roleservice == null)
                {
                    _roleservice = Configuration.Instance.GetService<IRoleService>();
                }
                return _roleservice;
            }
        }

        public static IUserService UserService
        {
            get
            {
                if (_userservice == null)
                {
                    _userservice = Configuration.Instance.GetService<IUserService>();
                }
                return _userservice;
            }
        }

        public static ILogService LogService
        {
            get
            {
                if (_logservice == null)
                {
                    _logservice = Configuration.Instance.GetService<ILogService>();
                }
                return _logservice;
            }
        }
	}
}
