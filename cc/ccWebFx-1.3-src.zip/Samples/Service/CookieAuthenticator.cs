#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace CchenSoft.WebFx.Samples.Service
{
    public class CookieAuthenticator : IAuthenticator
    {
        private const string CookieKey = "webfx";
        private const string IdentityKey = "userId";

        private string loginUrl;
        private IUserService userService;
        private IRoleService roleService;

        public IUserService UserService
        {
            set { userService = value; }
        }

        public IRoleService RoleService
        {
            set { roleService = value; }
        }

        #region IAuthenticator ��Ա

        public string LoginUrl
        {
            get { return loginUrl; }
            set { loginUrl = value; }
        }

        public bool Authenticate(string name, string passwd, bool persist)
        {
            int identity = userService.ValidateLogin(name, passwd);
            if (identity > 0)
            {
                HttpCookie cookie = new HttpCookie(CookieKey);
                cookie[IdentityKey] = identity.ToString();
                if (persist)
                {
                    cookie.Expires = DateTime.Now.AddYears(1);
                }
                HttpContext.Current.Response.Cookies.Add(cookie);
                return true;
            }
            return false;
        }

        public bool Authenticated
        {
            get
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
                return cookie != null ? !string.IsNullOrEmpty(cookie[IdentityKey]) : false;
            }
        }

        public string Identity
        {
            get
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
                return (cookie != null) ? cookie[IdentityKey] : null;
            }
        }

        public void SignOut()
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
            if (cookie != null)
            {
                cookie.Expires = DateTime.Now.AddDays(-1);
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
        }

        public void CheckPermission(string resource, int action)
        {
            bool flag = false;

            if (Authenticated)
            {
                if (Identity.Equals("1"))
                {
                    flag = true;
                }
                else
                {
                    IList<string> permissions = roleService.GetUserPermissions(Identity, resource);

                    string perms = "".PadRight(200, '0');

                    foreach (string permission in permissions)
                    {
                        perms = MergePermissions(perms, permission);
                    }

                    flag = (perms[action] == '1');
                }
            }

            if (flag == false)
            {
                string[] actionNames = ResourceManager.GetActionNames(resource);
                string message = actionNames != null
                    ? string.Format("û��{0}��Ȩ��!", actionNames[action])
                    : string.Format("û�в���{0}��Ȩ��!", resource);

                throw new SecurityException(message);
            }
        }

        #endregion

        private char GetPermission(char p, char p2)
        {
            if (p == '0' && p2 == '0')
                return '0';
            return '1';
        }

        private string MergePermissions(string perms, string perms2)
        {
            if (perms == "")
                return perms2.PadRight(200, '0');

            if (perms.Length < 200)
                perms = perms.PadRight(200, '0');

            if (perms2.Length < 200)
                perms2 = perms2.PadRight(200, '0');

            string result = "";

            // �ϲ�Ȩ��.
            for (int i = 0; i < 200; i++)
            {
                result = result + GetPermission(perms[i], perms2[i]);
            }

            return result;
        }
    }
}
