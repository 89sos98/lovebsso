#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using CchenSoft.WebFx.Samples.Dao;
using CchenSoft.WebFx.Samples.Model;

namespace CchenSoft.WebFx.Samples.Service
{
	/// <summary>
	/// Class1 ��ժҪ˵����
	/// </summary>
	public interface IInfoService : IService
	{		
		IInfoDao InfoDao { set; }
		
		void SaveInfo(Info info);

        void UpdateInfo(Info info);

        IList<Info> GetInfos(int pageIndex, int pageSize, ref int count);

        Info LoadInfo(int id);
    }

}
