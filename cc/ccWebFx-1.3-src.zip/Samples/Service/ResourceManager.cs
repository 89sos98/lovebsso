#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.WebFx.Samples.Service
{
    public class ResourceManager
    {
        private static IDictionary<string, string[]> resourceActions = new Dictionary<string, string[]>();

        static ResourceManager()
        {
            resourceActions.Add(InfoResource.Name, InfoResource.ActionNames);
            resourceActions.Add(SystemResource.Name, SystemResource.ActionNames);
            resourceActions.Add(ProductResource.Name, ProductResource.ActionNames);
        }

        public static IList<string> Resources
        {
            get { return new List<string>(resourceActions.Keys); }
        }

        public static string[] GetActionNames(string resource)
        {
            return resourceActions[resource];
        }
    }

    #region info resource & action

    public class InfoResource
    {
        public const string Name = "��Ѷ";
        public static string[] ActionNames = new string[] { "������Ѷ", "������Ѷ", "ɾ����Ѷ" };
    }

    public class InfoAction
    {
        public const int AddInfo = 0;
        public const int UpdateInfo = 1;
        public const int DeleteInfo = 2;
    }

    #endregion

    #region system resource & action

    public class SystemResource
    {
        public const string Name = "ϵͳ";
        public static string[] ActionNames = new string[] { "��ɫ�鿴", "���ӽ�ɫ", "���½�ɫ", "ɾ����ɫ", "����Ȩ��" };
    }

    public class SystemAction
    {
        public const int ViewRole = 0;
        public const int AddRole = 1;
        public const int UpdateRole = 2;
        public const int DeleteRole = 3;
        public const int SetPermission = 4;
    }

    #endregion

    #region product resource & action

    public class ProductResource
    {
        public const string Name = "��Ʒ";
        public static string[] ActionNames = new string[] { "���Ӳ�Ʒ", "���²�Ʒ", "ɾ����Ʒ" };
    }

    public class ProductAction
    {
        public const int AddRole = 0;
        public const int UpdateRole = 1;
        public const int DeleteRole = 2;
    }

    #endregion
}
