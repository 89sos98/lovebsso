#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.WebFx.Samples.Dao;
using CchenSoft.WebFx.Samples.Model;
using CchenSoft.WebFx.Attributes;

namespace CchenSoft.WebFx.Samples.Service.Impl
{
    public class UserServiceImpl : IUserService
    {
        private IUserDao userDao;

        public IUserDao UserDao
        {
            set { this.userDao = value; }
        }

        #region IService ��Ա

        public void Initialize()
        {
        }

        #endregion

        #region IUserService ��Ա

        [Log("��֤��¼, name={0}")]
        public int ValidateLogin(string username, string passwd)
        {
            return userDao.ValidateLogin(username, passwd);
        }

        #endregion
    }
}
