#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.WebFx.Samples.Dao;
using CchenSoft.WebFx.Samples.Model;
using CchenSoft.WebFx.Attributes;

namespace CchenSoft.WebFx.Samples.Service.Impl
{
    [Resource(SystemResource.Name)]
    public class RoleServiceImpl : IRoleService
    {
        private IRoleDao roleDao;

        public IRoleDao RoleDao
        {
            set { this.roleDao = value; }
        }

        #region IRoleService ��Ա

        public Role LoadRole(int roleId)
        {
            return roleDao.LoadRole(roleId);
        }

        public IList<Role> GetRoles()
        {
            return roleDao.GetRoles();
        }

        [Security(SystemAction.AddRole)]
        public int SaveRole(Role role)
        {
            return roleDao.SaveRole(role);
        }

        [Security(SystemAction.UpdateRole)]
        public int UpdateRole(Role role)
        {
            return roleDao.UpdateRole(role);
        }

        [Security(SystemAction.DeleteRole)]
        [Transaction(TransactionOption.RequiresNew)]
        public int DeleteRole(int roleId)
        {
            return roleDao.DeleteRole(roleId);
        }

        public IList<string> GetRoleUsers(int roleId)
        {
            return roleDao.GetRoleUsers(roleId);
        }

        public IList<Role> GetUserRoles(int userId)
        {
            return roleDao.GetUserRoles(userId);
        }

        public int DeleteRoleUsers(int roleId)
        {
            return roleDao.DeleteRoleUsers(roleId);
        }

        public int DeleteUserFromRole(int roleId, int userId)
        {
            return roleDao.DeleteUserFromRole(roleId, userId);
        }

        public int InsertUserToRole(int roleId, int userId)
        {
            return roleDao.InsertUserToRole(roleId, userId);
        }

        public string GetRolePermissions(int roleId, string name)
        {
            return roleDao.GetRolePermissions(roleId, name);
        }

        public IList<string> GetUserPermissions(string userId, string name)
        {
            return roleDao.GetUserPermissions(userId, name);
        }

        [Security(SystemAction.SetPermission)]
        public int UpdateResource(int roleId, string name, string permissions)
        {
            return roleDao.UpdateResource(roleId, name, permissions);
        }

        #endregion

        #region IService ��Ա

        public void Initialize()
        {
        }

        #endregion
    }
}
