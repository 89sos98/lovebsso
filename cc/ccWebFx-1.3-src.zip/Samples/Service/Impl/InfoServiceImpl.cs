#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Web;
using System.Collections.Generic;
using CchenSoft.WebFx.Samples.Dao;
using CchenSoft.WebFx.Samples.Model;
using CchenSoft.WebFx.Attributes;

namespace CchenSoft.WebFx.Samples.Service.Impl
{
	/// <summary>
	/// Class1 ��ժҪ˵����
	/// </summary>
    [Resource(InfoResource.Name)]
	public class InfoServiceImpl : IInfoService
	{
		private IInfoDao infoDao;

		public InfoServiceImpl()
		{
		}

		public IInfoDao InfoDao
		{
            set { this.infoDao = value; }
		}

		[Log("������Ϣ��ID={0}")]
        [Security(InfoAction.AddInfo)]
		public void SaveInfo(Info info)
		{
			infoDao.SaveInfo(info);
		}

        [Log("������Ϣ��ID={0}")]
        public void UpdateInfo(Info info)
        {
            infoDao.UpdateInfo(info);
        }

        public IList<Info> GetInfos(int pageIndex, int pageSize, ref int count)
        {
            return infoDao.GetInfos(pageIndex, pageSize, ref count);
        }

        [Cacheable]
        public Info LoadInfo(int id)
        {
            return infoDao.LoadInfo(id);
        }

        #region IService ��Ա

        public void Initialize()
        {
        }

        #endregion
    }

}
