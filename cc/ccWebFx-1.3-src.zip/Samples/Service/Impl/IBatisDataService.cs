#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using IBatisNet.DataMapper;
using IBatisNet.DataMapper.Configuration;
using System.Data;
using System.Collections;
using System.Xml;
using System.IO;
using System.Web;
using CchenSoft.WebFx.Service;

namespace CchenSoft.WebFx.Samples.Service.Impl
{
    public class IBatisDataService : IDataService
    {
        private ISqlMapper mapper;
        private string connectionString;
        private IList mappings;

        public IBatisDataService()
        {
        }

        public string ConnectionString
        {
            get { return connectionString; }
            set { connectionString = value; }
        }

        public IList Mappings
        {
            get { return mappings; }
            set { mappings = value; }
        }

        public void Initialize()
        {
            string xml = "";
            using (StreamReader reader = new StreamReader(HttpContext.Current.Server.MapPath("~/sqlmap.config")))
            {
                xml = reader.ReadToEnd();
            }

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < mappings.Count; i++)
                sb.AppendFormat("<sqlMap resource=\"{0}\"/>", mappings[i]).AppendFormat(Environment.NewLine);

            xml = xml.Replace("#sqlMaps#", sb.ToString());
            xml = xml.Replace("#connectionString#", connectionString);

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);

            DomSqlMapBuilder builder = new DomSqlMapBuilder();
            mapper = builder.Configure(doc);
        }

        public T Load<T>(object id)
        {
            throw new Exception("not implement, please use queryforobject.");
        }

        public object Insert(string statementName, object parameterObject)
        {
            return mapper.Insert(statementName, parameterObject);
        }

        public object QueryForObject(string statementName, object parameterObject)
        {
            return mapper.QueryForObject(statementName, parameterObject);
        }

        public T QueryForObject<T>(string statementName, object parameterObject)
        {
            return mapper.QueryForObject<T>(statementName, parameterObject);
        }

        public int Update(string statementName, object parameterObject)
        {
            return mapper.Update(statementName, parameterObject);
        }

        public int Delete(string statementName, object parameterObject)
        {
            return mapper.Delete(statementName, parameterObject);
        }

        public IList QueryForList(string statementName, object parameterObject)
        {
            return mapper.QueryForList(statementName, parameterObject);
        }

        public IList<T> QueryForList<T>(string statementName, object parameterObject)
        {
            return mapper.QueryForList<T>(statementName, parameterObject);
        }

        public IList QueryForList(string statementName, object parameterObject, int skipResults, int maxResults)
        {
            return mapper.QueryForList(statementName, parameterObject, skipResults, maxResults);
        }

        public IList<T> QueryForList<T>(string statementName, object parameterObject, int skipResults, int maxResults)
        {
            return mapper.QueryForList<T>(statementName, parameterObject, skipResults, maxResults);
        }

        public object BeginTransaction()
        {
            ISqlMapSession session = mapper.BeginTransaction();
            return session;
        }

        public void Commit(object obj)
        {
            ISqlMapSession session = (ISqlMapSession)obj;
            session.CommitTransaction();
        }

        public void Rollback(object obj)
        {
            ISqlMapSession session = (ISqlMapSession)obj;
            session.RollBackTransaction();
        }

        public IDbDataParameter CreateParameter(string name, object value)
        {
            if (!mapper.IsSessionStarted)
                mapper.OpenConnection();

            IDbDataParameter parameter = mapper.LocalSession.CreateDataParameter();
            parameter.ParameterName = name;
            parameter.Value = value;

            return parameter;
        }

        public DataSet QueryForDataSet(string statementName, object parameterObject)
        {
            if (!mapper.IsSessionStarted)
                mapper.OpenConnection();

            IDbCommand command = mapper.LocalSession.CreateCommand(CommandType.Text);
            command.CommandText = statementName;
            if (parameterObject is IList<IDbDataParameter>)
            {
                IList<IDbDataParameter> parameters = (IList<IDbDataParameter>)parameterObject;
                foreach (IDbDataParameter param in parameters)
                {
                    command.Parameters.Add(param);
                }
            }

            IDbDataAdapter adapter = mapper.LocalSession.CreateDataAdapter(command);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            return ds;
        }
    }
}
