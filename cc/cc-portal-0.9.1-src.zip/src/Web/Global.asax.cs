using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal;

namespace Web
{
    public class Global : PortalApplication
    {

    }
}