#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Util;
using System.Collections.Generic;
using CchenSoft.Portal.ImageGallery.Service;

namespace ImageGallery.Web
{
	/// <summary>
	/// WebForm1 ��ժҪ˵����
	/// </summary>
	public partial class AdminImages : ViewPage
	{
        private IImageService imageService;

        protected void Page_Load(object sender, System.EventArgs e)
        {
            imageService = portletContext.GetService<IImageService>();
            if (!IsPostBack)
            {
                //rptArticle.DataSource = docService.FindArticles("");
                //rptArticle.DataBind();
            }
        }

        protected void rptArticle_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            //if (e.Item.ItemType == ListItemType.Item ||
            //    e.Item.ItemType == ListItemType.AlternatingItem)
            //{
            //    Article art = (Article)e.Item.DataItem;

            //    Label lTitle = (Label)e.Item.FindControl("lTitle");
            //    lTitle.Text = art.Title;

            //    HyperLink hEdit = (HyperLink)e.Item.FindControl("hEdit");
            //    hEdit.NavigateUrl = "EditArticle.aspx?artid=" + art.ArticleId.ToString();

            //    ((Label)e.Item.FindControl("lCreated")).Text = art.AddDate.ToString();
            //}
        }

	}
}
