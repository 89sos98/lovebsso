#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.ImageGallery.Service;
using CchenSoft.Portal.ImageGallery.Model;

namespace CchenSoft.Portal.ImageGallery.Web
{
    public class ImageHandler : IHttpHandler
    {
        #region IHttpHandler ��Ա

        public bool IsReusable
        {
            get { return false; }
        }

        public void ProcessRequest(HttpContext context)
        {
            PortletContext portletContext = (PortletContext)context.Items["portlet_context"];

            int imageId = ParamUtil.GetInt32(context.Request, "id");

            IImageService service = portletContext.GetService<IImageService>();

            byte[] data = service.GetImageData(imageId);
            if (data != null)
            {
                context.Response.Clear();
                context.Response.ContentType = "image/*";
                context.Response.BinaryWrite(data);
                context.Response.End();
            }
        }

        #endregion
    }
}
