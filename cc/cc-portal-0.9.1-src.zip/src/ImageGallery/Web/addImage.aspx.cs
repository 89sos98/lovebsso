#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal;
using CchenSoft.Portal.Web.UI;
using System.IO;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.ImageGallery.Model;
using CchenSoft.Portal.ImageGallery.Service;

namespace ImageGallery.Web
{
	/// <summary>
	/// WebForm1 ��ժҪ˵����
	/// </summary>
	public partial class AddImage : ActionPage
	{
	
		protected void Page_Load(object sender, System.EventArgs e)
		{			
            
		}

		#region Web ������������ɵĴ���
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �õ����� ASP.NET Web ���������������ġ�
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void Button1_Click(object sender, System.EventArgs e)
		{
            if (fileU.HasFile)
            {
                IGImage image = new IGImage();
                image.Name = txtName.Text;
                image.Description = summary.Text;
                //image.FileSize = fileU.FileBytes.Length;
                image.FolderId = ParamUtil.GetInt32(Request, "fid");
                image.UserId = portletContext.User.UserId;
                image.CreateDate = DateTime.Now;

                portletContext.GetService<IImageService>().SaveImage(image, fileU.FileBytes);
            }

            SendPortalRedirect();
		}
	}
}
