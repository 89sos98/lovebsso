#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Model;

namespace ImageGallery.Web
{
	/// <summary>
	/// WebForm1 ��ժҪ˵����
	/// </summary>
	public partial class ViewConfig : ActionPage
	{	
		protected void Page_Load(object sender, System.EventArgs e)
		{
            if (!IsPostBack)
            {
                txtHeight.Text = preferences.GetInt32("height").ToString();
                txtWidth.Text = preferences.GetInt32("width").ToString();
                txtUrl.Text = preferences.GetString("url");
            }
		}

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            preferences.SetValue("height", txtHeight.Text);
            preferences.SetValue("width", txtWidth.Text);
            preferences.SetValue("url", txtUrl.Text);
            UpdatePreferences(preferences);
            SendPortalRedirect();
        }

		#region Web ������������ɵĴ���
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �õ����� ASP.NET Web ���������������ġ�
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion


	}
}
