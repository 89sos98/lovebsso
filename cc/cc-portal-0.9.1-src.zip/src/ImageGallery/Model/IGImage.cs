#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.ImageGallery.Model
{
    public class IGImage
    {
        private int imageId;
        private string name;
        private int folderId;
        private int userId;
        private string description;
        private DateTime createDate;

        public int ImageId
        {
            get { return imageId; }
            set { imageId = value; }
        }

        public int FolderId
        {
            get { return folderId; }
            set { folderId = value; }
        }

        public int UserId
        {
            get { return userId; }
            set { userId = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }


        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public DateTime CreateDate
        {
            get { return createDate; }
            set { createDate = value; }
        }

    }
}
