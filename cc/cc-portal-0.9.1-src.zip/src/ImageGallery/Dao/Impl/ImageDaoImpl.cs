#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using CchenSoft.Portal.ImageGallery.Model;
using System.IO;
using System.Web;
using System.Xml;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Service;

namespace CchenSoft.Portal.ImageGallery.Dao.Impl
{
    public class ImageDaoImpl : IImageDao
    {
        private IDataService service;

        public ImageDaoImpl()
        {
        }

        #region IImageDao ��Ա

        public int SaveImage(IGImage image, byte[] data)
        {
            service.Insert("InsertIGImage", image);

            Hashtable dict = new Hashtable();
            dict["ImageId"] = image.ImageId;
            dict["Data"] = data;
            service.Insert("InsertIGImageData", dict);

            return 0;
        }

        public int SaveFolder(IGFolder folder)
        {
            service.Insert("InsertIGFolder", folder);
            return 0;
        }

        public IList<IGFolder> GetSubFolders(int folderId)
        {
            return service.QueryForList<IGFolder>("GetSubIGFolders", folderId);
        }

        public IList<IGImage> GetImagesByFolder(int folderId)
        {
            return service.QueryForList<IGImage>("GetFolderIGImages", folderId);
        }

        public byte[] GetImageData(int imageId)
        {
            return service.QueryForObject<Byte[]>("GetIGImageData", imageId);
        }

        public IGImage LoadImage(int imageId)
        {
            return service.QueryForObject<IGImage>("SelectIGImage", imageId);
        }

        public IGFolder LoadFolder(int folderId)
        {
            return service.QueryForObject<IGFolder>("SelectIGFolder", folderId);
        }

        public IList Mappings
        {
            set { mappings = value; }
        }

        private IList mappings;

        #endregion

        #region IDao ��Ա

        public void Initialize()
        {
            service = PluginLocator.GetPluginService<IDataService>("data");
            service.Configure(mappings);
        }

        #endregion
    }
}
