#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Web;
using CchenSoft.Portal.ImageGallery.Model;
using CchenSoft.Portal.ImageGallery.Dao;
using System.Collections;
using CchenSoft.Portal.Spi.Attribute;

namespace CchenSoft.Portal.ImageGallery.Service.Impl
{
    public class ImageServiceImpl : IImageService
    {
        private IImageDao imageDao;

        public ImageServiceImpl()
        {
        }

        #region IImageService ��Ա

        [Transaction(TransactionOption.RequiresNew)]
        public int SaveImage(IGImage image, byte[] data)
        {
            return imageDao.SaveImage(image, data);
        }

        public int SaveFolder(IGFolder folder)
        {
            return imageDao.SaveFolder(folder);
        }

        public IImageDao ImageDao
        {
            set { this.imageDao = value; }
        }

        public IList<IGFolder> GetSubFolders(int folderId)
        {
            return imageDao.GetSubFolders(folderId);
        }

        public IList<IGImage> GetImagesByFolder(int folderId)
        {
            return imageDao.GetImagesByFolder(folderId);
        }

        public IGImage LoadImage(int imageId)
        {
            return imageDao.LoadImage(imageId);
        }

        public byte[] GetImageData(int imageId)
        {
            return imageDao.GetImageData(imageId);
        }

        public IGFolder LoadFolder(int folderId)
        {
            return imageDao.LoadFolder(folderId);
        }

        public void Initialize()
        {
        }

        #endregion
    }
}
