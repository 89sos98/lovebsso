#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.Calendar.Model
{
    public enum TaskState
    {
        Unstart,
        Running,
        Finish,
        WaitForOther,
        delaying,
    }

    public enum TaskPriority
    {
        Low,
        Normal,
        High,
    }

    public class Task
    {
        private int taskId;
        private string subject;
        private string content;
        private int userId;
        private DateTime endDate;
        private DateTime startDate;
        private TaskState state;
        private TaskPriority priority;
        private int percent;

        public int TaskId
        {
            get { return taskId; }
            set { taskId = value; }
        }

        public string Subject
        {
            get { return subject; }
            set { subject = value; }
        }

        public string Content
        {
            get { return content; }
            set { content = value; }
        }

        public int UserId
        {
            get { return userId; }
            set { userId = value; }
        }

        public DateTime EndDate
        {
            get { return endDate; }
            set { endDate = value; }
        }

        public DateTime StartDate
        {
            get { return startDate; }
            set { startDate = value; }
        }

        public TaskState State
        {
            get { return state; }
            set { state = value; }
        }

        public TaskPriority Priority
        {
            get { return priority; }
            set { priority = value; }
        }

        public int Percent
        {
            get { return percent; }
            set { percent = value; }
        }
    }
}
