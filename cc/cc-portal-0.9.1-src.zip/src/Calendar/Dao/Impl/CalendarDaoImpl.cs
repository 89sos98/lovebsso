#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using CchenSoft.Portal.Calendar.Model;
using CchenSoft.Portal.Calendar.Dao;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Service;

namespace CchenSoft.Portal.Calendar.Dao.Impl
{
	/// <summary>
	/// Class1 ��ժҪ˵����
	/// </summary>
	public class CalendarDaoImpl : ICalendarDao
	{
        private IDataService service;

        public CalendarDaoImpl()
		{
		}

		
		public void SaveTask(Task task)
		{
            service.Insert("InsertTask", task);
		}

        public IList<Task> GetTasks(int pageIndex, int pageSize, ref long count)
        {
            count = service.QueryForObject<long>("GetTaskCount", null);
            return service.QueryForList<Task>("SelectTask", null, (pageIndex - 1) * pageSize, pageSize);
        }

        public Task LoadTask(int id)
        {
            return service.QueryForObject<Task>("SelectTask", id);
        }

        public void UpdateTask(Task art)
        {
            service.Update("UpdateTask", art);
        }

        public IList Mappings
        {
            set { mappings = value; }
        }

        private IList mappings;

        #region IDao ��Ա

        public void Initialize()
        {
            service = PluginLocator.GetPluginService<IDataService>("data");
            service.Configure(mappings);
        }

        #endregion
    }
}
