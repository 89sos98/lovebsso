#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Calendar.Service;
using CchenSoft.Portal.Calendar.Model;

namespace Portal.Calendar.Web
{
	/// <summary>
	/// WebForm1 ��ժҪ˵����
	/// </summary>
	public partial class EditTask : ActionPage
	{
        private ICalendarService service;
        private Task task;

		protected void Page_Load(object sender, System.EventArgs e)
		{
            service = portletContext.GetService<ICalendarService>();
            int taskId = ParamUtil.GetInt32(Request, "taskid");
            task = service.LoadTask(taskId);

            if (!IsPostBack)
            {
                if (task != null)
                {
                    txtSubject.Text = task.Subject;
                    txtEndDate.Text = task.EndDate.ToString("yyyy-MM-dd");
                    txtStartDate.Text = task.StartDate.ToString("yyyy-MM-dd");
                    txtContent.Text = task.Content;
                }
            }
		}

		#region Web ������������ɵĴ���
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �õ����� ASP.NET Web ���������������ġ�
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void Button1_Click(object sender, System.EventArgs e)
		{
            if (task != null)
            {
                task.Subject = txtSubject.Text;
                task.EndDate = ConvertUtil.ToDateTime(txtEndDate.Text);
                task.StartDate = ConvertUtil.ToDateTime(txtStartDate.Text);
                task.Content = txtContent.Text;

                service.UpdateTask(task);
            }

            SendPortalRedirect();		
		}
	}
}
