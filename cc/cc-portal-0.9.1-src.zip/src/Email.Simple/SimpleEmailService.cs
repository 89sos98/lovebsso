#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion
using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Spi.Service;
using System.Net.Mail;
using CchenSoft.Portal.Spi.Plugin;

namespace CchenSoft.Portal.Email
{
    public class SimpleEmailService : IEmailService
    {
        private IServicePlugin plugin;
        private string smtpServer;
        private int smtpPort;
        private string mailAccount;
        private string mailPasswd;
        private bool smtpValidate;

        public string SmtpServer
        {
            get { return smtpServer; }
            set { smtpServer = value; }
        }

        public int SmtpPort
        {
            get { return smtpPort; }
            set { smtpPort = value; }
        }

        public bool SmtpValidate
        {
            get { return smtpValidate; }
            set { smtpValidate = value; }
        }

        public string MailAccount
        {
            get { return mailAccount; }
            set { mailAccount = value; }
        }

        public string MailPasswd
        {
            get { return mailPasswd; }
            set { mailPasswd = value; }
        }


        #region IEmailService ��Ա

        public bool SendEmail(string recipients, string subject, string body)
        {
            try
            {
                //�����ʼ�
                SmtpClient client = new SmtpClient(smtpServer, smtpPort);
                //client.EnableSsl = true;
                client.UseDefaultCredentials = false;
                client.Credentials = new System.Net.NetworkCredential(mailAccount, mailPasswd);
                client.DeliveryMethod = SmtpDeliveryMethod.Network;

                MailMessage mailmessage = new MailMessage(mailAccount, recipients, subject, body);

                mailmessage.BodyEncoding = System.Text.Encoding.UTF8;
                mailmessage.IsBodyHtml = true;

                client.Send(mailmessage);
                return true;
            }
            catch (Exception ex)
            {
                ILogService service = PluginLocator.GetPluginService<ILogService>("logging");
                service.Error(ex.Message + Environment.NewLine + ex.StackTrace, this.GetType());
                return false;
            }
        }

        #endregion

        #region IPluginService ��Ա

        public void SetPlugin(IPlugin plugin)
        {
            this.plugin = (IServicePlugin)plugin;
        }

        #endregion

        #region IService ��Ա

        public void Initialize()
        {
        }

        #endregion
    }
}
