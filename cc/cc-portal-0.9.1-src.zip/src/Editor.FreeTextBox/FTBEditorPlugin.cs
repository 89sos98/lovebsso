#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using FreeTextBoxControls;
using CchenSoft.Portal.Spi.Plugin;

namespace CchenSoft.Portal.Editor
{
    public class FTBEditorPlugin : GeneralPlugin, IEditorPlugin
    {
        private FreeTextBox editor;
        //private string content;
        private string controlName;

        #region IEditorPlugin ��Ա

        public void Initialize(Control control)
        {
            editor = (FreeTextBox)control.FindControl("editor");
            editor.HelperFilesPath = Path;
            //editor.Text = content;
        }

        public string ControlName
        {
            get { return controlName; }
            set { controlName = value; }
        }

        public string Content
        {
            get
            {
                //content = editor.Text;
                //return content;
                return editor.Text;
            }
            set
            {
                //content = value;
                editor.Text = value;
            }
        }

        public Control LoadEditor(Page page)
        {
            return page.LoadControl(controlName);
        }

        #endregion
    }
}
