#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using Lucene.Net.Search;
using Lucene.Net.QueryParsers;
using Lucene.Net.Analysis;
using Lucene.Net.Documents;
using System.Collections;
using Lucene.Net.Index;
using CchenSoft.Portal.Spi.Attribute;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Spi;
using CchenSoft.Portal.Spi.Plugin;

namespace CchenSoft.Portal.Search
{
    public class LuceneSearchService : ISearchService
    {
        private LuceneSearchPlugin plugin;

        #region ISearchService ��Ա

        private Analyzer analyzer;

        public Analyzer Analyzer
        {
            set { analyzer = value; }
            get { return analyzer; }
        }

        public int Index<T>(IList<T> entries, IModule module)
        {
            SearchableEntry se = plugin.GetEntry(module.Name);

            IndexWriter writer  = new IndexWriter(se.IndexFolder, analyzer, !IndexReader.IndexExists(se.IndexFolder));
            try
            {
                foreach (T entry in entries)
                {
                    Document doc = new Document();
                    PropertyInfo[] infos = entry.GetType().GetProperties();
                    foreach (PropertyInfo pi in infos)
                    {
                        object[] attrs = pi.GetCustomAttributes(typeof(IndexFieldAttribute), false);
                        if (attrs != null && attrs.Length > 0)
                        {
                            Field.Index indexType = Field.Index.UN_TOKENIZED;
                            if (pi.PropertyType == typeof(string))
                                indexType = Field.Index.TOKENIZED;
                            object val = pi.GetValue(entry, null);
                            string strVal = (val != null) ? val.ToString() : "";
                            doc.Add(new Field(pi.Name, strVal, Field.Store.YES, indexType));
                        }
                    }

                    writer.AddDocument(doc);
                }
                return 0;
            }
            finally
            {
                try
                {
                    writer.Optimize();
                }
                catch
                {
                }

                writer.Close();
            }
        }

        public IList<T> Search<T>(string word, IModule module)
        {
            SearchableEntry se = plugin.GetEntry(module.Name);

            Query query = QueryParser.Parse(word, "Title", analyzer);
            IndexSearcher search = new IndexSearcher(se.IndexFolder);
            Hits hits = search.Search(query);

            IList<T> list = new List<T>();
            for (int i = 0; i < hits.Length(); i++)
            {
                Document doc = hits.Doc(i);
                T obj = GetObject<T>(doc);
                list.Add(obj);
            }

            return list;
        }

        #endregion

        private T GetObject<T>(Document doc)
        {
            T obj = Activator.CreateInstance<T>();

            foreach (Field field in doc.Fields())
            {
                PropertyInfo pi = obj.GetType().GetProperty(field.Name());
                if (pi != null)
                {
                    object val = Convert.ChangeType(field.StringValue(), pi.PropertyType);
                    pi.SetValue(obj, val, null);
                }
            }

            return obj;
        }

        #region IService ��Ա

        public void Initialize()
        {
        }

        #endregion

        #region IPluginService ��Ա

        public void SetPlugin(IPlugin plugin)
        {
            this.plugin = (LuceneSearchPlugin)plugin;
        }

        #endregion
    }
}
