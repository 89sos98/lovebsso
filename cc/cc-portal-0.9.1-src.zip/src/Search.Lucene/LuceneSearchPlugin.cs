#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Lucene.Net.Analysis;
using System.Xml;
using CchenSoft.Portal.Spi.Plugin;

namespace CchenSoft.Portal.Search
{
    public class LuceneSearchPlugin : ServicePlugin, IServicePlugin
    {
        private IDictionary<string, SearchableEntry> searchables;

        public LuceneSearchPlugin()
        {
            searchables = new Dictionary<string, SearchableEntry>();
        }

        public SearchableEntry GetEntry(string moduleName)
        {
            if (searchables.ContainsKey(moduleName))
                return searchables[moduleName];
            return null;
        }

        public override void Configure(XmlDocument doc)
        {
            base.Configure(doc);

            XmlNodeList nodes = doc.DocumentElement.SelectNodes("searchable");

            foreach (XmlNode node in nodes)
            {
                SearchableEntry entry = new SearchableEntry();
                entry.ModuleName = node.Attributes.GetNamedItem("module").Value;
                entry.IndexFolder = node.SelectSingleNode("index-folder").InnerText;
                if (entry.IndexFolder.StartsWith("~/"))
                    entry.IndexFolder = Folder + entry.IndexFolder.Substring(2).Replace("/", "\\");
                entry.SearchFields = node.SelectSingleNode("search-fields").InnerText;
                searchables.Add(entry.ModuleName, entry);                
            }
        }
    }
}
