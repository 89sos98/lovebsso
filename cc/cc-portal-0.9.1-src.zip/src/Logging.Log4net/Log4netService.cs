#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Spi.Plugin;
using log4net.Config;
using System.IO;
using log4net;

namespace CchenSoft.Portal.Logging
{
    public class Log4netService : ILogService
    {
        private string configFile;
        private IServicePlugin plugin;

        public string ConfigFile
        {
            get { return configFile; }
            set { configFile = value; }
        }

        #region IPluginService ��Ա

        public void SetPlugin(IPlugin plugin)
        {
            this.plugin = (IServicePlugin)plugin;
        }

        #endregion

        #region IService ��Ա

        public void Initialize()
        {
            FileInfo f = new FileInfo(plugin.Folder + configFile);
            XmlConfigurator.ConfigureAndWatch(f);
        }

        #endregion

        #region ILogService ��Ա

        public void Info(string message, Type type)
        {
            ILog log = LogManager.GetLogger(type);
            log.Info(message);
        }

        public void Warn(string message, Type type)
        {
            ILog log = LogManager.GetLogger(type);
            log.Warn(message);
        }

        public void Debug(string message, Type type)
        {
            ILog log = LogManager.GetLogger(type);
            log.Debug(message);
        }

        public void Error(string message, Type type)
        {
            ILog log = LogManager.GetLogger(type);
            log.Error(message);
        }

        #endregion
    }
}
