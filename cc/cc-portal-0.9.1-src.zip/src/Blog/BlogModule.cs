#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using CchenSoft.Portal.Spi;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Service;

namespace CchenSoft.Portal.Blog
{
    public class BlogModule : GeneralModule, IModule
    {
        private User user;

        public override void HandleDomain(string domainName, HttpContext context)
        {
            //string newPath = "/blog" + context.Request.Path;
            //context.RewritePath(newPath, null, context.Request.QueryString.ToString());
            context.Response.Redirect("http://www.cchensoft.com/blog/");
        }

        public override void BeginRequest(HttpContext context)
        {
            string reqPath = context.Request.Path;

            string blogPath = reqPath.Substring(Path.Length);
            string blogName = "";
            
            int pos = blogPath.IndexOf("/");
            if (pos > -1)
            {
                blogName = blogPath.Substring(0, pos);
                user = ServiceLocator.UserService.GetUserByName(blogName);
            }

            if (user == null)
                user = ServiceLocator.UserService.GetUserByName("admin");
        }

        public User User
        {
            get { return user; }
        }
    }
}
