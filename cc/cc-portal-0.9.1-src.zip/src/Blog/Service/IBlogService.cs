#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using CchenSoft.Portal.Blog.Model;
using CchenSoft.Portal.Blog.Dao;
using System.Collections.Generic;
using CchenSoft.Portal.Spi;

namespace CchenSoft.Portal.Blog.Service
{
	/// <summary>
	/// IBlogService ��ժҪ˵����
	/// </summary>
	public interface IBlogService : IService
	{
		IBlogDao BlogDao { set; }

		IList GetNewBlogArticles(int userId,int Num);

		IList GetCategory(int UserID,int pageNo,int pageSize,ref int count);
	
		IList GetCategory(int UserID);

		IList GetFriend(int UserID,int Num);

		IList GetMyintro(int UserID);

		IList<Post> GetHotReadPosts(int UserID,int Num);

		IList GetNewComments(int userid,int num);

		IList GetPostComments(int articleid);

		IList<Post> GetPosts(int UserId,int pageNo,int pageSize,ref int count,int typeid);

        int SavePostComment(PostComment comment);

        Post LoadPost(int id);

        string GetPostContent(int postId);

		int Categorydelete(int id);
		
		int CategoryUpdate(int id, string name);

		IList<PostComment> GetCommentsByUser(int to_userId,int pageNo,int pageSize,ref int count);

		void deleteArticleComment(int id);

		void SavePost(Post post);
		
		void InsertCategory(PostCategory category);

        void updateuserarticlecount(int userid);

		void UpdatePost(Post post);

		int GetUserArticleCommentcount(int userid);

		
		int GetCommentcountbyArticleId(int article);

        void UpdatePostHits(int postId);

		PostCategory Getcategoryby_typeid(int typeid);

		IList GetBlogArticlesbytime(int userid,string time);

		
		IList GetTjBlogArticles(int num);
		
		IList<Post> GetPostsByUser(int UserId,int pageNo,int pageSize,ref int count);

		IList GetAllArticleForPage(int pageNo,int pageSize,ref int count);

		void UpdateArticleTj(int id);

		void UpdateArticleNoTj(int id);

		IList GetAllCommentForPage(int pageNo,int pageSize,ref int count);

		void UpdateArticlesCate(int typeid);


        void DeletePost(int postId);

        void UpdatePostData(int postId, string content);

        string GetPostData(int postId);

        void UpdateSubscriber(Subscriber sub);

        Subscriber GetSubscriberByCode(int subId, string code);

        void DeleteSubscriber(Subscriber sub);

        void SaveSubscriber(Subscriber sub);

        Subscriber GetSubscriberByEmail(string email);
    }
}
