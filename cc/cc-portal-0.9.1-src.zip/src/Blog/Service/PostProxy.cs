#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Blog.Model;
using CchenSoft.Portal.Spi.Attribute;

namespace CchenSoft.Portal.Blog.Service
{
    public class PostProxy : Post
    {
        private Post post;
        private IBlogService service;

        public PostProxy(Post post, IBlogService service)
        {
            this.post = post;
            this.service = service;
        }

        public Post Target
        {
            get { return this.post; }
        }

        [IndexField]
        public override int PostID
        {
            get { return post.PostID; }
        }

        [IndexField]
        public override string Title
        {
            get { return post.Title; }
        }

        [IndexField]
        public override string Summary
        {
            get { return post.Summary; }
        }

        [IndexField]
        public override string Content
        {
            get { return service.GetPostData(post.PostID); }
        }

        [IndexField]
        public override DateTime CreateDate
        {
            get { return post.CreateDate; }
        }

        [IndexField]
        public override int UserID
        {
            get { return post.UserID; }
        }

        [IndexField]
        public override string Name
        {
            get { return post.Name; }
        }

        [IndexField]
        public override int CategoryId
        {
            get { return post.CategoryId; }
        }

        [IndexField]
        public override int Hits
        {
            get { return post.Hits; }
        }

        [IndexField]
        public override int Comments
        {
            get { return post.Comments; }
        }

        [IndexField]
        public override char IsHot
        {
            get { return post.IsHot; }
        }

        [IndexField]
        public override string Tags
        {
            get { return post.Tags; }
        }

        public override string Filename
        {
            get { return post.Filename; }
        }
    }
}
