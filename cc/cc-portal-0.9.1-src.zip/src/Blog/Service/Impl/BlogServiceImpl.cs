#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.Xml;
using System.Web;
using CchenSoft.Portal.Blog.Model;
using CchenSoft.Portal.Blog.Dao;
using System.Collections.Generic;
using CchenSoft.Portal.Spi.Attribute;

namespace CchenSoft.Portal.Blog.Service.Impl
{
	/// <summary>
	/// BlogServiceImpl ��ժҪ˵����
	/// </summary>
	public class BlogServiceImpl : IBlogService
	{
		private IBlogDao blogDao;
        private const string moduleName = "blog";

		public BlogServiceImpl()
		{

		}

		public IBlogDao BlogDao
		{
			set { this.blogDao = value; }
		}

		public IList GetNewBlogArticles(int userId,int Num)
		{
			return  blogDao.GetNewBlogArticles(userId,Num);

		}

		public  IList GetCategory(int UserID,int pageNo,int pageSize,ref int count)
		{
			return this.blogDao.GetCategory(UserID,pageNo,pageSize,ref count);
		}

        [Cacheable(moduleName)]
		public  IList GetCategory(int UserID)
		{
			return this.blogDao.GetCategory(UserID);
		}
		
		public  IList GetFriend(int UserID,int Num)
		{
			return this.blogDao.GetFriend(UserID,Num);
		}

		public  IList GetMyintro(int UserID)
		{
			return this.blogDao.GetMyintro(UserID);
		}

        [Cacheable(moduleName)]
		public  IList<Post> GetHotReadPosts(int UserID ,int Num)
		{
			return this.blogDao.GetHotReadPosts(UserID,Num);
		}

        [Cacheable(moduleName)]
		public IList GetNewComments(int userid,int num)
		{
			return this.blogDao.GetNewComments(userid,num);
		}

        [Transaction(TransactionOption.Required)]
		public IList GetPostComments(int articleid)
		{
			return this.blogDao.GetPostComments(articleid);
		}

        [Cacheable(moduleName)]
		public IList<Post> GetPosts(int UserId,int pageNo,int pageSize,ref int count,int typeid)
		{
			return WrapperPost(this.blogDao.GetPosts(UserId,pageNo,pageSize,ref count,typeid));
		}

		public int SavePostComment(PostComment ArticleComment)
		{
			return this.blogDao.SavePostComment(ArticleComment);
		}

        [Cacheable(moduleName)]
		public Post LoadPost(int id)
		{
			Post result = blogDao.LoadPost(id);
            return (result != null) ? new PostProxy(result, this) : null;
		}

        public string GetPostContent(int postId)
        {
            return "";
            //return this.blogDao.GetPostContent(postId);
        }

        public IList Gettzlist(int userId,int pageNo,int pageSize,ref int count)
		{
			return this.blogDao.Gettzlist(userId,pageNo,pageSize,ref count);
		}
		public int Categorydelete(int id)
		{
			return this.blogDao.Categorydelete(id);
		}

        [Transaction(TransactionOption.Required)]
		public void DeletePost(int postId)
		{
            this.blogDao.DeletePost(postId);
		}

		public int CategoryUpdate(int id, string name)
		{
			return this.blogDao.CategoryUpdate(id, name);
		}
		public IList<PostComment> GetCommentsByUser(int to_userId,int pageNo,int pageSize,ref int count)
		{
			return this.blogDao.GetCommentsByUser(to_userId,pageNo,pageSize,ref count);
		}
		public void deleteArticleComment(int id)
		{
			this.blogDao.deleteArticleComment(id);
		}

        [Transaction(TransactionOption.RequiresNew)]
		public void SavePost(Post post)
		{
			blogDao.SavePost(post);
		}

		
		public void InsertCategory(PostCategory category)
		{
			this.blogDao.InsertCategory(category);
		}
		
		public void updateuserarticlecount(int userid)
		{
			this.blogDao.updateuserarticlecount(userid);
		}

        [Transaction(TransactionOption.RequiresNew)]
		public void UpdatePost(Post blogarticles)
		{
			this.blogDao.UpdatePost(blogarticles);
		}

		public int GetUserArticleCommentcount(int userid)
		{
			return this.blogDao.GetUserArticleCommentcount(userid);
		}
		
		public int GetCommentcountbyArticleId(int article)
		{
			return this.blogDao.GetCommentcountbyArticleId(article);
		}
        public void UpdatePostHits(int postId)
		{
            this.blogDao.UpdatePostHits(postId);
		}
		public PostCategory Getcategoryby_typeid(int typeid)
		{
			return this.blogDao.Getcategoryby_typeid(typeid);
		}

		public IList GetBlogArticlesbytime(int userid,string time)
		{
			return this.blogDao.GetBlogArticlesbytime(userid,time);
		}

		public IList GetUsertopnum(int num)
		{
			return this.blogDao.GetUsertopnum(num);
		}
		public IList GetTjBlogArticles(int num)
		{
			return this.blogDao.GetTjBlogArticles(num);
		}

        [Cacheable(moduleName)]
		public IList<Post> GetPostsByUser(int UserId,int pageNo,int pageSize,ref int count)
		{
			return WrapperPost(this.blogDao.GetPostsByUser(UserId,pageNo,pageSize,ref count));
		}

		public IList GetAllArticleForPage(int pageNo,int pageSize,ref int count)
		{
			return this.blogDao.GetAllArticleForPage(pageNo,pageSize,ref count);
		}
		public void UpdateArticleTj(int id)
		{
			this.blogDao.UpdateArticleTj(id);
		}
		public void UpdateArticleNoTj(int id)
		{
			this.blogDao.UpdateArticleNoTj(id);
		}

		public IList GetAllCommentForPage(int pageNo,int pageSize,ref int count)
		{
			return this.blogDao.GetAllCommentForPage(pageNo,pageSize,ref count);
		}
		
		public void UpdateArticlesCate(int typeid)
		{
			this.blogDao.UpdateArticlesCate(typeid);
		}

        public void UpdateSubscriber(Subscriber sub)
        {
            blogDao.UpdateSubscriber(sub);
        }

        public Subscriber GetSubscriberByCode(int subId, string code)
        {
            return blogDao.GetSubscriberByCode(subId, code);
        }

        public void DeleteSubscriber(Subscriber sub)
        {
            blogDao.DeleteSubscriber(sub);
        }

        public void SaveSubscriber(Subscriber sub)
        {
            blogDao.SaveSubscriber(sub);
        }

        public Subscriber GetSubscriberByEmail(string email)
        {
            return blogDao.GetSubscriberByEmail(email);
        }

        #region IService ��Ա

        public void Initialize()
        {
        }

        #endregion

        #region helper methods.

        private IList<Post> WrapperPost(IList<Post> posts)
        {
            IList<Post> proxys = new List<Post>();
            if (posts != null)
            {
                foreach (Post post in posts)
                {
                    proxys.Add(new PostProxy(post, this));
                }
            }

            return proxys;
        }

         public void UpdatePostData(int postId, string content)
        {
            blogDao.UpdatePostData(postId, content);
        }

        public string GetPostData(int postId)
        {
            return blogDao.GetPostData(postId);
        }

        #endregion
    }
}
