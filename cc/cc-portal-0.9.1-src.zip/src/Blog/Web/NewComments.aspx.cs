#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Blog.Model;
using CchenSoft.Portal.Blog.Service;
using CchenSoft.Portal.Blog;

namespace Blog.Web
{
	/// <summary>
	///		NewArticle ��ժҪ˵����
	/// </summary>
    public partial class NewComments : ViewPage
    {
        private IBlogService service;
        private BlogModule module;

        private void Page_Load(object sender, EventArgs e)
        {
            module = (BlogModule)portletContext.Module;
            service = portletContext.GetService<IBlogService>();

            // �ڴ˴������û������Գ�ʼ��ҳ��
            if (!IsPostBack)
            {
                DataView();
            }
        }

        private void DataView()
        {
            rptComment.DataSource = service.GetNewComments(module.User.UserId, 5);
            rptComment.DataBind();
        }

        protected void rptComment_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                PostComment comment = (PostComment)e.Item.DataItem;
                ExHyperLink hlnkTitle = (ExHyperLink)e.Item.FindControl("hlnkTitle");

                Post post = service.LoadPost(comment.PostID);

                hlnkTitle.Text = comment.Content;
                hlnkTitle.TargetPortlet = "21";
                hlnkTitle.TargetQuery = "viewpost.aspx?pid=" + post.PostID;
            }
        }
    }
}