#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Blog.Service;
using CchenSoft.Portal.Blog.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Blog;
using CchenSoft.Portal.Cfg;
using CchenSoft.Portal.Registry;
using System.Collections.Generic;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal;

namespace Blog.Web
{
	/// <summary>
	///		ArticleList ��ժҪ˵����
	/// </summary>
    public partial class PostList : ViewPage
    {
        private int pageSize;
        private int typeid;
        private IBlogService service;
        private BlogModule module;

        private void Page_Load(object sender, EventArgs e)
        {
            module = (BlogModule)portletContext.Module;
            service = portletContext.GetService<IBlogService>();
            pageSize = preferences.GetInt32("pageNum");
            if (pageSize == 0)
                pageSize = 20;

            // �ڴ˴������û������Գ�ʼ��ҳ��
            if (!IsPostBack)
            {
                LoadData();
            }
        }

        private void LoadData()
        {
            string keyword = ParamUtil.GetString(Request, "keyword");
            if (string.IsNullOrEmpty(keyword))
            {
                typeid = ParamUtil.GetInt32(Request, "category");
                int count = 0;
                int pageIndex = ParamUtil.GetInt32(Request, "page");
                if (pageIndex < 1)
                    pageIndex = 1;

                IList<Post> list = null;
                if (typeid > 0)
                {
                    list = service.GetPosts(module.User.UserId, pageIndex, pageSize, ref count, typeid);
                }
                else
                {
                    list = service.GetPostsByUser(module.User.UserId, pageIndex, pageSize, ref count);
                }
                rptPost.DataSource = list;
                rptPost.DataBind();

                pager.CurrentPage = pageIndex;
                pager.PageCount = (count + pageSize - 1) / pageSize;

                portalURL.AppendParam("_" + instanceId + "_page", "{0}");
                pager.BaseUrl = portalURL.ToURLString();
            }
            else
            {
                IList<Post> posts = PluginLocator.GetPluginService<ISearchService>("search").Search<Post>(keyword, module);
                rptPost.DataSource = posts;
                rptPost.DataBind();
            }
        }

        protected void rptPost_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Post post = (Post)e.Item.DataItem;

                string viewUrl = string.Format("viewpost.aspx?pid={0}", post.PostID);
                HyperLink hlnkTitle = (HyperLink)e.Item.FindControl("hlnkTitle");
                hlnkTitle.Text = post.Title;
                hlnkTitle.NavigateUrl = viewUrl;

                Label lblContent = (Label)e.Item.FindControl("lblContent");
                lblContent.Text = post.Summary;

                HyperLink hlnkView = (HyperLink)e.Item.FindControl("hlnkView");
                hlnkView.NavigateUrl = viewUrl;

                HyperLink hlnkViewByDate = (HyperLink)e.Item.FindControl("hlnkViewByDate");
                hlnkViewByDate.Text = post.CreateDate.ToString("yyyy-MM-dd HH:mm");

                Label lblHits = (Label)e.Item.FindControl("lblHits");
                lblHits.Text = post.Hits.ToString();

                HyperLink hlnkComment = (HyperLink)e.Item.FindControl("hlnkComment");
                hlnkComment.Text = string.Format("����({0})", post.Comments);
            }
        }

        private void pagelist_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                string[] strs = (string[])e.Item.DataItem;
                HyperLink pages = (HyperLink)e.Item.FindControl("pages");
                pages.Text = strs[0];
                pages.NavigateUrl = strs[1];
            }
        }
    }
}