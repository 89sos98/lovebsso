#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Blog.Model;
using CchenSoft.Portal.Blog.Service;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal.Spi.Plugin;
using System.Web;

namespace Blog.Web
{
	/// <summary>
	///		news_infochannel_chnl ��ժҪ˵����
	/// </summary>
    public partial class PostList_Config : ActionPage
	{
		private void Page_Load(object sender, EventArgs e)
		{
            if (!IsPostBack)
            {
                txtPageNum.Text = preferences.GetInt32("pageNum").ToString();
                chkNotice.Checked = preferences.GetBoolean("notice");
                txtEmail.Text = preferences.GetString("email");
                txtExclusion.Text = preferences.GetString("exclusion");
            }
		}

        protected void btnOK_Click(object sender, EventArgs e)
        {
            preferences.SetValue("pageNum", txtPageNum.Text);
            preferences.SetValue("notice", chkNotice.Checked);
            preferences.SetValue("email", txtEmail.Text);
            preferences.SetValue("exclusion", txtExclusion.Text);
            UpdatePreferences(preferences);
            SendPortalRedirect();
        }
	}
}