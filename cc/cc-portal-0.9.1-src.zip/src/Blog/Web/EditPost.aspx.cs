#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.Web;
using System.Web.UI.WebControls;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Blog.Service;
using CchenSoft.Portal.Blog.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Util;

namespace Blog.Web
{
	/// <summary>
	/// ChannelType ��ժҪ˵����
	/// </summary>
    public partial class EditPost : ActionPage
	{
		protected int UserID;
        private int postId;
        private IBlogService service;

        private void Page_Load(object sender, EventArgs e)
        {
            service = portletContext.GetService<IBlogService>();
            UserID = portletContext.User.UserId;
            postId = ParamUtil.GetInt32(Request, "id");

            if (!Page.IsPostBack)
            {
                category.Items.Add(new ListItem("none", "0"));
                IList list = service.GetCategory(portletContext.User.UserId);
                foreach (PostCategory c in list)
                {
                    category.Items.Add(new ListItem(c.Name, c.CategoryID.ToString()));
                }

                if (postId > 0)
                {
                    Post post = service.LoadPost(postId);
                    title.Text = post.Title;
                    summary.Text = post.Summary;
                    lable.Text = post.Tags;
                    category.Value = post.CategoryId.ToString();
                    editor.Content = post.Content;
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
		{
			if (Check())
			{
				if (postId > 0)
				{
					Post post = service.LoadPost(postId);
                    if (post is PostProxy)
                        post = ((PostProxy)post).Target;

					post.Title = title.Text;
                    post.Summary = summary.Text;
    				post.Tags = lable.Text;
					post.Content = editor.Content;
                    post.CategoryId = ConvertUtil.ToInt32(category.Value);
    				service.UpdatePost(post);

                    SendPortalRedirect();
				}
			}

		}

		private bool Check()
		{
			bool key = true;
			if (title.Text == "")
			{
				Response.Write("<script>alert('ʧ�ܣ�����д���±��⣡');window.history.go(-1);</script>");
				key = false;
			}
			else if (editor.Content == "")
			{
				Response.Write("<script>alert('ʧ�ܣ�����д�������ݣ�');window.history.go(-1);</script>");
				key = false;
			}
			return key;
		}

	}
}