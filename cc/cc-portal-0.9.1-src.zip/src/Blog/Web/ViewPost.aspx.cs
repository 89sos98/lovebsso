#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Blog.Model;
using CchenSoft.Portal.Blog.Service;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal.Spi.Plugin;
using System.Web;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Spi.Registry;

namespace Blog.Web
{
	/// <summary>
	///		news_infochannel_chnl ��ժҪ˵����
	/// </summary>
    public partial class ViewPost : ActionPage
	{
		protected int postId;
        private IBlogService service;

		private void Page_Load(object sender, EventArgs e)
		{
            postId = ParamUtil.GetInt32(Request, "pid");

            service = portletContext.GetService<IBlogService>();
			if (!Page.IsPostBack)
			{                
                if (postId > 0)
				{
					LoadData();
				}
			}
		}

        private void LoadData()
		{
            IFormatPlugin plugin = (IFormatPlugin)PluginRegistry.Instance.GetPluginByCategory("codehighlight");

            Post post = service.LoadPost(postId);
            if (post != null)
            {
                hlnkTitle.Text = post.Title;
                lblPostDate.Text = post.CreateDate.ToString("yyyy-MM-dd HH:mm");
                lblHit.Text = post.Hits.ToString();
                lblComments.Text = post.Comments.ToString();
                hlnkCategory.Text = "";
                lblContent.Text = post.Content; // plugin.Format(post.Content.Replace("&nbsp;", " ").Replace("&quot;", "\"").Replace("<p>", "").Replace("</p>", "").Replace("<br />", "")).Replace(Environment.NewLine, "<br/>");

                rptComment.DataSource = service.GetPostComments(postId);
                rptComment.DataBind();

                service.UpdatePostHits(postId);
            }
		}

        protected void rptComment_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                PostComment comment = (PostComment)e.Item.DataItem;

                ((Label)e.Item.FindControl("lblCommentDate")).Text = comment.CreateDate.ToString("yyyy-MM-dd HH:mm");
                ((HyperLink)e.Item.FindControl("hlnkAuthor")).Text = comment.UserName;
                ((Label)e.Item.FindControl("lblContent")).Text = comment.Content;
            }
        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            PostComment comment = new PostComment();
            comment.Content = txtComment.Text;
            comment.UserName = txtName.Text;
            comment.PostID = postId;
            service.SavePostComment(comment);

            SendNoticeEmail(comment);

            SendPortalRedirect(false);
        }

        private void SendNoticeEmail(PostComment comment)
        {
            // send email.
            if (preferences.GetBoolean("notice"))
            {
                string exclusion = preferences.GetString("exclusion");
                if (exclusion.IndexOf(comment.UserName) == -1)
                {
                    string email = preferences.GetString("email");

                    IEmailService mailService = PluginLocator.GetPluginService<IEmailService>("email");
                    mailService.SendEmail(email, "comment", comment.Content);
                }
            }
        }
	}
}