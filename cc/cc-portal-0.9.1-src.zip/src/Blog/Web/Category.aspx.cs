#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Drawing;
using System.Web.UI.WebControls;
using System.Web.UI;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Blog.Service;
using CchenSoft.Portal.Blog.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Blog;

namespace Blog.Web
{
	/// <summary>
	///		Category ��ժҪ˵����
	/// </summary>
    public partial class Category : ViewPage
    {
        private IBlogService service;
        private int category;
        private BlogModule module;
        private string consumeInstance;

        private void Page_Load(object sender, EventArgs e)
        {
            service = portletContext.GetService<IBlogService>();
            module = (BlogModule)portletContext.Module;
            
            category = ParamUtil.GetInt32(Request, "category");

            consumeInstance = preferences.GetString("consume-instance");

            hlnkCate.NavigateUrl = "?category=0";
            hlnkCate.TargetPortlet = consumeInstance;
            hlnkCate.TargetQuery = "category=0";

            rptCategory.DataSource = service.GetCategory(module.User.UserId); //zone.Config.Shangs;
            rptCategory.DataBind();
        }

        protected void rptCategory_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                PostCategory cate = (PostCategory)e.Item.DataItem;

                ExHyperLink hlnkCat = (ExHyperLink)e.Item.FindControl("hlnkCat");
                hlnkCat.Text = cate.Name;

                if (category == cate.CategoryID)
                {
                    hlnkCat.Attributes["style"] = "color:#ff0000;font-weight:bold;";
                }
                else
                {
                    hlnkCat.NavigateUrl = "?category=" + cate.CategoryID;
                    hlnkCat.TargetPortlet = consumeInstance;
                    hlnkCat.TargetQuery = "category=" + cate.CategoryID;
                }
            }
        }
    }
}