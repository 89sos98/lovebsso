#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.Web;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Blog.Model;
using CchenSoft.Portal.Blog.Service;
using CchenSoft.Portal.Service;
using System.Collections.Generic;
using CchenSoft.Portal.Util;

namespace Blog.Web
{
	/// <summary>
	/// ChannelType ��ժҪ˵����
	/// </summary>
    public partial class AdminComments : ViewPage
	{
		protected int userId;
		protected int PageSize = 15;

        private IBlogService service;

        private void Page_Load(object sender, EventArgs e)
        {
            service = portletContext.GetService<IBlogService>();

            if (!Page.IsPostBack)
            {
                ProcessAction();

                userId = ServiceLocator.UserService.LoggedUser.UserId;

                tzlistBind();
            }
        }

        private void ProcessAction()
        {
            int del = ParamUtil.GetInt32(Request, "del");
            if (del > 0)
            {
                service.deleteArticleComment(del);
            }
        }

		void tzlistBind()
		{
			int count = 0;
			int pageIndex = Convert.ToInt32(Request["page"]);
			
			if (pageIndex < 1)
				pageIndex = 1;
			showpage.Text = pageIndex.ToString();
			IList<PostComment> list = service.GetCommentsByUser(userId, pageIndex, PageSize, ref count);
			this.tzlist.DataSource = list;
			this.tzlist.DataBind();
			int pageCount = (count + PageSize - 1)/PageSize;
			counts.Text = pageCount.ToString();
			int start = pageIndex - 5;
			if (start < 0)
				start = 0;
			int end = start + 10;
			if (end > pageCount)
				end = pageCount;
			ArrayList list1 = new ArrayList();
			for (int i = start + 1; i <= end; i++)
			{
				string url = string.Format("adminComments.aspx?page={0}", i);
				this.nextpage.NavigateUrl = url;
				list1.Add(new string[] {i.ToString(), url});
			}
			this.pagelist.DataSource = list1;
			this.pagelist.DataBind();
		}

		#region Web ������������ɵĴ���

		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �õ����� ASP.NET Web ���������������ġ�
			//
			InitializeComponent();
			base.OnInit(e);
		}

		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{
			this.tzlist.ItemDataBound += new RepeaterItemEventHandler(this.tzlist_ItemDataBound);
			this.tzlist.ItemCommand += new RepeaterCommandEventHandler(this.tzlist_ItemCommand);
			this.pagelist.ItemDataBound += new RepeaterItemEventHandler(this.pagelist_ItemDataBound);
			this.Load += new EventHandler(this.Page_Load);

		}

		#endregion

		private void tzlist_ItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
                PostComment comment = (PostComment)e.Item.DataItem;
                
                Label time = (Label)e.Item.FindControl("lblDate");
                time.Text = comment.CreateDate.ToString();
                
                Label name = (Label)e.Item.FindControl("lblName");
                name.Text = comment.UserName.ToString();

                Label content = (Label)e.Item.FindControl("lblContent");
                content.Text = comment.Content;

                HyperLink del = (HyperLink)e.Item.FindControl("hlnkDelete");                
                del.Attributes.Add("onclick", "return confirm('ȷ��Ҫɾ����������');");
                del.NavigateUrl = "?del=" + comment.CommentID;
			}
		}


		private void tzlist_ItemCommand(object source, RepeaterCommandEventArgs e)
		{
			if (e.CommandName.ToLower().Equals("delete"))
			{
				//service.Deltz(Convert.ToInt32(e.CommandArgument));
				Response.Write("<script>alert('ɾ�����³ɹ���');window.history.go(-1);</script>");
				Response.Write("<script>window.location='rizhigunli.aspx';</script>");
			}
			else if (e.CommandName.ToLower().Equals("edit"))
			{
				Response.Redirect(string.Format("zxrj.aspx?id={0}", Convert.ToInt32(e.CommandArgument)));

			}
		}

		private void pagelist_ItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
				string[] strs = (string[]) e.Item.DataItem;
				HyperLink pages = (HyperLink) e.Item.FindControl("pages");
				pages.Text = strs[0];
				pages.NavigateUrl = strs[1];
			}
		}
	}
}