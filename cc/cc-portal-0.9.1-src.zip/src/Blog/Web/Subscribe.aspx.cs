#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Web.UI.WebControls;
using System.Web.UI;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Blog.Service;
using CchenSoft.Portal.Blog.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Util;
using System.Drawing;
using CchenSoft.Portal.Blog;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal;
using System.Collections.Generic;
using CchenSoft.Portal.Cfg;
using CchenSoft.Portal.Spi.Service;

namespace Blog.Web
{
	/// <summary>
	///		Category ��ժҪ˵����
	/// </summary>
    public partial class Subscribe : ActionPage
    {
        private IBlogService blogService;
        private IEmailService emailService;

        private void Page_Load(object sender, EventArgs e)
        {
            blogService = portletContext.GetService<IBlogService>();
            emailService = PluginLocator.GetPluginService<IEmailService>("email");
        }

        public void btnSubscribe_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;

            Subscriber sub = blogService.GetSubscriberByEmail(email);
            if (sub == null)
            {
                sub = new Subscriber();
                sub.UserId = ((BlogModule)portletContext.Module).User.UserId;
                sub.Email = email;
                sub.ValidateCode = "abcdef";
                blogService.SaveSubscriber(sub);
            }

            if (sub.Enabled == false)
            {
                portalURL.AppendParam("_" + instanceId + "_action", "subscribevalidate.aspx");
                portalURL.AppendParam("_" + instanceId + "_subId", sub.SubId.ToString());
                portalURL.AppendParam("_" + instanceId + "_code", sub.ValidateCode);
                portalURL.AppendParam("_" + instanceId + "_mode", "1");
                string url = portalURL.ToURLString();

                // send email.
                string subject = "blog subscribe";
                string body = string.Format("<a href='http://{0}{1}' target='_blank'>{2}</a>", GetHostName(), url, url);
                emailService.SendEmail(email, subject, body);

                SendPortalRedirect("SubscribeMsg.aspx", "type=1&mode=1");
            }

            SendPortalRedirect();
        }

        public void btnUnSubscribe_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            Subscriber sub = blogService.GetSubscriberByEmail(email);
            if (sub != null)
            {
                portalURL.AppendParam("_" + instanceId + "_action", "subscribevalidate.aspx");
                portalURL.AppendParam("_" + instanceId + "_subId", sub.SubId.ToString());
                portalURL.AppendParam("_" + instanceId + "_code", sub.ValidateCode);
                portalURL.AppendParam("_" + instanceId + "_mode", "2");

                string url = portalURL.ToURLString();

                // send email.
                string subject = "blog subscribe";
                string body = string.Format("<a href='http://{0}{1}' target='_blank'>{2}</a>", GetHostName(), url, url);
                emailService.SendEmail(email, subject, body);

                SendPortalRedirect("SubscribeMsg.aspx", "type=1&mode=2");
            }

            SendPortalRedirect();
        }

        private string GetHostName()
        {
            string hostName;

            if (Page.Request.Url.Port == 80)
                hostName = Page.Request.Url.Host;
            else
                hostName = Page.Request.Url.Host + ":" + Page.Request.Url.Port;

            return hostName;
        }
    }
}