#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Web.UI.WebControls;
using System.Web.UI;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Blog.Service;
using CchenSoft.Portal.Blog.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Util;
using System.Drawing;
using CchenSoft.Portal.Blog;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal;
using System.Collections.Generic;
using CchenSoft.Portal.Cfg;
using CchenSoft.Portal.Spi.Service;

namespace Blog.Web
{
	/// <summary>
	///		Category ��ժҪ˵����
	/// </summary>
    public partial class Search : ActionPage
    {
        private void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                txtKeyword.Text = ParamUtil.GetString(Request, "keyword");
            }
        }

        public void btnSearch_Click(object sender, EventArgs e)
        {
            string word = txtKeyword.Text;
            string url = BuildPortalUrl("?keyword=" + word, "post_list", "keyword=" + word);
            Response.Redirect(url);
        }

        public void btnIndex_Click(object sender, EventArgs e)
        {
            BlogModule module = (BlogModule)portletContext.Module;
            IBlogService blogService = portletContext.GetService<IBlogService>();

            int count = 0;
            IList<Post> posts = blogService.GetPostsByUser(module.User.UserId, 1, 100, ref count);

            PluginLocator.GetPluginService<ISearchService>("search").Index<Post>(posts, module);
            SendPortalRedirect();
        }
    }
}