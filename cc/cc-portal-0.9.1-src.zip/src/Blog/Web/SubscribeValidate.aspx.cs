#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Web.UI.WebControls;
using System.Web.UI;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Blog.Service;
using CchenSoft.Portal.Blog.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Util;
using System.Drawing;
using CchenSoft.Portal.Blog;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal;
using System.Collections.Generic;
using CchenSoft.Portal.Cfg;
using CchenSoft.Portal.Spi.Service;

namespace Blog.Web
{
	/// <summary>
	///		Category ��ժҪ˵����
	/// </summary>
    public partial class SubscribeValidate : ActionPage
    {
        private void Page_Load(object sender, EventArgs e)
        {
            IBlogService service = portletContext.GetService<IBlogService>();

            int subId = ParamUtil.GetInt32(Request, "subId");
            string code = ParamUtil.GetString(Request, "code");
            int mode = ParamUtil.GetInt32(Request, "mode");
                        
            Subscriber sub = service.GetSubscriberByCode(subId, code);
            if (sub != null)
            {
                if (mode == 1)
                {
                    sub.Enabled = true;
                    service.UpdateSubscriber(sub);

                    SendPortalRedirect("SubscribeMsg.aspx", "type=2&mode=1");
                }
                else if (mode == 2)
                {
                    service.DeleteSubscriber(sub);
                    SendPortalRedirect("SubscribeMsg.aspx", "type=2&mode=2");
                }
            }
            
            SendPortalRedirect("SubscribeMsg.aspx", "type=3");
        }
    }
}