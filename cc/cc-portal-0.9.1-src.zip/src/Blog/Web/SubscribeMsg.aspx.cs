#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Web.UI.WebControls;
using System.Web.UI;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Blog.Service;
using CchenSoft.Portal.Blog.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Util;
using System.Drawing;
using CchenSoft.Portal.Blog;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal;
using System.Collections.Generic;
using CchenSoft.Portal.Cfg;
using CchenSoft.Portal.Spi.Service;

namespace Blog.Web
{
	/// <summary>
	///		Category ��ժҪ˵����
	/// </summary>
    public partial class SubscribeMsg : ViewPage
    {
        private void Page_Load(object sender, EventArgs e)
        {
            int type = ParamUtil.GetInt32(Request, "type");
            int mode = ParamUtil.GetInt32(Request, "mode");

            switch (type)
            {
                case 1: // send email
                    if (mode == 1)
                    {
                        lblMsg.Text = "���ĵ�ȷ���ʼ��ѷ��͵��������䣬�����ʼ��е���ɶ��ġ�";
                    }
                    else if (mode == 2)
                    {
                        lblMsg.Text = "ȡ�����ĵ�ȷ���ʼ��ѷ��͵��������䣬�����ʼ��е����ȡ�����ġ�";
                    }
                    break;

                case 2: // validate code
                    if (mode == 1)
                    {
                        lblMsg.Text = "���ѳɹ����ġ�";
                    }
                    else if (mode == 2)
                    {
                        lblMsg.Text = "���ѳɹ�ȡ�����ġ�";
                    }
                    break;
                    
                case 3:
                    lblMsg.Text = "��Ч����֤����";
                    break;
            }
        }

    }
}