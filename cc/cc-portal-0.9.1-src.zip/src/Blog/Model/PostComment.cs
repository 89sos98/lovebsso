#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;

namespace CchenSoft.Portal.Blog.Model
{
    public enum CommentType
    {
        Comment,
        PingTrack,
    }


	/// <summary>
	/// BlogArticleComment ��ժҪ˵����
	/// </summary>
    public class PostComment
    {
        public PostComment()
        {
            type = CommentType.Comment;
            createDate = DateTime.Now;
        }

        #region Model
        private int commentId;
        private string title;
        private string content;
        private DateTime createDate;
        private int userId;
        private int postId;
        private CommentType type;
        private string userName;
        private string sourceUrl;

        /// <summary>
        /// ��������ID
        /// </summary>
        public int CommentID
        {
            set { commentId = value; }
            get { return commentId; }
        }

        public string Title
        {
            set { title = value; }
            get { return title; }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public string Content
        {
            set { content = value; }
            get { return content; }
        }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        public DateTime CreateDate
        {
            set { createDate = value; }
            get { return createDate; }
        }
        /// <summary>
        /// ����������UserID
        /// </summary>
        public int UserID
        {
            set { userId = value; }
            get { return userId; }
        }

        /// <summary>
        /// ����id
        /// </summary>
        public int PostID
        {
            set { postId = value; }
            get { return postId; }
        }

        public string UserName
        {
            set { userName = value; }
            get { return userName; }
        }

        public CommentType Type
        {
            set { type = value; }
            get { return type; }
        }

        public string SourceUrl
        {
            set { sourceUrl = value; }
            get { return sourceUrl; }
        }

        #endregion Model
    }
}
