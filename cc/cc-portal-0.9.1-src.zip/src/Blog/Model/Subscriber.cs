#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace CchenSoft.Portal.Blog.Model
{
    public class Subscriber
    {
        private int subId;
        private int userId;
        private string email;
        private DateTime subDate;
        private string validateCode;
        private bool enabled;

        public Subscriber()
        {
            subDate = DateTime.Now;
            enabled = false;
        }

        /// <summary>
        /// subscribe id.
        /// </summary>
        public int SubId
        {
            get { return subId; }
            set { subId = value; }
        }

        /// <summary>
        /// user id.
        /// </summary>
        public int UserId
        {
            get { return userId; }
            set { userId = value; }
        }

        /// <summary>
        /// email.
        /// </summary>
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        /// <summary>
        /// subscribe date.
        /// </summary>
        public DateTime SubDate
        {
            get { return subDate; }
            set { subDate = value; }
        }

        /// <summary>
        /// validate code.
        /// </summary>
        public string ValidateCode
        {
            get { return validateCode; }
            set { validateCode = value; }
        }

        /// <summary>
        /// enabled.
        /// </summary>
        public bool Enabled
        {
            get { return enabled; }
            set { enabled = value; }
        }
    }
}
