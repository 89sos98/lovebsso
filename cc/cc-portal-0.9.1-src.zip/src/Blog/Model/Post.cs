#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;

namespace CchenSoft.Portal.Blog.Model
{
	/// <summary>
	/// Post ��ժҪ˵����
	/// </summary>
    public class Post
    {
        public Post()
        {
            createDate = DateTime.Now;
        }

        #region Model
        private int postId;
        private string title;
        private string summary;
        private string content;
        private DateTime createDate;
        private int userId;
        private string name;
        private int categoryId;
        private int hits;
        private int comments;
        private char isHot;
        private string tags;
        private string filename;

        /// <summary>
        /// ����ID
        /// </summary>
        public virtual int PostID
        {
            set { postId = value; }
            get { return postId; }
        }
        /// <summary>
        /// ���±���
        /// </summary>
        public virtual string Title
        {
            set { title = value; }
            get { return title; }
        }

        /// <summary>
        /// ժҪ
        /// </summary>
        public virtual string Summary
        {
            get { return summary; }
            set { summary = value; }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public virtual string Content
        {
            set { content = value; }
            get { return content; }
        }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        public virtual DateTime CreateDate
        {
            set { createDate = value; }
            get { return createDate; }
        }
        /// <summary>
        /// UserID
        /// </summary>
        public virtual int UserID
        {
            set { userId = value; }
            get { return userId; }
        }
        /// <summary>
        /// ����������
        /// </summary>
        public virtual string Name
        {
            set { name = value; }
            get { return name; }
        }
        /// <summary>
        /// �������
        /// </summary>
        public virtual int CategoryId
        {
            set { categoryId = value; }
            get { return categoryId; }
        }
        /// <summary>
        /// ���µ����
        /// </summary>
        public virtual int Hits
        {
            set { hits = value; }
            get { return hits; }
        }
        /// <summary>
        /// ����������
        /// </summary>
        public virtual int Comments
        {
            set { comments = value; }
            get { return comments; }
        }
        /// <summary>
        /// �Ƿ����������£�0������1����
        /// </summary>
        public virtual char IsHot
        {
            set { isHot = value; }
            get { return isHot; }
        }
        /// <summary>
        ///��ǩ
        /// </summary>
        public virtual string Tags
        {
            set { tags = value; }
            get { return tags; }
        }

        public virtual string Filename
        {
            set { filename = value; }
            get { return filename; }
        }

        #endregion Model
    }
}
