#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using CchenSoft.Portal.Blog.Model;
using System.Collections.Generic;
using System.Data;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Spi.Service;

namespace CchenSoft.Portal.Blog.Dao.Impl
{
	/// <summary>
	/// IBatisBlogDao ��ժҪ˵����
	/// </summary>
    public class BlogDaoImpl : IBlogDao
    {
        private IDataService service;

        public BlogDaoImpl()
        {
        }

        public IList GetCategory(int UserID, int pageNo, int pageSize, ref int count)
        {
            count = service.QueryForObject<int>("GetCategorycount", UserID);
            if (count > 0)
            {
                return service.QueryForList("GetCategorys", UserID, (pageNo - 1) * pageSize, pageSize);
            }
            return null;
        }

        public IList GetCategory(int UserID)
        {
            return service.QueryForList("GetCategorys", UserID);
        }

        public IList GetFriend(int UserId, int Num)
        {
            Hashtable dt = new Hashtable();
            dt["userid"] = UserId;
            dt["num"] = Num;
            return service.QueryForList("GetFriend", dt);
        }

        public IList GetMyintro(int UserID)
        {

            return service.QueryForList("GetMyintros", UserID);
        }

        public IList<Post> GetHotReadPosts(int UserID, int Num)
        {
            return service.QueryForList<Post>("GetHotReadPosts", UserID, 0, Num);
        }

        public IList<Post> GetHotCommentPosts(int UserID, int Num)
        {
            return service.QueryForList<Post>("GetHotCommentPosts", UserID, 0, Num);
        }

        public IList GetNewBlogArticles(int userId, int Num)
        {
            Hashtable ht = new Hashtable();
            ht["userid"] = userId;
            ht["num"] = Num;
            return service.QueryForList("GetNewBlogArticles", ht);
        }


        public IList GetNewComments(int userid, int num)
        {
            return service.QueryForList("GetNewComment", userid, 0, num);
        }

        public IList GetPostComments(int articleid)
        {
            return service.QueryForList("GetPostComments", articleid);
        }

        public IList<PostComment> GetCommentsByUser(int to_userId, int pageNo, int pageSize, ref int count)
        {
            count = (int)service.QueryForObject("GetUserArticleCommentcount", to_userId);
            if (count > 0)
            {
                return service.QueryForList<PostComment>("GetUserArticleComment", to_userId, (pageNo - 1) * pageSize, pageSize);
            }
            return null;
        }

        public IList<Post> GetPosts(int UserId, int pageNo, int pageSize, ref int count, int typeid)
        {
            Hashtable dict = new Hashtable();
            dict["userid"] = UserId;
            dict["typeid"] = typeid;
            count = (int)service.QueryForObject("GetPostCount", dict);
            if (count > 0)
            {
                return service.QueryForList<Post>("GetPosts", dict, (pageNo - 1) * pageSize, pageSize);
            }

            return null;
        }

        public int SavePostComment(PostComment comment)
        {
            service.Insert("addArticleComment", comment);
            service.Update("UpdatePostComments", comment.PostID);
            return 0;
        }

        public Post LoadPost(int id)
        {
            return service.QueryForObject<Post>("GetPostById", id);
        }

        public IList Gettzlist(int userId, int pageNo,int pageSize,ref int count)
        {
            count = (int)service.QueryForObject("Gettzlistcount", userId);
            if (count > 0)
            {
                return service.QueryForList("Gettzlist", userId, (pageNo - 1) * pageSize, pageSize);
            }
            return null;
        }

        public int Categorydelete(int id)
        {
            return service.Delete("Categorydelete", id);
        }

        public void DeletePost(int postId)
        {
            service.Delete("DeletePost", postId);
            service.Delete("DeletePostData", postId);
        }

        public int CategoryUpdate(int id, string name)
        {
            Hashtable dict = new Hashtable();
            dict["id"] = id;
            dict["name"] = name;

            return service.Update("CategoryUpdate", dict);
        }

        public void deleteArticleComment(int id)
        {
            service.Delete("deleteArticleComment", id);
        }

        public void SavePost(Post post)
        {
            service.Insert("InsertPost", post);

            Hashtable dict = new Hashtable();
            dict["postId"] = post.PostID;
            dict["content"] = post.Content;
            service.Insert("InsertPostData", dict);
        }

        public void InsertCategory(PostCategory category)
        {
            service.Insert("InsertCategory", category);
        }

        public void updateuserarticlecount(int userid)
        {
            service.Update("updateuserarticlecount", userid);
        }

        public void UpdatePost(Post post)
        {
            service.Update("UpdatePost", post);

            Hashtable dict = new Hashtable();
            dict["postId"] = post.PostID;
            dict["content"] = post.Content;
            service.Update("UpdatePostData", dict);
        }

        public int GetUserArticleCommentcount(int userid)
        {
            int count = (int)service.QueryForObject("GetUserArticleCommentcount", userid);
            return count;
        }


        public int GetCommentcountbyArticleId(int article)
        {
            int count = (int)service.QueryForObject("GetCommentcountbyArticleId", article);
            return count;
        }

        public void UpdatePostHits(int postId)
        {
            service.Update("UpdatePostHits", postId);
        }

        public PostCategory Getcategoryby_typeid(int typeid)
        {
            return service.QueryForObject<PostCategory>("Getcategoryby_typeid", typeid);
        }

        public IList GetBlogArticlesbytime(int userid, string time)
        {
            Hashtable dt = new Hashtable();
            dt["userid"] = userid;
            dt["time"] = time;
            return service.QueryForList("GetBlogArticlesbytime", dt);
        }

        public IList GetUsertopnum(int num)
        {
            return service.QueryForList("GetUsertopnum", num);
        }

        public IList GetTjBlogArticles(int num)
        {

            return service.QueryForList("GetTjBlogArticles", num);
        }

        public IList<Post> GetPostsByUser(int UserId, int pageNo, int pageSize, ref int count)
        {
            count = (int)service.QueryForObject("GetArticleCountByUserId", UserId);
            if (count > 0)
            {
                return service.QueryForList<Post>("GetArticleListByUserId", UserId, (pageNo - 1) * pageSize, pageSize);
            }
            return null;
        }

        public IList GetAllArticleForPage(int pageNo, int pageSize, ref int count)
        {
            count = (int)service.QueryForObject("GetAllArticleCount", "");
            if (count > 0)
            {
                return service.QueryForList("GetAllArticleForPage", "", (pageNo - 1) * pageSize, pageSize);
            }
            return null;
        }

        public void UpdateArticleTj(int id)
        {
            service.Update("UpdateArticleTj", id);
        }

        public void UpdateArticleNoTj(int id)
        {
            service.Update("UpdateArticleNoTj", id);
        }

        public IList GetAllCommentForPage(int pageNo, int pageSize, ref int count)
        {
            count = (int)service.QueryForObject("GetAllCommentcount", "");
            if (count > 0)
            {

                return service.QueryForList("GetAllComment", "", (pageNo - 1) * pageSize, pageSize);
            }
            return null;
        }

        public void UpdateArticlesCate(int typeid)
        {
            service.Update("UpdateArticlesCate", typeid);
        }

        public IList Mappings
        {
            get { return mappings; }
            set { mappings = value; }
        }

        private IList mappings;

        #region IDao ��Ա

        public void Initialize()
        {
            service = PluginLocator.GetPluginService<IDataService>("data");
            service.Configure(mappings);
        }

        public void UpdatePostData(int postId, string content)
        {
            Hashtable dict = new Hashtable();
            dict["postId"] = postId;
            dict["content"] = content;

            service.Update("UpdatePostData", dict);
        }

        public string GetPostData(int postId)
        {
            return service.QueryForObject<string>("GetPostData", postId);
        }

        public void DeleteSubscriber(Subscriber sub)
        {
            service.Delete("DeleteSubscriber", sub.SubId);
        }

        public void SaveSubscriber(Subscriber sub)
        {
            service.Insert("InsertSubscriber", sub);
        }

        public Subscriber GetSubscriberByCode(int subId, string code)
        {
            Hashtable dict = new Hashtable();
            dict["SubId"] = subId;
            dict["Code"] = code;
            return service.QueryForObject<Subscriber>("GetSubscriberByCode", dict);
        }

        public void UpdateSubscriber(Subscriber sub)
        {
            service.Update("UpdateSubscriber", sub);
        }

        public Subscriber GetSubscriberByEmail(string email)
        {
            return service.QueryForObject<Subscriber>("GetSubscriberByEmail", email);
        }

        #endregion
    }
}
