#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.CMS.Model
{
    public abstract class VisualFile
    {
        private int fileId;
        private string name;
        private long fileSize;
        private int userId;
        private DateTime createDate;

        public int FileId
        {
            get { return fileId; }
            set { fileId = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public long FileSize
        {
            get { return fileSize; }
            set { fileSize = value; }
        }

        public int UserId
        {
            get { return userId; }
            set { userId = value; }
        }

        public DateTime CreateDate
        {
            get { return createDate; }
            set { createDate = value; }
        }

        public virtual bool IsFolder
        {
            get { return false; }
        }
    }
}
