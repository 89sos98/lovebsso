#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;

namespace CchenSoft.Portal.CMS.Model
{
	/// <summary>
	/// Info ��ժҪ˵����
	/// </summary>
	public class Article
	{
		private int artId;
		private string title;
		private string content;
        private DateTime addDate;
        private int userId;
        private int structureId;

		public Article()
		{
			title = "";
			content = "";
            addDate = DateTime.Now.Date;
		}

		/// <summary>
		/// ��ѶId
		/// </summary>
		public int ArticleId
		{
			get { return artId; }
			set { artId = value; }
		}

		/// <summary>
		/// ����
		/// </summary>
		public string Title
		{
			get { return title; }
			set { title = value; }
		}

		/// <summary>
		/// ����
		/// </summary>
		public string Content
		{
			get { return content; }
			set { content = value; }
		}

        /// <summary>
        /// ��������
        /// </summary>
        public DateTime AddDate
        {
            get { return addDate; }
            set { addDate = value; }
        }

        /// <summary>
        /// �û�ID
        /// </summary>
        public int UserId
        {
            get { return userId; }
            set { userId = value; }
        }

        public int StructureId
        {
            get { return structureId; }
            set { structureId = value; }
        }
	}
}
