using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using CchenSoft.Portal.CMS.Model;
using CchenSoft.Portal.CMS.Web;

namespace CMS.Web.View
{
    public partial class DefaultView : DocumentViewControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblName.Text = doc.Name;
            lblSize.Text = doc.FileSize.ToString();
            lblSummary.Text = doc.Summary;
        }
    }
}
