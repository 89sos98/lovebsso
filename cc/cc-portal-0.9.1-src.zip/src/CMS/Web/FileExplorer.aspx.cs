#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal.CMS.Model;
using CchenSoft.Portal;
using CchenSoft.Portal.CMS.Service;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Util;
using System.Collections.Generic;

namespace CMS.Web
{
	/// <summary>
	/// WebForm1 ��ժҪ˵����
	/// </summary>
	public partial class FileExplorer : PortletPage
	{
        private IDocumentService docService;

        protected void Page_Load(object sender, System.EventArgs e)
        {
            docService = portletContext.GetService<IDocumentService>();
            if (!IsPostBack)
            {
                int folderId = ParamUtil.GetInt32(Request, "fid");                

                if (folderId != 0)
                {
                    Folder folder = docService.LoadFolder(folderId);
                    if (folder != null)
                    {
                        txtFolderPath.Text = folder.Name;
                    }
                    else
                    {
                        // TODO: ��������ʾ
                    }
                }

                hAddDoc.NavigateUrl = string.Format(hAddDoc.NavigateUrl, folderId);
                hAddFolder.NavigateUrl = string.Format(hAddFolder.NavigateUrl, folderId);

                IList<VisualFile> fileList = new List<VisualFile>();

                IList<Folder> folders = docService.GetSubFolders(folderId);
                foreach (Folder f in folders)
                    fileList.Add(f);

                IList<Document> docs = docService.GetDocumentsByFolder(folderId);
                foreach (Document d in docs)
                    fileList.Add(d);

                rptView.DataSource = fileList;
                rptView.DataBind();
            }
        }

        protected void rptView_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                VisualFile file = (VisualFile)e.Item.DataItem;

                HyperLink hFolder = (HyperLink)e.Item.FindControl("hFolder");
                hFolder.Text = file.Name;

                if (!file.IsFolder)
                {
                    hFolder.NavigateUrl = "viewdocument.aspx?docid=" + file.FileId;
                    hFolder.Attributes["target"] = "_blank";
                    ((Label)e.Item.FindControl("lSize")).Text = file.FileSize + "Bytes";
                }
                else
                {
                    hFolder.NavigateUrl = "fileExplorer.aspx?fid=" + file.FileId;
                    ((Label)e.Item.FindControl("lType")).Text = "�ļ���";
                }

                ((Label)e.Item.FindControl("lCreated")).Text = file.CreateDate.ToString();
            }
        }


	}
}
