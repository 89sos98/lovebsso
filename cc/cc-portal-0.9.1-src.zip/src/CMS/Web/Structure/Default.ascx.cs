using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using CchenSoft.Portal.CMS.Model;
using CchenSoft.Portal.CMS.Web;

namespace CMS.Web.Structure
{
    public partial class Default : StructureControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblContent.Text = article.Content;
        }
    }
}
