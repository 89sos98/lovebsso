#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal.CMS.Model;
using CchenSoft.Portal;
using CchenSoft.Portal.CMS.Service;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.CMS.Web;

namespace CMS.Web
{
	/// <summary>
	/// WebForm1 ��ժҪ˵����
	/// </summary>
	public partial class ViewArticle : ViewPage
	{	
		protected void Page_Load(object sender, System.EventArgs e)
		{
            IArticleService service = portletContext.GetService<IArticleService>();
            Article art = service.LoadArticle(preferences.GetInt32("article-id"));
            if (art != null)
            {
                StructureControl control = service.LoadStructureControl(art, this);
                view.Controls.Add(control);

                //Response.Write(dataInput);
                OutputData("article=" + art.ArticleId);
            }

            bool canAdmin = IsAdmin() || IsOwner();
            
            hlnkAdd.Visible = canAdmin;
            hlnkSelect.Visible = canAdmin;
		}

		#region Web ������������ɵĴ���
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �õ����� ASP.NET Web ���������������ġ�
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion


	}
}
