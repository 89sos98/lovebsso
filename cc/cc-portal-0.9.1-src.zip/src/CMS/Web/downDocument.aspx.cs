#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal.CMS.Model;
using CchenSoft.Portal;
using CchenSoft.Portal.CMS.Service;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Util;
using System.IO;

namespace CMS.Web
{
	/// <summary>
	/// WebForm1 ��ժҪ˵����
	/// </summary>
	public partial class DownDocument : ViewPage
	{	
		protected void Page_Load(object sender, System.EventArgs e)
		{
            int docId = ParamUtil.GetInt32(Request, "docid");

            IDocumentService docService = portletContext.GetService<IDocumentService>();

            Document doc = docService.LoadDocumnet(docId);
            if (doc != null)
            {
                Byte[] docData = docService.GetDocumentData(docId);

                Response.Clear();
                Response.ContentType = GetContentType(doc.Name);

                string agent = Request.UserAgent;
                string filename = doc.Name;
                if (agent != null && agent.IndexOf("MSIE") != -1)
                    filename = HttpUtility.UrlEncode(doc.Name);

                Response.AddHeader("Content-Disposition", "filename=" + filename);
                Response.BinaryWrite(docData);
                Response.End();
            }
		}

        private string GetContentType(string filename)
        {
            string contentType = "text/html";
            int n = filename.LastIndexOf(".");
            if (n > -1)
            {
                string ext = filename.Substring(n).ToLower();

                switch (ext)
                {
                    case ".jpg":
                        contentType = "image/jpeg";
                        break;

                    case ".gif":
                        contentType = "image/gif";
                        break;

                    case ".doc":
                        contentType = "application/msword";
                        break;
                }

            }

            return contentType;
        }

		#region Web ������������ɵĴ���
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �õ����� ASP.NET Web ���������������ġ�
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion


	}
}
