#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.CMS.Model;
using CchenSoft.Portal.CMS.Dao;
using System.Web.UI;
using CchenSoft.Portal.CMS.Web;
using CchenSoft.Portal.Spi;

namespace CchenSoft.Portal.CMS.Service
{
    public interface IDocumentService : IService
    {
        IDocumentDao DocumentDao { set; }

        string ViewConfigFile { set; }

        int SaveDocument(Document doc, byte[] data);

        int SaveFolder(Folder folder);

        IList<Folder> GetSubFolders(int folderId);

        IList<Document> GetDocumentsByFolder(int folderId);

        Document LoadDocumnet(int fileId);

        byte[] GetDocumentData(int fileId);

        Folder LoadFolder(int folderId);

        IList<Article> FindArticles(string p);

        DocumentViewControl LoadDocumentView(Document doc, Page Page);
    }
}
