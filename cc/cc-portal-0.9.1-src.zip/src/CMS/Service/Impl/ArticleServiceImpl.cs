#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Configuration;
using System.Collections;
using System.Data;

using CchenSoft.Portal.CMS.Dao;
using CchenSoft.Portal.CMS.Model;
using System.Collections.Generic;
using CchenSoft.Portal.CMS.Web;
using System.Web.UI;
using CchenSoft.Portal.Spi.Attribute;

namespace CchenSoft.Portal.CMS.Service.Impl
{
	/// <summary>
	/// Class1 ��ժҪ˵����
	/// </summary>
	public class ArticleServiceImpl : IArticleService
	{
		private IArticleDao articleDao;
        private string structureConfigFile;
        private const string groupName = "article";

		public ArticleServiceImpl()
		{
        }

        #region IArticleService ��Ա
        
        public IArticleDao ArticleDao
		{
			set { this.articleDao = value; }
		}

		[Security("ADD_ARTICLE")]
		public void SaveArticle(Article art)
		{
            articleDao.SaveArticle(art);
		}

        public IList<Article> GetArticles(int pageIndex, int pageSize, ref long count)
        {
            return articleDao.GetArticles(pageIndex, pageSize, ref count);
        }

        [Cacheable(groupName)]
        public Article LoadArticle(int id)
        {
            return articleDao.LoadArticle(id);
        }

        public string StructureConfigFile
        {
            set { structureConfigFile = value; }
        }

        public void Initialize()
        {
        }

        public IList<ArticleStructure> GetArticleStructures()
        {
            return articleDao.GetArticleStructures();
        }

        public StructureControl LoadStructureControl(Article article, Page page)
        {
            ArticleStructure structure = GetArticleStructure(article.StructureId);

            StructureControl control = (StructureControl)page.LoadControl(structure.StructureFile);
            control.Article = article;
            return control;
        }

        public void UpdateArticle(Article art)
        {
            articleDao.UpdateArticle(art);
        }

        #endregion

        private ArticleStructure GetArticleStructure(int structureId)
        {
            ArticleStructure result = null;
            IList<ArticleStructure> structures = GetArticleStructures();
            foreach (ArticleStructure st in structures)
            {
                if (st.StructureId == structureId)
                {
                    result = st;
                    break;
                }
            }
            return result;
        }

    }
}
