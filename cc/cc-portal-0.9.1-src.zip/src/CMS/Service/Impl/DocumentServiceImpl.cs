#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.CMS.Dao;
using CchenSoft.Portal.CMS.Model;
using System.Web.UI;
using System.Xml;
using System.Web;
using CchenSoft.Portal.CMS.Web;
using CchenSoft.Portal.Spi.Attribute;

namespace CchenSoft.Portal.CMS.Service.Impl
{
    public class DocumentServiceImpl : IDocumentService
    {
        private IDocumentDao docDao;
        private string viewConfigFile;
        private IDictionary<string, string> documentViews;
        private const string groupName = "document";

        public DocumentServiceImpl()
        {
            documentViews = new Dictionary<string, string>();
        }

        #region IDocumentService ��Ա

        public string ViewConfigFile
        {
            set { viewConfigFile = value; }
        }

        [Transaction(TransactionOption.RequiresNew)]
        public int SaveDocument(Document doc, byte[] data)
        {
            return docDao.SaveDocument(doc, data);
        }

        public int SaveFolder(Folder folder)
        {
            return docDao.SaveFolder(folder);
        }

        public IDocumentDao DocumentDao
        {
            set { this.docDao = value; }
        }

        [Cacheable(groupName)]
        public IList<Folder> GetSubFolders(int folderId)
        {
            return docDao.GetSubFolders(folderId);
        }

        [Cacheable(groupName)]
        public IList<Document> GetDocumentsByFolder(int folderId)
        {
            return docDao.GetDocumentsByFolder(folderId);
        }

        [Cacheable(groupName)]
        public Document LoadDocumnet(int fileId)
        {
            return docDao.LoadDocumment(fileId);
        }

        public byte[] GetDocumentData(int fileId)
        {
            return docDao.GetDocumentData(fileId);
        }

        [Cacheable(groupName)]
        public Folder LoadFolder(int folderId)
        {
            return docDao.LoadFolder(folderId);
        }

        public IList<Article> FindArticles(string keyword)
        {
            return docDao.FindArticles(keyword);
        }

        public DocumentViewControl LoadDocumentView(Document doc, Page Page)
        {
            //MimeType mimeType = GetDocumentMimeType(doc);

            DocumentViewControl view = (DocumentViewControl)Page.LoadControl("/portlets/cms/view/defaultview.ascx");
            view.Document = doc;
            return view;
        }

        public void Initialize()
        {
        }

        #endregion
    }
}
