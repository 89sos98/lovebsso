#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using CchenSoft.Portal.CMS.Model;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Service;

namespace CchenSoft.Portal.CMS.Dao.Impl
{
    public class DocumentDaoImpl : IDocumentDao
    {
        private IDataService service;

        public DocumentDaoImpl()
        {
        }

        #region IDocumentDao ��Ա

        public int SaveDocument(Document doc, byte[] data)
        {
            service.Insert("InsertDocument", doc);

            Hashtable dict = new Hashtable();
            dict["DocId"] = doc.FileId;
            dict["Data"] = data;
            service.Insert("InsertDocumentData", dict);

            return 0;
        }

        public int SaveFolder(Folder folder)
        {
            service.Insert("InsertFolder", folder);
            return 0;
        }

        public IList<Folder> GetSubFolders(int folderId)
        {
            return service.QueryForList<Folder>("GetSubFolders", folderId);
        }

        public IList<Document> GetDocumentsByFolder(int folderId)
        {
            return service.QueryForList<Document>("GetFolderDocuments", folderId);
        }

        public byte[] GetDocumentData(int fileId)
        {
            return service.QueryForObject<Byte[]>("GetDocumentData", fileId);
        }

        public Document LoadDocumment(int fileId)
        {
            return service.QueryForObject<Document>("SelectDocument", fileId);
        }

        public Folder LoadFolder(int folderId)
        {
            return service.QueryForObject<Folder>("SelectFolder", folderId);
        }

        public IList<Article> FindArticles(string keyword)
        {
            if (keyword == null)
                keyword = "";
            if (keyword != "")
                keyword = "%" + keyword + "%";
            return service.QueryForList<Article>("FindArticles", keyword);
        }

        public IList Mappings
        {
            set { mappings = value; }
        }

        #endregion

        private IList mappings;

        #region IDao ��Ա

        public void Initialize()
        {
            service = PluginLocator.GetPluginService<IDataService>("data");
            service.Configure(mappings);
        }

        #endregion
    }
}
