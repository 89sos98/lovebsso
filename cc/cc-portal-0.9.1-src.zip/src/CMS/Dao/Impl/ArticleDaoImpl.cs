#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using CchenSoft.Portal.CMS.Dao;
using CchenSoft.Portal.CMS.Model;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Service;

namespace CchenSoft.Portal.CMS.Dao.Impl
{
	/// <summary>
	/// Class1 ��ժҪ˵����
	/// </summary>
	public class ArticleDaoImpl : IArticleDao
	{
        private IDataService service;

        public ArticleDaoImpl()
		{
		}

		
		public void SaveArticle(Article art)
		{
            service.Insert("InsertArticle", art);
		}

        public IList<Article> GetArticles(int pageIndex, int pageSize, ref long count)
        {
            count = service.QueryForObject<long>("GetArticleCount", null);
            return service.QueryForList<Article>("SelectArticle", null, (pageIndex - 1) * pageSize, pageSize);
        }

        public Article LoadArticle(int id)
        {
            return service.QueryForObject<Article>("SelectArticle", id);
        }

        public IList<ArticleStructure> GetArticleStructures()
        {
            return service.QueryForList<ArticleStructure>("GetArticleStructures", null);
        }


        #region IArticleDao ��Ա


        public void UpdateArticle(Article art)
        {
            service.Update("UpdateArticle", art);
        }

        public IList Mappings
        {
            set { mappings = value; }
        }

        #endregion

        private IList mappings;

        #region IDao ��Ա

        public void Initialize()
        {
            service = PluginLocator.GetPluginService<IDataService>("data");
            service.Configure(mappings);
        }

        #endregion
    }
}
