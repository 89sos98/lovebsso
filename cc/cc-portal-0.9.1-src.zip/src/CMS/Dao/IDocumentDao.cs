#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.CMS.Model;
using CchenSoft.Portal.Spi;

namespace CchenSoft.Portal.CMS.Dao
{
    public interface IDocumentDao: IDao
    {
        int SaveDocument(Document doc, byte[] data);

        int SaveFolder(Folder folder);

        IList<Folder> GetSubFolders(int folderId);

        IList<Document> GetDocumentsByFolder(int folderId);

        byte[] GetDocumentData(int fileId);

        Document LoadDocumment(int fileId);

        Folder LoadFolder(int folderId);

        IList<Article> FindArticles(string keyword);
    }
}
