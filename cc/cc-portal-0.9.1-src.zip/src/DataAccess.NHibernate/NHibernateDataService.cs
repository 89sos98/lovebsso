#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using NHibernate;
using NHibernate.Cfg;
using System.Reflection;
using System.Collections;
using System.Web;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Spi.Plugin;
using System.Data;
using NHibernateEnvironment = NHibernate.Cfg.Environment;

namespace CchenSoft.Portal.DataAccess.NHibernate
{

    public class NHibernateDataService : IDataService
    {
        private static ISessionFactory sessionFactory = null;
        private IServicePlugin plugin;
        private string connectionString;
        private string parameterClass;
        private string dataAdapterClass;
        private string cfgFile;

        public void Initialize()
        {
        }

        public string CfgFile
        {
            get { return cfgFile; }
            set { cfgFile = value; }
        }

        public string ParameterClass
        {
            get { return parameterClass; }
            set { parameterClass = value; }
        }

        public string DataAdapterClass
        {
            get { return dataAdapterClass; }
            set { dataAdapterClass = value; }
        }

        public string ConnectionString
        {
            get { return connectionString; }
            set { connectionString = value; }
        }

        public void SetPlugin(IPlugin plugin)
        {
            this.plugin = (IServicePlugin)plugin;
        }

        protected ISession OpenSession()
        {
            return sessionFactory.OpenSession();
        }

        protected ISessionFactory SessionFactory
        {
            get { return sessionFactory; }
        }


        #region IDataService ��Ա

        public void Configure(IList mappings)
        {
            Configuration cfg = new Configuration().Configure(plugin.Folder + cfgFile);
            cfg.SetProperty(NHibernateEnvironment.ConnectionString, connectionString);

            foreach (string xmlfile in mappings)
            {
                cfg.AddFile(xmlfile);
            }
            
            sessionFactory = cfg.BuildSessionFactory();
        }

        private void AttachParameters(IQuery query, object parameterObject)
        {
            if (parameterObject is IDictionary<string, object>)
            {
                IDictionary<string, object> dict = (IDictionary<string, object>)parameterObject;
                foreach (string name in dict.Keys)
                    query.SetParameter(name, dict[name]);
            }
        }

        public T QueryForObject<T>(string statementName, object parameterObject)
        {
            ISession session = OpenSession();
            try
            {
                T obj = default(T);
                IQuery query = session.CreateQuery(statementName);
                AttachParameters(query, parameterObject);

                IList list = query.List();
                if (list.Count > 0)
                    obj = (T)(list[0]);

                return obj;
            }
            finally
            {
                session.Close();
            }
        }

        public object QueryForObject(string statementName, object parameterObject)
        {
            ISession session = OpenSession();
            try
            {
                object obj = null;
                IQuery query = session.CreateQuery(statementName);
                AttachParameters(query, parameterObject);
                IList list = query.List();
                if (list.Count > 0)
                    obj = (list[0]);

                return obj;
            }
            finally
            {
                session.Close();
            }
        }

        public IList QueryForList(string statementName, object parameterObject)
        {
            ISession session = OpenSession();
            try
            {
                IQuery query = session.CreateQuery(statementName);
                AttachParameters(query, parameterObject);

                return query.List();
            }
            finally
            {
                session.Close();
            }
        }

        public IList QueryForList(string statementName, object parameterObject, int firstResult, int maxResults)
        {
            ISession session = OpenSession();
            try
            {
                IQuery query = session.CreateQuery(statementName);
                AttachParameters(query, parameterObject);

                query.SetFirstResult(firstResult);
                query.SetMaxResults(maxResults);
                return query.List();
            }
            finally
            {
                session.Close();
            }
        }

        public IList<T> QueryForList<T>(string statementName, object parameterObject)
        {
            ISession session = OpenSession();
            try
            {
                IQuery query = session.CreateQuery(statementName);
                AttachParameters(query, parameterObject);

                return query.List<T>();
            }
            finally
            {
                session.Close();
            }
        }

        public IList<T> QueryForList<T>(string statementName, object parameterObject, int firstResult, int maxResults)
        {
            ISession session = OpenSession();
            try
            {
                IQuery query = session.CreateQuery(statementName);
                AttachParameters(query, parameterObject);

                query.SetFirstResult(firstResult);
                query.SetMaxResults(maxResults);
                return query.List<T>();
            }
            finally
            {
                session.Close();
            }
        }


        public object Insert(string statementName, object parameterObject)
        {
            ISession s = OpenSession();
            try
            {
                s.Save(parameterObject);
                return parameterObject;
            }
            finally
            {
                s.Close();
            }
        }

        public int Update(string statementName, object parameterObject)
        {
            ISession s = OpenSession();
            try
            {
                s.Update(parameterObject);
                return 1;
            }
            finally
            {
                s.Close();
            }
        }

        public int Delete(string statementName, object parameterObject)
        {
            ISession s = OpenSession();
            try
            {
                s.Delete(parameterObject);
                return 1;
            }
            finally
            {
                s.Close();
            }
        }

        public IDbDataParameter CreateParameter(string name, object value)
        {
            Type parameterClazz = Type.GetType(parameterClass);
            IDbDataParameter parameter = (IDbDataParameter)Activator.CreateInstance(parameterClazz);
            parameter.ParameterName = name;
            parameter.Value = value;
            return parameter;
        }

        private IDbDataAdapter CreateDataAdapter()
        {
            Type dataAdpaterClazz = Type.GetType(dataAdapterClass);
            return (IDbDataAdapter)Activator.CreateInstance(dataAdpaterClazz);
        }

        public DataSet QueryForDataSet(string statementName, object parameterObject)
        {
            IDbConnection conn = sessionFactory.ConnectionProvider.GetConnection();
            IDbCommand command = conn.CreateCommand();
            command.CommandType = CommandType.Text;
            command.CommandText = statementName;
            IDbDataAdapter adapter = CreateDataAdapter();
            adapter.SelectCommand = command;
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            return ds;
        }

        public object BeginTransaction()
        {
            ISession session = OpenSession();
            return session.BeginTransaction();
        }

        public void Commit(object obj)
        {
            ITransaction trans = (ITransaction)obj;
            trans.Commit();
        }

        public void Rollback(object obj)
        {
            ITransaction trans = (ITransaction)obj;
            trans.Rollback();
        }

        #endregion
    }
}
