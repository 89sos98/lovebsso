#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.Money.Model
{
    public enum ItemType
    {
        Income,
        Payout
    }

    /// <summary>
    /// ��ĿС��
    /// </summary>
    public class AccountItem
    {
        private int itemId;
        private int accountId;        
        private DateTime date;
        private string kind;
        private ItemType type;
        private decimal money;
        private string summary;

        /// <summary>
        /// ��ĿId
        /// </summary>
        public int ItemId
        {
            get { return itemId; }
            set { itemId = value; }
        }

        /// <summary>
        /// �ʻ�Id
        /// </summary>
        public int AccountId
        {
            get { return accountId; }
            set { accountId = value; }
        }

        /// <summary>
        /// ����
        /// </summary>
        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }
        
        /// <summary>
        /// ����
        /// </summary>
        public string Kind
        {
            get { return kind; }
            set { kind = value; }
        }

        /// <summary>
        /// ���� 0: ���룻 1: ֧��
        /// </summary>
        public ItemType Type
        {
            get { return type; }
            set { type = value; }
        }

        /// <summary>
        /// ���
        /// </summary>
        public decimal Money
        {
            get { return money; }
            set { money = value; }
        }

        /// <summary>
        /// ժҪ
        /// </summary>
        public string Summary
        {
            get { return summary; }
            set { summary = value; }
        }

    }
}
