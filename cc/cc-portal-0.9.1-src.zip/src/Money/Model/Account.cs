#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.Money.Model
{
    /// <summary>
    /// �˻�
    /// </summary>
    public class Account
    {
        private int accountId;
        private string name;
        private string type;
        private decimal initMoney;
        private int userId;
        private int used;
        private string summary;

        /// <summary>
        /// �˻�ID
        /// </summary>
        public int AccountId
        {
            get { return accountId; }
            set { accountId = value; }
        }

        /// <summary>
        /// ����
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// �ʻ����
        /// </summary>
        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        /// <summary>
        /// ��ʼ���
        /// </summary>
        public decimal InitMoney
        {
            get { return initMoney; }
            set { initMoney = value; }
        }

        /// <summary>
        /// ժҪ
        /// </summary>
        public string Summary
        {
            get { return summary; }
            set { summary = value; }
        }

        public int UserId
        {
            get { return userId; }
            set { userId = value; }
        }

        /// <summary>
        /// �Ƿ���ʹ����
        /// </summary>
        public int Used
        {
            get { return used; }
            set { used = value; }
        }
    }
}
