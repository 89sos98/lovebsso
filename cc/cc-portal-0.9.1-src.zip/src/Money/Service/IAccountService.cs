#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using CchenSoft.Portal.Money.Dao;
using CchenSoft.Portal.Money.Model;
using CchenSoft.Portal.Spi;


namespace CchenSoft.Portal.Money.Service
{
	/// <summary>
	/// Class1 ��ժҪ˵����
	/// </summary>
	public interface IAccountService : IService
	{		
		IAccountDao AccountDao { set; }

		void SaveAccount(Account account);

        IList<Account> GetAccounts(int pageIndex, int pageSize, ref long count);

        Account LoadAccount(int id);

        void UpdateAccount(Account account);

        IList<AccountItem> GetAccountItems(DateTime date, int pageIndex, int pageSize, ref long count);

        void SaveAccountItem(AccountItem item);

        AccountItem LoadAccountItem(int accountId);

        void UpdateAccountItem(AccountItem item);

        IList<Account> GetAllAccounts();

        IList<AccountItem> GetItemsByAccount(int accountId, int pageIndex, int pageSize, ref long count);

        //decimal GetAccountIncomeTotal(int accountId);

        //decimal GetAccountPayoutTotal(int accountId);


    }
}
