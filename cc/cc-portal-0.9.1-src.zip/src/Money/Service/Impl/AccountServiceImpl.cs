#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Configuration;
using System.Collections;
using System.Data;

using System.Collections.Generic;
using CchenSoft.Portal.Money.Dao;
using CchenSoft.Portal.Money.Model;
using CchenSoft.Portal.Spi.Attribute;

namespace CchenSoft.Portal.Money.Service.Impl
{
	/// <summary>
	/// Class1 ��ժҪ˵����
	/// </summary>
	public class AccountServiceImpl : IAccountService
	{
		private IAccountDao accountDao;
        private const string groupName = "money";

		public AccountServiceImpl()
		{
        }

        #region IAccountService ��Ա
        
        public IAccountDao AccountDao
		{
			set { this.accountDao = value; }
		}

		
		public void SaveAccount(Account art)
		{
            accountDao.SaveAccount(art);
		}

        public IList<Account> GetAccounts(int pageIndex, int pageSize, ref long count)
        {
            return accountDao.GetAccounts(pageIndex, pageSize, ref count);
        }

        [Cacheable(groupName)]
        public Account LoadAccount(int id)
        {
            return accountDao.LoadAccount(id);
        }

        public void Initialize()
        {
        }

        public void UpdateAccount(Account art)
        {
            accountDao.UpdateAccount(art);
        }


        public IList<AccountItem> GetAccountItems(DateTime date, int pageIndex, int pageSize, ref long count)
        {
            return accountDao.GetAccountItems(date, pageIndex, pageSize, ref count);
        }

        public void SaveAccountItem(AccountItem item)
        {
            accountDao.SaveAccountItem(item);
        }

        [Cacheable(groupName)]
        public IList<Account> GetAllAccounts()
        {
            return accountDao.GetAllAccounts();
        }

        public IList<AccountItem> GetItemsByAccount(int accountId, int pageIndex, int pageSize, ref long count)
        {
            return accountDao.GetItemsByAccount(accountId, pageIndex, pageSize, ref count);
        }

        //public decimal GetAccountIncomeTotal(int accountId)
        //{
        //    return accountDao.GetAccountIncomeTotal(accountId);
        //}

        //public decimal GetAccountPayoutTotal(int accountId)
        //{
        //    return accountDao.GetAccountPayoutTotal(accountId);
        //}

        [Cacheable(groupName)]
        public AccountItem LoadAccountItem(int accountId)
        {
            return accountDao.LoadAccountItem(accountId);
        }

        public void UpdateAccountItem(AccountItem item)
        {
            accountDao.UpdateAccountItem(item);
        }

        #endregion
    }
}
