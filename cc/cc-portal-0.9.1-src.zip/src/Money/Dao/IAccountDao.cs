#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using CchenSoft.Portal.Money.Model;
using CchenSoft.Portal.Spi;

namespace CchenSoft.Portal.Money.Dao
{
	/// <summary>
	/// Class1 ��ժҪ˵����
	/// </summary>
	public interface IAccountDao : IDao
	{
        void SaveAccount(Account art);

        IList<Account> GetAccounts(int pageIndex, int pageSize, ref long count);

        Account LoadAccount(int id);

        void UpdateAccount(Account art);

        IList<AccountItem> GetAccountItems(DateTime date, int pageIndex, int pageSize, ref long count);

        void SaveAccountItem(AccountItem item);

        IList<Account> GetAllAccounts();

        IList<AccountItem> GetItemsByAccount(int accountId, int pageIndex, int pageSize, ref long count);

        //decimal GetAccountPayoutTotal(int accountId);

        //decimal GetAccountIncomeTotal(int accountId);

        void UpdateAccountItem(AccountItem item);

        AccountItem LoadAccountItem(int itemId);
    }

}
