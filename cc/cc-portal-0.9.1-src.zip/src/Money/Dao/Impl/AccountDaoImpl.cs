#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using CchenSoft.Portal.Money.Model;
using CchenSoft.Portal.Money.Dao;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Spi.Service;

namespace CchenSoft.Portal.Money.Dao.Impl
{
	/// <summary>
	/// Class1 ��ժҪ˵����
	/// </summary>
    public class AccountDaoImpl : IAccountDao
	{
        private IDataService service;

        public AccountDaoImpl()
		{
		}


        public void SaveAccount(Account art)
		{
            service.Insert("InsertAccount", art);
		}

        public IList<Account> GetAccounts(int pageIndex, int pageSize, ref long count)
        {
            count = service.QueryForObject<long>("GetAccountCount", null);
            return service.QueryForList<Account>("SelectAccount", null, (pageIndex - 1) * pageSize, pageSize);
        }

        public Account LoadAccount(int id)
        {
            return service.QueryForObject<Account>("SelectAccount", id);
        }

        #region IArticleDao ��Ա


        public void UpdateAccount(Account art)
        {
            service.Update("UpdateAccount", art);
        }

        public IList<AccountItem> GetAccountItems(DateTime date, int pageIndex, int pageSize, ref long count)
        {
            count = service.QueryForObject<long>("GetAccountItemCountByDate", date);
            return service.QueryForList<AccountItem>("GetAccountItemsByDate", date, (pageIndex - 1) * pageSize, pageSize);
        }


        public void SaveAccountItem(AccountItem item)
        {
            service.Insert("InsertAccountItem", item);
        }

        public IList<Account> GetAllAccounts()
        {
            return service.QueryForList<Account>("SelectAccount", null);
        }

        public IList<AccountItem> GetItemsByAccount(int accountId, int pageIndex, int pageSize, ref long count)
        {
            count = service.QueryForObject<long>("GetAccountItemCountByAccount", accountId);
            return service.QueryForList<AccountItem>("GetAccountItemsByAccount", accountId, (pageIndex - 1) * pageSize, pageSize);
        }

        public IList Mappings
        {
            set { mappings = value; }
        }

        #endregion

        private IList mappings;

        #region IDao ��Ա

        public void Initialize()
        {
            service = PluginLocator.GetPluginService<IDataService>("data");
            service.Configure(mappings);
        }

        #endregion

        #region IAccountDao ��Ա


        public void UpdateAccountItem(AccountItem item)
        {
            service.Update("UpdateAccountItem", item);
        }

        public AccountItem LoadAccountItem(int itemId)
        {
            return service.QueryForObject<AccountItem>("SelectAccountItem", itemId);
        }

        #endregion
    }
}
