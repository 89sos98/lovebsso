#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Util;
using System.Collections.Generic;
using CchenSoft.Portal.Money.Service;
using CchenSoft.Portal.Money.Model;

namespace Money.Web
{
	/// <summary>
	/// WebForm1 ��ժҪ˵����
	/// </summary>
	public partial class AdminAccounts : ViewPage
	{
        private IAccountService service;

        protected void Page_Load(object sender, System.EventArgs e)
        {
            service = portletContext.GetService<IAccountService>();
            if (!IsPostBack)
            {
                long count = 0;
                rptAccount.DataSource = service.GetAccounts(1, 20, ref count);
                rptAccount.DataBind();
            }
        }

        protected void rptAccount_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Account account = (Account)e.Item.DataItem;

                Label lTitle = (Label)e.Item.FindControl("lName");
                lTitle.Text = account.Name;

                Label lType = (Label)e.Item.FindControl("lType");
                lType.Text = account.Type;

                Label lUsed = (Label)e.Item.FindControl("lUsed");
                lUsed.Text = account.Used == 1 ? "ʹ����" : "δʹ��";

                //Label lIncomeTotal = (Label)e.Item.FindControl("lIncomeTotal");
                //lIncomeTotal.Text = service.GetAccountIncomeTotal(account.AccountId).ToString();

                //Label lPayoutTotal = (Label)e.Item.FindControl("lPayoutTotal");
                //lPayoutTotal.Text = service.GetAccountPayoutTotal(account.AccountId).ToString();

                HyperLink hEdit = (HyperLink)e.Item.FindControl("hEdit");
                hEdit.NavigateUrl = "EditAccount.aspx?accountid=" + account.AccountId.ToString();

                //((Label)e.Item.FindControl("lCreated")).Text = art.AddDate.ToString();
            }
        }

	}
}
