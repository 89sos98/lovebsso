#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Util;
using System.Collections.Generic;
using CchenSoft.Portal.Money.Service;
using CchenSoft.Portal.Money.Model;

namespace Money.Web
{
	/// <summary>
	/// WebForm1 ��ժҪ˵����
	/// </summary>
	public partial class ItemsByAccount : ActionPage
	{
        private IAccountService service;
        private decimal incomeTotal;
        private decimal payoutTotal;
        private int pageSize = 20;

        protected void Page_Load(object sender, System.EventArgs e)
        {
            service = portletContext.GetService<IAccountService>();
            if (!IsPostBack)
            {
                int accountId = ParamUtil.GetInt32(Request, "accid");
                int page = ParamUtil.GetInt32(Request, "page");
                if (page < 1) 
                    page = 1;

                IList<Account> accounts = service.GetAllAccounts();
                foreach (Account acc in accounts)
                {
                    ddlstAccount.Items.Add(new ListItem(acc.Name, acc.AccountId.ToString()));
                }
                ListItem item = ddlstAccount.Items.FindByValue(accountId.ToString());
                if (item != null)
                    item.Selected = true;
                else
                    accountId = ConvertUtil.ToInt32(ddlstAccount.SelectedValue);

                long count = 0;
                rptItem.DataSource = service.GetItemsByAccount(accountId, page, pageSize, ref count);
                rptItem.DataBind();
                
                lIncomeTotal.Text = incomeTotal.ToString();
                lPayoutTotal.Text = payoutTotal.ToString();

                pager.CurrentPage = page;
                pager.PageCount = (int)(count + 1) / pageSize;

                portalURL.AppendParam("_" + instanceId + "_page", "{0}");
                pager.BaseUrl = portalURL.ToURLString();
            }
        }

        protected void btnOk_Click(object sender, EventArgs e)
        {
            portalURL.AppendParam("_" + instanceId + "_accid", ddlstAccount.SelectedValue);
            Response.Redirect(portalURL.ToURLString());
        }

        protected void rptItem_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                AccountItem item = (AccountItem)e.Item.DataItem;

                Label lDate = (Label)e.Item.FindControl("lDate");
                lDate.Text = item.Date.ToString("yyyy-MM-dd");

                Label lIncome = (Label)e.Item.FindControl("lIncome");
                Label lPayout = (Label)e.Item.FindControl("lPayout");

                if (item.Type == ItemType.Income)
                {
                    lIncome.Text = item.Money.ToString();
                    incomeTotal += item.Money;
                }
                else
                {
                    lPayout.Text = item.Money.ToString();
                    payoutTotal += item.Money;
                }

                Label lKind = (Label)e.Item.FindControl("lKind");
                lKind.Text = item.Kind;

                Label lSummary = (Label)e.Item.FindControl("lSummary");
                lSummary.Text = item.Summary;

                HyperLink hEdit = (HyperLink)e.Item.FindControl("hEdit");
                hEdit.NavigateUrl = "EditItem.aspx?itemid=" + item.ItemId.ToString();
            }
        }

	}
}
