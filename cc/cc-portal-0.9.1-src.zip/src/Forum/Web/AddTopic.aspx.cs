#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.Web;
using System.Web.UI.WebControls;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Forum.Service;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Forum.Model;
using System.Collections.Specialized;

namespace Forum.Web
{
	/// <summary>
	/// ChannelType ��ժҪ˵����
	/// </summary>
    public partial class AddTopic : ActionPage
	{
        private IForumService service;
        private int forumId;

        private void Page_Load(object sender, EventArgs e)
        {
            service = portletContext.GetService<IForumService>();
            forumId = ParamUtil.GetInt32(Request, "forumid");
        }

		#region Web ������������ɵĴ���

		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �õ����� ASP.NET Web ���������������ġ�
			//
			InitializeComponent();
			base.OnInit(e);
		}

		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{
			this.Button1.Click += new EventHandler(this.Button1_Click);
			this.Load += new EventHandler(this.Page_Load);

		}

		#endregion

		private void Button1_Click(object sender, EventArgs e)
		{
			if (Check())
			{
                Topic topic = new Topic();
                topic.ForumId = forumId;
                topic.UserId = ServiceLocator.UserService.LoggedUser.UserId;
                topic.Title = title.Text;
                topic.Content = editor.Content;
                topic.ClientIP = Request.UserHostAddress;

                service.SaveTopic(topic);

                SendPortalRedirect("viewtopic.aspx", "topicid=" + topic.TopicId);
			}
		}

		private bool Check()
		{
			bool key = true;
			if (title.Text == "")
			{
				Response.Write("<script>alert('ʧ�ܣ�����д���±��⣡');window.history.go(-1);</script>");
				key = false;
			}
			else if (editor.Content == "")
			{
				Response.Write("<script>alert('ʧ�ܣ�����д�������ݣ�');window.history.go(-1);</script>");
				key = false;
			}
			return key;
		}

	}
}