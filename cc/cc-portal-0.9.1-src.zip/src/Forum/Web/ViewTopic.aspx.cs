#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Util;
using System.Text;
using CchenSoft.Portal.Forum.Service;
using CchenSoft.Portal.Forum.Model;
using CchenSoft.Portal.Service;
using ForumAlias = CchenSoft.Portal.Forum.Model.Forum;
using System.Collections.Generic;

namespace Forum.Web
{
	/// <summary>
	/// WebForm1 ��ժҪ˵����
	/// </summary>
	public partial class ViewTopic : ActionPage
	{
        private int topicid;
        private IForumService service;

        private UserInfoView LoadUserInfoView()
        {
            return (UserInfoView)Page.LoadControl(portletContext.Module.Path + "/userinfoview.ascx");
        }

		protected void Page_Load(object sender, System.EventArgs e)
		{
            topicid = ParamUtil.GetInt32(Request, "topicid");
            service = portletContext.GetService<IForumService>();

            service.CheckUserInfo(portletContext.User);

            if (!IsPostBack)
            {                
                Topic topic = service.LoadTopic(topicid);

                if (topic != null)
                {
                    lblTitle.Text = topic.Title;
                    lblContent.Text = topic.Content;

                    UserInfoView view = LoadUserInfoView();
                    view.UserId = topic.UserId;
                    uiView.Controls.Add(view);

                    ForumAlias forum = service.LoadForum(topic.ForumId);
                    InitLocation(forum);

                    Label lbl = new Label();
                    lbl.Text = topic.Title;
                    location.Controls.Add(lbl);

                    rptReply.DataSource = service.GetReplies(topicid);
                    rptReply.DataBind();

                    service.UpdateTopicViewCount(topic.TopicId);
                }
            }
		}

        private void InitLocation(ForumAlias forum)
        {
            hlnkForumHome.NavigateUrl = portalURL.RequestPath;

            Stack<ForumAlias> stack = new Stack<ForumAlias>();
            stack.Push(forum);
            while (forum.ParentId > 0)
            {
                forum = service.LoadForum(forum.ParentId);
                if (forum == null)
                    break;

                stack.Push(forum);
            }

            while (stack.Count > 0)
            {
                ForumAlias fa = stack.Pop();

                ExHyperLink hlnk = new ExHyperLink();
                hlnk.Text = fa.Name;
                hlnk.NavigateUrl = "topiclist.aspx?forumid=" + forum.ForumId;

                location.Controls.Add(hlnk);

                Literal lt = new Literal();
                lt.Text = " - ";
                location.Controls.Add(lt);
            }
        }

        protected void rptReply_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Reply reply = (Reply)e.Item.DataItem;

                Label lblTitle = (Label)e.Item.FindControl("lblTitle");
                lblTitle.Text = reply.Title;

                Label lblContent = (Label)e.Item.FindControl("lblContent");
                lblContent.Text = reply.Content;

                PlaceHolder uiView = (PlaceHolder)e.Item.FindControl("uiView");
                UserInfoView view = LoadUserInfoView();
                view.UserId = reply.UserId;
                uiView.Controls.Add(view);
            }
        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Reply reply = new Reply();
            reply.TopicId = topicid;
            reply.Title = txtTitle.Text;
            reply.Content = editor.Content;
            reply.UserId = ServiceLocator.UserService.LoggedUser.UserId;
            service.SaveReply(reply);

            SendPortalRedirect(false);
        }

		#region Web ������������ɵĴ���
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �õ����� ASP.NET Web ���������������ġ�
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion


	}
}
