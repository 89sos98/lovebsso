#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal;
using CchenSoft.Portal.Web.UI;
using CchenSoft.Portal.Util;
using System.Text;
using CchenSoft.Portal.Forum.Service;
using CchenSoft.Portal.Forum.Model;
using ForumAlias = CchenSoft.Portal.Forum.Model.Forum;
using System.Collections.Generic;

namespace Forum.Web
{
	/// <summary>
	/// TopicList ��ժҪ˵����
	/// </summary>
	public partial class TopicList : ViewPage
	{
        private IForumService forumService;

		protected void Page_Load(object sender, System.EventArgs e)
		{
            forumService = portletContext.GetService<IForumService>();
            if (!IsPostBack)
            {
                int forumid = ParamUtil.GetInt32(Request, "forumid");

                ForumAlias forum = forumService.LoadForum(forumid);
                if (forum != null)
                {
                    InitLocation(forum);

                    lblForum.Text = forum.Name;
                    lblSummary.Text = forum.Description;

                    hlnkAdd.NavigateUrl = "addtopic.aspx?forumid=" + forumid;

                    IList<ForumAlias> forums = forumService.GetForums(forumid);
                    if (forums != null && forums.Count > 0)
                    {
                        rptForum.Visible = true;
                        rptForum.DataSource = forums;
                        rptForum.DataBind();
                    }

                    rptTopic.DataSource = forumService.GetTopics(forumid);
                    rptTopic.DataBind();
                }
                else
                {
                    // 
                }
            }
		}

        private void InitLocation(ForumAlias forum)
        {
            hlnkForumHome.NavigateUrl = portalURL.RequestPath;

            Stack<ForumAlias> stack = new Stack<ForumAlias>();
            stack.Push(forum);
            while (forum.ParentId > 0)
            {
                forum = forumService.LoadForum(forum.ParentId);
                if (forum == null)
                    break;

                stack.Push(forum);
            }

            while (stack.Count > 0)
            {
                ForumAlias fa = stack.Pop();

                ExHyperLink hlnk = new ExHyperLink();
                hlnk.Text = fa.Name;
                hlnk.NavigateUrl = "topiclist.aspx?forumid=" + forum.ForumId;

                location.Controls.Add(hlnk);

                if (stack.Count > 0)
                {
                    Literal lt = new Literal();
                    lt.Text = " - ";
                    location.Controls.Add(lt);
                }
            }
        }

        private string GetUserNickname(int userId)
        {
            UserInfo ui = forumService.LoadUserInfo(userId);
            return (ui != null) ? ui.Nickname : "";
        }

        protected void rptTopic_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Topic topic = (Topic)e.Item.DataItem;

                HyperLink hlnkTitle = (HyperLink)e.Item.FindControl("hlnkTitle");
                hlnkTitle.Text = topic.Title;
                hlnkTitle.NavigateUrl = "viewtopic.aspx?topicid=" + topic.TopicId;

                Label lblUsername = (Label)e.Item.FindControl("lblUsername");
                lblUsername.Text = GetUserNickname(topic.UserId);

                Label lblViewCount = (Label)e.Item.FindControl("lblViewCount");
                lblViewCount.Text = topic.ViewCount.ToString();

                Label lblReplyCount = (Label)e.Item.FindControl("lblReplyCount");
                lblReplyCount.Text = topic.ReplyCount.ToString();

                Label lblPostDate = (Label)e.Item.FindControl("lblPostDate");
                lblPostDate.Text = topic.PostDate.ToString("yyyy-MM-dd HH:mm");
            }
        }

        protected void rptForum_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                ForumAlias forum = (ForumAlias)e.Item.DataItem;

                HyperLink hlnkName = (HyperLink)e.Item.FindControl("hlnkName");
                hlnkName.Text = forum.Name;
                hlnkName.NavigateUrl = "topiclist.aspx?forumid=" + forum.ForumId;

                Label lblDescr = (Label)e.Item.FindControl("lblDescription");
                lblDescr.Text = forum.Description;

                Label lblTopicCount = (Label)e.Item.FindControl("lblTopicCount");
                lblTopicCount.Text = forum.TopicCount.ToString();

                Label lblReplyCount = (Label)e.Item.FindControl("lblReplyCount");
                lblReplyCount.Text = forum.ReplyCount.ToString();

                Topic topic = null;
                if (forum.LastTopic > 0)
                {
                    topic = forumService.LoadTopic(forum.LastTopic);
                }

                if (topic != null)
                {
                    HyperLink hlnkLastTopic = (HyperLink)e.Item.FindControl("hlnkLastTopic");

                    hlnkLastTopic.Text = topic.Title;
                    hlnkLastTopic.NavigateUrl = "viewtopic.aspx?topicid=" + topic.TopicId;

                    Label lblPostDate = (Label)e.Item.FindControl("lblPostDate");
                    lblPostDate.Text = topic.PostDate.ToString("yyyy-MM-dd HH:mm");
                }
            }
        }

		#region Web ������������ɵĴ���
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �õ����� ASP.NET Web ���������������ġ�
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion


	}
}
