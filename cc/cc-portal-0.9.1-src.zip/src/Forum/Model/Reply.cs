#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.Forum.Model
{
    public class Reply
    {
        private int replyId;
        private int topicId;
        private int forumId;
        private string title;
        private string content;
        private DateTime postDate;
        private string clientIP;
        private int userId;

        public Reply()
        {
            postDate = DateTime.Now;
        }

        public int ReplyId
        {
            get { return replyId; }
            set { replyId = value; }
        }

        public int TopicId
        {
            get { return topicId; }
            set { topicId = value; }
        }

        public int ForumId
        {
            get { return forumId; }
            set { forumId = value; }
        }

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public string Content
        {
            get { return content; }
            set { content = value; }
        }

        public DateTime PostDate
        {
            get { return postDate; }
            set { postDate = value; }
        }

        public string ClientIP
        {
            get { return clientIP; }
            set { clientIP = value; }
        }

        public int UserId
        {
            get { return userId; }
            set { userId = value; }
        }

    }
}
