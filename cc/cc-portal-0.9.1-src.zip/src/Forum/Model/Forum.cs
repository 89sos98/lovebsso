#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.Forum.Model
{
    public class Forum
    {
        private int forumId;
        private int parentId;
        private string name;
        private string description;
        private int sortNo;
        private int topicCount;
        private int replyCount;
        private int lastTopic;

        public int ForumId
        {
            get { return forumId; }
            set { forumId = value; }
        }

        public int ParentId
        {
            get { return parentId; }
            set { parentId = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public int SortNo
        {
            get { return sortNo; }
            set { sortNo = value; }
        }

        public int TopicCount
        {
            get { return topicCount; }
            set { topicCount = value; }
        }

        public int ReplyCount
        {
            get { return replyCount; }
            set { replyCount = value; }
        }

        public int LastTopic
        {
            get { return lastTopic; }
            set { lastTopic = value; }
        }
    }
}
