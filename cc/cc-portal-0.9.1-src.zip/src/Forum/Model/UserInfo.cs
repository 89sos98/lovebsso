#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Data;
using System.Configuration;

namespace CchenSoft.Portal.Forum.Model
{
    public class UserInfo
    {
        private int userId;
        private string nickname;
        private string photoUrl;
        private string signature;
        private int grade;

        public UserInfo()
        {
            grade = 1;
        }

        /// <summary>
        /// user id.
        /// </summary>
        public int UserId
        {
            get { return userId; }
            set { userId = value; }
        }

        /// <summary>
        /// nickname.
        /// </summary>
        public string Nickname
        {
            get { return nickname; }
            set { nickname = value; }
        }

        /// <summary>
        /// photo url.
        /// </summary>
        public string PhotoUrl
        {
            get { return photoUrl; }
            set { photoUrl = value; }
        }

        /// <summary>
        /// signature.
        /// </summary>
        public string Signature
        {
            get { return signature; }
            set { signature = value; }
        }

        /// <summary>
        /// grade.
        /// </summary>
        public int Grade
        {
            get { return grade; }
            set { grade = value; }
        }
    }
}
