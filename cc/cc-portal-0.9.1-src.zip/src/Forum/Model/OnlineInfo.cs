#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace CchenSoft.Portal.Forum.Model
{
    public class OnlineInfo
    {
        private int onlineId;
        private int userId;
        private string clientIP;
        private string nickname;
        private DateTime loginDate;
        private DateTime lastActivedDate;
        private int forumId;
        private int topicId;
        private int state;

        public int OnlineId
        {
            get { return onlineId; }
            set { onlineId = value; }
        }

        public int UserId
        {
            get { return userId; }
            set { userId = value; }
        }

        public string ClientIP
        {
            get { return clientIP; }
            set { clientIP = value; }
        }

        public string Nickname
        {
            get { return nickname; }
            set { nickname = value; }
        }

        public DateTime LoginDate
        {
            get { return loginDate; }
            set { loginDate = value; }
        }

        public DateTime LastActivedDate
        {
            get { return lastActivedDate; }
            set { lastActivedDate = value; }
        }

        public int State
        {
            get { return state; }
            set { state = value; }
        }

        public int ForumId
        {
            get { return forumId; }
            set { forumId = value; }
        }

        public int TopicId
        {
            get { return topicId; }
            set { topicId = value; }
        }
    }
}
