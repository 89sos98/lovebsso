#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Data;
using System.Configuration;

namespace CchenSoft.Portal.Forum.Model
{
    public class Favorite
    {
        private int favId;
        private int userId;
        private int topicId;
        private DateTime favDate;

        /// <summary>
        /// favorite id.
        /// </summary>
        public int FavId
        {
            get { return favId; }
            set { favId = value; }
        }

        /// <summary>
        /// user id.
        /// </summary>
        public int UserId
        {
            get { return userId; }
            set { userId = value; }
        }

        /// <summary>
        /// topic id.
        /// </summary>
        public int TopicId
        {
            get { return topicId; }
            set { topicId = value; }
        }

        /// <summary>
        /// favorite date.
        /// </summary>
        public DateTime FavDate
        {
            get { return favDate; }
            set { favDate = value; }
        }
    }
}
