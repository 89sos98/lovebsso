#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace CchenSoft.Portal.Forum.Model
{
    public class UserGrade
    {
        private int gradeId;
        private string name;
        private string imageUrl;
        private int topics;

        public int GradeId
        {
            get { return gradeId; }
            set { gradeId = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string ImageUrl
        {
            get { return imageUrl; }
            set { imageUrl = value; }
        }

        public int Topics
        {
            get { return topics; }
            set { topics = value; }
        }
    }
}
