#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using CchenSoft.Portal.Forum.Model;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Model;

namespace CchenSoft.Portal.Forum.Dao.Impl
{
    public class ForumDaoImpl : IForumDao
    {
        private IDataService service;

        private IList mappings;

        public IList Mappings
        {
            get { return mappings; }
            set { mappings = value; }
        }

        #region IDao ��Ա

        public void Initialize()
        {
            service = PluginLocator.GetPluginService<IDataService>("data");
            service.Configure(mappings);
        }

        #endregion

        #region IForumDao ��Ա

        public IList<Model.Forum> GetForums(int parentId)
        {
            return service.QueryForList<Model.Forum>("GetForumsByParent", parentId);
        }

        public IList<Topic> GetTopics(int forumId)
        {
            return service.QueryForList<Topic>("GetTopicsByForum", forumId);
        }

        public IList<Reply> GetReplies(int topicid)
        {
            return service.QueryForList<Reply>("GetRepliesByTopic", topicid);
        }

        public Topic LoadTopic(int topicid)
        {
            return service.QueryForObject<Topic>("GetTopicById", topicid);
        }

        public void SaveTopic(Topic topic)
        {
            service.Insert("InsertTopic", topic);

            Hashtable dict = new Hashtable();
            dict["TopicId"] = topic.TopicId;
            dict["ForumId"] = topic.ForumId;
            service.Update("UpdateForumTopicCount", dict);
        }

        public void SaveReply(Reply reply)
        {
            service.Insert("InsertReply", reply);

            Hashtable dict = new Hashtable();
            dict["ReplyId"] = reply.ReplyId;
            dict["TopicId"] = reply.TopicId;
            service.Update("UpdateTopicReplyCount", dict);

            service.Update("UpdateForumReplyCount", reply.ForumId);
        }

        public void UpdateTopicViewCount(int topicId)
        {
            service.Update("UpdateTopicViewCount", topicId);
        }

        public Model.Forum LoadForum(int forumid)
        {
            return service.QueryForObject<Model.Forum>("GetForumById", forumid);
        }

        public UserInfo LoadUserInfo(int userId)
        {
            return service.QueryForObject<UserInfo>("GetUserInfoById", userId);
        }

        public void SaveUserInfo(UserInfo user)
        {
            service.Insert("InsertUserInfo", user);
        }

        public UserGrade LoadUserGrade(int gradeId)
        {
            return service.QueryForObject<UserGrade>("GetUserGradeById", gradeId);
        }


        #endregion
    }
}
