#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Forum.Model;
using CchenSoft.Portal.Spi;

namespace CchenSoft.Portal.Forum.Dao
{
    public interface IForumDao : IDao
    {
        IList<Model.Forum> GetForums(int parentId);

        IList<Topic> GetTopics(int forumId);

        IList<Reply> GetReplies(int topicid);

        Topic LoadTopic(int topicid);

        void SaveReply(Reply reply);

        void SaveTopic(Topic topic);

        void UpdateTopicViewCount(int topicId);

        Model.Forum LoadForum(int forumid);

        UserInfo LoadUserInfo(int userId);

        void SaveUserInfo(UserInfo user);

        UserGrade LoadUserGrade(int gradeId);
    }
}
