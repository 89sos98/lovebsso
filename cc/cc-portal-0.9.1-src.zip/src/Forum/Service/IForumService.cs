#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Forum.Dao;
using CchenSoft.Portal.Forum.Model;
using CchenSoft.Portal.Spi;
using CchenSoft.Portal.Model;

namespace CchenSoft.Portal.Forum.Service
{
    public interface IForumService : IService
    {
        IForumDao ForumDao { set; }

        IList<Model.Forum> GetForums(int parentId);

        IList<Topic> GetTopics(int forumid);

        IList<Reply> GetReplies(int topicid);

        Topic LoadTopic(int topicid);

        void SaveReply(Reply reply);

        void SaveTopic(Topic topic);

        void UpdateTopicViewCount(int topicId);

        Model.Forum LoadForum(int forumid);

        UserInfo LoadUserInfo(int userId);

        void SaveUserInfo(UserInfo ui);

        UserGrade LoadUserGrade(int gradeId);

        void CheckUserInfo(User user);
    }
}
