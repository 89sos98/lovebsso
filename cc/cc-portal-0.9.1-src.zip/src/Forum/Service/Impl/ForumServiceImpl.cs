#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Forum.Dao;
using CchenSoft.Portal.Forum.Model;
using CchenSoft.Portal.Spi.Attribute;
using CchenSoft.Portal.Model;

namespace CchenSoft.Portal.Forum.Service.Impl
{
    public class ForumServiceImpl : IForumService
    {
        private IForumDao forumDao;
        private const string groupName = "forum";

        #region IService ��Ա

        public void Initialize()
        {
        }

        #endregion

        #region IForumService ��Ա

        public IForumDao ForumDao
        {
            set { this.forumDao = value; }
        }

        public IList<Model.Forum> GetForums(int parentId)
        {
            return forumDao.GetForums(parentId);
        }

        public IList<Topic> GetTopics(int forumId)
        {
            return forumDao.GetTopics(forumId);
        }

        public IList<Reply> GetReplies(int topicid)
        {
            return forumDao.GetReplies(topicid);
        }

        public Topic LoadTopic(int topicid)
        {
            return forumDao.LoadTopic(topicid);
        }

        [Transaction(TransactionOption.RequiresNew)]
        public void SaveTopic(Topic topic)
        {
            forumDao.SaveTopic(topic);
        }

        [Transaction(TransactionOption.RequiresNew)]
        public void SaveReply(Reply reply)
        {
            forumDao.SaveReply(reply);
        }

        public void UpdateTopicViewCount(int topicId)
        {
            forumDao.UpdateTopicViewCount(topicId);
        }

        public Model.Forum LoadForum(int forumid)
        {
            return forumDao.LoadForum(forumid);
        }

        [Cacheable(groupName)]
        public UserInfo LoadUserInfo(int userId)
        {
            return forumDao.LoadUserInfo(userId);
        }

        public void SaveUserInfo(UserInfo user)
        {
            forumDao.SaveUserInfo(user);
        }

        [Cacheable(groupName)]
        public UserGrade LoadUserGrade(int gradeId)
        {
            return forumDao.LoadUserGrade(gradeId);
        }


        public void CheckUserInfo(User user)
        {
            if (user != null)
            {
                UserInfo ui = LoadUserInfo(user.UserId);
                if (ui == null)
                {
                    ui = new UserInfo();
                    ui.UserId = user.UserId;
                    ui.Nickname = user.LoginName;
                    SaveUserInfo(ui);
                }
            }
        }

        #endregion
    }
}
