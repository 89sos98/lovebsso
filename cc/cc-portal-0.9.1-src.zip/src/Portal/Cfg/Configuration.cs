#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal.Service;
using System.Reflection;
using CchenSoft.Portal.Web.UI;
using System.Web;
using CchenSoft.Portal.Spi.Registry;
using CchenSoft.Portal.Spi;
using CchenSoft.Portal.Interceptor;
using CchenSoft.Portal.Spi.Interceptor;

namespace CchenSoft.Portal.Cfg
{
    public class Configuration
    {
        private string portletsPath;
        private string layoutsFile;
        private string themesFile;
        private string pluginsFile;
        
        private IList<IPortalInterceptor> serviceInterceptors;

        private static Configuration _instance = new Configuration();

        private Configuration()
        {
        }

        public static Configuration Instance
        {
            get { return _instance; }
        }

        public void Configure(string filename)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(filename);

            ParseConfig(doc.DocumentElement.SelectSingleNode("configuration"));

            serviceInterceptors = new List<IPortalInterceptor>();
            ParseServiceInterceptors(doc.DocumentElement.SelectSingleNode("service-interceptors"));

            portletsPath = doc.DocumentElement.SelectSingleNode("hot-deploy/portlets").InnerText;
            layoutsFile = doc.DocumentElement.SelectSingleNode("hot-deploy/layouts").InnerText;
            themesFile = doc.DocumentElement.SelectSingleNode("hot-deploy/themes").InnerText;
            pluginsFile = doc.DocumentElement.SelectSingleNode("hot-deploy/plugins").InnerText;
        }

        public IPortalInterceptor[] ServiceInterceptors
        {
            get { return new List<IPortalInterceptor>(serviceInterceptors).ToArray(); }
        }

        public string PortletsPath
        {
            get { return portletsPath; }
        }

        public string LayoutsFile
        {
            get { return layoutsFile; }
        }

        public string ThemesFile
        {
            get { return themesFile; }
        }

        public string PluginsFile
        {
            get { return pluginsFile; }
        }

        private void ParseConfig(XmlNode configNode)
        {
            XmlNodeList nodes = configNode.SelectSingleNode("plugins").SelectNodes("plugin");

            foreach (XmlNode node in nodes)
            {
                string category = node.Attributes.GetNamedItem("category").Value;
                string pluginName = node.InnerText;
                PluginRegistry.Instance.AddCategory(category, pluginName);
            }
       }

        private void ParseServiceInterceptors(XmlNode interceptorsNode)
        {
            XmlNodeList list = interceptorsNode.SelectNodes("interceptor");

            foreach (XmlNode node in list)
            {
                Type interceptorType = Type.GetType(node.Attributes.GetNamedItem("type").Value);
                if (interceptorType == null)
                    continue;

                IPortalInterceptor interceptor = (IPortalInterceptor)Activator.CreateInstance(interceptorType);
                serviceInterceptors.Add(interceptor);
            }
        }

    }
}
