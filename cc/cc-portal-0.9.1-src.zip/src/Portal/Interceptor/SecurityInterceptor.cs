#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Castle.DynamicProxy;
using System.Reflection;
using CchenSoft.Portal.Spi.Attribute;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal.Spi;
using CchenSoft.Portal.Spi.Interceptor;

namespace CchenSoft.Portal.Interceptor
{
    public class SecurityInterceptor : IPortalInterceptor
    {
        #region IInterceptor ��Ա

        public object Invoke(IPortalInvocation invocation)
        {
            SecurityAttribute[] attrs = ReflectUtil.GetCustomAttributes<SecurityAttribute>(invocation.Method);
            if (attrs != null && attrs.Length > 0)
            {
                Type serviceClass = invocation.Method.ReflectedType;
                if (typeof(IService).IsAssignableFrom(serviceClass))
                {
                    IModule module = PortalRegistry.Instance.GetModuleByServiceType(serviceClass);

                    for (int i = 0; i < attrs.Length; i++)
                    {
                        SecurityAttribute attr = attrs[i];
                        if (!ServiceLocator.UserService.HasPermission(module.Name, attr.Permission))
                        {
                            throw new SecurityException("has no permission: " + module.Name + "," + attr.Permission);
                        }
                    }
                }
            }

            return invocation.InvokeNext();
        }

        #endregion

    }
}
