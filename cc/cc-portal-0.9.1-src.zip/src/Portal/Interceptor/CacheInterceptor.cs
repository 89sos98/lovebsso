#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Castle.DynamicProxy;
using System.Reflection;
using CchenSoft.Portal.Spi.Attribute;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Spi.Interceptor;

namespace CchenSoft.Portal.Interceptor
{
    public class CacheInterceptor : IPortalInterceptor
    {
        private ICacheService cacheService;

        public ICacheService CacheService
        {
            get
            {
                if (cacheService == null)
                {
                    cacheService = PluginLocator.GetPluginService<ICacheService>("cache");
                }
                return cacheService;
            }
        }

        #region IInterceptor ��Ա

        public object Invoke(IPortalInvocation invocation)
        {
            CacheableAttribute[] attrs = ReflectUtil.GetCustomAttributes<CacheableAttribute>(invocation.Method);
            if (attrs != null && attrs.Length > 0)
            {
                string module = attrs[0].Module;

                string key = invocation.Method.Name + GetCacheKey(invocation.Args);

                object result = CacheService.GetItem(module, key);

                if (result == null)
                {
                    result = invocation.InvokeNext();
                    CacheService.AddItem(module, key, result);                    
                }

                return result;
            }

            return invocation.InvokeNext();
        }

        #endregion

        private string GetCacheKey(object[] args)
        {
            if (args == null)
                return "";

            string result = "";

            for (int i = 0; i < args.Length; i++)
            {
                result += "_" + ((args[i] != null) ? args[i] : "nil");
            }

            return result;
        }
    }
}
