#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Castle.DynamicProxy;
using System.Reflection;
using CchenSoft.Portal.Spi.Interceptor;

namespace CchenSoft.Portal.Interceptor
{
    public class DefaultPortalInvocation : IPortalInvocation
    {
        private IPortalInterceptor[] interceptors;
        private IInvocation invocation;
        private object[] args;
        private int index = 0;

        public DefaultPortalInvocation(IPortalInterceptor[] interceptors, IInvocation invocation, params object[] args)
        {
            this.interceptors = interceptors;
            this.invocation = invocation;
            this.args = args;
        }

        #region IPortalInvocation ��Ա

        public object InvokeNext()
        {
            if (index < interceptors.Length)
                return interceptors[index++].Invoke(this);

            return invocation.Proceed(args);
        }

        public MethodInfo Method
        {
            get { return invocation.Method; }
        }

        public object[] Args
        {
            get { return args; }
        }

        #endregion
    }
}
