#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Quartz;
using System.IO;
using CchenSoft.Portal.Registry;

namespace CchenSoft.Portal.Job
{
    public class DeployPortletJob : IJob
    {
        #region IJob ��Ա

        public void Execute(JobExecutionContext context)
        {
            string folder = (string)context.JobDetail.JobDataMap.Get("PortletsFolder");
            DeployUtil.DeployPortlet(folder);
        }

        #endregion

    }
}
