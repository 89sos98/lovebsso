#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Dao;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal.Spi.Registry;
using CchenSoft.Portal.Spi.Attribute;

namespace CchenSoft.Portal.Service.Impl
{
    public class PortalServiceImpl : IPortalService
    {
        private IPortalDao portalDao;
        private const string groupName = "portal";

        #region IService ��Ա

        public void Initialize()
        {
            portalDao.Initialize();
        }

        #endregion
        
        #region IPortalService ��Ա

        [Cacheable(groupName)]
        public PortalPage GetPortalPageByUrl(string pageUrl)
        {
            return portalDao.GetPortalPageByUrl(pageUrl);
        }

        [Cacheable(groupName)]
        public PortletInstance LoadPortletInstance(int instanceId)
        {
            return portalDao.LoadPortletInstance(instanceId);
        }

        [Cacheable(groupName)]
        public PortletInstance GetInstanceByPortlet(string portletId, int pageId)
        {
            return portalDao.GetInstanceByPortlet(portletId, pageId);
        }

        public IPortalDao PortalDao
        {
            set { this.portalDao = value; }
        }

        [Cacheable(groupName)]
        public IList<PortalPage> GetPortalPages(int parentId, int userId)
        {
            return portalDao.GetPortalPages(parentId, userId);
        }

        public void UpdatePreferences(int instanceId, string preferences)
        {
            portalDao.UpdatePreferences(instanceId, preferences);
        }

        [Cacheable(groupName)]
        public PortalPage GetPortalPageById(int pid)
        {
            return portalDao.GetPortalPageById(pid);
        }

        [Security("UPDATE_PORTALPAGE")]
        public void UpdatePortalPage(PortalPage page)
        {
            portalDao.UpdatePortalPage(page);
        }

        [Security("UPDATE_PORTALPAGE")]
        public void RemovePortletFromPage(PortalPage page, int instanceId)
        {
            portalDao.DeletePortletInstance(instanceId);

            page.Settings = page.Settings.Replace(instanceId + ",", "");
            UpdatePortalPage(page);
        }

        [Security("UPDATE_PORTALPAGE")]
        public void AddPortletToPage(PortalPage page, string portlet, int columnIndex)
        {
            // add portlet instance.
            PortletEntry entry = PortalRegistry.Instance.GetPortlet(portlet);
            int instanceId = 0;
            if (entry.Instanceable)
            {
                PortletInstance instance = new PortletInstance();
                instance.PortletId = portlet;
                instance.PageId = page.PageId;
                instance.UserId = page.UserId;
                instance.Title = entry.Caption;
                instance.Preferences = entry.Preferences;

                portalDao.InsertPortletInstance(instance);
                instanceId = instance.InstanceId;
            }
            else
            {
                PortletInstance instance = GetInstanceByPortlet(portlet, page.PageId);
                if (instance == null)
                {
                    instance = new PortletInstance();
                    instance.PortletId = portlet;
                    instance.PageId = page.PageId;
                    instance.UserId = page.UserId;
                    instance.Preferences = entry.Preferences;
                    portalDao.InsertPortletInstance(instance);
                }
                instanceId = instance.InstanceId;
            }

            // update portal page.
            string[] columns = page.Settings.Split(';');
            if (columns.Length > columnIndex)
            {
                columns[columnIndex] = columns[columnIndex] + instanceId + ",";
                page.Settings = string.Join(";", columns);
                UpdatePortalPage(page);
            }
        }

        public void AddPortletToPage(PortalPage page, string portlet)
        {
            AddPortletToPage(page, portlet, 0);
        }

        [Security("UPDATE_PORTALPAGE")]
        public void UpdateColumnInstances(int pageId, int columnIndex, string[] instances)
        {
            PortalPage page = GetPortalPageById(pageId);
            string[] columns = page.Settings.Split(';');
            if (columns.Length > columnIndex)
            {
                string name = columns[columnIndex].Split('=')[0];
                columns[columnIndex] = name + '=' + string.Join(",", instances) + ",";

                page.Settings = string.Join(";", columns);

                UpdatePortalPage(page);
            }
        }

        #endregion

        //private string GetRandomStr(int n)
        //{
        //    Random rnd = new Random();
        //    string str = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789";
        //    string result = "";
        //    for (int i = 0; i < n; i++)
        //        result += str[rnd.Next(str.Length)];
        //    return result;
        //}

    }
}
