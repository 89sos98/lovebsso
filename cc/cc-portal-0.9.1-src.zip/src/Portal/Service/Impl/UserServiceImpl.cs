#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Dao;
using System.Web;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Spi.Attribute;

namespace CchenSoft.Portal.Service.Impl
{
    public class UserServiceImpl : IUserService
    {
        private IUserDao userDao;
        private const string groupName = "portal";

        #region IUserDao ��Ա

        public IUserDao UserDao
        {
            set { this.userDao = value; }
        }

        public User SignIn(string name, string passwd, int cookieDay)
        {
            User user = userDao.ValidateLogin(name, passwd);
            if (user != null)
                WriteCookie(user, cookieDay);
            return user;
        }

        public void SignOut()
        {
            RemoveCookie();
        }

        public bool UserHasLogin
        {
            get 
            { 
                HttpCookie cookie = HttpContext.Current.Request.Cookies["portal_user"];
                if (cookie != null)
                {
                    return ConvertUtil.ToInt32(cookie["user_id"]) > 0;
                }
                return false;
            }
        }

        public User LoggedUser
        {
            get 
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies["portal_user"];
                if (cookie != null)
                {
                    int userId = ConvertUtil.ToInt32(cookie["user_id"]);
                    if (userId > 0)
                    {
                        return userDao.LoadUser(userId);
                    }
                }
                return null;
            }
        }

        public bool HasPermission(string module, string permission)
        {
            return true; // TODO
        }

        #endregion

        private void WriteCookie(User user, int cookieDay)
        {
            HttpCookie cookie = new HttpCookie("portal_user");
            cookie["user_id"] = user.UserId.ToString();
            cookie.Path = "/";
            if (cookieDay == 0)
                cookie.Expires = DateTime.Now.AddMinutes(20);
            else
                cookie.Expires = DateTime.Now.AddDays(cookieDay);

            HttpContext.Current.Response.Cookies.Add(cookie);
        }

        private void RemoveCookie()
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies["portal_user"];
            cookie.Expires = DateTime.Now.AddDays(-1);
            HttpContext.Current.Response.Cookies.Add(cookie);
        }


        #region IService ��Ա

        public void Initialize()
        {
            userDao.Initialize();
        }

        #endregion

        #region IUserService ��Ա

        [Cacheable(groupName)]
        public User GetUserByName(string name)
        {
            return userDao.GetUserByName(name);
        }

        public void SaveUser(User user)
        {
            userDao.SaveUser(user);
        }

        public IList<User> GetUsers(int pageIndex, int pageSize, ref int count)
        {
            return userDao.GetUsers(pageIndex, pageSize, ref count);
        }

        #endregion
    }
}
