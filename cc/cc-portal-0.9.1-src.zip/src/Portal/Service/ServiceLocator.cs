#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Spi;
using CchenSoft.Portal.Spi.Plugin;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal.Cfg;
using CchenSoft.Portal.Spi.Service;
using Castle.DynamicProxy;
using CchenSoft.Portal.Interceptor;
using CchenSoft.Portal.Spi.Registry;

namespace CchenSoft.Portal.Service
{
    public class ServiceLocator
    {
        private static Dictionary<string, IService> services = new Dictionary<string, IService>();

        public static void Initialize()
        {
            foreach (IService service in services.Values)
                service.Initialize();
        }

        public static void RegisterService(string name, IService service)
        {
            ProxyGenerator gen = new ProxyGenerator();
            IService serviceProxy = (IService)gen.CreateProxy(service.GetType().GetInterfaces(), new ServiceInterceptor(), service);

            services.Add(name, serviceProxy);
        }

        public static IPortalService PortalService
        {
            get
            {
                IModule module = PortalRegistry.Instance.GetModuleByName("root");
                if (module != null && module.Services.ContainsKey("IPortalService"))
                    return (IPortalService)module.Services["IPortalService"];
                return null;
            }
        }

        public static IUserService UserService
        {
            get
            {
                IModule module = PortalRegistry.Instance.GetModuleByName("root");
                if (module != null && module.Services.ContainsKey("IUserService"))
                    return (IUserService)module.Services["IUserService"];
                return null;
            }
        }

        public static IExportService ExportService
        {
            get
            {
                IModule module = PortalRegistry.Instance.GetModuleByName("root");
                if (module != null && module.Services.ContainsKey("IExportService"))
                    return (IExportService)module.Services["IExportService"];
                return null;
            }
        }

    }
}
