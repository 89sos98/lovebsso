#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal.Spi;
using CchenSoft.Portal.Spi.Registry;

namespace CchenSoft.Portal.Service
{
    public interface IExportService : IService
    {
        void UpdatePreferences(int instanceId, string preferences);

        PortletInstance LoadPortletInstance(int instanceId);

        PortletEntry GetPortlet(string portlet);
    }
}
