#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.Model
{
    public enum ViewType
    {
        Self,
        Guest,
        User,
    }

    public class PortalPage
    {
        private int pageId;
        private string name;
        private int userId;
        private string pageType;
        private string settings;
        private int parentId;
        private string friendlyUrl;
        private string layoutId;
        private string themeId;
        private int sortNo;
        private bool isHidden;
        private ViewType viewType;

        public int PageId
        {
            get { return pageId; }
            set { pageId = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        
        public int UserId
        {
            get { return userId; }
            set { userId = value; }
        }

        public string PageType
        {
            get { return pageType; }
            set { pageType = value; }
        }

        public string Settings
        {
            get { return settings; }
            set { settings = value; }
        }

        /// <summary>
        /// ��Id
        /// </summary>
        public int ParentId
        {
            get { return parentId; }
            set { parentId = value; }
        }

        /// <summary>
        /// �Ѻ�Url
        /// </summary>
        public string FriendlyUrl
        {
            get { return friendlyUrl; }
            set { friendlyUrl = value; }
        }

        /// <summary>
        /// ����Id
        /// </summary>
        public string LayoutId
        {
            get { return layoutId; }
            set { layoutId = value; }
        }

        /// <summary>
        /// ����Id
        /// </summary>
        public string ThemeId
        {
            get { return themeId; }
            set { themeId = value; }
        }

        /// <summary>
        /// �����
        /// </summary>
        public int SortNo
        {
            get { return sortNo; }
            set { sortNo = value; }
        }

        /// <summary>
        /// �Ƿ�����
        /// </summary>
        public bool IsHidden
        {
            get { return isHidden; }
            set { isHidden = value; }
        }

        /// <summary>
        /// ��ͼ����, 0: �Լ��ɼ�; 1: �����û��ɿ�; 2: ��Ա�ɼ�;
        /// </summary>
        public ViewType ViewType
        {
            get { return viewType; }
            set { viewType = value; }
        }
    }
}
