#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.Model
{
    public class User
    {
        private int userId;
        private string loginName;
        private string passwd;

        private string realName;
        private string email;
        private bool isAdmin;

        public int UserId
        {
            get { return userId; }
            set { userId = value; }
        }

        public string LoginName
        {
            get { return loginName; }
            set { loginName = value; }
        }

        public string Passwd
        {
            get { return passwd; }
            set { passwd = value; }
        }

        public string RealName
        {
            get { return realName; }
            set { realName = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public bool IsAdmin
        {
            get { return isAdmin; }
            set { isAdmin = value; }
        }
    }
}
