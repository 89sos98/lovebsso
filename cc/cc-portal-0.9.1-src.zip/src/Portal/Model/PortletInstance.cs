#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;

namespace CchenSoft.Portal.Model
{
    public class PortletInstance
    {
        private int instanceId;
        private string portletId;
        private string title;
        private int userId;
        private int pageId;
        private string preferences;
        private string dataInput;
        private string dataOutput;

        public int InstanceId
        {
            get { return instanceId; }
            set { instanceId = value; }
        }

        public string PortletId
        {
            get { return portletId; }
            set { portletId = value; }
        }

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public int UserId
        {
            get { return userId; }
            set { userId = value; }
        }

        public int PageId
        {
            get { return pageId; }
            set { pageId = value; }
        }

        public string Preferences
        {
            get { return preferences; }
            set { preferences = value; }
        }

        public string DataInput
        {
            get { return dataInput; }
            set { dataInput = value; }
        }

        public string DataOutput
        {
            get { return dataOutput; }
            set { dataOutput = value; }
        }

    }
}
