#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal.Spi.Registry;

namespace CchenSoft.Portal
{
    public class DeployUtil
    {
        private static object lockObj = new object();

        public static void DeployPortlet(string folder)
        {
            lock (lockObj)
            {
                PortalRegistry.Instance.RegisterModule(folder);

                string[] dirs = Directory.GetDirectories(folder);
                foreach (string dir in dirs)
                {
                    PortalRegistry.Instance.RegisterModule(dir);
                }
            }
        }

        public static void DeployPlugin(string folder)
        {
            lock (lockObj)
            {
                PluginRegistry.Instance.RegisterPlugin(folder);

                string[] dirs = Directory.GetDirectories(folder);
                foreach (string dir in dirs)
                {
                    PluginRegistry.Instance.RegisterPlugin(dir);
                }
            }
        }

        public static void DeployLayout(string layoutFile)
        {
            lock (lockObj)
            {
                LayoutRegistry.Instance.RegisterLayout(layoutFile);
            }
        }

        public static void DeployTheme(string themeFile)
        {
            lock (lockObj)
            {
                ThemeRegistry.Instance.RegisterTheme(themeFile);
            }
        }
    }
}
