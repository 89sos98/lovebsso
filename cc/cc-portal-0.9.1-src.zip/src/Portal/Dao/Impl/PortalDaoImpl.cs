#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Model;
using System.Collections;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Spi.Service;

namespace CchenSoft.Portal.Dao.Impl
{
    public class PortalDaoImpl : IPortalDao
    {
        private IDataService service;

        public PortalDaoImpl()
        {
        }

        #region IPortalDao ��Ա

        public PortalPage GetPortalPageByUrl(string pageUrl)
        {
            return service.QueryForObject<PortalPage>("GetPortalPageByUrl", pageUrl);
        }

        public PortalPage GetPortalPageById(int pageId)
        {
            return service.QueryForObject<PortalPage>("GetPortalPageById", pageId);
        }

        public PortletInstance LoadPortletInstance(int instanceId)
        {
            return service.QueryForObject<PortletInstance>("LoadPortletInstance", instanceId);
        }

        public IList<PortalPage> GetPortalPages(int parentId, int userId)
        {
            Hashtable map = new Hashtable();
            map["ParentId"] = parentId;
            map["UserId"] = userId;
            return service.QueryForList<PortalPage>("GetPortalPages", map);
        }

        public void UpdatePreferences(int instanceId, string preferences)
        {
            Hashtable dict = new Hashtable();
            dict["InstanceId"] = instanceId;
            dict["Preferences"] = preferences;
            service.Update("UpdatePreferences", dict);
        }

        public void UpdatePortalPage(PortalPage page)
        {
            service.Update("UpdatePortalPage", page);
        }

        public void InsertPortletInstance(PortletInstance instance)
        {
            service.Insert("InsertPortletInstance", instance);
        }

        public PortletInstance GetInstanceByPortlet(string portlet, int pageId)
        {
            Hashtable dict = new Hashtable();
            dict["Portlet"] = portlet;
            dict["PageId"] = pageId;
            return service.QueryForObject<PortletInstance>("GetInstanceByPortlet", dict);
        }

        public void DeletePortletInstance(int instanceId)
        {
            service.Delete("DeletePortletInstance", instanceId);
        }

        #endregion

        public IList Mappings
        {
            get { return mappings; }
            set { mappings = value; }
        }

        private IList mappings;

        #region IDao ��Ա

        public void Initialize()
        {
            service = PluginLocator.GetPluginService<IDataService>("data");
            service.Configure(mappings);
        }

        #endregion
    }
}
