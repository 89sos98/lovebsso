#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Model;
using System.Collections;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Service;

namespace CchenSoft.Portal.Dao.Impl
{
    public class UserDaoImpl : IUserDao
    {
        private IDataService service;

        public UserDaoImpl()
        {
        }

        #region IUserDao ��Ա

        public User ValidateLogin(string name, string passwd)
        {
            Hashtable dict = new Hashtable();
            dict["Name"] = name;
            dict["Passwd"] = passwd;
            return service.QueryForObject<User>("ValidateLogin", dict);
        }

        public User LoadUser(int userId)
        {
            return service.QueryForObject<User>("SelectUser", userId);
        }

        public User GetUserByName(string name)
        {
            return service.QueryForObject<User>("GetUserByName", name);
        }

        public void SaveUser(User user)
        {
            service.Insert("InsertUser", user);
        }

        public IList<User> GetUsers(int pageIndex, int pageSize, ref int count)
        {
            count = service.QueryForObject<int>("GetUserCount", null);
            return service.QueryForList<User>("SelectUser", null, (pageIndex - 1) * pageSize, pageSize);
        }

        #endregion

        public IList Mappings
        {
            get { return mappings; }
            set { mappings = value; }
        }

        private IList mappings;

        #region IDao ��Ա

        public void Initialize()
        {
            service = PluginLocator.GetPluginService<IDataService>("data");
            service.Configure(mappings);
        }

        #endregion
    }
}
