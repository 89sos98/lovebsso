#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Spi;

namespace CchenSoft.Portal.Dao
{
    public interface IPortalDao : IDao
    {
        PortalPage GetPortalPageByUrl(string pageUrl);

        PortletInstance LoadPortletInstance(int instanceId);

        IList<PortalPage> GetPortalPages(int parentId, int userId);

        void UpdatePreferences(int instanceId, string preferences);

        PortalPage GetPortalPageById(int pid);

        void UpdatePortalPage(PortalPage page);

        void InsertPortletInstance(PortletInstance instance);

        void DeletePortletInstance(int instanceId);

        PortletInstance GetInstanceByPortlet(string portletId, int pageId);
    }
}
