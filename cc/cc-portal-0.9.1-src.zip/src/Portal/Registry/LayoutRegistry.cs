#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace CchenSoft.Portal.Registry
{
    public class LayoutRegistry
    {
        private static LayoutRegistry instance = new LayoutRegistry();
        private IDictionary<string, LayoutTemplate> layouts;
        private DateTime lastWriteTime;

        private LayoutRegistry()
        {
            layouts = new Dictionary<string, LayoutTemplate>();
            lastWriteTime = DateTime.MinValue;
        }

        public static LayoutRegistry Instance
        {
            get { return instance; }
        }

        public void RegisterLayout(string file)
        {
            FileInfo fi = new FileInfo(file);
            if (fi.LastWriteTime > lastWriteTime)
            {
                layouts.Clear();

                XmlDocument doc = new XmlDocument();
                doc.Load(file);

                XmlNodeList list = doc.DocumentElement.SelectNodes("layout-template");
                foreach (XmlNode node in list)
                {
                    string id = node.Attributes.GetNamedItem("id").Value;
                    string name = node.Attributes.GetNamedItem("name").Value;
                    string templatePath = node.SelectSingleNode("template-path").InnerText;
                    string thumbnailPath = node.SelectSingleNode("thumbnail-path").InnerText;

                    LayoutTemplate temp = new LayoutTemplate();
                    temp.Name = name;
                    temp.TempId = id;
                    temp.TemplatePath = templatePath;
                    temp.ThumbnailPath = thumbnailPath;

                    layouts.Add(id, temp);
                }
                lastWriteTime = fi.LastWriteTime;
            }
        }

        public LayoutTemplate MaxLayout
        {
            get { return GetLayoutTemplate("max"); }
        }

        public LayoutTemplate GetLayoutTemplate(string tempId)
        {
            return layouts[tempId];
        }
    }
}
