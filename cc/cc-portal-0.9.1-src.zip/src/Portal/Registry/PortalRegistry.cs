#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Net;
using System.IO;
using System.Reflection;
using System.Collections;
using System.Web;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Spi;
using CchenSoft.Portal.Spi.Registry;
using CchenSoft.Portal.Spi.Plugin;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Spi.Service;

namespace CchenSoft.Portal.Registry
{
    public class PortalRegistry
    {
        private static PortalRegistry instance = new PortalRegistry();

        private IDictionary<string, IModule> modulesByFolder;
        private IDictionary<string, IModule> modulesByName;
        private IDictionary<Type, IModule> modulesByService;

        private IDictionary<string, PortletEntry> portlets;
        private IDictionary<string, IHttpHandler> handlers;

        private PortalRegistry()
        {
            modulesByFolder = new Dictionary<string, IModule>();
            modulesByName = new Dictionary<string, IModule>();
            modulesByService = new Dictionary<Type, IModule>();

            portlets = new Dictionary<string, PortletEntry>();
            handlers = new Dictionary<string, IHttpHandler>();
        }

        public static PortalRegistry Instance
        {
            get { return instance; }
        }

        public IList<PortletEntry> Portlets
        {
            get { return new List<PortletEntry>(portlets.Values); }
        }

        public IList<IModule> Modules
        {
            get { return new List<IModule>(modulesByFolder.Values); }
        }

        public IDictionary<string, IHttpHandler> Handlers
        {
            get { return handlers; }
        }

        public IModule GetModuleByDomain(string domainName)
        {
            foreach (IModule module in modulesByFolder.Values)
            {
                if (module.DomainName.Equals(domainName))
                    return module;
            }
            return null;
        }

        public IModule GetModule(string folder)
        {
            if (modulesByFolder.ContainsKey(folder))
            {
                return modulesByFolder[folder];
            }
            else
            {
                int n = folder.TrimEnd('\\').LastIndexOf('\\');
                if (n > -1)
                {
                    string parentFolder = folder.Substring(0, n + 1);
                    return GetModule(parentFolder);
                }
                return null;
            }
        }

        public void RegisterHttpHandler(HandlerEntry entry)
        {
            IHttpHandler handler = (IHttpHandler)Activator.CreateInstance(entry.HandlerType);
            handlers.Add(entry.Pattern, handler);
        }

        public IModule RegisterModule(string folder)
        {
            string folder2 = folder.ToLower();
            if (!folder2.EndsWith("\\"))
                folder2 += "\\";

            string configFile = folder2 + "portlet.config";
            FileInfo fi = new FileInfo(configFile);

            if (modulesByFolder.ContainsKey(folder2))
            {
                IModule module = modulesByFolder[folder2];
                if (fi.Exists)
                {
                    // update.
                    if (fi.LastWriteTime > module.LastWriteTime)
                        UnregisterModule(folder2);
                }
                else
                {
                    // delete.
                    UnregisterModule(folder2);
                }
            }

            if (!modulesByFolder.ContainsKey(folder2))
            {
                // add.
                if (!fi.Exists)
                    return null;

                BootLogger.Instance.Info("register module: " + folder2, this.GetType());

                XmlDocument doc = new XmlDocument();
                doc.Load(configFile);
                XmlNode node = doc.DocumentElement.SelectSingleNode("module-type");
                if (node != null && !string.IsNullOrEmpty(node.InnerText))
                {
                    Type moduleType = Type.GetType(node.InnerText);
                    IModule module = (IModule)Activator.CreateInstance(moduleType);
                    module.Folder = folder2;
                    module.Path = HttpUtil.ConvertFolderToPath(folder2);
                    module.LastWriteTime = fi.LastWriteTime;
                    module.Configure(doc);

                    // add portlets.
                    foreach (PortletEntry entry in module.Portlets)
                    {
                        portlets.Add(entry.PortletId, entry);
                    }

                    foreach (IService service in module.ServiceList)
                    {
                        modulesByService.Add(service.GetType(), module);
                    }

                    // add httpHandlers.
                    foreach (HandlerEntry entry in module.Handlers)
                    {
                        IHttpHandler handler = (IHttpHandler)Activator.CreateInstance(entry.HandlerType);
                        handlers.Add(entry.Pattern, handler);
                    }

                    // set parent module.
                    int n = folder2.TrimEnd('\\').LastIndexOf('\\');
                    if (n > -1)
                    {
                        string parentPath = folder2.Substring(0, n + 1);
                        module.Parent = RegisterModule(parentPath);
                    }

                    modulesByFolder[folder2] = module;
                    modulesByName[module.Name] = module;
                }
            }

            return modulesByFolder[folder2];
        }

        public void UnregisterModule(string folder)
        {
            if (modulesByFolder.ContainsKey(folder))
            {
                IModule module = modulesByFolder[folder];
                //domainServices.Remove(entry);
                foreach (PortletEntry entry in module.Portlets)
                    portlets.Remove(entry.PortletId);

                foreach (HandlerEntry entry in module.Handlers)
                    handlers.Remove(entry.Pattern);

                foreach (IService service in module.Services.Values)
                    modulesByService.Remove(service.GetType());

                modulesByFolder.Remove(folder);
                modulesByName.Remove(module.Name);

                BootLogger.Instance.Info("unregister module: " + folder, this.GetType());
            }
        }

        public PortletEntry GetPortlet(string portletId)
        {
            return portlets[portletId];
        }

        private string GetNodeValue(XmlNode node)
        {
            if (node == null)
                return "";

            if (node is XmlElement)
                return node.InnerText;
            else if (node is XmlAttribute)
                return node.Value;
            else
                return node.InnerText;
        }

        private string GetPortletConfig(Uri url)
        {
            string pcUrl = url.ToString();
            if (!pcUrl.EndsWith("/"))
                pcUrl += "/";

            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(pcUrl + "portlet.config");
            HttpWebResponse resp = (HttpWebResponse)req.GetResponse();

            StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8);
            StringBuilder ret = new StringBuilder();
            int BufferLengh = 8 * 1024;  // 8K
            char[] buf = new char[BufferLengh];
            int len = sr.Read(buf, 0, BufferLengh);
            while (len > 0)
            {
                ret.Append(new string(buf, 0, len));
                len = sr.Read(buf, 0, BufferLengh);
            }

            return ret.ToString();
        }

        public IModule GetModuleByServiceType(Type serviceClass)
        {
            foreach (Type type in modulesByService.Keys)
            {
                if (type.IsAssignableFrom(serviceClass))
                    return modulesByService[serviceClass];
            }
            return null;
        }

        internal IModule GetModuleByName(string moduleName)
        {
            if (modulesByName.ContainsKey(moduleName))
                return modulesByName[moduleName];
            return null;
        }
    }
}
