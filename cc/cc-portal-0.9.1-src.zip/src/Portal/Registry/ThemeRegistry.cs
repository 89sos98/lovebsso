#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace CchenSoft.Portal.Registry
{
    public class ThemeRegistry
    {
        private static ThemeRegistry instance = new ThemeRegistry();
        private IDictionary<string, Theme> themes;
        private DateTime lastWriteTime;

        private ThemeRegistry()
        {
            themes = new Dictionary<string, Theme>();
            lastWriteTime = DateTime.MinValue;
        }

        public static ThemeRegistry Instance
        {
            get { return instance; }
        }

        public void RegisterTheme(string file)
        {
            FileInfo fi = new FileInfo(file);
            if (fi.LastWriteTime > lastWriteTime)
            {
                themes.Clear();

                XmlDocument doc = new XmlDocument();
                doc.Load(file);

                XmlNodeList list = doc.DocumentElement.SelectNodes("theme");
                foreach (XmlNode node in list)
                {
                    string id = node.Attributes.GetNamedItem("id").Value;
                    string name = node.Attributes.GetNamedItem("name").Value;
                    string rootPath = node.SelectSingleNode("root-path").InnerText;
                    string templatesPath = node.SelectSingleNode("templates-path").InnerText;
                    string imagesPath = node.SelectSingleNode("images-path").InnerText;

                    Theme theme = new Theme();
                    theme.Name = name;
                    theme.RootPath = rootPath;
                    theme.TemplatesPath = templatesPath;
                    theme.ImagesPath = imagesPath;

                    themes.Add(id, theme);
                }

                lastWriteTime = fi.LastWriteTime;
            }
        }

        public Theme GetTheme(string themeId)
        {
            return themes[themeId];
        }
    }
}
