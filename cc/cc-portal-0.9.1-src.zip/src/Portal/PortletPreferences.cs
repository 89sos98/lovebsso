#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Service;
using System.IO;

namespace CchenSoft.Portal
{
    public class PortletPreferences
    {
        private IDictionary<string, string> preferences;

        private PortletPreferences()
        {
            preferences = new Dictionary<string, string>();
        }

        public string ToXml()
        {
            MemoryStream ms = new MemoryStream();
            XmlTextWriter writer = new XmlTextWriter(ms, Encoding.Default);
            writer.WriteStartElement("preferences");

            foreach (string name in preferences.Keys)
            {
                writer.WriteStartElement("preference");
                writer.WriteElementString("name", name);
                writer.WriteElementString("value", preferences[name]);
                writer.WriteEndElement();
            }

            writer.WriteEndElement();
            writer.Flush();

            return Encoding.Default.GetString(ms.GetBuffer(), 0, (int)ms.Length);
        }

        public void AddPreference(string name, string value)
        {
            preferences.Add(name, value);
        }

        public static PortletPreferences FromXml(string xml)
        {
            PortletPreferences prefs = new PortletPreferences();

            if (string.IsNullOrEmpty(xml))
                return prefs;

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);

            XmlNodeList list = doc.DocumentElement.SelectNodes("preference");

            foreach (XmlNode node in list)
            {
                string name = GetNodeText(node.SelectSingleNode("name"));
                string value = GetNodeText(node.SelectSingleNode("value"));
                if (!string.IsNullOrEmpty(name))
                    prefs.AddPreference(name, value);
            }

            return prefs;
        }

        private static string GetNodeText(XmlNode xmlNode)
        {
            if (xmlNode != null)
                return xmlNode.InnerText;

            return "";
        }

        public int GetInt32(string name)
        {
            if (preferences.ContainsKey(name))
                return ConvertUtil.ToInt32(preferences[name]);
            return 0;
        }

        public string GetString(string name)
        {
            if (preferences.ContainsKey(name))
                return preferences[name];
            return "";
        }

        public void SetValue(string name, string value)
        {
            preferences[name] = value;
        }

        public void SetValue(string name, bool value)
        {
            preferences[name] = value ? "true" : "false";
        }

        public bool GetBoolean(string name)
        {
            if (preferences.ContainsKey(name))
                return preferences[name] == "true";
            return false;
        }
    }


}
