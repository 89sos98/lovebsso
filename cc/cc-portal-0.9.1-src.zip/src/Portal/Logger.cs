using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Spi.Plugin;
using CchenSoft.Portal.Spi.Registry;

namespace CchenSoft.Portal.Service
{
    public class Logger
    {
        private static ILogService service;

        static Logger()
        {
            service = PluginLocator.GetPluginService<ILogService>("logging");
        }

        public static void Info(string message, Type type)
        {
            if (service != null)
                service.Info(message, type);
        }

        public static void Warn(string message, Type type)
        {
            if (service != null)
                service.Warn(message, type);
        }

        public static void Debug(string message, Type type)
        {
            if (service != null)
                service.Debug(message, type);
        }

        public static void Error(string message, Type type)
        {
            if (service != null)
                service.Error(message, type);
        }

    }
}
