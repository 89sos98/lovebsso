#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Registry;
using System.Xml;
using System.Collections;
using System.Reflection;
using System.Web;
using CchenSoft.Portal.Spi;
using CchenSoft.Portal.Spi.Registry;
using Castle.DynamicProxy;
using CchenSoft.Portal.Interceptor;

namespace CchenSoft.Portal
{
    public class GeneralModule : IModule
    {
        private string moduleId;
        private string moduleName;
        private string domainName;
        private string path;
        private string folder;
        private IModule parent;
        private DateTime lastWriteTime = DateTime.MinValue;

        protected IDictionary<string, IService> services;
        protected IList<IService> serviceList;
        protected IDictionary<string, PortletEntry> portlets;
        protected IDictionary<string, HandlerEntry> handlers;

        public GeneralModule()
        {
            serviceList = new List<IService>();
        }

        #region IModule ��Ա

        public string Name
        {
            get { return moduleName; }
        }

        public string Path
        {
            get { return path; }
            set { path = value; }
        }

        public string Folder
        {
            get { return folder; }
            set { folder = value; }
        }

        public DateTime LastWriteTime
        {
            get { return lastWriteTime; }
            set { lastWriteTime = value; }
        }

        public IModule Parent
        {
            get { return parent; }
            set { parent = value; }
        }

        public string ModuleId
        {
            get { return moduleId; }
        }

        public string DomainName
        {
            get { return domainName; }
        }

        public IList<PortletEntry> Portlets
        {
            get { return new List<PortletEntry>(portlets.Values); }
        }

        public IList<HandlerEntry> Handlers
        {
            get { return new List<HandlerEntry>(handlers.Values); }
        }

        public IDictionary<string, IService> Services
        {
            get { return services; }
        }

        public IList<IService> ServiceList
        {
            get { return serviceList; }
        }

        public void Configure(XmlDocument doc)
        {
            moduleId = GetNodeValue(doc.DocumentElement.SelectSingleNode("module-id"));
            moduleName = GetNodeValue(doc.DocumentElement.SelectSingleNode("module-name"));
            domainName = GetNodeValue(doc.DocumentElement.SelectSingleNode("domain-name"));

            // parse service.
            services = ParseServices(doc.DocumentElement.SelectNodes("service"));

            // parse portlet.
            portlets = ParsePortlets(doc.DocumentElement.SelectNodes("portlet"));

            // parse httpHandlers
            handlers = ParseHandlers(doc.DocumentElement.SelectNodes("httpHandler"));
        }

        public virtual void BeginRequest(HttpContext context)
        {
            // do nothing.
        }

        public virtual void HandleDomain(string domainName, HttpContext context)
        {
            // do nothing.
        }

        #endregion

        #region helper methods.

        private IDictionary<string, HandlerEntry> ParseHandlers(XmlNodeList list)
        {
            IDictionary<string, HandlerEntry> hes = new Dictionary<string, HandlerEntry>();

            if (list == null)
                return hes;

            foreach (XmlNode node in list)
            {
                HandlerEntry he = new HandlerEntry();
                
                string pattern = GetNodeValue(node.Attributes.GetNamedItem("pattern"));
                if (pattern.StartsWith("~/"))
                    pattern = path + pattern.Substring(2);

                he.Pattern = pattern;
                he.Verb = GetNodeValue(node.Attributes.GetNamedItem("verb"));
                he.HandlerType = Type.GetType(GetNodeValue(node.Attributes.GetNamedItem("type")));

                hes.Add(he.Pattern, he);
            }

            return hes;
        }

        private IDictionary<string, PortletEntry> ParsePortlets(XmlNodeList list)
        {
            IDictionary<string, PortletEntry> pes = new Dictionary<string, PortletEntry>();

            foreach (XmlNode node in list)
            {
                PortletEntry pi = new PortletEntry();

                pi.PortletId = GetNodeValue(node.SelectSingleNode("portlet-id"));
                pi.Caption = GetNodeValue(node.SelectSingleNode("display-name"));
                pi.RootPath = GetNodeValue(node.SelectSingleNode("root-path"));
                pi.ViewPath = GetNodeValue(node.SelectSingleNode("view-path"));
                pi.ConfigPath = GetNodeValue(node.SelectSingleNode("config-path"));
                pi.Preferences = node.SelectSingleNode("preferences").OuterXml;
                pi.Instanceable = GetNodeValue(node.SelectSingleNode("instanceable")).Equals("true");
                pi.IsProducer = GetNodeValue(node.SelectSingleNode("is-producer")).Equals("true");

                pes.Add(pi.PortletId, pi);
            }

            return pes;
        }

        private IDictionary<string, IService> ParseServices(XmlNodeList list)
        {
            IDictionary<string, IService> services = new Dictionary<string, IService>();

            foreach (XmlNode node in list)
            {
                string serviceName = node.Attributes.GetNamedItem("name").Value;
                Type serviceType = Type.GetType(node.Attributes.GetNamedItem("type").Value);
                if (serviceType == null)
                    continue;

                IService service = (IService)Activator.CreateInstance(serviceType);

                XmlNodeList list2 = node.SelectNodes("property");

                foreach (XmlNode node2 in list2)
                {
                    string name = node2.Attributes.GetNamedItem("name").Value;
                    object value = null;

                    if (node2.ChildNodes.Count > 0)
                    {
                        XmlNode valueNode = node2.ChildNodes[0];

                        if (valueNode.Name.Equals("dao"))
                        {
                            value = ParseDao(valueNode);
                        }
                        if (valueNode.Name.Equals("type"))
                        {
                            Type type = Type.GetType(valueNode.InnerText);
                            if (type != null)
                                value = Activator.CreateInstance(type);
                        }
                        else if (valueNode.Name.Equals("string"))
                        {
                            value = valueNode.InnerText;
                        }
                        else if (valueNode.Equals("integer"))
                        {
                            value = Convert.ToInt32(valueNode.InnerText);
                        }
                        else if (valueNode.Equals("list"))
                        {
                            ArrayList items = new ArrayList();

                            XmlNodeList itemList = valueNode.SelectNodes("item");
                            foreach (XmlNode itemNode in itemList)
                            {
                                items.Add(itemNode.InnerText);
                            }

                            value = list;
                        }
                    }
                    else
                    {
                        value = node2.InnerText;
                    }

                    PropertyInfo pi = service.GetType().GetProperty(name);
                    if (pi != null)
                    {
                        pi.SetValue(service, value, null);
                    }
                }

                service.Initialize();

                serviceList.Add(service);

                // ���� proxy.
                ProxyGenerator gen = new ProxyGenerator();                
                IService serviceProxy = (IService)gen.CreateProxy(serviceType.GetInterfaces(), new ServiceInterceptor(), service);
                services.Add(serviceName, serviceProxy);
            }

            return services;
        }

        private IDao ParseDao(XmlNode daoNode)
        {
            Type daoType = Type.GetType(daoNode.Attributes.GetNamedItem("type").Value);
            if (daoType == null)
                return null;

            IDao dao = (IDao)Activator.CreateInstance(daoType);

            XmlNodeList list2 = daoNode.SelectNodes("property");

            foreach (XmlNode node2 in list2)
            {
                string name = node2.Attributes.GetNamedItem("name").Value;
                object value = null;

                if (node2.ChildNodes.Count > 0)
                {
                    XmlNode valueNode = node2.ChildNodes[0];

                    if (valueNode.Name.Equals("list"))
                    {
                        ArrayList items = new ArrayList();

                        XmlNodeList itemList = valueNode.SelectNodes("item");
                        foreach (XmlNode itemNode in itemList)
                        {
                            items.Add(itemNode.InnerText);
                        }

                        value = items;
                    }
                }
                else
                {
                    value = node2.InnerText;
                }

                PropertyInfo pi = dao.GetType().GetProperty(name);
                if (pi != null)
                {
                    pi.SetValue(dao, value, null);
                }

            }
            dao.Initialize();
            return dao;
        }

        private string GetNodeValue(XmlNode node)
        {
            if (node == null)
                return "";

            if (node is XmlElement)
                return node.InnerText;
            else if (node is XmlAttribute)
                return node.Value;
            else
                return node.InnerText;
        }

        #endregion

    }
}
