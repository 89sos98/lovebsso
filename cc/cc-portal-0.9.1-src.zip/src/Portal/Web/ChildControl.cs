#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;

namespace CchenSoft.Portal.Web
{
    [ParseChildren(true)]
    public abstract class ChildControl : Control, INamingContainer
    {
        protected override void CreateChildControls()
        {
            Control control = this.LoadSkin();
            this.InitializeSkin(control);
            this.Controls.Add(control);
        }

        protected abstract void InitializeSkin(Control control);

        protected abstract Control LoadSkin();
    }
}
