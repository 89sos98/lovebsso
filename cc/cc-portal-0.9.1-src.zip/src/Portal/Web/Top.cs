#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Model;

namespace CchenSoft.Portal.Web
{
    [ParseChildren(true)]
    public class Top : ThemeControl
    {
        public Top()
        {
            SkinFileName = "portal_top.ascx";
        }

        protected override void InitializeSkin(Control control)
        {            
            IList<PortalPage> pages = ServiceLocator.PortalService.GetPortalPages(0, PortalContext.Current.PortalPage.UserId);

            HyperLink hlnkLogin = (HyperLink)control.FindControl("hlnkLogin");
            if (PortalContext.Current.User != null)
            {
                hlnkLogin.NavigateUrl = "~/command.aspx?action=logout";
                hlnkLogin.Text = "logout";
            }
            else
            {
                hlnkLogin.NavigateUrl = "~/login.aspx";
                hlnkLogin.Text = "login";

                HyperLink hlnkAddContent = (HyperLink)control.FindControl("hlnkAddContent");
                hlnkAddContent.Visible = false;
            }
            
            Repeater rMenu = (Repeater)control.FindControl("rMenu");
            rMenu.DataSource = pages;
            rMenu.ItemDataBound += new RepeaterItemEventHandler(rMenu_ItemDataBound);
            rMenu.DataBind();
        }

        void rMenu_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                PortalPage page = (PortalPage)e.Item.DataItem;

                HyperLink hMenu = (HyperLink)e.Item.FindControl("hMenu");
                hMenu.Text = page.Name;
                hMenu.NavigateUrl = page.FriendlyUrl;
            }
        }
    }
}
