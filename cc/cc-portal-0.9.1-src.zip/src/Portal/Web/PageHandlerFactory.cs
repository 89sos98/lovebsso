#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.Compilation;
using CchenSoft.Portal.Registry;

namespace CchenSoft.Portal.Web
{
    public class PageHandlerFactory : IHttpHandlerFactory
    {
        #region IHttpHandlerFactory ��Ա

        public IHttpHandler GetHandler(HttpContext context, string requestType, string url, string pathTranslated)
        {
            IHttpHandler handler = GetHandler(url);
            if (handler != null)
                return handler;

            return BuildManager.CreateInstanceFromVirtualPath(url, typeof(Page)) as IHttpHandler;
        }

        private IHttpHandler GetHandler(string url)
        {
            IDictionary<string, IHttpHandler> handlers = PortalRegistry.Instance.Handlers;
            if (handlers.ContainsKey(url))
                return handlers[url];

            foreach (string pattern in handlers.Keys)
            {
                if (!pattern.StartsWith("/") && (url.EndsWith(pattern)))
                {
                    return handlers[pattern];
                }
            }

            return null;
        }

        public void ReleaseHandler(IHttpHandler handler)
        {
        }

        #endregion
    }
}
