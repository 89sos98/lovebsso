#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Collections.Specialized;
using System.Xml;
using System.IO;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Model;

namespace CchenSoft.Portal.Web
{
    public class PortalURL
    {
        private string reqPath = "";
        private WindowState windowState;
        private NameValueCollection reqParams = new NameValueCollection();
        //private string commandName;
        //private string commandArgs;

        private PortalURL()
        {
        }

        public PortalURL(HttpRequest request)
        {
            reqPath = request.Path;
            reqParams = new NameValueCollection(request.QueryString);
            windowState = (WindowState)ConvertUtil.ToInt32(reqParams["window_state"]);
        }

        public PortalURL(string path, string queryString)
        {
            reqPath = path;
            reqParams = HttpUtility.ParseQueryString(queryString);
            windowState = (WindowState)ConvertUtil.ToInt32(reqParams["window_state"]);
        }

        public PortalURL Clone()
        {
            PortalURL url = new PortalURL();
            url.reqPath = this.reqPath;
            url.reqParams = new NameValueCollection(reqParams);
            return url;
        }

        public string RequestPath
        {
            get { return reqPath; }
        }

        public NameValueCollection RequestParams
        {
            get { return reqParams; }
        }

        public string ToXml()
        {
            bool needComma = false;
            StringBuilder sb = new StringBuilder();
            foreach (string name in reqParams)
            {
                if (needComma)
                    sb.Append("&");

                sb.AppendFormat("{0}={1}", name, reqParams[name]);
                needComma = true;
            }

            return "request-path=" + reqPath + ";request-params=" + ConvertUtil.ToBase64String(sb.ToString());
        }

        public static PortalURL FromXml(string xml)
        {
            PortalURL url = new PortalURL();

            if (string.IsNullOrEmpty(xml))
                return url;

            string[] ss = xml.Split(';');

            foreach (string s in ss)
            {
                int n = s.IndexOf('=');
                if (n == -1)
                    continue;

                string name = s.Substring(0, n);
                string value = s.Substring(n + 1);

                if (name.Equals("request-path"))
                    url.reqPath = value;
                else if (name.Equals("request-params"))
                    url.reqParams = HttpUtility.ParseQueryString(ConvertUtil.FromBase64String(value));
            }

            return url;
        }

        public string GetInstanceParams(int instanceId)
        {
            StringBuilder sb = new StringBuilder();
            bool needSep = false;
            string prefix = "_" + instanceId;
            foreach (string name in reqParams)
            {
                if (name.Equals(prefix + "_action"))
                    continue;

                if (name.StartsWith(prefix + "_"))
                {
                    if (needSep)
                        sb.AppendFormat("&");
                    sb.AppendFormat("{0}={1}", name.Substring(prefix.Length + 1), reqParams[name]);
                    needSep = true;
                }
            }
            return sb.ToString();
        }

        public string GetInstanceAction(int instanceId)
        {
            string name = "_" + instanceId + "_action";
            return reqParams[name];
        }

        public string ToURLString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(reqPath);

            if (reqParams.Count > 0)
                sb.Append("?");

            bool needComma = false;
            foreach (string name in reqParams)
            {
                if (needComma)
                    sb.Append("&");

                sb.AppendFormat("{0}={1}", name, reqParams[name]);
                needComma = true;
            }

            return sb.ToString();
        }

        public void AppendParam(string name, string value)
        {
            reqParams.Remove(name);
            reqParams.Add(name, value);
        }

        public void RemoveParam(string name)
        {
            reqParams.Remove(name);
        }

        public WindowState WindowState
        {
            get 
            { 
                return this.windowState; 
            }
            set 
            { 
                AppendParam("window_state", ((int)value).ToString());
                this.windowState = value; 
            }
        }

        public void SetMaxInstance(int instId)
        {
            AppendParam("max_instance", instId.ToString());
        }

        public int GetMaxInstance()
        {
            return ConvertUtil.ToInt32(reqParams["max_instance"]);
        }

        public string GetMaxPortlet()
        {
            return reqParams["max_portlet"];
        }
    }
}
