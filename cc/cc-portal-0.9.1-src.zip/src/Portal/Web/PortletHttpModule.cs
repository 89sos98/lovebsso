#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.IO;
using CchenSoft.Portal.Cfg;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal.Spi;

namespace CchenSoft.Portal.Web
{
    public class PortletHttpModule : IHttpModule
    {
        private void Application_BeginRequest(object sender, EventArgs e)
        {
            HttpContext context = ((HttpApplication)sender).Context;

            string path = context.Request.Path.ToLower();

            if (path.EndsWith(".aspx"))
            {
                PortletContext pc = null;

                if (path.StartsWith(Cfg.Configuration.Instance.PortletsPath))
                {
                    string portletPath = path.Substring(0, path.LastIndexOf('/') + 1);

                    string portletFolder = context.Server.MapPath(portletPath).ToLower();
                    if (!portletFolder.EndsWith("\\"))
                        portletFolder += "\\";

                    IModule module = PortalRegistry.Instance.GetModule(portletFolder);

                    if (module != null)
                    {
                        module.BeginRequest(context);
                    }

                    pc = new PortletContext(module);
                }
                else
                {
                    pc = new PortletContext();
                }

                context.Items["portlet_context"] = pc;
            }
        }

        #region IHttpModule ��Ա

        public void Dispose()
        {
        }

        public void Init(HttpApplication context)
        {
            context.BeginRequest += new EventHandler(Application_BeginRequest);
        }

        #endregion
    }
}
