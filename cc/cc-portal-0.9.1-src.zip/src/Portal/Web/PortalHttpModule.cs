#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.IO;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Registry;
using System.Collections.Generic;
using CchenSoft.Portal.Spi;
using CchenSoft.Portal.Spi.Service;

namespace CchenSoft.Portal.Web
{
    public class PortalHttpModule : IHttpModule
    {
        private void Application_BeginRequest(object sender, EventArgs e)
        {
            HttpContext context = ((HttpApplication)sender).Context;

            string portletInstanceId = context.Request.Headers["portlet-instanceId"];
            if (!string.IsNullOrEmpty(portletInstanceId))
                return;

            // handle domain.
            string domain = context.Request.ServerVariables["SERVER_NAME"];
            IModule module = PortalRegistry.Instance.GetModuleByDomain(domain);
            if (module != null)
                module.HandleDomain(domain, context);

            // process portal page.
            string path = context.Request.Path.ToLower();
            if (path.EndsWith("/"))
                path += "default.aspx";

            if (path.EndsWith(".aspx"))
            {
                PortalPage page = ServiceLocator.PortalService.GetPortalPageByUrl(path);

                if (page == null)
                {
                    int pid = ParamUtil.GetInt32(context.Request, "__pid");
                    page = ServiceLocator.PortalService.GetPortalPageById(pid);
                }

                if (page != null)
                {
                    //log.Info("found page: " + page.Name, this.GetType());

                    bool isGuest = true;
                    if (page.UserId > 0)
                    {
                        User user = ServiceLocator.UserService.LoggedUser;
                        if (user == null || page.UserId != user.UserId)
                        {
                            //IList<PortalPage> pages = ServiceLocator.PortalService.GetPortalPages(0, user.UserId);
                            context.Response.Redirect("/default.aspx");
                        }
                        isGuest = false;
                    }

                    PortalURL url = new PortalURL(context.Request);
                    PortalContext portalCtx = new PortalContext(page, url, context);
                    if (url.WindowState == WindowState.Maximized)
                        context.RewritePath(portalCtx.Theme.TemplatesPath + "portal_max.aspx");
                    else
                        context.RewritePath(portalCtx.Theme.TemplatesPath + "portal_normal.aspx");
                }
            }
        }

        #region IHttpModule ��Ա

        public void Dispose()
        {
        }

        public void Init(HttpApplication context)
        {
            context.BeginRequest += new EventHandler(Application_BeginRequest);
        }

        #endregion
    }
}
