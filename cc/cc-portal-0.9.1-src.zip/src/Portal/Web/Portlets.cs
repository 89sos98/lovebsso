#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal.Spi.Registry;

namespace CchenSoft.Portal.Web
{
    [ParseChildren(true)]
    public class Portlets : ThemeControl
    {
        public Portlets()
        {
            SkinFileName = "portlets.ascx";
        }

        protected override void InitializeSkin(Control control)
        {
            Repeater rPortlet = (Repeater)control.FindControl("rPortlet");
            rPortlet.DataSource = PortalRegistry.Instance.Portlets;
            rPortlet.ItemDataBound += new RepeaterItemEventHandler(rPortlet_ItemDataBound);
            rPortlet.DataBind();
        }

        void rPortlet_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                PortletEntry entry = (PortletEntry)e.Item.DataItem;

                Label lblName = (Label)e.Item.FindControl("lblName");
                lblName.Text = entry.PortletId;

                HyperLink hlnkAdd = (HyperLink)e.Item.FindControl("hlnkAdd");
                hlnkAdd.NavigateUrl = string.Format("javascript:Portal.addPortlet(\"{0}\");", entry.PortletId);
            }
        }
    }
}
