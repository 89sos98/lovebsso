#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.Design.WebControls;
using System.ComponentModel;

namespace CchenSoft.Portal.Web.UI
{
    [Designer(typeof(HyperLinkDesigner))]
    public class ExHyperLink : HyperLink
    {
        protected override void AddAttributesToRender(HtmlTextWriter writer)
        {
            if (this.Enabled && !base.IsEnabled)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Disabled, "disabled");
            }

            writer.AddAttribute(HtmlTextWriterAttribute.Id, base.ID);
            //base.AddAttributesToRender(writer);

            string navigateUrl = this.NavigateUrl;
            string str2 = string.IsNullOrEmpty(navigateUrl) ? "" : base.ResolveClientUrl(navigateUrl);
            if (base.IsEnabled)
            {
                //writer.                
                string newUrl = this.Page is PortletPage ? ((PortletPage)Page).BuildPortalUrl(str2, targetPortlet, targetQuery) : str2;
                writer.AddAttribute(HtmlTextWriterAttribute.Href, newUrl);
            }
            navigateUrl = this.Target;
            if (navigateUrl.Length > 0)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Target, navigateUrl);
            }
        }
        private string targetPortlet;
        private string targetQuery;

        public string TargetPortlet
        {
            get { return targetPortlet; }
            set { targetPortlet = value; }
        }

        public string TargetQuery
        {
            get { return targetQuery; }
            set { targetQuery = value; }
        }

    }
}
