#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Web.UI.Design;
using CchenSoft.Portal.Cfg;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal.Spi.Plugin;
using CchenSoft.Portal.Spi.Registry;

namespace CchenSoft.Portal.Web.UI
{
    [Designer(typeof(HtmlControlDesigner))]
    [ParseChildren(true)]
    public class Pager : Control, INamingContainer, IPluginSupport
    {        
        private string pluginName;
        private IPagerPlugin plugin;
        private string baseUrl;
        private int pageCount;
        private int currentPage;
        private int itemNum = 8;

        public IPlugin GetPlugin()
        {
            if (plugin == null)
            {
                if (!string.IsNullOrEmpty(pluginName))
                    plugin = (IPagerPlugin)PluginRegistry.Instance.GetPlugin(pluginName);

                if (plugin == null)
                {
                    plugin = (IPagerPlugin)PluginRegistry.Instance.GetPluginByCategory("pager");
                }
            }
            return plugin;
        }

        protected override void CreateChildControls()
        {
            plugin = (IPagerPlugin)GetPlugin();
            Control pager = this.LoadPager();
            this.InitializePager(pager);
            this.Controls.Add(pager);
        }

        protected virtual void InitializePager(Control pager)
        {
            plugin.BaseUrl = baseUrl;
            plugin.PageCount = pageCount;
            plugin.CurrentPage = currentPage;
            plugin.ItemNum = itemNum;

            plugin.Initialize(pager);
        }

        public string PluginName
        {
            get { return pluginName; }
            set { pluginName = value; }
        }

        public string BaseUrl
        {
            get { return baseUrl; }
            set { baseUrl = value; }
        }

        public int PageCount
        {
            get { return pageCount; }
            set { pageCount = value; }
        }

        public int CurrentPage
        {
            get { return currentPage; }
            set { currentPage = value; }
        }

        public int ItemNum
        {
            get { return itemNum; }
            set { itemNum = value; }
        }

        protected virtual Control LoadPager()
        {
            return plugin.LoadPager(this.Page);
        }
    }
}
