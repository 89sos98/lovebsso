#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.Specialized;
using System.Web;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Util;

namespace CchenSoft.Portal.Web.UI
{
    public class ActionPage : PortletPage
    {
        protected override string GetExportService()
        {
            string exportService = Request.Form["portal-exportservice"];
            return string.IsNullOrEmpty(exportService) ? base.GetExportService() : exportService;
        }

        protected override string GetPortalUrl()
        {
            string url = Request.Form["portal-url"];
            return string.IsNullOrEmpty(url) ? base.GetPortalUrl() : url;
        }

        protected override int GetInstanceId()
        {
            string insId = Request.Form["portlet-instanceId"];
            return string.IsNullOrEmpty(insId) ? base.GetInstanceId() : ConvertUtil.ToInt32(insId);
        }

        protected override string GetPortletName()
        {
            string name = Request.Form["portlet-name"];
            return string.IsNullOrEmpty(name) ? base.GetPortletName() : name;
        }

        protected void SendPortalRedirect()
        {
            SendPortalRedirect(true);
        }

        protected void SendPortalRedirect(string action, string args)
        {
            portalURL.AppendParam("_" + instanceId + "_action", action);

            if (!string.IsNullOrEmpty(args))
            {
                NameValueCollection coll = HttpUtility.ParseQueryString(args);
                foreach (string name in coll)
                {
                    portalURL.AppendParam("_" + instanceId + "_" + name, coll[name]);
                }
            }

            Response.Redirect(portalURL.ToURLString());
        }

        protected void SendPortalRedirect(bool removeAction)
        {
            if (removeAction)
            {
                portalURL.RemoveParam("_" + instanceId + "_state");
                portalURL.RemoveParam("_" + instanceId + "_action");
            }
            Response.Redirect(portalURL.ToURLString());
        }

        protected void SendSuccessRedirect()
        {
            portalURL.AppendParam("_" + instanceId + "_state", "success");
            Response.Redirect(portalURL.ToURLString());
        }

        protected void SendFailRedirect()
        {
            portalURL.AppendParam("_" + instanceId + "_state", "fail");
            Response.Redirect(portalURL.ToURLString());
        }
    }
}
