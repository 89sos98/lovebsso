#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Web.UI.Design;

namespace CchenSoft.Portal.Web.UI
{
    [Designer(typeof(HtmlControlDesigner))]
    [ToolboxData("<{0}:ExForm runat=server></{0}:ExForm>")]
    public class ExForm : HtmlForm
    {
        private string GetFormName()
        {
            if (this.Page is PortletPage) 
                return ((PortletPage)this.Page).InstanceId + "_" + base.Name;
            else
                return Name;
        }

        private string GetPortletRoot()
        {
            if (this.Page is PortletPage)
                if (((PortletPage)this.Page).Portlet != null)
                    return ((PortletPage)this.Page).Portlet.RootPath;
            return "";
        }

        protected override void Render(HtmlTextWriter output)
        {
            StringWriter html = new StringWriter();
            HtmlTextWriter tw = new HtmlTextWriter(html);
            base.Render(tw);
           
            string formText = html.ToString();

            string actionBegin = "action=\"";
            int n = formText.IndexOf(actionBegin) + actionBegin.Length;

            formText = formText.Insert(n, GetPortletRoot());
            output.Write(formText);
        } 

        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            if (Page is ActionPage)
            {
                ActionPage page2 = (ActionPage)Page;

                HtmlInputHidden hiddenPortalUrl = new HtmlInputHidden();
                hiddenPortalUrl.ID = "portal-url";
                hiddenPortalUrl.Value = page2.PortalURL.ToXml();
                this.Controls.Add(hiddenPortalUrl);

                HtmlInputHidden hiddenExportService = new HtmlInputHidden();
                hiddenExportService.ID = "portal-exportservice";
                hiddenExportService.Value = page2.ExportService.GetType().FullName;
                this.Controls.Add(hiddenExportService);

                HtmlInputHidden hiddenInstanceId = new HtmlInputHidden();
                hiddenInstanceId.ID = "portlet-instanceId";
                hiddenInstanceId.Value = page2.InstanceId.ToString();
                this.Controls.Add(hiddenInstanceId);

                HtmlInputHidden hiddenPortletName = new HtmlInputHidden();
                hiddenPortletName.ID = "portlet-name";
                hiddenPortletName.Value = page2.PortletName;
                this.Controls.Add(hiddenPortletName);
            }
        }

        public override string Name
        {
            get
            {
                return GetFormName();
            }
            set
            {
                base.Name = value;
            }
        }
    }
}
