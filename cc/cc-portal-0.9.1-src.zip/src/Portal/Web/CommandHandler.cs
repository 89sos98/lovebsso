#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Registry;
using System.Collections;

namespace CchenSoft.Portal.Web
{
    public class CommandHandler : IHttpHandler
    {
        #region IHttpHandler ��Ա

        public bool IsReusable
        {
            get { return false; }
        }

        public void ProcessRequest(HttpContext context)
        {
            string action = ParamUtil.GetString(context.Request, "action");
            if (!string.IsNullOrEmpty(action))
            {
                ICommand command = CommandFactory.CreateCommand(action.ToLower());
                if (command != null)
                    command.Execute(context);
            }
        }

        #endregion
    }

    public class CommandFactory
    {
        private static IDictionary<string, ICommand> commands = new Dictionary<string, ICommand>();

        static CommandFactory()
        {
            commands.Add("removeportlet", new RemovePortletCommand());
            commands.Add("addportlet", new AddPortletCommand());
            commands.Add("updatepage", new UpdatePageCommand());
            commands.Add("logout", new LogoutCommand());
        }

        public static ICommand CreateCommand(string name)
        {
            if (commands.ContainsKey(name))
                return commands[name];
            return null;
        }
    }

    public interface ICommand
    {
        void Execute(HttpContext context);
    }

    public class LogoutCommand : ICommand
    {
        #region ICommand ��Ա

        public void Execute(HttpContext context)
        {
            ServiceLocator.UserService.SignOut();
            context.Response.Redirect("~/");
        }

        #endregion
    }

    public class RemovePortletCommand : ICommand
    {
        #region ICommand ��Ա

        public void Execute(HttpContext context)
        {
            IPortalService service = ServiceLocator.PortalService;

            int instanceId = ParamUtil.GetInt32(context.Request, "instance");
            int pageId = ParamUtil.GetInt32(context.Request, "page");

            PortalPage page = service.GetPortalPageById(pageId);
            if (page != null)
            {
                service.RemovePortletFromPage(page, instanceId);
            }
        }

        #endregion
    }

    public class AddPortletCommand : ICommand
    {
        #region ICommand ��Ա

        public void Execute(HttpContext context)
        {
            IPortalService service = ServiceLocator.PortalService;

            string portlet = ParamUtil.GetString(context.Request, "portlet");
            int pageId = ParamUtil.GetInt32(context.Request, "page");

            PortalPage page = service.GetPortalPageById(pageId);
            if (page != null)
            {
                service.AddPortletToPage(page, portlet);
            }
        }

        #endregion
    }

    public class UpdatePageCommand : ICommand
    {
        #region ICommand ��Ա

        public void Execute(HttpContext context)
        {
            IPortalService service = ServiceLocator.PortalService;

            string settings = ParamUtil.GetString(context.Request, "settings");
            int pageId = ParamUtil.GetInt32(context.Request, "page");

            PortalPage page = service.GetPortalPageById(pageId);
            if (page != null)
            {
                if (settings.EndsWith(";"))
                    settings = settings.TrimEnd(';');

                string[] columns = settings.Split(';');
                List<string> cols = new List<string>();
                for (int i = 0; i < columns.Length; i++)
                {
                    string[] strs = columns[i].Split('=');
                    string colName = "";
                    string colVal = "";

                    if (strs.Length > 0)
                    {
                        colName = strs[0];
                    }

                    if (strs.Length > 1)
                    {
                        string[] ids = strs[1].Split(',');
                        for (int j = 0; j < ids.Length; j++)
                        {
                            if (!string.IsNullOrEmpty(ids[j]))
                            {
                                string id = ids[j];
                                int n = id.LastIndexOf('_');
                                if (n != -1)
                                    id = id.Substring(n + 1);
                                colVal += id + ",";
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(colName))
                        cols.Add(colName + "=" + colVal);
                }

                page.Settings = string.Join(";", cols.ToArray());
                service.UpdatePortalPage(page);
            }
        }

        #endregion
    }
}
