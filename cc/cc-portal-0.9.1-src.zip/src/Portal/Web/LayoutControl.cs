#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal.Spi.Registry;

namespace CchenSoft.Portal.Web
{
    [ParseChildren(true)]
    public class LayoutControl : ChildControl
    {
        protected override void InitializeSkin(Control control)
        {
            string hostName = GetHostName();
            
            PortalPage page = PortalContext.Current.PortalPage;

            if (true) //(page.Type == "portlet")
            {
                string[] columns = page.Settings.Split(';');
                foreach (string column in columns)
                {
                    string[] s = column.Split('=');
                    string columnName = s[0];
                    string[] instances = s[1].Split(',');

                    Control column_1 = control.FindControl(columnName);

                    foreach (string instance in instances)
                    {
                        int instId = ConvertUtil.ToInt32(instance);
                        if (instId == 0)
                            continue;

                        PortletInstance p1 = ServiceLocator.PortalService.LoadPortletInstance(instId);
                        PortletControl view = new PortletControl(hostName, p1);
                        column_1.Controls.Add(view);

                        PortletEntry portlet = PortalRegistry.Instance.GetPortlet(p1.PortletId);
                        if (portlet.IsProducer)
                        {
                            Producer p = new Producer(p1.InstanceId, p1.Title);
                            PortalContext.Current.AddProducer(p);
                        }

                        PortalContext.Current.AddPortlet(p1);
                    }
                }
            }
        }

        protected override Control LoadSkin()
        {
            Control control = Page.LoadControl(PortalContext.Current.Layout.TemplatePath);
            return control;
        }

        private string GetHostName()
        {
            string hostName;

            if (Page.Request.Url.Port == 80)
                hostName = "http://" + Page.Request.Url.Host;
            else
                hostName = "http://" + Page.Request.Url.Host + ":" + Page.Request.Url.Port;

            return hostName;
        }
    }
}
