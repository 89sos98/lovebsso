#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Util;
using CchenSoft.Portal.Registry;
using System.Collections;
using System.IO;

namespace CchenSoft.Portal.Web
{
    public class PortletHandler : IHttpHandler
    {
        #region IHttpHandler ��Ա

        public bool IsReusable
        {
            get { return false; }
        }

        public void ProcessRequest(HttpContext context)
        {
            string reqName = Path.GetFileNameWithoutExtension(context.Request.Path);
            int n = reqName.LastIndexOf("/");
            if (n > -1)
                reqName = reqName.Substring(n + 1);

            string querystring = context.Request.QueryString.ToString();
            if (!string.IsNullOrEmpty(querystring))
                querystring += "&";
            querystring += "window_state=1&max_portlet=" + reqName;

            PortalPage page = ServiceLocator.PortalService.GetPortalPageByUrl("/default.aspx");
            PortalURL url = new PortalURL("/default.aspx", querystring);
            PortalContext portalCtx = new PortalContext(page, url, context);
            context.Server.Transfer(portalCtx.Theme.TemplatesPath + "portal_max.aspx");
        }

        #endregion
    }
}
