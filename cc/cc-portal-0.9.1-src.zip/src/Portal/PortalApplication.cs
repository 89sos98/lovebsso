#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using CchenSoft.Portal.Registry;
using CchenSoft.Portal.Cfg;
using CchenSoft.Portal.Job;
using Quartz.Impl;
using Quartz;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Service.Impl;

namespace CchenSoft.Portal
{
    public class PortalApplication : HttpApplication
    {
        private IScheduler sched = null;

        protected void Application_Start(object sender, EventArgs e)
        {
            DateTime start = DateTime.Now;

            BootLogger.Instance.Info("portal starting...", this.GetType());

            HttpContext ctx = HttpContext.Current;

            Configuration cfg = Configuration.Instance;
            cfg.Configure(ctx.Server.MapPath("/portal.config"));

            DeployUtil.DeployPlugin(ctx.Server.MapPath(cfg.PluginsFile));
            DeployUtil.DeployLayout(ctx.Server.MapPath(cfg.LayoutsFile));
            DeployUtil.DeployTheme(ctx.Server.MapPath(cfg.ThemesFile));            
            DeployUtil.DeployPortlet(ctx.Server.MapPath(cfg.PortletsPath));

            ServiceLocator.Initialize();

            StartDeploySchedule();

            TimeSpan duartion = DateTime.Now - start;
            BootLogger.Instance.Info(string.Format("portal started. {0}:{1}", duartion.Seconds, duartion.Milliseconds), this.GetType());
        }

        private void StartDeploySchedule()
        {
            // First we must get a reference to a scheduler
            ISchedulerFactory sf = new StdSchedulerFactory();
            sched = sf.GetScheduler();

            // will run every thirty minutes but only between 5pm and 9am
            JobDetail job = new JobDetail("DeployPortletJob", "group1", typeof(DeployPortletJob));
            job.JobDataMap.Add("PortletsFolder", HttpContext.Current.Server.MapPath(Configuration.Instance.PortletsPath));
            CronTrigger trigger = new CronTrigger("trigger1", "group1", "DeployPortletJob", "group1", "0 0/1 0-23 * * ?");
            sched.AddJob(job, true);
            sched.ScheduleJob(trigger);

            job = new JobDetail("DeployLayoutJob", "group1", typeof(DeployLayoutJob));
            job.JobDataMap.Add("LayoutsFile", HttpContext.Current.Server.MapPath(Configuration.Instance.LayoutsFile));
            trigger = new CronTrigger("trigger2", "group1", "DeployLayoutJob", "group1", "0 0/1 0-23 * * ?");
            sched.AddJob(job, true);
            sched.ScheduleJob(trigger);

            job = new JobDetail("DeployThemeJob", "group1", typeof(DeployThemeJob));
            job.JobDataMap.Add("ThemesFile", HttpContext.Current.Server.MapPath(Configuration.Instance.ThemesFile));
            trigger = new CronTrigger("trigger3", "group1", "DeployThemeJob", "group1", "0 0/1 0-23 * * ?");
            sched.AddJob(job, true);
            sched.ScheduleJob(trigger);

            job = new JobDetail("DeployPluginJob", "group1", typeof(DeployPluginJob));
            job.JobDataMap.Add("PluginsFile", HttpContext.Current.Server.MapPath(Configuration.Instance.PluginsFile));
            trigger = new CronTrigger("trigger4", "group1", "DeployPluginJob", "group1", "0 0/1 0-23 * * ?");
            sched.AddJob(job, true);
            sched.ScheduleJob(trigger);

            // will run until the scheduler has been started
            sched.Start();
        }
        
        protected void Application_End(object sender, EventArgs e)
        {
            sched.Shutdown(true);
        }
    }
}
