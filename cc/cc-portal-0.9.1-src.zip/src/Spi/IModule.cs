#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Web;
using CchenSoft.Portal.Spi.Registry;

namespace CchenSoft.Portal.Spi
{
    public interface IModule
    {
        string ModuleId { get; }

        string Name { get; }

        string Path { get; set; }

        string Folder { get; set; }

        string DomainName { get; }

        DateTime LastWriteTime { get; set; }

        IModule Parent { get; set; }

        IList<PortletEntry> Portlets { get; }

        IList<HandlerEntry> Handlers { get; }

        IList<IService> ServiceList { get; }

        IDictionary<string, IService> Services { get; }

        void Configure(XmlDocument doc);

        void HandleDomain(string domainName, HttpContext context);

        void BeginRequest(HttpContext context);
    }
}
