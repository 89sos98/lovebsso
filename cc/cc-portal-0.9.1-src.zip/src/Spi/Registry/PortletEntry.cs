#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.Spi.Registry
{
    public class PortletEntry
    {
        private string portletId;
        private string caption;
        private string rootPath;
        private string viewPath;
        private string configPath;
        private bool instanceable;
        private bool isProducer;
        private string preferences;

        public string PortletId
        {
            get { return portletId; }
            set { portletId = value; }
        }

        public string Caption
        {
            get { return caption; }
            set { caption = value; }
        }

        public string RootPath
        {
            get { return rootPath; }
            set { rootPath = value; }
        }

        public string ViewPath
        {
            get { return viewPath; }
            set { viewPath = value; }
        }

        public string ConfigPath
        {
            get { return configPath; }
            set { configPath = value; }
        }

        public bool Instanceable
        {
            get { return instanceable; }
            set { instanceable = value; }
        }

        public bool IsProducer
        {
            get { return isProducer; }
            set { isProducer = value; }
        }

        public string Preferences
        {
            get { return preferences; }
            set { preferences = value; }
        }
    }
}
