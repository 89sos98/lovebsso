using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Spi.Registry;
using CchenSoft.Portal.Spi.Plugin;

namespace CchenSoft.Portal.Spi.Service
{
    public class PluginLocator
    {
        public static T GetPluginService<T>(string category)
        {
            IServicePlugin plugin = (IServicePlugin)PluginRegistry.Instance.GetPluginByCategory(category);
            return plugin.GetService<T>();
        }

        public static T GetPluginService<T>(IPlugin plugin)
        {
            IServicePlugin plugin2 = (IServicePlugin)plugin;
            return plugin2.GetService<T>();
        }
    }
}
