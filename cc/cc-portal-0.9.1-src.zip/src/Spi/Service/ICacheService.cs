#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.Spi.Service
{
    public interface ICacheService : IPluginService
    {
        void AddItem(string module, string key, object item);

        void RemoveItem(string module, string key);

        void RemoveItems(string module);

        IList<string> Items { get; }

        object GetItem(string module, string key);
    }
}
