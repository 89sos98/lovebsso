using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.Spi.Service
{
    public interface IEmailService : IPluginService
    {
        bool SendEmail(string recipients, string subject, string body); 
    }
}
