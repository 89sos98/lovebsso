#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Spi.Plugin;
using System.IO;
using System.Web;

namespace CchenSoft.Portal.Spi.Service
{
    public class BootLogger
    {
        private static BootLogger _instance = new BootLogger();

        private string filename;

        private BootLogger()
        {
            filename = HttpContext.Current.Server.MapPath("/boot.log");
            FileInfo fi = new FileInfo(filename);
            if (fi.Exists)
                fi.Delete();
        }

        public static BootLogger Instance
        {
            get { return _instance; }
        }

        private static object lockObject = new object();

        private void WriteLog(string message, string category, Type type)
        {
            lock (lockObject)
            {
                using (StreamWriter writer = new StreamWriter(filename, true, Encoding.UTF8))
                {
                    string text = string.Format("{0} {1}  {2} - {3}", DateTime.Now, category, type, message);
                    writer.WriteLine(text);
                    writer.Flush();
                    writer.Close();
                }
            }
        }

        public void Info(string message, Type type)
        {
            WriteLog(message, "INFO", type);
        }

        public void Warn(string message, Type type)
        {
            WriteLog(message, "WARN", type);
        }

        public void Debug(string message, Type type)
        {
            WriteLog(message, "DEBUG", type);
        }

        public void Error(string message, Type type)
        {
            WriteLog(message, "ERROR", type);
        }

    }
}
