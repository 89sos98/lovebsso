#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;

namespace CchenSoft.Portal.Spi.Service
{
    public interface IDataService : IPluginService
    {
        void Configure(IList mappings);

        object Insert(string statementName, object parameterObject);

        object QueryForObject(string statementName, object parameterObject);

        T QueryForObject<T>(string statementName, object parameterObject);

        int Update(string statementName, object parameterObject);

        int Delete(string statementName, object parameterObject);

        IList QueryForList(string statementName, object parameterObject);

        IList<T> QueryForList<T>(string statementName, object parameterObject);

        IList QueryForList(string statementName, object parameterObject, int skipResults, int maxResults);

        IList<T> QueryForList<T>(string statementName, object parameterObject, int skipResults, int maxResults);

        IDbDataParameter CreateParameter(string name, object value);

        DataSet QueryForDataSet(string statementName, object parameterObject);

        object BeginTransaction();

        void Commit(object obj);

        void Rollback(object obj);
    }
}
