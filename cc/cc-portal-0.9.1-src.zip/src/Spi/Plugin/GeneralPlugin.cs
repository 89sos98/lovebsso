#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Collections;
using System.Reflection;
using CchenSoft.Portal.Spi.Plugin;
using CchenSoft.Portal.Spi.Registry;

namespace CchenSoft.Portal.Spi.Plugin
{
    public class GeneralPlugin : IPlugin
    {
        private string pluginId;
        private string pluginName;
        private string path;
        private string folder;
        private DateTime lastWriteTime = DateTime.MinValue;

        protected IDictionary<string, HandlerEntry> handlers;
        protected IDictionary<string, string> properties;

        #region IPlugin ��Ա

        public string Name
        {
            get { return pluginName; }
        }

        public string Path
        {
            get { return path; }
            set { path = value; }
        }

        public string Folder
        {
            get { return folder; }
            set { folder = value; }
        }

        public DateTime LastWriteTime
        {
            get { return lastWriteTime; }
            set { lastWriteTime = value; }
        }

        public string PluginId
        {
            get { return pluginId; }
        }

        public IList<HandlerEntry> Handlers
        {
            get { return new List<HandlerEntry>(handlers.Values); }
        }

        public virtual void Configure(XmlDocument doc)
        {
            pluginId = GetNodeValue(doc.DocumentElement.SelectSingleNode("plugin-id"));
            pluginName = GetNodeValue(doc.DocumentElement.SelectSingleNode("plugin-name"));

            // parse httpHandlers
            handlers = ParseHandlers(doc.DocumentElement.SelectNodes("httpHandler"));

            // parse service.
            properties = ParseProperties(doc.DocumentElement.SelectNodes("property"));

            foreach (string name in properties.Keys)
            {
                PropertyInfo pi = this.GetType().GetProperty(name);
                if (pi != null)
                {
                    object val = Convert.ChangeType(properties[name], pi.PropertyType);
                    pi.SetValue(this, val, null);
                }
            }
        }


        #endregion

        #region helper methods.

        private IDictionary<string, HandlerEntry> ParseHandlers(XmlNodeList list)
        {
            IDictionary<string, HandlerEntry> hes = new Dictionary<string, HandlerEntry>();

            if (list == null)
                return hes;

            foreach (XmlNode node in list)
            {
                HandlerEntry he = new HandlerEntry();
                
                string pattern = GetNodeValue(node.Attributes.GetNamedItem("pattern"));
                if (pattern.StartsWith("~/"))
                    pattern = path + pattern.Substring(2);

                he.Pattern = pattern;
                he.Verb = GetNodeValue(node.Attributes.GetNamedItem("verb"));
                he.HandlerType = Type.GetType(GetNodeValue(node.Attributes.GetNamedItem("type")));

                hes.Add(he.Pattern, he);
            }

            return hes;
        }

        private IDictionary<string, string> ParseProperties(XmlNodeList list)
        {
            IDictionary<string, string> props = new Dictionary<string, string>();

            foreach (XmlNode node in list)
            {
                string name = GetNodeValue(node.Attributes.GetNamedItem("name"));
                string value = GetNodeValue(node);
                if (value.StartsWith("~/"))
                    value = path + value.Substring(2);
                props.Add(name, value);
            }

            return props;
        }

        protected string GetNodeValue(XmlNode node)
        {
            if (node == null)
                return "";

            if (node is XmlElement)
                return node.InnerText;
            else if (node is XmlAttribute)
                return node.Value;
            else
                return node.InnerText;
        }

        #endregion
    }
}
