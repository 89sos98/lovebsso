#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Spi.Plugin;
using ActiproSoftware.CodeHighlighter;
using System.Xml;
using ActiproSoftware.SyntaxEditor;
using System.Web.UI;

namespace CchenSoft.Portal.CodeHighlight
{
    public class CodeHighlightPlugin : GeneralPlugin, IFormatPlugin
    {
        private CodeHighlighterConfiguration config;

        public string Format(string text)
        {
            CodeHighlighterEngine engine = new CodeHighlighterEngine();
            engine.KeywordLinkingEnabled = config.KeywordLinkingEnabled;
            engine.KeywordLinkingTarget = config.KeywordLinkingTarget;
            engine.LineNumberMarginForeColor = config.LineNumberMarginForeColor;
            engine.LineNumberMarginPaddingCharacter = config.LineNumberMarginPaddingCharacter;
            engine.LineNumberMarginVisible = config.LineNumberMarginVisible;
            engine.OutliningEnabled = config.OutliningEnabled;
            engine.OutliningImagesPath = Path + config.OutliningImagesPath.Substring(2);
            engine.SpacesInTabs = config.SpacesInTabs;
            //engine.Keywords.AddRange(config.KeywordCollections);


            SyntaxLanguage language = CodeHighlighter.GetLanguage(config, "C#");

            return engine.GenerateHtmlInline("", text, language);
        }

        public override void Configure(XmlDocument doc)
        {
            base.Configure(doc);

            CodeHighlighterConfigurationSectionHandler handler = new CodeHighlighterConfigurationSectionHandler();
            config = (CodeHighlighterConfiguration)handler.Create(null, null, doc.DocumentElement.SelectSingleNode("codeHighlighter"));
        }
    }
}
