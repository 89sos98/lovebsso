#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using FredCK.FCKeditorV2;
using CchenSoft.Portal.Spi.Plugin;

namespace CchenSoft.Portal.Editor
{
    public class FCKEditorPlugin : GeneralPlugin, IEditorPlugin
    {
        private FCKeditor editor;
        //private string content;
        private string controlName;

        #region IEditorPlugin ��Ա

        public void Initialize(Control control)
        {
            editor = (FCKeditor)control.FindControl("editor");
            editor.BasePath = Path;
            //editor.Value = content;
        }

        public string ControlName
        {
            get { return controlName; }
            set { controlName = value; }
        }

        public string Content
        {
            get
            {
                //content = editor.Value;
                //return content;
                return editor.Value;
            }
            set
            {
                //content = value;
                editor.Value = value;
            }
        }

        public Control LoadEditor(Page page)
        {
            return page.LoadControl(controlName);
        }

        #endregion
    }
}
