#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Spi.Service;
using CchenSoft.Portal.Spi.Plugin;
using System.Web;
using System.Web.Caching;
using System.Collections;

namespace CchenSoft.Portal.Caching
{
    public class SimpleCacheService : ICacheService
    {
        private IPlugin plugin;
        private int cacheMinutes;

        //private IDictionary<string, object> modules = new Dictionary<string, object>();
        private IDictionary<string, CacheItem> items = new Dictionary<string, CacheItem>();

        private class CacheItem
        {
            private string key;
            private object target;
            private DateTime expiresDate;

            public CacheItem(string key, object target, DateTime expiresDate)
            {
                this.key = key;
                this.target = target;
                this.expiresDate = expiresDate;
            }

            public string Key
            {
                get { return key; }
            }

            public object Target
            {
                get { return target; }
            }

            public DateTime ExpiresDate
            {
                get { return expiresDate; }
            }
        }

        #region IPluginService ��Ա

        public void SetPlugin(IPlugin plugin)
        {
            this.plugin = plugin;
        }

        #endregion

        #region IService ��Ա

        public void Initialize()
        {
        }

        #endregion

        public int CacheMinutes
        {
            get { return cacheMinutes; }
            set { cacheMinutes = value; }
        }

        #region ICacheService ��Ա

        public void AddItem(string module, string key, object item)
        {
            RemoveItem(module, key);
            if (item != null)
            {
                string fullKey = module + "_" + key;
                items.Add(fullKey, new CacheItem(fullKey, item, DateTime.Now.AddMinutes(cacheMinutes)));
            }
        }

        public IList<string> Items
        {
            get { return new List<string>(items.Keys); }
        }

        public void RemoveItem(string module, string key)
        {
            string fullKey = module + "_" + key;
            if (items.ContainsKey(fullKey))
                items.Remove(fullKey);
        }

        public void RemoveItems(string module)
        {
            IList<string> keys = new List<string>();

            foreach (string key in items.Keys)
            {
                if (key.StartsWith(module))
                {
                    keys.Add(key);
                }
            }

            foreach (string key in keys)
            {
                items.Remove(key);
            }
        }

        public object GetItem(string module, string key)
        {
            string fullKey = module + "_" + key;
            if (items.ContainsKey(fullKey))
            {
                CacheItem item = items[fullKey];
                if (item.ExpiresDate > DateTime.Now)
                {
                    return item.Target;
                }
                items.Remove(fullKey);
            }

            return null;
        }

        #endregion
    }
}
