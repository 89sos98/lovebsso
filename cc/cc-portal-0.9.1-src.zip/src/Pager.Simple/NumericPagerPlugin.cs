using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using CchenSoft.Portal.Spi.Plugin;

namespace CchenSoft.Portal.Pager
{
    [ParseChildren(true)]
    public class NumericPagerPlugin : GeneralPlugin, IPagerPlugin
    {
        private string baseUrl;
        private int pageCount;
        private int currentPage;
        private int itemNum;
        private string controlName;

        public string ControlName
        {
            get { return controlName; }
            set { controlName = value; }
        }

        public string BaseUrl
        {
            get { return baseUrl; }
            set { baseUrl = value; }
        }

        public int PageCount
        {
            get { return pageCount; }
            set { pageCount = value; }
        }

        public int CurrentPage
        {
            get { return currentPage; }
            set { currentPage = value; }
        }

        public int ItemNum
        {
            get { return itemNum; }
            set { itemNum = value; }
        }

        private List<int> GetPageItems()
        {
            List<int> items = new List<int>();

            int i = itemNum / 2;
            int start = currentPage - i;
            if (start < 1)
                start = 1;
            
            int end = currentPage + i;
            if (end > pageCount)
                end = pageCount;

            for (int j = start; j <= end; j++)
            {
                items.Add(j);
            }

            return items;
        }

        public Control LoadPager(Page page)
        {
            return page.LoadControl(ControlName);
        }

        public void Initialize(Control control)
        {
            HyperLink hPrev = (HyperLink)control.FindControl("hPrev");
            if (currentPage > 1)
                hPrev.NavigateUrl = string.Format(baseUrl, currentPage - 1);
            else
                hPrev.Visible = false;

            HyperLink hNext = (HyperLink)control.FindControl("hNext");
            if (currentPage < pageCount)
                hNext.NavigateUrl = string.Format(baseUrl, currentPage + 1);
            else
                hNext.Visible = false;

            Repeater rPager = (Repeater)control.FindControl("rPager");
            rPager.DataSource = GetPageItems();
            rPager.ItemDataBound += new RepeaterItemEventHandler(rPager_ItemDataBound);
            rPager.DataBind();
        }

        void rPager_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                int page = (int)e.Item.DataItem;

                HyperLink hItem = (HyperLink)e.Item.FindControl("hItem");
                hItem.Text = page.ToString();

                if (page == CurrentPage)
                {
                    hItem.Attributes["color"] = "#ff0000";
                }
                else
                {
                    hItem.NavigateUrl = string.Format(baseUrl, page);
                }
            }
        }
    }
}
