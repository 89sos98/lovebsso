using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using Dottext.Framework;
using Dottext.Framework.Components;
using Dottext.Framework.Util;
using Dottext.Framework.Configuration;

using System.Collections.Generic;
using Dottext.Framework.Service;
using CchenSoft.Framework.Attributes;
using CchenSoft.Framework;
using System.Web.Services.Protocols;

namespace Dottext.Web.ServiceAPI
{
    /// <summary>
    /// Summary description for CoreAPI.
    /// </summary>
    [WebService(Name = "DotText Core API", Namespace = "http://www.cchensoft.com/opensource/cc-dottext/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class CoreAPI : BaseWebService
    {
        public BlogUserHeader userHeader = new BlogUserHeader();

        [Bean]
        protected BlogService blogService;

        [Bean("Authenticator")]
        protected IAuthenticator auth;

        public CoreAPI()
            : base()
        {
        }

        private BlogConfig _currentBlog = null;
        protected BlogConfig CurrentBlog
        {
            get
            {
                if (_currentBlog == null)
                {
                    _currentBlog = BlogContext.Current.Config;
                }
                return _currentBlog;
            }
        }


        #region internal helpers
        private void Validate()
        {
            if (userHeader != null)
            {
                if (string.Compare(userHeader.UserName, CurrentBlog.UserName, false) == 0)
                {
                    if (userHeader.Password == CurrentBlog.Password)
                    {
                        return;
                    }
                }
            }

            throw new ApplicationException("Invalid User");
        }

        #endregion

        #region Query Entries

        [SoapHeader("userHeader")]
        [WebMethod(Description = "Returns a collection of CategoryEnties based on the supplied EntryQuery. An EntryQuery can be used to filter by PostType (flagged enum), PostConfig (flagged enum), CategoryID or CategoryTitle, and either a specific date or date range. The maximum number of entries returned will be limited to 50", EnableSession = false)]
        public CategoryEntry[] GetEntriesByQuery(EntryQuery query)
        {
            Validate();
            if (query.ItemCount > 50 || query.ItemCount == 0)
            {
                query.ItemCount = 50;
            }
            return new List<CategoryEntry>(blogService.GetCategoryEntryCollection(query)).ToArray();
        }

        [SoapHeader("userHeader")]
        [WebMethod(Description = "Returns a a single entry for the given entry name.", EnableSession = false)]
        public CategoryEntry GetEntryByName(string EntryName)
        {
            Validate();
            return blogService.GetCategoryEntry(EntryName, PostConfig.Empty);
        }

        [SoapHeader("userHeader")]
        [WebMethod(Description = "Returns a a single entry for the given EntryID.", EnableSession = false)]
        public CategoryEntry GetEntry(int EntryID)
        {
            Validate();
            CategoryEntry entry = new CategoryEntry();
            entry.Body = "hello!";
            return entry;//Entries.GetCategoryEntry(EntryID,PostConfig.Empty);
        }

        #endregion

        #region Select Categories

        [SoapHeader("userHeader")]
        [WebMethod(Description = "Returns a collection of LinkCategories by the specified CategoryType.", EnableSession = false)]
        public LinkCategory[] GetCategories(CategoryType categoryType)
        {
            Validate();
            return new List<LinkCategory>(blogService.GetCategoriesByType(categoryType, false)).ToArray();
        }

        [SoapHeader("userHeader")]
        [WebMethod(Description = "Returns all of the categories (of type CategoryType.LinkCollection) with corresponding Links.", EnableSession = false)]
        public LinkCategory[] GetCategoriesWithLinks()
        {
            Validate();
            return new List<LinkCategory>(blogService.GetCategoriesWithLinks(true)).ToArray();
        }

        /*[WebMethod(MessageName="GetGlobalCategoriesByType",Description="Returns all of the global categories the current user has access to.",EnableSession=false)]
        public LinkCategoryCollection GetGlobalCategoriesByType(CategoryType catType)
        {
            Validate();
            return Links.GetGlobalCategoriesByType(catType,true);
        }

        [WebMethod(MessageName="GetGlobalCategoriesByEntryID",Description="Returns all of the global categories for a given entry. This request is handled on its own method call since it is an optional configuration",EnableSession=false)]
        public string[] GetGlobalCategoriesByEntryID(int EntryID)
        {
            Validate();
            return Links.GetGlobalCategoriesByEntryID(EntryID,true);
        }*/

        #endregion

        #region edit entries

        private void Check(CategoryEntry entry)
        {
            if (entry.PostType == PostType.Undeclared)
            {
                throw new ApplicationException("You must set a valid PostType");
            }

            if (entry.PostType == PostType.Comment || entry.PostType == PostType.PingTrack)
            {
                if (entry.ParentID <= 0)
                {
                    throw new ApplicationException("ParentID must be set for a Comment or PingTrack PostType");
                }
            }

            entry.BlogID = CurrentBlog.BlogID;
            if (entry.Author == null)
            {
                entry.Author = CurrentBlog.Author;
            }
            if (entry.Email == null)
            {
                entry.Email = CurrentBlog.Email;
            }


        }

        [SoapHeader("userHeader")]
        [WebMethod(Description = "Inserts a new entry into the data store", EnableSession = false)]
        public int CreateEntry(CategoryEntry entry)
        {
            Validate();

            Check(entry);
            entry.DateUpdated = entry.DateCreated;

            return blogService.Create(entry);
        }

        /*[WebMethod(MessageName="CreateEntryWithGlobalCategories",Description="Inserts a new entry into the data store In addition, the global categories for the entry are either created.",EnableSession=false)]
        public int CreateEntry(CategoryEntry entry, string[] GlobalCategories)
        {
            Validate();

            Check(entry);
            entry.DateUpdated = entry.DateCreated;

            return Entries.Create(entry,null,GlobalCategories);
        }*/

        [SoapHeader("userHeader")]
        [WebMethod(Description = "Updates an existing entry", EnableSession = false)]
        public bool UpdateEntry(CategoryEntry entry)
        {
            Validate();
            Check(entry);
            return blogService.Update(entry);
        }

        /*[WebMethod(MessageName="UpdateEntryWithGlobalCategories",Description="Updates an existing entry. In addition, the global categories for the entry are either created or updated.",EnableSession=false)]
        public bool UpdateEntry(CategoryEntry entry, string[] GlobalCategories)
        {
            Validate();
            Check(entry);
            return Entries.Update(entry,null,GlobalCategories);
        }*/

        [SoapHeader("userHeader")]
        [WebMethod(Description = "Delete an entry", EnableSession = false)]
        public bool DeleteEntry(int entryID)
        {
            Validate();
            return blogService.Delete(entryID);
        }

        #endregion

        #region Edit Links

        [SoapHeader("userHeader")]
        [WebMethod(Description = "Create a new Link", EnableSession = false)]
        public int CreateLink(Link link)
        {
            Validate();
            return blogService.CreateLink(link);
        }

        [SoapHeader("userHeader")]
        [WebMethod(Description = "Update an existing Link", EnableSession = false)]
        public bool UpdateLink(Link link)
        {
            Validate();
            return blogService.UpdateLink(link);
        }

        [SoapHeader("userHeader")]
        [WebMethod(Description = "Delete an existing Link", EnableSession = false)]
        public bool DeleteLink(int LinkID)
        {
            Validate();
            return blogService.DeleteLink(LinkID);
        }

        #endregion

        #region Edit LinkCategories

        [SoapHeader("userHeader")]
        [WebMethod(Description = "Create a new LinkCategory", EnableSession = false)]
        public int CreateLinkCategory(LinkCategory lc)
        {
            Validate();
            return blogService.CreateLinkCategory(lc);
        }

        [SoapHeader("userHeader")]
        [WebMethod(Description = "Update an existing LinkCategory", EnableSession = false)]
        public bool UpdateLinkCategory(LinkCategory lc)
        {
            Validate();
            return blogService.UpdateLinkCategory(lc);
        }

        [SoapHeader("userHeader")]
        [WebMethod(Description = "Delete an existing LinkCategory", EnableSession = false)]
        public bool DeleteLinkCategory(int CategoryID)
        {
            Validate();
            return blogService.DeleteLinkCategory(CategoryID);
        }

        [WebMethod(Description = "Delete an existing LinkCategory", EnableSession = false)]
        public string test()
        {

            return "Hello World";
        }

        #endregion

        #region
        //-1 --�û�������
        //-2 --�������
        public int Login(string username, string password)
        {
            BlogConfig config = blogService.GetConfig(username);
            if (config == null)
            {
                return -2;
            }
            if (auth.Authenticate(username, password, 0) > 0)
            {
                return -1;
            }
            return 1;
        }

        public BlogConfig GetBlogConfig(string username)
        {

            if (true)//||blogService.IsAuthenticated)
            {
                BlogConfig config = blogService.GetConfig(username);
                //Dottext.Framework.Logger.LogManager.Log("BlogID",config.BlogID.ToString());
                return config;
            }
            else
            {
                throw new ApplicationException("�㻹û�е�¼,���ȵ�¼");
            }
            return null;
        }
        #endregion




    }
}
