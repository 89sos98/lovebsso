﻿#region License
/*
 *  Copyright (C) 2005-2008 THE CCHENSOFT.COM
 *  
 *  This library is free software; you can redistribute it and/or modify it 
 *  under the terms of the GNU Lesser General Public License 2.1 or later, as
 *  published by the Free Software Foundation. See the included License.txt
 *  or http://www.cchensoft.com/opensource/license.txt for details. 
 */
#endregion
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// 有关程序集的常规信息通过下列属性集
// 控制。更改这些属性值可修改
// 与程序集关联的信息。
[assembly: AssemblyTitle("DotText Web")]
[assembly: AssemblyDescription("WebUI Layer")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("长城IT咨询")]
[assembly: AssemblyProduct("CchenSoft DotText")]
[assembly: AssemblyCopyright("Copyright 2005")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]	


// 程序集的版本信息由下面四个值组成:
//
//      主版本
//      次版本 
//      内部版本号
//      修订号
//
// 可以指定所有这些值，也可以使用“修订号”和“内部版本号”的默认值，
// 方法是按如下所示使用“*”:
[assembly: AssemblyVersion("1.0")]
[assembly: AssemblyFileVersion("1.0")]
