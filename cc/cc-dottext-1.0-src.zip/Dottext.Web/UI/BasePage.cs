#region License
/*
 *  Copyright (C) 2005-2008 THE CCHENSOFT.COM
 *  
 *  This library is free software; you can redistribute it and/or modify it 
 *  under the terms of the GNU Lesser General Public License 2.1 or later, as
 *  published by the Free Software Foundation. See the included License.txt
 *  or http://www.cchensoft.com/opensource/license.txt for details. 
 */
#endregion

using System;
using System.Web.UI;
using Dottext.Framework.Service;
using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Utils;

namespace Dottext.Web.UI
{
	/// <summary>
	/// ManagePage ��ժҪ˵����
	/// </summary>
    public class BasePage : Page
    {
        [Bean]
        protected BlogService blogService;

        protected override void OnInit(EventArgs e)
        {
            ReflectUtil.InjectBeans(this);
            base.OnInit(e);
        }

    }
}
