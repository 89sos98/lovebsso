namespace Dottext.Web.UI.Controls
{
	using System;
	using System.Data;
	using System.Data.SqlClient;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	using Dottext.Framework.Data;
	using Dottext.Framework.Configuration;
    using Dottext.Framework;

	/// <summary>
	///		TopViewPosts ��ժҪ˵����
	/// </summary>
	public class TopViewPosts : System.Web.UI.UserControl
	{
        protected System.Web.UI.WebControls.Repeater TopList;

		private void Page_Load(object sender, System.EventArgs e)
		{
			this.Visible=Dottext.Web.UI.Globals.CheckContorVisible("TopViewPosts");
			if(!Visible)
			{
				return;
			}
            BlogConfig config = BlogContext.Current.Config;
            IBlogDao blogDao = (IBlogDao)CchenSoft.Framework.Config.Configuration.Instance.GetBean("IBlogDao");
			SqlParameter[] p=
						{
							SqlHelper.MakeInParam("@BlogID",SqlDbType.Int,4,config.BlogID),
							SqlHelper.MakeInParam("@ItemCount",SqlDbType.Int,4,config.ItemCount)
						};
			string sql="blog_GetTopPostsByBlogID";
			DataSet ds = blogDao.ExecuteDataset(CommandType.StoredProcedure,sql,p);
			TopList.DataSource=ds.Tables[0];
			TopList.DataBind();
		}

		protected string BuildUrl(string datestr,string id)
		{
            return BlogContext.Current.Config.FullyQualifiedUrl + "archive/" + DateTime.Parse(datestr).ToString("yyyy'/'MM'/'dd") + "/" + id + ".aspx";
		}
	}
}
