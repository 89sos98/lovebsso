namespace Dottext.Web.UI.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
    using FredCK.FCKeditorV2;
    using Dottext.Framework.Configuration;

	/// <summary>
	///		AdvancedPostComment ��ժҪ˵����
	/// </summary>
	public class AdvancedPostComment : System.Web.UI.UserControl
	{
        protected System.Web.UI.WebControls.Button Button1;
        protected FCKeditor fckComment;

		private void Page_Load(object sender, System.EventArgs e)
		{
            fckComment.BasePath = Config.RootPath + "fckeditor/";
		}


		protected void Button1_Click(object sender, System.EventArgs e)
		{
			Response.Write(fckComment.Value);
		}
	}
}
