namespace Dottext.Web.UI.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		BlogSearch ��ժҪ˵����
	/// </summary>
    public class RelatedLinks : Dottext.Web.UI.Controls.SkinControl
	{
        protected Repeater Links;

        protected void MoreReadingCreated(object sender, RepeaterItemEventArgs e)
        {
        }

        protected void RemovePTR_ItemCommand(object sender, RepeaterCommandEventArgs e)
        {
        }
	}


}
