#region Disclaimer/Info
///////////////////////////////////////////////////////////////////////////////////////////////////
// .Text WebLog
// 
// .Text is an open source weblog system started by Scott Watermasysk. 
// Blog: http://ScottWater.com/blog 
// RSS: http://scottwater.com/blog/rss.aspx
// Email: Dottext@ScottWater.com
//
// For updated news and information please visit http://scottwater.com/dottext and subscribe to 
// the Rss feed @ http://scottwater.com/dottext/rss.aspx
//
// On its release (on or about August 1, 2003) this application is licensed under the BSD. However, I reserve the 
// right to change or modify this at any time. The most recent and up to date license can always be fount at:
// http://ScottWater.com/License.txt
// 
// Please direct all code related questions to:
// GotDotNet Workspace: http://www.gotdotnet.com/Community/Workspaces/workspace.aspx?id=e99fccb3-1a8c-42b5-90ee-348f6b77c407
// Yahoo Group http://groups.yahoo.com/group/DotText/
// 
///////////////////////////////////////////////////////////////////////////////////////////////////
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using Dottext.Framework;
using Dottext.Framework.Components;
using Dottext.Framework.Configuration;

using CchenSoft.Framework.Attributes;
using CchenSoft.Framework;
using CchenSoft.Framework.Service;

namespace Dottext.Web.UI.Controls
{
    public class Contact : SkinControl
    {
        protected System.Web.UI.WebControls.ValidationSummary ValidationSummary1;
        protected System.Web.UI.WebControls.Label lblMessage;
        protected System.Web.UI.WebControls.Button btnSend;
        protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
        protected System.Web.UI.WebControls.TextBox tbMessage;
        protected System.Web.UI.WebControls.TextBox tbSubject;
        protected System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator1;
        protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator2;
        protected System.Web.UI.WebControls.TextBox tbEmail;
        protected System.Web.UI.WebControls.TextBox tbName;

        [Bean]
        protected IMailService mailService;

        override protected void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (blogService.IsAuthenticated)
            {
                BlogConfig config = blogService.GetConfig(blogService.GetCurrentUserName);
                tbName.Text = config.Author;
                tbEmail.Text = config.Email;
            }
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);

            if (Request.QueryString["id"] == "1")
            {
                btnSend.Text = "��������";
                CheckBox ckb = new CheckBox();
                ckb.Text = "˽������";
                ckb.ID = "chkIsPrivate";
                Controls.Add(ckb);
            }
        }


        private void btnSend_Click(object sender, System.EventArgs e)
        {
            if (Page.IsValid)
            {
                if (Request.QueryString["id"] == "1")
                {
                    SendMessage();

                }
                else
                {
                    SendMail();
                }
            }
        }

        private void SendMail()
        {
            BlogConfig config = BlogContext.Current.Config;
            string To = config.Email;
            string From = tbEmail.Text;

            string Subject = String.Format("{0} (via {1})", tbSubject.Text,
                config.Title);
            //Response.Write(email.SmtpServer);
            string sendersIpAddress = Dottext.Framework.Util.Globals.GetUserIpAddress(Context);

            // \n by itself has issues with qmail (unix via openSmtp), \r\n should work on unix + wintel
            string Body = String.Format("Mail from {0}:\r\n\r\nSender: {1}\r\nEmail: {2}\r\nIP Address: {3}\r\n=====================================\r\n{4}",
                config.Title,
                tbName.Text,
                tbEmail.Text,
                sendersIpAddress,
                tbMessage.Text);

            if (mailService.Send(From, To, Subject, Body) >= 0)
            {
                lblMessage.Text = "����ʼ��Ѿ�������.";
                tbName.Text = "";
                tbEmail.Text = "";
                tbSubject.Text = "";
                tbMessage.Text = "";
            }
            else
            {
                lblMessage.Text = "����ʼ����ܱ�����, �������ʼ�����������������.";
            }

        }

        private void SendMessage()
        {
            Entry entry = new Entry();
            entry.Author = Dottext.Framework.Util.Globals.SafeFormat(tbName.Text);
            entry.Title = Dottext.Framework.Util.Globals.SafeFormat(tbSubject.Text);
            entry.Body = Dottext.Framework.Util.Globals.SafeFormat(tbMessage.Text);
            entry.PostType = PostType.Message;
            entry.Email = tbEmail.Text;
            entry.DateCreated = DateTime.Now;
            Control con = FindControl("chkIsPrivate");
            if (con != null)
            {
                if (!((CheckBox)con).Checked)
                {
                    entry.PostConfig = PostConfig.DisplayOnHomePage | PostConfig.IsActive | PostConfig.AllowComments;
                }
            }
            int PostID = blogService.Create(entry);
            if (PostID > 0)
            {
                lblMessage.Text = "��������Ѿ�������.";
                BlogConfig config = BlogContext.Current.Config;
                string To = config.Email;
                string From = mailService.Sender;
                string Subject = "����������";
                string viewmsg = config.FullyQualifiedUrl + "admin/MyMessages.aspx";
                string Body = String.Format("������: {0}\r\nEmail: {1}\r\n����: {2}\r\n��������: {3}\r\n�������Թ���: {4}",
                    tbName.Text,
                    tbEmail.Text,
                    tbSubject.Text,
                    tbMessage.Text,
                    viewmsg);
                mailService.Send(From, To, Subject, Body);
                tbName.Text = "";
                tbEmail.Text = "";
                tbSubject.Text = "";
                tbMessage.Text = "";
            }


        }
    }
}

