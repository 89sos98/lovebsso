namespace Dottext.Web.UI.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		BlogSearch ��ժҪ˵����
	/// </summary>
    public class BlogSearch : Dottext.Web.UI.Controls.SkinControl
	{

	}
}
