namespace Dottext.Web.UI.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using Dottext.Framework.Components;
	using Dottext.Framework.Data;
	using Dottext.Framework;
    using System.Collections.Generic;

	/// <summary>
	///		MyMessages ��ժҪ˵����
	/// </summary>
	public class MyMessages : SkinControl
	{
        protected System.Web.UI.WebControls.HyperLink lnkMessages;
        protected System.Web.UI.WebControls.HyperLink lnkPublicMsgView;
        protected System.Web.UI.WebControls.HyperLink lnkPrivateMsgView;
        protected System.Web.UI.WebControls.Literal ltMsgCount;
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			
			this.Visible=Dottext.Web.UI.Globals.CheckContorVisible("MyMessages");
			if(!Visible)
			{
				return;
			}
            lnkPrivateMsgView.NavigateUrl = BlogContext.Current.Config.FullyQualifiedUrl + "admin/MyMessages.aspx";
            lnkPublicMsgView.NavigateUrl = BlogContext.Current.Config.FullyQualifiedUrl + "default.aspx?opt=msg";
            lnkMessages.NavigateUrl = BlogContext.Current.Config.FullyQualifiedUrl + "Contact.aspx?id=1";
			EntryQuery eq=new EntryQuery();
			eq.PostType=PostType.Message;
            IList<Entry> ec = blogService.GetEntryCollection(eq);
			ltMsgCount.Text=ec.Count.ToString();
		}

	}
}
