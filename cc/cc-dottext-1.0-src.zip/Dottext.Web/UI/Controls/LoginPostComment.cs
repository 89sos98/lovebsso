using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using Dottext.Framework;
using Dottext.Framework.Tracking;
using Dottext.Framework.Components;
using Dottext.Framework.Util;
using Dottext.Common.Data;
using Dottext.Framework.Configuration;
using System.Xml;
using CchenSoft.Framework;
using CchenSoft.Framework.Attributes;
using FredCK.FCKeditorV2;

namespace Dottext.Web.UI.Controls
{
	/// <summary>
	///		LoginPostComment ��ժҪ˵����
	/// </summary>
    public class LoginPostComment : SkinControl
    {
        protected System.Web.UI.WebControls.TextBox tbTitle;
        protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
        protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator3;
        protected System.Web.UI.WebControls.Button btnSubmit;
        protected System.Web.UI.WebControls.Label Message;

        private const string FTB_RESOURCE_PATH = "/admin/resources/ftb/DotText/";
        protected System.Web.UI.WebControls.HyperLink linkReturn;
        protected System.Web.UI.WebControls.ValidationSummary ValidationSummary1;
        protected System.Web.UI.WebControls.LinkButton btnSubscibe;
        protected System.Web.UI.WebControls.LinkButton btnUnSubscibe;
        private BlogConfig blog_config = null;
        protected FCKeditor fckComment;

        private void Page_Load(object sender, System.EventArgs e)
        {
            // �ڴ˴������û������Գ�ʼ��ҳ��
        }

        protected override void OnLoad(EventArgs e)
        {
            fckComment.BasePath = Config.RootPath + "fckeditor/";

            if (Request.QueryString["login"] == "1")
            {
                this.Visible = true;
                string tmpurl = Request.Url.AbsoluteUri;
                int index = tmpurl.IndexOf("?");
                if (index > 0)
                {
                    linkReturn.NavigateUrl = tmpurl.Substring(0, tmpurl.IndexOf("?")) + "#Post";
                }
            }
            else
            {
                this.Visible = false;
                return;

            }
            base.OnLoad(e);

            if (!blogService.IsAuthenticated)
            {
                string url = Dottext.Framework.Util.Globals.GetSiteQualifiedUrl();
                Response.Redirect(url + "login.aspx?ReturnURL=" + Request.Url.AbsoluteUri);
            }
            else
            {
            }

            if (!IsPostBack)
            {

                Entry entry = Cacher.GetEntryFromRequest(Context, CacheTime.Short);
                if (BlogContext.Current.Config.EnableComments && entry != null && entry.AllowComments)
                {

                    //Need to get this without a db hit?
                    tbTitle.Text = "re: " + entry.Title;
                }
                else
                {
                    this.Visible = false;
                }
            }


        }

        protected void btnSubmit_Click(object sender, System.EventArgs e)
        {
            if (Page.IsValid)
            {
                try
                {

                    Entry currentEntry = Cacher.GetEntryFromRequest(Context, CacheTime.Short);
                    Entry entry = new Entry(PostType.Comment);

                    entry.Author = blog_config.Author;
                    entry.TitleUrl = blog_config.FullyQualifiedUrl;
                    entry.Body = Dottext.Framework.Util.Globals.FilterScript(fckComment.Value);
                    entry.Title = tbTitle.Text;
                    entry.ParentID = currentEntry.EntryID;
                    entry.SourceName = Dottext.Framework.Util.Globals.GetUserIpAddress(Context);
                    entry.SourceUrl = currentEntry.Link;
                    entry.PostType = PostType.Comment;
                    entry.BlogID = blog_config.BlogID;

                    blogService.Create(entry);
                    //Dottext.Framework.Entries.InsertComment(entry);

                    /*if(chkPostAdvanced.Checked)
                    {
                        HttpCookie CommentMode = new HttpCookie("CommentMode","1");
                        CommentMode.Expires = DateTime.Now.AddDays(30);
                        Response.Cookies.Add(CommentMode);
                    }*/
                    Response.Redirect(string.Format("{0}?Pending=true#Post", Request.Path));
                    //Response.Write(ftbComment.Text);
                }
                catch { }
            }
        }

        protected void btnSubscibe_Click(object sender, System.EventArgs e)
        {
            BlogConfig SenderBlogConfig = blogService.GetConfig(blogService.GetCurrentUserName);
            Entry entry = Cacher.GetEntryFromRequest(Context, CacheTime.Short);
            blogService.InsertNotifySubscibe(entry.EntryID, entry.BlogID, SenderBlogConfig.BlogID, SenderBlogConfig.NotifyMail);
            Message.Text = "���ĳɹ�";
        }

        protected void btnUnSubscibe_Click(object sender, System.EventArgs e)
        {
            BlogConfig SenderBlogConfig = blogService.GetConfig(blogService.GetCurrentUserName);
            Entry entry = Cacher.GetEntryFromRequest(Context, CacheTime.Short);
            blogService.DeleteMailNotify(entry.EntryID, SenderBlogConfig.BlogID);
            Message.Text = "��ȡ������";
        }
    }
}
