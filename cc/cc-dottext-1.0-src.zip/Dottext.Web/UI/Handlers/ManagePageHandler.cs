#region License
/*
 *  Copyright (C) 2005-2008 THE CCHENSOFT.COM
 *  
 *  This library is free software; you can redistribute it and/or modify it 
 *  under the terms of the GNU Lesser General Public License 2.1 or later, as
 *  published by the Free Software Foundation. See the included License.txt
 *  or http://www.cchensoft.com/opensource/license.txt for details. 
 */
#endregion

using System;
using System.Web;
using System.Web.UI;
using Dottext.Framework;
using Dottext.Framework.Configuration;
using System.Text.RegularExpressions;

namespace Dottext.Web.UI.Handlers 
{
	/// <summary>
	/// Most pages in WebUI do not exist and are loaded via Activator.CreateInstance(Page page). However, the admin pages
	/// exist and must be parsed. When in BlogRequestType.Multiple the admin directory likely exists in a different 
	/// directory than request. This Handler will edit the path property and reset it to the actual path.
	/// </summary>
    public class ManagePageHandler : IHttpHandlerFactory
    {
        protected static IConfig iconfig;

        public ManagePageHandler()
        {
            iconfig = (IConfig)CchenSoft.Framework.Config.Configuration.Instance.GetBean("Config");
        }

        public virtual IHttpHandler GetHandler(HttpContext context, string requestType, string url, string path)
        {
            return PageParser.GetCompiledPageInstance(url, path, context);
        }

        public void ReleaseHandler(IHttpHandler handler)
        {

        }
    }
}

