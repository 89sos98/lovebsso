#region License
/*
 *  Copyright (C) 2005-2008 THE CCHENSOFT.COM
 *  
 *  This library is free software; you can redistribute it and/or modify it 
 *  under the terms of the GNU Lesser General Public License 2.1 or later, as
 *  published by the Free Software Foundation. See the included License.txt
 *  or http://www.cchensoft.com/opensource/license.txt for details. 
 */
#endregion

using System;
using System.Web.UI;
using Dottext.Web.UI;

namespace Dottext.Web.Admin.Pages
{
	/// <summary>
	/// ManagePage ��ժҪ˵����
	/// </summary>
	public class ManagePage : BasePage
	{
        protected override void OnLoad(EventArgs e)
        {
            if (!blogService.IsAuthenticated)
            {
                //Dottext.Framework.Util.Globals.GetAppUrl(Request)
                Response.Redirect("~/Login.aspx?ReturnUrl=" + Request.Path);//Config.CurrentBlog().FullyQualifiedUrl
            }

            if (!blogService.IsInManagers())
            {
                Response.Write("�����ǹ������Ա�������µ�¼��");
            }

            base.OnLoad(e);
        }
	}
}
