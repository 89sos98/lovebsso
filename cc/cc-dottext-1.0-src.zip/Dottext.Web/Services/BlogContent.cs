#region Disclaimer/Info
///////////////////////////////////////////////////////////////////////////////////////////////////
// .Text WebLog
// Blog:		http://ScottWater.com/blog 
// RSS:			http://scottwater.com/blog/rss.aspx
// License:		http://scottwater.com/License
// Email:		Scott@TripleASP.NET
///////////////////////////////////////////////////////////////////////////////////////////////////
#endregion
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using Dottext.Framework.Components;
using Dottext.Framework;
using Dottext.Framework.Util;
using System.Collections.Generic;
using Dottext.Framework.Service;
using CchenSoft.Framework.Attributes;

namespace Dottext.Web.Services
{
    /// <summary>
    /// Summary description for BlogContent.
    /// </summary>
    [WebService(Name = "DotText Content", Namespace = "http://www.cchensoft.com/opensource/cc-dottext/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class BlogContent : BaseWebService
    {
        [Bean]
        protected BlogService blogService;

        public BlogContent()
            : base()
        {
        }

        [WebMethod(Description = "Requests the last X number of Blog Entries. The number is limited by the settings in the blog.config file. The return type, is an an Array of Entries", EnableSession = false)]
        public Entry[] GetEntries(int ItemCount)
        {
            EntryQuery query = new EntryQuery(PostConfig.IsActive, PostType.BlogPost, Globals.AllowedItemCount(ItemCount));
            return new List<Entry>(blogService.GetEntryCollection(query)).ToArray();
        }

        [WebMethod(Description = "Requests the last X number of Blog Entries By a specific category. The number is limited by the settings in the blog.config file. The return type, is an an Array of Entries", EnableSession = false)]
        public Entry[] GetEntriesByCategory(int ItemCount, int CategoryID)
        {
            EntryQuery query = new EntryQuery();
            query.PostType = PostType.BlogPost;
            query.PostConfig = PostConfig.IsActive;
            query.ItemCount = Globals.AllowedItemCount(ItemCount);
            query.CategoryID = CategoryID;
            return new List<Entry>(blogService.GetEntryCollection(query)).ToArray();
        }

    }
}

