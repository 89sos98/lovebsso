#region Disclaimer/Info
///////////////////////////////////////////////////////////////////////////////////////////////////
// .Text WebLog
// 
// .Text is an open source weblog system started by Scott Watermasysk. 
// Blog: http://ScottWater.com/blog 
// RSS: http://scottwater.com/blog/rss.aspx
// Email: Dottext@ScottWater.com
//
// For updated news and information please visit http://scottwater.com/dottext and subscribe to 
// the Rss feed @ http://scottwater.com/dottext/rss.aspx
//
// On its release (on or about August 1, 2003) this application is licensed under the BSD. However, I reserve the 
// right to change or modify this at any time. The most recent and up to date license can always be fount at:
// http://ScottWater.com/License.txt
// 
// Please direct all code related questions to:
// GotDotNet Workspace: http://www.gotdotnet.com/Community/Workspaces/workspace.aspx?id=e99fccb3-1a8c-42b5-90ee-348f6b77c407
// Yahoo Group http://groups.yahoo.com/group/DotText/
// 
///////////////////////////////////////////////////////////////////////////////////////////////////
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using Dottext.Framework;
using Dottext.Framework.Components;
using Dottext.Framework.Util;
using Dottext.Framework.Configuration;
using System.Collections.Generic;
using CchenSoft.Framework.Attributes;
using Dottext.Framework.Service;

namespace Dottext.Web.Services
{
    /// <summary>
    /// Summary description for Dottext.
    /// </summary>
    [WebService(Name = "ASPNetWebLogApi", Namespace = "http://www.cchensoft.com/opensource/cc-dottext/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class ASPNetWebLogApi : BaseWebService
    {
        [Bean]
        protected BlogService blogService;

        public BlogUser ASPNetWebLogUser;

        public ASPNetWebLogApi()
            : base()
        {
            ASPNetWebLogUser = new BlogUser();
        }

        #region Valiation

        private bool ValidateUser()
        {
            if (ASPNetWebLogUser != null)
            {
                return blogService.IsValidUser(ASPNetWebLogUser.UserName, ASPNetWebLogUser.Password);
            }
            return false;
        }

        #endregion

        #region Categories/Links

        [SoapHeaderAttribute("ASPNetWebLogUser", Direction = SoapHeaderDirection.InOut)]
        [WebMethod(Description = "Set the categories by PostID", EnableSession = false)]
        public bool AddPostToCategories(int PostID, int[] CategoryIDs)
        {
            try
            {
                if (ValidateUser())
                {
                    blogService.SetEntryCategoryList(PostID, CategoryIDs);
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [SoapHeaderAttribute("ASPNetWebLogUser", Direction = SoapHeaderDirection.InOut)]
        [WebMethod(Description = "The entry collection methods do not return each Entry and/or Story's categories. This method will return the category collection for the specified Entry/Story", EnableSession = false)]
        public LinkCollection GetLinkCollectionByPostID(int PostID)
        {
            try
            {
                if (ValidateUser())
                {
                    return blogService.GetLinkCollectionByPostID(PostID);
                }
                return null;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [SoapHeaderAttribute("ASPNetWebLogUser", Direction = SoapHeaderDirection.InOut)]
        [WebMethod(Description = "Returns the categories available for the specificid CategoryType (PostCollection or StoryCollection)", EnableSession = false)]
        public LinkCategory[] GetCategories(CategoryType CategoryType)
        {
            try
            {
                if (ValidateUser())
                {
                    return new List<LinkCategory>(blogService.GetCategoriesByType(CategoryType, false)).ToArray();
                }
                return null;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        #endregion

        #region Update Helpers
        private int InsertEntryCheck(Entry entry, int[] Categories)
        {
            try
            {
                if (ValidateUser())
                {

                    if (entry.Author == null)
                    {
                        entry.Author = BlogContext.Current.Config.Author;
                    }
                    if (entry.Email == null)
                    {
                        entry.Email = BlogContext.Current.Config.Email;
                    }
                    entry.DateCreated.AddHours(BlogTime.ServerToClientTimeZoneFactor);

                    return blogService.Create(entry, Categories);
                }
                return -1;

            }
            catch (Exception e)
            {
                throw e;
            }
        }


        private bool UpdateEntryCheck(Entry entry, int[] Categories)
        {
            try
            {
                if (ValidateUser())
                {
                    if (entry.Author == null)
                    {
                        entry.Author = BlogContext.Current.Config.Author;
                    }
                    if (entry.Email == null)
                    {
                        entry.Email = BlogContext.Current.Config.Email;
                    }
                    entry.DateUpdated.AddHours(BlogTime.ServerToClientTimeZoneFactor);
                    blogService.Update(entry, Categories);
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        #endregion

        #region ResetDates

        private void ResetEntryCollectionDates(ref IList<Entry> ec)
        {
            if (ec != null && ec.Count > 0)
            {
                int offset = BlogTime.ServerToClientTimeZoneFactor;
                int count = ec.Count;
                for (int i = 0; i < count; i++)
                {
                    ec[i].DateUpdated = ec[i].DateUpdated.AddHours(offset);
                    ec[i].DateCreated = ec[i].DateCreated.AddHours(offset);
                }
            }
        }

        #endregion

        #region Insert/Update Methods

        [SoapHeaderAttribute("ASPNetWebLogUser", Direction = SoapHeaderDirection.InOut)]
        [WebMethod(Description = "Insert a new Entry", EnableSession = false)]
        public int InsertEntry(Entry entry)
        {
            return InsertEntryCheck(entry, null);
        }

        [SoapHeaderAttribute("ASPNetWebLogUser", Direction = SoapHeaderDirection.InOut)]
        [WebMethod(Description = "Add a new Blog Entry with a set of categories (LinkCollection)", EnableSession = false)]
        public int InsertEntryAndCategories(Entry entry, int[] lc)
        {
            return InsertEntryCheck(entry, lc);
        }

        [SoapHeaderAttribute("ASPNetWebLogUser", Direction = SoapHeaderDirection.InOut)]
        [WebMethod(Description = "Update an existing entry", EnableSession = false)]
        public bool UpdateEntry(Entry entry)
        {
            return UpdateEntryCheck(entry, null);
        }

        [SoapHeaderAttribute("ASPNetWebLogUser", Direction = SoapHeaderDirection.InOut)]
        [WebMethod(Description = "Update an existing entry and its categories", EnableSession = false)]
        public bool UpdateEntryAndCategories(Entry entry, int[] Categories)
        {
            return UpdateEntryCheck(entry, Categories);
        }


        #endregion

        #region Post Collections

        [SoapHeaderAttribute("ASPNetWebLogUser", Direction = SoapHeaderDirection.InOut)]
        [WebMethod(Description = "Returns the most recent posts")]
        public Entry[] GetRecentPosts(int ItemCount)
        {
            try
            {
                if (ValidateUser())
                {
                    EntryQuery query = new EntryQuery(PostConfig.Empty, PostType.BlogPost, ItemCount);
                    IList<Entry> ec = blogService.GetEntryCollection(query);
                    //EntryCollection ec =  Entries.GetRecentPosts(ItemCount,PostType.BlogPost,false);
                    ResetEntryCollectionDates(ref ec);
                    return new List<Entry>(ec).ToArray();
                }
                return null;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //		[SoapHeaderAttribute("ASPNetWebLogUser", Direction=SoapHeaderDirection.InOut)]
        //		[WebMethod(MessageName="GetStories",Description="Returns an EntryCollection with all of the current stories",EnableSession=false)]
        //		public EntryCollection GetStories()
        //		{
        //			try
        //			{
        //				if(ValidateUser())
        //				{
        //					EntryCollection ec = Entries.GetAllStoreis(false);
        //					ResetEntryCollectionDates(ref ec);
        //					return ec;
        //				}
        //				return null;
        //			}
        //			catch(Exception e)
        //			{
        //				throw e;
        //			}
        //		}
        //
        //		[SoapHeaderAttribute("ASPNetWebLogUser", Direction=SoapHeaderDirection.InOut)]
        //		[WebMethod(MessageName="GetUpdatedStories",Description="Returns an EntryCollection with all of the current stories",EnableSession=false)]
        //		public EntryCollection GetStories(DateTime UpdatedSince)
        //		{
        //			try
        //			{
        //				if(ValidateUser())
        //				{
        //					EntryCollection ec = Entries.GetAllStoreis(false,UpdatedSince.AddHours(BlogTime.ServerToClientTimeZoneFactor));
        //					ResetEntryCollectionDates(ref ec);
        //					return ec;
        //				}
        //				return null;
        //			}
        //			catch(Exception e)
        //			{
        //				throw e;
        //			}
        //		}

        #endregion

        #region Delete Posts

        [SoapHeaderAttribute("ASPNetWebLogUser", Direction = SoapHeaderDirection.InOut)]
        [WebMethod(Description = "Remove an entry and/or story", EnableSession = false)]
        public bool DeleteEntry(int PostID)
        {
            try
            {
                if (ValidateUser())
                {
                    blogService.Delete(PostID);
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        #endregion

        #region Update Categories and Links

        [SoapHeaderAttribute("ASPNetWebLogUser", Direction = SoapHeaderDirection.InOut)]
        [WebMethod(Description = "Insert a new LinkCateogry", EnableSession = false)]
        public int InsertCategory(LinkCategory lc)
        {
            try
            {
                if (ValidateUser())
                {
                    return blogService.CreateLinkCategory(lc);
                }
                return -1;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [SoapHeaderAttribute("ASPNetWebLogUser", Direction = SoapHeaderDirection.InOut)]
        [WebMethod(Description = "Update a LinkCateogry", EnableSession = false)]
        public void UpdateCategory(LinkCategory lc)
        {
            try
            {
                if (ValidateUser())
                {
                    blogService.UpdateLinkCategory(lc);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [SoapHeaderAttribute("ASPNetWebLogUser", Direction = SoapHeaderDirection.InOut)]
        [WebMethod(Description = "Insert a new Link", EnableSession = false)]
        public int InsertLink(Link _link)
        {
            try
            {
                if (ValidateUser())
                {
                    return blogService.CreateLink(_link);
                }
                return -1;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [SoapHeaderAttribute("ASPNetWebLogUser", Direction = SoapHeaderDirection.InOut)]
        [WebMethod(Description = "Update a Link", EnableSession = false)]
        public void UpdateLink(Link _link)
        {
            try
            {
                if (ValidateUser())
                {
                    blogService.UpdateLink(_link);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        #endregion


    }
}

