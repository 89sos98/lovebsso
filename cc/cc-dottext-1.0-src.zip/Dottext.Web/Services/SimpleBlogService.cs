#region Disclaimer/Info
///////////////////////////////////////////////////////////////////////////////////////////////////
// .Text WebLog
// 
// .Text is an open source weblog system started by Scott Watermasysk. 
// Blog: http://ScottWater.com/blog 
// RSS: http://scottwater.com/blog/rss.aspx
// Email: Dottext@ScottWater.com
//
// For updated news and information please visit http://scottwater.com/dottext and subscribe to 
// the Rss feed @ http://scottwater.com/dottext/rss.aspx
//
// On its release (on or about August 1, 2003) this application is licensed under the BSD. However, I reserve the 
// right to change or modify this at any time. The most recent and up to date license can always be fount at:
// http://ScottWater.com/License.txt
// 
// Please direct all code related questions to:
// GotDotNet Workspace: http://www.gotdotnet.com/Community/Workspaces/workspace.aspx?id=e99fccb3-1a8c-42b5-90ee-348f6b77c407
// Yahoo Group http://groups.yahoo.com/group/DotText/
// 
///////////////////////////////////////////////////////////////////////////////////////////////////
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using Dottext.Framework;
using Dottext.Framework.Components;
using Dottext.Framework.Util;
using Dottext.Framework.Configuration;
using System.Collections.Generic;
using CchenSoft.Framework.Attributes;
using Dottext.Framework.Service;

namespace Dottext.Web.Services
{
    /// <summary>
    /// Summary description for SimpleBlogService.
    /// </summary>
    [WebService(Name = "SBS (Simple Blog Service)", Namespace = "http://www.cchensoft.com/opensource/cc-dottext/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class SBS : BaseWebService
    {
        [Bean]
        protected BlogService blogService;

        public SBS()
            : base()
        {

        }

        private void CheckUser(string username, string password)
        {
            BlogConfig config = BlogContext.Current.Config;

            if (!blogService.IsValidUser(username, password))
            {
                throw new Exception("Unknown User. Try another UserName/Password...or go away");
            }
        }

        [WebMethod(Description = "Insert a Post with Categories", EnableSession = false)]
        public int InsertCategoryPost(string username, string password, DateTime postdate, string title, string body, string url, string[] categories)
        {
            BlogConfig config = BlogContext.Current.Config;
            CheckUser(username, password);
            CategoryEntry entry = new CategoryEntry();
            entry.PostType = PostType.BlogPost;
            entry.Title = title;
            entry.Body = body;
            entry.TitleUrl = url;
            entry.DateCreated = postdate.AddHours(BlogTime.ServerToClientTimeZoneFactor);
            entry.DateUpdated = entry.DateCreated;
            entry.IsActive = true;
            entry.AllowComments = true;
            entry.DisplayOnHomePage = true;
            entry.IncludeInMainSyndication = true;
            entry.IsAggregated = true;
            entry.SyndicateDescriptionOnly = false;
            entry.Author = config.Author;
            entry.Email = config.Email;
            entry.Categories = categories;
            return blogService.Create(entry);
        }

        [WebMethod(Description = "Add a new Blog Entry", EnableSession = false)]
        public int InsertPost(string username, string password, DateTime postdate, string title, string body, string url)
        {
            CheckUser(username, password);
            BlogConfig config = BlogContext.Current.Config;
            Entry entry = new Entry(PostType.BlogPost);
            entry.Title = title;
            entry.Body = body;
            entry.TitleUrl = url;
            entry.DateCreated = postdate.AddHours(BlogTime.ServerToClientTimeZoneFactor);
            entry.IsActive = true;
            entry.AllowComments = true;
            entry.DisplayOnHomePage = true;
            entry.IncludeInMainSyndication = true;
            entry.IsAggregated = true;
            entry.SyndicateDescriptionOnly = false;
            entry.Author = config.Author;
            entry.Email = config.Email;
            return blogService.Create(entry);

        }

        [WebMethod(Description = "Update existing entry", EnableSession = false)]
        public bool UpdateEntry(int entryid, string username, string password, DateTime postupdate, string title, string body, string url)
        {
            CheckUser(username, password);
            Entry entry = blogService.GetEntry(entryid, PostConfig.Empty);
            if (entry != null)
            {
                entry.Title = title;
                entry.Body = body;
                entry.TitleUrl = url;
                entry.DateUpdated = postupdate.AddHours(BlogTime.ServerToClientTimeZoneFactor);
                entry.IsActive = true;
                return blogService.Update(entry);
            }

            return false;

        }

        [WebMethod(Description = "A list of Post Categories", EnableSession = false)]
        public string[] GetCategories(string username, string password)
        {
            CheckUser(username, password);
            IList<LinkCategory> lcc = blogService.GetCategoriesByType(CategoryType.PostCollection, false);
            ArrayList al = new ArrayList();
            foreach (LinkCategory lc in lcc)
            {
                al.Add(lc.Title);
            }
            return (string[])al.ToArray(typeof(string));
        }

    }
}

