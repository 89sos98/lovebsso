﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Services;
using CchenSoft.Framework.Utils;

namespace Dottext.Web
{
    public class BaseWebService : WebService
    {
        public BaseWebService()
        {
            ReflectUtil.InjectBeans(this);
        }
    }
}
