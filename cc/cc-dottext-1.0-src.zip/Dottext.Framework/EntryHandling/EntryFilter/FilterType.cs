using System;

namespace Dottext.Framework.EntryHandling
{
	/// <summary>
	/// FilterType ��ժҪ˵����
	/// </summary>
	[Flags()]
	public enum FilterType
	{
		Script = 1,
		Html =2,
		Object=4		
	}
}
