using System;
using Dottext.Framework.Configuration;
using Dottext.Framework.Components;
using Dottext.Framework.Util;
using Dottext.Framework.Service;
using CchenSoft.Framework.Service;

namespace Dottext.Framework.EntryHandling
{
	/// <summary>
	/// IEntryFactoryHandler for sending comments
	/// </summary>
	public class CommentDeliveryHandler : IEntryFactoryHandler
	{
        protected BlogService blogService;
        protected IMailService mailService;

		public CommentDeliveryHandler()
		{
            blogService = CchenSoft.Framework.Config.Configuration.Instance.GetService<BlogService>();
            mailService = CchenSoft.Framework.Config.Configuration.Instance.GetService<IMailService>();
		}

		#region IEntryFactoryHandler Members

		/// <summary>
		/// Sends a comment aynchronously, if the commenter is not the blog administrator
		/// </summary>
		/// <param name="e"></param>
		public void Process(Dottext.Framework.Components.Entry e)
		{
			if((!isAdmin)&&isEnableMailNotify)
			{
				try
				{
					// create and format an email to the site admin with comment details
                    //IMailService im = EmailProvider.Instance();
					
					string To = to;
                    string From = mailService.Sender;
					string Subject = String.Format("[�ظ�֪ͨ]{0}[{1}]", e.Title, blogTitle);
					string Body = String.Format("{0}\r\n=====================================\r\n\r\n{1}\r\n\r\n=====================================\r\n����: {2}\r\nUrl: {3}\r\nSource: {4}#{5}\r\nIP: {6}\r\n\r\n���ʼ���ϵͳ�Զ�����,�벻Ҫ�ظ����ʼ�", 
						//blogTitle,
						//e.SourceName,
						e.Title,					
						// we're sending plain text email by default, but body includes <br>s for crlf
						Globals.RemoveHtml(e.Body.Replace("<br>", "\n").Replace("&nbsp;"," ")), 
						e.Author,
						e.TitleUrl,
						e.SourceUrl,
						e.EntryID,e.SourceName);

                    mailService.Send(From, To, Subject, Body);
				}
				catch{}
			}
		}

		/// <summary>
		/// Grab items we might not have access to later
		/// </summary>
		public void Configure()
		{
            BlogConfig config = BlogContext.Current.Config;
			blogTitle = config.Title;
			to = config.NotifyMail;
			isAdmin = blogService.IsAdmin;
			isEnableMailNotify=config.IsMailNotify;
		}

		string blogTitle = null;
		string to = null;
		bool isAdmin;
		bool isEnableMailNotify;

		#endregion
	}
}
