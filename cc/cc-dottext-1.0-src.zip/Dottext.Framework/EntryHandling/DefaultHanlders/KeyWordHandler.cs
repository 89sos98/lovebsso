using System;
using Dottext.Framework.Util;
using Dottext.Framework.Service;

namespace Dottext.Framework.EntryHandling
{
	/// <summary>
	/// Summary description for KeyWordFactory.
	/// </summary>
	public class KeyWordHandler : IEntryFactoryHandler
	{
        protected BlogService blogService;

		public KeyWordHandler()
		{
            blogService = CchenSoft.Framework.Config.Configuration.Instance.GetService<BlogService>();
		}

		#region IEntryFactoryHandler Members

		public void Configure(){}

		public void Process(Dottext.Framework.Components.Entry e)
		{
            blogService.Format(ref e);
		}

		#endregion
	}
}
