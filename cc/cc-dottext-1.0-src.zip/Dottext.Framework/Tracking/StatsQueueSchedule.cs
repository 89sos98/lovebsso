using System;
using Dottext.Framework.Service;
using FxConfiguration = CchenSoft.Framework.Config.Configuration;

namespace Dottext.Framework.Tracking
{
	/// <summary>
	/// Summary description for StatsQueueSchedule.
	/// </summary>
	public class StatsQueueSchedule : Dottext.Framework.ScheduledEvents.IEvent
	{
        protected BlogService blogService;

		public StatsQueueSchedule()
		{
            blogService = FxConfiguration.Instance.GetService<BlogService>();
		}
		#region IEvent Members

		public void Execute(object state)
		{
			blogService.ClearQueue(true);
		}

		#endregion
	}
}
