#region License
/*
 *  Copyright (C) 2005-2008 THE CCHENSOFT.COM
 *  
 *  This library is free software; you can redistribute it and/or modify it 
 *  under the terms of the GNU Lesser General Public License 2.1 or later, as
 *  published by the Free Software Foundation. See the included License.txt
 *  or http://www.cchensoft.com/opensource/license.txt for details. 
 */
#endregion

using System;
using System.Data;
using System.Globalization;
using Dottext.Framework.Components;
using Dottext.Framework.Util;
using Dottext.Framework.Configuration;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using CchenSoft.Framework.DataAccess;


namespace Dottext.Framework.Application
{
	/// <summary>
	/// Summary description for DataHelper.
	/// </summary>
	public class EntryConverter : IConverter
	{
        #region IConverter ��Ա

        public T Convert<T>(IDataReader reader)
        {
            T result = default(T);
            if (typeof(T) == typeof(Entry))
            {
                result = (T)LoadSingleEntry(reader);
            }
            else if (typeof(T) == typeof(EntryStatsView))
            {
                result = (T)LoadSingleEntryStatsView(reader);
            }
            else if (typeof(T) == typeof(BlogConfig))
            {
                result = (T)LoadConfigData(reader);
            }
            else if (typeof(T) == typeof(CategoryEntry))
            {
                result = (T)LoadSingleCategoryEntry(reader);
            }
            else if (typeof(T) == typeof(SkinControl))
            {
                result = (T)LoadSkinControl(reader);
            }
            else if (typeof(T) == typeof(ArchiveCount))
            {
                result = (T)LoadArchiveCount(reader);
            }
            else if (typeof(T) == typeof(KeyWord))
            {
                result = (T)LoadSingleKeyWord(reader);
            }
            else if (typeof(T) == typeof(LinkCategory))
            {
                result = (T)LoadSingleLinkCategory(reader);
            }
            else if (typeof(T) == typeof(Link))
            {
                result = (T)LoadSingleLink(reader);
            }
            else if (typeof(T) == typeof(Image))
            {
                result = (T)LoadSingleImage(reader);
            }
            else if (typeof(T) == typeof(Referrer))
            {
                result = (T)LoadSingleReferrer(reader);
            }
            else if (typeof(T) == typeof(Role))
            {
                result = (T)LoadSingleRole(reader);
            }
            else if (typeof(T) == typeof(int) || typeof(T) == typeof(string))
            {
                result = (T)reader[0];
            }

            return result;
        }

        #endregion

		#region Statisitics

		public static ViewStat LoadSingleViewStat(IDataReader reader)
		{
			ViewStat vStat = new ViewStat();


			if (reader["Title"] != DBNull.Value)
			{
				vStat.PageTitle = (string) reader["Title"];
			}

			if (reader["Count"] != DBNull.Value)
			{
				vStat.ViewCount = (int) reader["Count"];
			}

			if (reader["Day"] != DBNull.Value)
			{
				vStat.ViewDate = (DateTime) reader["Day"];
			}

			if (reader["PageType"] != DBNull.Value)
			{
				vStat.PageType = (PageType)((byte)reader["PageType"]);
			}

            return vStat;
		}

		public object LoadSingleReferrer(IDataReader reader)
		{
			Referrer refer = new Referrer();


			if (reader["URL"] != DBNull.Value)
			{
				refer.ReferrerURL = (string) reader["URL"];
			}

			if (reader["Title"] != DBNull.Value)
			{
				refer.PostTitle = (string) reader["Title"];
			}

			if (reader["EntryID"] != DBNull.Value)
			{
				refer.EntryID = (int) reader["EntryID"];
			}

			if (reader["LastUpdated"] != DBNull.Value)
			{
				refer.LastReferDate = (DateTime) reader["LastUpdated"];
			}

			if (reader["Count"] != DBNull.Value)
			{
				refer.Count = (int) reader["Count"];
			}

			return refer;
		}

		#endregion
    
		#region Single Entry

		//Crappy. Need to clean up all of the entry references
		private object LoadSingleEntryStatsView(IDataReader reader)
		{
			EntryStatsView entry = new EntryStatsView();

			entry.PostType = ((PostType)(int)reader["PostType"]);
			if(reader["BlogID"] != DBNull.Value)
			{
				entry.BlogID = (int)reader["BlogID"];	
			}

			if(reader["WebCount"] != DBNull.Value)
			{
				entry.WebCount = (int)reader["WebCount"];	
			}

			if(reader["AggCount"] != DBNull.Value)
			{
				entry.AggCount = (int)reader["AggCount"];	
			}

			if(reader["WebLastUpdated"] != DBNull.Value)
			{
				entry.WebLastUpdated = (DateTime)reader["WebLastUpdated"];	
			}
			
			if(reader["AggLastUpdated"] != DBNull.Value)
			{
				entry.AggLastUpdated = (DateTime)reader["AggLastUpdated"];	
			}

			if(reader["Author"] != DBNull.Value)
			{
				entry.Author = (string)reader["Author"];
			}
			if(reader["Email"] != DBNull.Value)
			{
				entry.Email = (string)reader["Email"];
			}
			entry.DateCreated = (DateTime)reader["DateAdded"];
			entry.DateUpdated = (DateTime)reader["DateUpdated"];

			entry.EntryID = (int)reader["ID"];

			if(reader["TitleUrl"] != DBNull.Value)
			{
				entry.TitleUrl = (string)reader["TitleUrl"];
			}
			
			if(reader["SourceName"] != DBNull.Value)
			{
				entry.SourceName = (string)reader["SourceName"];
			}
			if(reader["SourceUrl"] != DBNull.Value)
			{
				entry.SourceUrl = (string)reader["SourceUrl"];
			}

			if(reader["Description"] != DBNull.Value)
			{
				entry.Description = (string)reader["Description"];
			}

			if(reader["EntryName"] != DBNull.Value)
			{
				entry.EntryName = (string)reader["EntryName"];
			}

			entry.FeedBackCount = (int)reader["FeedBackCount"];
			if(reader["Text"]!=DBNull.Value)
			{
				entry.Body = (string)reader["Text"];
			}
			else
			{
				entry.Body="";
			}
			entry.Title =(string)reader["Title"];

			entry.PostConfig = (PostConfig)((int)reader["PostConfig"]);

			entry.ParentID = (int)reader["ParentID"];

			SetUrlPattern(entry);
            BlogConfig config = BlogContext.Current.Config;
            if (BlogContext.Current.Config is SiteBlogConfig && reader["Application"] != DBNull.Value)
			{
				string url=config.FullyQualifiedUrl;
				//string url=Util.Globals.GetSiteQualifiedUrl();
				if(!url.EndsWith("/"))
				{
					url+="/";
				}
				
                //gjung  modify
				entry.Link=Regex.Replace(entry.Link,url,url+reader["Application"]+"/");
			}
			
			return entry;
		}

		public static EntryStatsView LoadSingleEntryView(IDataReader reader)
		{
			EntryStatsView entry = new EntryStatsView();

			if(reader["WebCount"] != DBNull.Value)
			{
				entry.WebCount = (int)reader["WebCount"];	
			}
			

			if(reader["AggCount"] != DBNull.Value)
			{
				entry.AggCount = (int)reader["AggCount"];	
			}

			if(reader["WebLastUpdated"] != DBNull.Value)
			{
				entry.WebLastUpdated = (DateTime)reader["WebLastUpdated"];	
			}
			
			if(reader["AggLastUpdated"] != DBNull.Value)
			{
				entry.AggLastUpdated = (DateTime)reader["AggLastUpdated"];	
			}

			return entry;
		}

        private void LoadSingleEntry(ref Entry entry, IDataReader reader)
        {
            entry = (Entry)LoadSingleEntry(reader, true);
        }

        private object LoadSingleEntry(IDataReader reader)
		{
            return LoadSingleEntry(reader, true);
		}

		private object LoadSingleEntry(IDataReader reader, bool BuildLinnks)
		{
			Entry entry = new Entry((PostType)(int)reader["PostType"]);

			if(reader["BlogID"] != DBNull.Value)
			{
				entry.BlogID = (int)reader["BlogID"];
			}
			
			if(reader["Author"] != DBNull.Value)
			{
				entry.Author = (string)reader["Author"];
			}
			if(reader["Email"] != DBNull.Value)
			{
				entry.Email = (string)reader["Email"];
			}
			entry.DateCreated = (DateTime)reader["DateAdded"];
			entry.DateUpdated = (DateTime)reader["DateUpdated"];

			entry.EntryID = (int)reader["ID"];

			if(reader["TitleUrl"] != DBNull.Value)
			{
				entry.TitleUrl = (string)reader["TitleUrl"];
			}
			
			if(reader["SourceName"] != DBNull.Value)
			{
				entry.SourceName = (string)reader["SourceName"];
			}
			if(reader["SourceUrl"] != DBNull.Value)
			{
				entry.SourceUrl = (string)reader["SourceUrl"];
			}

			if(reader["Description"] != DBNull.Value)
			{
				entry.Description = (string)reader["Description"];
			}

			if(reader["EntryName"] != DBNull.Value)
			{
				entry.EntryName = (string)reader["EntryName"];
			}

			entry.FeedBackCount = (int)reader["FeedBackCount"];
			if(reader["Text"]!=DBNull.Value)
			{
				entry.Body = (string)reader["Text"];
			}
			else
			{
				entry.Body="";
			}
			entry.Title =(string)reader["Title"];

			entry.PostConfig = (PostConfig)((int)reader["PostConfig"]);

			entry.ParentID = (int)reader["ParentID"];

			if(reader["WebCount"] != DBNull.Value)
			{
				entry.WebCount = (int)reader["WebCount"];	
			}

			if(reader["AggCount"] != DBNull.Value)
			{
				entry.AggCount = (int)reader["AggCount"];	
			}

			if(BuildLinnks)
			{
				SetUrlPattern(entry);

                if (BlogContext.Current.Config.BlogID < 0 && reader["Application"] != DBNull.Value)
				{
                    BlogConfig config = BlogContext.Current.Config;
					string url=config.FullyQualifiedUrl;
					if(!url.EndsWith("/"))
					{
						url+="/";
					}
				
                    // gjung modify
					entry.Link=Regex.Replace(entry.Link,url,url+reader["Application"]+"/");
				}
			}

			return entry;
		}

		private static void SetUrlPattern(Entry entry)
		{
			switch(entry.PostType)
			{
				case PostType.BlogPost:
                    entry.Link = BlogContext.Current.Config.UrlFormats.EntryUrl(entry);
					break;
				case PostType.Article:
                    entry.Link = BlogContext.Current.Config.UrlFormats.ArticleUrl(entry);
					break;
				case PostType.Message:
                    entry.Link = BlogContext.Current.Config.UrlFormats.MessageUrl(entry);
					break;

				case PostType.Comment:
				case PostType.PingTrack:
                    entry.Link = BlogContext.Current.Config.UrlFormats.CommentUrl(entry);
					break;
			}			
		}

		/// <summary>
		/// Returns a single CategoryEntry from a DataReader. Expects the data reader to have
		/// two sets of results. Should only be used to load 1 ENTRY
		/// </summary>
		/// <param name="reader"></param>
		/// <returns></returns>
		private object LoadSingleCategoryEntry(IDataReader reader)
		{
			//This method is quite disgusting. Either clean up the helpers or remove them :)
			CategoryEntry entry = new CategoryEntry();

			if(reader["Author"] != DBNull.Value)
			{
				entry.Author = (string)reader["Author"];
			}
			if(reader["Email"] != DBNull.Value)
			{
				entry.Email = (string)reader["Email"];
			}
			entry.DateCreated = (DateTime)reader["DateAdded"];
			entry.DateUpdated = (DateTime)reader["DateUpdated"];

			entry.EntryID = (int)reader["ID"];

			if(reader["TitleUrl"] != DBNull.Value)
			{
				entry.TitleUrl = (string)reader["TitleUrl"];
			}
			
			if(reader["SourceName"] != DBNull.Value)
			{
				entry.SourceName = (string)reader["SourceName"];
			}
			if(reader["SourceUrl"] != DBNull.Value)
			{
				entry.SourceUrl = (string)reader["SourceUrl"];
			}

			if(reader["Description"] != DBNull.Value)
			{
				entry.Description = (string)reader["Description"];
			}

			if(reader["EntryName"] != DBNull.Value)
			{
				entry.EntryName = (string)reader["EntryName"];
			}

			entry.FeedBackCount = (int)reader["FeedBackCount"];
			entry.Body = (string)reader["Text"];
			entry.Title =(string)reader["Title"];

			entry.PostConfig = (PostConfig)((int)reader["PostConfig"]);

			entry.ParentID = (int)reader["ParentID"];


			SetUrlPattern(entry);

			return entry;
		}

        private object LoadSingleRole(IDataReader reader)
        {
            Role role = new Role();
            if (reader["RoleID"] != DBNull.Value)
            {
                role.RoleID = (int)reader["RoleID"];
            }
            if (reader["Name"] != DBNull.Value)
            {
                role.Name = (string)reader["Name"];
            }
            if (reader["Description"] != DBNull.Value)
            {
                role.Description = (string)reader["Description"];
            }
            return role;
        }

		#endregion

		#region Categories

		public object LoadSingleLinkCategory(IDataReader reader)
		{
			LinkCategory lc = new LinkCategory();
			lc.CategoryID = (int)reader["CategoryID"];
			lc.Title = (string)reader["Title"];
			lc.IsActive = (bool)reader["Active"];
			lc.CategoryType = (CategoryType)((byte)reader["CategoryType"]);
			if(reader["ParentID"] != DBNull.Value)
			{
				lc.ParentID = (int)reader["ParentID"];
			}
			if(reader["Description"] != DBNull.Value)
			{
				lc.Description = (string)reader["Description"];
			}
			return lc;
		}

        //public static LinkCategory LoadSingleLinkCategory(DataRow dr)
        //{
        //    LinkCategory lc = new LinkCategory();
        //    lc.CategoryID = (int)dr["CategoryID"];
        //    lc.Title = (string)dr["Title"];
        //    lc.IsActive = (bool)dr["Active"];
        //    lc.CategoryType = (CategoryType)((byte)dr["CategoryType"]);
        //    if(dr["Description"] != DBNull.Value)
        //    {
        //        lc.Description = (string)dr["Description"];
        //    }
        //    return lc;
        //}

		#endregion

		#region Links

		public object LoadSingleLink(IDataReader reader)
		{
			Link link = new Link();
			link.IsActive = (bool)reader["Active"];
			link.NewWindow = (bool)reader["NewWindow"];
			link.LinkID = (int)reader["LinkID"];
			if(reader["Rss"] != DBNull.Value)
			{
				link.Rss = (string)reader["Rss"];
			}
			if(reader["Url"] != DBNull.Value)
			{
				link.Url = (string)reader["Url"];
			}
			if(reader["Title"] != DBNull.Value)
			{
				link.Title = (string)reader["Title"];
			}
			if(reader["UpdateTime"] != DBNull.Value)
			{
				link.UpdateTime = (DateTime)reader["UpdateTime"];
			}
			link.CategoryID = (int)reader["CategoryID"];
			link.PostID = (int)reader["PostID"];
			return link;
		}

        //public static Link LoadSingleLink(DataRow dr)
        //{
        //    Link link = new Link();
        //    link.IsActive = (bool)dr["Active"];
        //    link.NewWindow = (bool)dr["NewWindow"];
        //    link.LinkID = (int)dr["LinkID"];
        //    if(dr["Rss"] != DBNull.Value)
        //    {
        //        link.Rss = (string)dr["Rss"];
        //    }
        //    if(dr["Url"] != DBNull.Value)
        //    {
        //        link.Url = (string)dr["Url"];
        //    }
        //    if(dr["Title"] != DBNull.Value)
        //    {
        //        link.Title = (string)dr["Title"];
        //    }
        //    if(dr["UpdateTime"] != DBNull.Value)
        //    {
        //        link.UpdateTime = (DateTime)dr["UpdateTime"];
        //    }
        //    link.CategoryID = (int)dr["CategoryID"];
        //    link.PostID = (int)dr["PostID"];
        //    return link;
        //}

		#endregion

		#region Config

		private object LoadConfigData(IDataReader reader)
		{
			BlogConfig config = new BlogConfig();
			config.Author = (string)reader["Author"];
			config.BlogID = (int)reader["BlogID"];
			config.Email = (string)reader["Email"];
			config.Password = (string)reader["Password"];

			config.SubTitle = (string)reader["SubTitle"];
			config.Title = (string)reader["Title"];
			config.UserName = (string)reader["UserName"];
			config.TimeZone = (int)reader["TimeZone"];
			config.ItemCount = (int)reader["ItemCount"];
			config.Language = (string)reader["Language"];
			

			/*config.PostCount = (int)reader["PostCount"];
			config.CommentCount = (int)reader["CommentCount"];
			config.StoryCount = (int)reader["StoryCount"];
			config.PingTrackCount = (int)reader["PingTrackCount"];*/
			if(reader["PostCount"]!=DBNull.Value)
			{
				config.PostCount = (int)reader["PostCount"];
			}
			if(reader["CommentCount"]!=DBNull.Value)
			{
				config.CommentCount = (int)reader["CommentCount"];
			}
			if(reader["StoryCount"]!=DBNull.Value)
			{
				config.StoryCount = (int)reader["StoryCount"];
			}
			if(reader["PingTrackCount"]!=DBNull.Value)
			{
				config.PingTrackCount = (int)reader["PingTrackCount"];
			}

			if(reader["News"] != DBNull.Value)
			{
				config.News = (string)reader["News"];
			}

			if(reader["LastUpdated"] != DBNull.Value)
			{
				config.LastUpdated = (DateTime)reader["LastUpdated"];
			}
			else
			{
				config.LastUpdated = new DateTime(2003,1,1);
			}
			config.Host = (string)reader["Host"];
			config.Application = (string)reader["Application"];

			config.Flag = (ConfigurationFlag)((int)reader["Flag"]);

			config.Skin = new SkinConfig();
			config.Skin.SkinName = (string)reader["Skin"];

			if(reader["SkinCssFile"] != DBNull.Value)
			{
				config.Skin.SkinCssFile = (string)reader["SkinCssFile"];
			}
		
			if(reader["SecondaryCss"] != DBNull.Value)
			{
				config.Skin.SkinCssText = (string)reader["SecondaryCss"];
			}
			if(reader["IsMailNotify"]!=DBNull.Value)
			{
				config.IsMailNotify=(bool)reader["IsMailNotify"];
			}
			else
			{
				config.IsMailNotify=true;
			}
			
			if(reader["IsOnlyListTitle"]!=DBNull.Value)
			{
				config.IsOnlyListTitle=(bool)reader["IsOnlyListTitle"];
			}
			else
			{
				config.IsOnlyListTitle=false;
			}

			if(reader["NotifyMail"]==DBNull.Value)
			{
				config.NotifyMail=config.Email;
			}
			else
			{
				config.NotifyMail=(string)reader["NotifyMail"];
			}

			//Wait till v2.0
			//config.ExtendedProperties = new ExtendedProperties((byte[])reader["NVC"]);

			return config;
		}

		private object LoadSkinControl(IDataReader reader)
		{
			SkinControl skinControl = new SkinControl();
			skinControl.ID=(int)reader["ID"];
			skinControl.Control=(string)reader["Control"];
			skinControl.Name=(string)reader["ControlName"];
			skinControl.Visible=(bool)reader["Visible"];
			return skinControl;
		}
		#endregion

		#region Archive

        private object LoadArchiveCount(IDataReader reader)
        {
            const string dateformat = "{0}/{1}/{2}";
            CultureInfo en = new CultureInfo("en-US");

            ArchiveCount ac = new ArchiveCount();
            string dt = string.Format(dateformat, (int)reader["Month"], (int)reader["Day"], (int)reader["Year"]);
            ac.Date = DateTime.Parse(dt);
            //ac.Date = DateTime.ParseExact(dt,"MM/dd/yyyy",en);

            ac.Count = (int)reader["Count"];

            return ac;
        }

		#endregion

		#region Image

		public object LoadSingleImage(IDataReader reader)
		{
			Image _image = new Image();
			_image.CategoryID = (int)reader["CategoryID"];
			_image.File = (string)reader["File"];
			_image.Height = (int)reader["Height"];
			_image.Width = (int)reader["Width"];
			_image.ImageID = (int)reader["ImageID"];
			_image.IsActive = (bool)reader["Active"];
			_image.Title = (string)reader["Title"];
			return _image;
		}

		#endregion

		#region Keywords

		private object LoadSingleKeyWord(IDataReader reader)
		{
			KeyWord kw = new KeyWord();
			kw.KeyWordID = (int)reader["KeyWordID"];
			kw.BlogID = (int)reader["BlogID"];
			kw.OpenInNewWindow = (bool)reader["OpenInNewWindow"];
			kw.ReplaceFirstTimeOnly = (bool)reader["ReplaceFirstTimeOnly"];
			kw.CaseSensitive = (bool)reader["CaseSensitive"];
			kw.Text = (string)reader["Text"];
			kw.Title = CheckNullString(reader["Title"]);
			kw.Url = (string)reader["Url"];
			kw.Word = (string)reader["Word"];
			return kw;
		}



		#endregion

        #region Helpers

        public static string CheckNullString(object obj)
        {
            if (obj is DBNull)
            {
                return null;
            }
            return (string)obj;
        }

        #endregion


    }
}

