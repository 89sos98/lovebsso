#region License
/*
 *  Copyright (C) 2005-2008 THE CCHENSOFT.COM
 *  
 *  This library is free software; you can redistribute it and/or modify it 
 *  under the terms of the GNU Lesser General Public License 2.1 or later, as
 *  published by the Free Software Foundation. See the included License.txt
 *  or http://www.cchensoft.com/opensource/license.txt for details. 
 */
#endregion

using System;
using System.Data;
using System.Reflection;
using System.Collections;

using Dottext.Framework.Components;
using Dottext.Framework.Configuration;
using Dottext.Framework.Format;
using Dottext.Framework.Tracking;
using Dottext.Framework.Util;
using Dottext.Framework.Logger;
using System.Collections.Generic;
using System.Data.SqlClient;
using CchenSoft.Framework.Data;
using CchenSoft.Framework.Attributes;



namespace Dottext.Framework.Data
{
	/// <summary>
    /// Summary description for SqlBlogDao.
	/// </summary>
    public class SqlBlogDao : IBlogDao
    {
        private IDataService dataService;

        public SqlBlogDao()
        {
        }

        public IDataService DataService
        {
            set { this.dataService = value; }
        }

        #region Parameters

        public object CheckForNullString(string text)
        {
            if (text == null || text.Trim().Length == 0)
            {
                return System.DBNull.Value;
            }
            else
            {
                return text;
            }
        }

        public SqlParameter MakeInParam(string ParamName, object Value)
        {
            return new SqlParameter(ParamName, Value);
        }

        /// <summary>
        /// Make input param.
        /// </summary>
        /// <param name="ParamName">Name of param.</param>
        /// <param name="DbType">Param type.</param>
        /// <param name="Size">Param size.</param>
        /// <param name="Value">Param value.</param>
        /// <returns>New parameter.</returns>
        public SqlParameter MakeInParam(string ParamName, SqlDbType DbType, int Size, object Value)
        {
            return MakeParam(ParamName, DbType, Size, ParameterDirection.Input, Value);
        }

        /// <summary>
        /// Make input param.
        /// </summary>
        /// <param name="ParamName">Name of param.</param>
        /// <param name="DbType">Param type.</param>
        /// <param name="Size">Param size.</param>
        /// <returns>New parameter.</returns>
        public SqlParameter MakeOutParam(string ParamName, SqlDbType DbType, int Size)
        {
            return MakeParam(ParamName, DbType, Size, ParameterDirection.Output, null);
        }

        /// <summary>
        /// Make stored procedure param.
        /// </summary>
        /// <param name="ParamName">Name of param.</param>
        /// <param name="DbType">Param type.</param>
        /// <param name="Size">Param size.</param>
        /// <param name="Direction">Parm direction.</param>
        /// <param name="Value">Param value.</param>
        /// <returns>New parameter.</returns>
        public SqlParameter MakeParam(string ParamName, SqlDbType DbType, Int32 Size, ParameterDirection Direction, object Value)
        {
            SqlParameter param;

            if (Size > 0)
                param = new SqlParameter(ParamName, DbType, Size);
            else
                param = new SqlParameter(ParamName, DbType);

            param.Direction = Direction;
            if (!(Direction == ParameterDirection.Output && Value == null))
                param.Value = Value;

            return param;
        }


        private SqlParameter BlogIDParam
        {
            get
            {
                return MakeInParam("@BlogID", SqlDbType.Int, 4, BlogContext.Current.Config.BlogID);
            }
        }

        public static SqlParameter[] DefaultEntryParameters
        {
            get
            {
                return BuildDefaultEntryParameters();
            }
        }

        private static SqlParameter[] BuildDefaultEntryParameters()
        {
            SqlParameter[] p = new SqlParameter[5];
            p[0] = new SqlParameter("@EntryID", SqlDbType.Int, 4);
            p[0].IsNullable = true;
            p[0].Direction = ParameterDirection.Input;

            p[1] = new SqlParameter("@EntryName", SqlDbType.NVarChar, 150);
            p[1].IsNullable = true;
            p[1].Direction = ParameterDirection.Input;

            p[2] = new SqlParameter("@PostConfig", SqlDbType.Int, 4);
            p[2].IsNullable = false;
            p[2].Direction = ParameterDirection.Input;

            p[3] = new SqlParameter("@IncludeCategories", SqlDbType.Bit, 1);
            p[3].IsNullable = false;
            p[3].Direction = ParameterDirection.Input;

            p[4] = new SqlParameter("@BlogID", SqlDbType.Int, 4);
            p[4].IsNullable = false;
            p[4].Direction = ParameterDirection.Input;

            return p;
        }

        private SqlParameter[] EntryParameters(int EntryID, string EntryName, PostConfig pc, bool IncludeCategories)
        {

            SqlParameter[] p = new SqlParameter[5];
            Array.Copy(DefaultEntryParameters, 0, p, 0, 5);
            p[0].Value = NullCheck(EntryID > 0, EntryID);
            p[1].Value = NullCheck(EntryName != null, EntryName);
            p[2].Value = pc;
            p[3].Value = IncludeCategories;
            p[4].Value = BlogContext.Current.Config.BlogID;
            return p;
        }

        public static SqlParameter[] DefaultEntryQueryParameters
        {
            get
            {
                return BuildDefaultEntryQueryParameters();
            }
        }

        private static SqlParameter[] BuildDefaultEntryQueryParameters()
        {
            SqlParameter[] p = new SqlParameter[8];
            try
            {
                p[0] = new SqlParameter("@ItemCount", SqlDbType.Int, 4);
                p[0].IsNullable = false;
                p[0].Direction = ParameterDirection.Input;

                p[1] = new SqlParameter("@PostType", SqlDbType.Int, 4);
                p[1].IsNullable = false;
                p[1].Direction = ParameterDirection.Input;

                p[2] = new SqlParameter("@PostConfig", SqlDbType.Int, 4);
                p[2].IsNullable = false;
                p[2].Direction = ParameterDirection.Input;

                p[3] = new SqlParameter("@BlogID", SqlDbType.Int, 4);
                p[3].IsNullable = false;
                p[3].Direction = ParameterDirection.Input;

                p[4] = new SqlParameter("@CategoryID", SqlDbType.Int, 4);
                p[4].IsNullable = true;
                p[4].Direction = ParameterDirection.Input;

                p[5] = new SqlParameter("@CategoryName", SqlDbType.NVarChar, 100);
                p[5].IsNullable = true;
                p[5].Direction = ParameterDirection.Input;

                p[6] = new SqlParameter("@StartDate", SqlDbType.DateTime, 8);
                p[6].IsNullable = true;
                p[6].Direction = ParameterDirection.Input;

                p[7] = new SqlParameter("@StopDate", SqlDbType.DateTime, 8);
                p[7].IsNullable = true;
                p[7].Direction = ParameterDirection.Input;
            }
            catch (Exception e)
            {
                Logger.LogManager.CreateExceptionLog(e, "BuildDefaultEntryQueryParameters Exception");
                throw e;
            }

            return p;
        }

        private object NullCheck(bool isNotNull, object obj)
        {
            if (isNotNull)
            {
                return obj;
            }
            else
            {
                return DBNull.Value;
            }
        }

        public static string CheckNullString(object obj)
        {
            if (obj is DBNull)
            {
                return null;
            }
            return (string)obj;
        }

        public object CheckNull(string text)
        {
            if (!string.IsNullOrEmpty(text))
                return text;

            return DBNull.Value;
        }

        public string CheckNull(object obj)
        {
            return (string)obj;
        }

        public string CheckNull(DBNull obj)
        {
            return null;
        }

        //use with caution. Using index's can be messy :(
        private SqlParameter[] EntryQueryParameters(EntryQuery query)
        {

            SqlParameter[] p = new SqlParameter[11];
            try
            {
                Array.Copy(DefaultEntryQueryParameters, 0, p, 0, 8);
                p[0].Value = query.ItemCount;
                p[1].Value = query.PostType;
                p[2].Value = query.PostConfig;
                p[3].Value = NullCheck(BlogContext.Current.Config.BlogID >= 0, BlogContext.Current.Config.BlogID);
                p[4].Value = NullCheck(query.HasCategoryID, query.CategoryID);
                p[5].Value = NullCheck(query.HasCategoryTitle, query.CategoryTitle);
                p[6].Value = NullCheck(query.HasStartDate, query.StartDate);
                p[7].Value = NullCheck(query.HasEndDate, query.EndDate);
                p[8] = new SqlParameter("@CategoryType", SqlDbType.Int, 4);
                p[8].Direction = ParameterDirection.Input;
                p[8].Value = NullCheck(query.HasCateType, query.CateType);
                p[9] = new SqlParameter("@BlogGroupID", SqlDbType.Int, 4);
                p[9].Direction = ParameterDirection.Input;
                p[9].Value = NullCheck(query.HasBlogGroupID, query.BlogGroupID);
                p[10] = new SqlParameter("@Author", SqlDbType.NVarChar, 100);
                p[10].Direction = ParameterDirection.Input;
                p[10].Value = NullCheck(query.HasAuthor, query.Author);
            }
            catch (Exception e)
            {
                Logger.LogManager.CreateExceptionLog(e, "EntryQueryParameters Exception");
                throw e;
            }

            return p;
        }


        private SqlParameter[] PagedEntryQueryParameters(PagedEntryQuery query)
        {

            SqlParameter[] p = new SqlParameter[13];
            Array.Copy(EntryQueryParameters(query), 0, p, 0, 11);

            p[11] = new SqlParameter("@PageIndex", SqlDbType.Int, 4);
            p[11].Direction = ParameterDirection.Input;
            p[11].Value = query.PageIndex;

            p[12] = new SqlParameter("@PageSize", SqlDbType.Int, 4);
            p[12].Direction = ParameterDirection.Input;
            p[12].Value = query.PageSize;

            return p;
        }


        #endregion

        #region Entries

        #region EntryCollections

        /// <summary>
        /// EntryCollection returned can contain CategoryEntries if a categoryid or categoryname is supplied.
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public IList<Entry> GetEntryCollection(EntryQuery query)
        {
            return dataService.QueryForList<Entry>("blog_GenericGetEntries_10", EntryQueryParameters(query));
        }

        public IList<CategoryEntry> GetCategoryEntryCollection(EntryQuery query)
        {
            IList<CategoryEntry> cec = dataService.QueryForList<CategoryEntry>("blog_GenericGetEntriesWithCategories_10", EntryQueryParameters(query)); ;
            foreach (CategoryEntry ce in cec)
            {
                SqlParameter[] p = { MakeInParam("@EntryID", ce.EntryID) };
                IList<string> cats = dataService.QueryForList<string>("blog_GetEntryCategories", p);
                ce.Categories = new List<string>(cats).ToArray();
            }
            return cec;
        }

        private bool IsNewDay(DateTime dtCurrent, DateTime dtDay)
        {
            return !(dtCurrent.DayOfYear == dtDay.DayOfYear && dtCurrent.Year == dtDay.Year);
        }

        public IList<EntryDay> GetEntryDayCollection(EntryQuery query)
        {
            IList<Entry> entries = dataService.QueryForList<Entry>("blog_GenericGetEntries_10", EntryQueryParameters(query));

            DateTime dt = new DateTime(1900, 1, 1);
            IList<EntryDay> edc = new List<EntryDay>();
            EntryDay day = null;

            foreach (Entry en in entries)
            {
                if (IsNewDay(dt, en.DateCreated))
                {
                    dt = en.DateCreated;
                    day = new EntryDay(dt);
                    edc.Add(day);
                }
                day.Add(en);
            }
            return edc;
        }

        public PagedList<Entry> GetPagedEntryCollection(PagedEntryQuery query)
        {
            SqlParameter[] p = PagedEntryQueryParameters(query);
            IList<EntryStatsView> entries = dataService.QueryForList<EntryStatsView>("blog_GenericGetPagedEntries_10", p);
            PagedList<Entry> pec = new PagedList<Entry>();
            pec.AddRange(new List<EntryStatsView>(entries).ToArray());
            pec.MaxItems = dataService.QueryForObject<int>("blog_GenericGetPagedEntries_Count", p);
            return pec;
        }

        public EntryDay GetEntryDay(EntryQuery query)
        {
            EntryDay ed = new EntryDay(query.StartDate);
            IList<Entry> entries = dataService.QueryForList<Entry>("blog_GenericGetEntries_10", EntryQueryParameters(query));
            ed.AddRange(entries);
            return ed;
        }

        public IList<Entry> GetFeedBack(int ParentID)
        {
            SqlParameter[] p =
			{
				MakeInParam("@ParentID",SqlDbType.Int,4,ParentID),
				BlogIDParam
			};
            return dataService.QueryForList<Entry>("blog_GetFeedBack", p);
        }

        public IList<Entry> GetFeedBack(Entry ParentEntry)
        {
            IList<Entry> entries = GetFeedBack(ParentEntry.EntryID);
            UrlFormats formats = BlogContext.Current.Config.UrlFormats;
            foreach (Entry en in entries)
            {
                en.Link = formats.CommentUrl(ParentEntry, en);
            }
            return entries;
        }

        #endregion

        #region Single Entry

        public Entry GetEntry(int EntryID)
        {
            SqlParameter[] p = 
				{
					MakeInParam("@EntryID",SqlDbType.Int,4,EntryID),
					BlogIDParam
				};
            return dataService.QueryForObject<Entry>("blog_GetEntryByID", p);
        }

        public Entry GetEntry(int EntryID, int BlogID)
        {
            SqlParameter[] p = 
				{
					MakeInParam("@EntryID",SqlDbType.Int,4,EntryID),
					MakeInParam("@BlogID",SqlDbType.Int,4,BlogID)
				};
            return dataService.QueryForObject<Entry>("blog_GetEntryByID", p);
        }

        public EntryStatsView GetEntryStatsView(int EntryID)
        {
            SqlParameter[] p = 
				{
					MakeInParam("@EntryID",SqlDbType.Int,4,EntryID)
				};
            return dataService.QueryForObject<EntryStatsView>("blog_GetEntryStatViewByEntryID", p);
        }

        public Entry GetEntry(int EntryID, string EntryName, PostConfig config)
        {
            return dataService.QueryForObject<Entry>("blog_GetEntry_10", EntryParameters(EntryID, EntryName, config, false));
        }

        public CategoryEntry GetCategoryEntry(int EntryID, string EntryName, PostConfig config)
        {
            CategoryEntry ce = dataService.QueryForObject<CategoryEntry>("blog_GetEntry_10", EntryParameters(EntryID, EntryName, config, false));
            SqlParameter[] p = { MakeInParam("@EntryID", EntryID) };
            IList<string> cats = dataService.QueryForList<string>("blog_GetEntryCategories", p);
            ce.Categories = new List<string>(cats).ToArray();
            return ce;
        }


        #endregion

        #region Delete

        public bool Delete(int PostID)
        {
            SqlParameter[] p =
			{
				MakeInParam("@ID",SqlDbType.Int,4,PostID),
				BlogIDParam
			};
            return dataService.Delete("blog_DeletePost", p) > 0;
        }

        #endregion

        #region Create Entry

        public int Create(Entry entry, int[] CategoryIDs)
        {
            if (entry.PostType == PostType.PingTrack)
            {
                SqlParameter[] p =
				{
					MakeInParam("@Title", SqlDbType.NVarChar,255,entry.Title),
					MakeInParam("@TitleUrl", SqlDbType.NVarChar,255,CheckNull(entry.TitleUrl)),
					MakeInParam("@Text",SqlDbType.NText,0,entry.Body),
					MakeInParam("@SourceUrl",SqlDbType.NVarChar,200,CheckNull(entry.SourceUrl)),
					MakeInParam("@PostType",SqlDbType.Int,4,entry.PostType),
					MakeInParam("@Author",SqlDbType.NVarChar,50,CheckNull(entry.Author)),
					MakeInParam("@Email",SqlDbType.NVarChar,50,CheckNull(entry.Email)),
					MakeInParam("@Description",SqlDbType.NVarChar,500,CheckNull(entry.Description)),
					MakeInParam("@SourceName",SqlDbType.NVarChar,200,CheckNull(entry.SourceName)),
					MakeInParam("@DateAdded",SqlDbType.DateTime,8,entry.DateCreated),
					MakeInParam("@PostConfig",SqlDbType.Int,4,entry.PostConfig),
					MakeInParam("@ParentID",SqlDbType.Int,4,entry.ParentID),
					MakeInParam("@EntryName",SqlDbType.NVarChar,150,CheckNull(entry.EntryName)),
					BlogIDParam,
					MakeOutParam("@ID",SqlDbType.Int,4)
					
				};

                dataService.Insert("blog_InsertPingTrackEntry", p);
                return (int)p[13].Value;
            }
            else
            {
                FormatEntry(ref entry);

                SqlParameter[] p =
			{
				MakeInParam("@Title", SqlDbType.NVarChar,255,entry.Title),
				MakeInParam("@TitleUrl", SqlDbType.NVarChar,255,CheckNull(entry.TitleUrl)),
				MakeInParam("@Text",SqlDbType.NText,0,entry.Body),
				MakeInParam("@SourceUrl",SqlDbType.NVarChar,200,CheckNull(entry.SourceUrl)),
				MakeInParam("@PostType",SqlDbType.Int,4,entry.PostType),
				MakeInParam("@Author",SqlDbType.NVarChar,50,CheckNull(entry.Author)),
				MakeInParam("@Email",SqlDbType.NVarChar,50,CheckNull(entry.Email)),
				MakeInParam("@Description",SqlDbType.NVarChar,500,CheckNull(entry.Description)),
				MakeInParam("@SourceName",SqlDbType.NVarChar,200,CheckNull(entry.SourceName)),
				MakeInParam("@DateAdded",SqlDbType.DateTime,8,entry.DateCreated),
				MakeInParam("@PostConfig",SqlDbType.Int,4,entry.PostConfig),
				MakeInParam("@ParentID",SqlDbType.Int,4,entry.ParentID),
				MakeInParam("@EntryName",SqlDbType.NVarChar,150,CheckNull(entry.EntryName)),
				BlogIDParam,
				MakeOutParam("@ID",SqlDbType.Int,4)				
			};

                dataService.Insert("blog_InsertEntry", p);
                entry.EntryID = (int)p[14].Value;

                if (entry.EntryID < 0)
                    throw new BlogFailedPostException("Your entry could not be added to the datastore");


                if (entry is CategoryEntry)
                {
                    CategoryEntry ce = (CategoryEntry)entry;

                    if (ce.Categories != null && ce.Categories.Length > 0)
                    {
                        p = new SqlParameter[3];
                        p[0] = new SqlParameter("@Title", SqlDbType.NVarChar, 150);
                        p[1] = MakeInParam("@PostID", SqlDbType.Int, 4, entry.EntryID);
                        p[2] = ce.BlogID > 0 ? MakeInParam("@BlogID", SqlDbType.Int, 4, ce.BlogID) : BlogIDParam;
                        p[3] = MakeInParam("@CategoryType", SqlDbType.TinyInt, 1, ce.PostType == PostType.BlogPost ? CategoryType.PostCollection : CategoryType.StoryCollection);

                        foreach (string s in ce.Categories)
                        {
                            p[0].Value = s;
                            dataService.ExecuteNonQuery("blog_InsertPostCategoryByName", p);
                        }
                    }
                }
                else
                {
                    SetEntryCategoryList(entry.EntryID, CategoryIDs);
                }

                entry.Link = BlogContext.Current.Config.UrlFormats.EntryUrl(entry);
                BlogContext.Current.Config.LastUpdated = entry.DateCreated;

                return entry.EntryID;
            }
        }

        #endregion

        #region Update

        public bool Update(Entry entry, int[] CategoryIDs)
        {
            FormatEntry(ref entry);

            SqlParameter[] p =
            {
                MakeInParam("@Title", SqlDbType.NVarChar,255,entry.Title),
                MakeInParam("@TitleUrl", SqlDbType.NVarChar,255,CheckNull(entry.TitleUrl)),
                MakeInParam("@Text",SqlDbType.NText,0,entry.Body),
                MakeInParam("@SourceUrl",SqlDbType.NVarChar,200,CheckNull(entry.SourceUrl)),
                MakeInParam("@PostType",SqlDbType.Int,4,entry.PostType),
                MakeInParam("@Author",SqlDbType.NVarChar,50,CheckNull(entry.Author)),
                MakeInParam("@Email",SqlDbType.NVarChar,50,CheckNull(entry.Email)),
                MakeInParam("@Description",SqlDbType.NVarChar,500,CheckNull(entry.Description)),
                MakeInParam("@SourceName",SqlDbType.NVarChar,200,CheckNull(entry.SourceName)),
                MakeInParam("@DateUpdated",SqlDbType.SmallDateTime,4,entry.DateUpdated),
                MakeInParam("@ID",SqlDbType.Int,4,entry.EntryID),
                MakeInParam("@PostConfig",SqlDbType.Int,4,entry.PostConfig),
                MakeInParam("@ParentID",SqlDbType.Int,4,entry.ParentID),
                MakeInParam("@EntryName",SqlDbType.NVarChar,150,CheckNull(entry.EntryName)),
                BlogIDParam
            };

            bool result = dataService.Update("blog_UpdateEntry", p) > 0;
            if (!result)
                return false;

            if (entry is CategoryEntry)
            {
                CategoryEntry ce = (CategoryEntry)entry;

                dataService.ExecuteNonQuery("blog_DeleteLinksByPostID", new SqlParameter[] { MakeInParam("@PostID", SqlDbType.Int, 4, entry.EntryID), BlogIDParam });

                if (ce.Categories != null && ce.Categories.Length > 0)
                {
                    p = new SqlParameter[3];
                    p[0] = new SqlParameter("@Title", SqlDbType.NVarChar, 150);
                    p[1] = MakeInParam("@PostID", SqlDbType.Int, 4, ce.EntryID);
                    p[2] = BlogIDParam;
                    p[3] = MakeInParam("@CategoryType", SqlDbType.TinyInt, 1, ce.PostType == PostType.BlogPost ? CategoryType.PostCollection : CategoryType.StoryCollection);


                    foreach (string s in ce.Categories)
                    {
                        p[0].Value = s;
                        dataService.ExecuteNonQuery("blog_InsertPostCategoryByName", p);
                    }
                }
            }
            else
            {
                SetEntryCategoryList(entry.EntryID, CategoryIDs);
            }

            BlogContext.Current.Config.LastUpdated = entry.DateUpdated;

            return true;
        }

        #endregion

        #region SetCategoriesList

        public bool SetEntryCategoryList(int EntryID, int[] Categories)
        {
            if (Categories != null)
            {
                string[] cats = new string[Categories.Length];
                for (int i = 0; i < Categories.Length; i++)
                {
                    cats[i] = Categories[i].ToString();
                }
                string catList = string.Join(",", cats);
                SqlParameter[] p = new SqlParameter[]
			            {
				            MakeInParam("@PostID",SqlDbType.Int,4, EntryID),
				            BlogIDParam,
				            MakeInParam("@CategoryList",SqlDbType.NVarChar,4000,catList)
			            };
                return dataService.ExecuteNonQuery("blog_InsertLinkCategoryList", p) > 0;
            }
            return false;
        }

        #endregion

        #region Format Helper

        private void FormatEntry(ref Entry e)
        {
            if ((e.PostType & (PostType.Article | PostType.BlogPost)) == e.PostType)
            {
                if (Config.Settings.UseXHTML)
                {
                    Globals.IsValidXHTML(ref e);
                }
            }
        }

        #endregion

        #endregion

        #region Links/Categories

        #region Paged Links

        public PagedList<Link> GetPagedLinks(int categoryTypeID, int pageIndex, int pageSize, bool sortDescending)
        {
            PagedList<Link> plc = new PagedList<Link>();
            SqlParameter[] p = 
			{
				MakeInParam("@PageIndex", SqlDbType.Int, 4, pageIndex),
				MakeInParam("@PageSize", SqlDbType.Int, 4, pageSize),
				MakeInParam("@SortDesc", SqlDbType.Bit, 1, sortDescending),
				BlogIDParam,
				MakeInParam("@CategoryID", SqlDbType.Int, 4, NullCheck(categoryTypeID>=0,categoryTypeID))
			};
            plc.AddRange(dataService.QueryForList<Link>("blog_GetPageableLinks", p));

            string query = "SELECT COUNT(*) FROM blog_Links WHERE blogID = @BlogID AND CategoryID = @CategoryID";
            p = new SqlParameter[] { 
                BlogIDParam, 
                MakeInParam("@CategoryID", SqlDbType.Int, 4, NullCheck(categoryTypeID>=0,categoryTypeID)) 
            };
            plc.MaxItems = dataService.QueryForObject<int>(query, p);
            return plc;
        }

        #endregion

        #region LinkCollection

        public LinkCollection GetLinkCollectionByPostID(int PostID)
        {
            LinkCollection lc = new LinkCollection();
            SqlParameter[] p =
			{
				MakeInParam("@PostID",SqlDbType.Int,4,PostID),
				BlogIDParam
			};
            lc.AddRange(dataService.QueryForList<Link>("blog_GetLinkCollectionByPostID", p));
            return lc;
        }

        public LinkCollection GetLinkCollectionByPostID(int BlogID, int PostID)
        {
            LinkCollection lc = new LinkCollection();
            SqlParameter[] p =
			{
				MakeInParam("@PostID",SqlDbType.Int,4,PostID),
				MakeInParam("@BlogID",SqlDbType.Int,4,BlogID)
			};
            lc.AddRange(dataService.QueryForList<Link>("blog_GetLinkCollectionByPostID", p));
            return lc;
        }


        public LinkCollection GetLinksByCategoryID(int catID, bool ActiveOnly)
        {
            LinkCollection lc = new LinkCollection();
            SqlParameter[] p = 
			{
				MakeInParam("@CategoryID",SqlDbType.Int,4 ,catID),
				MakeInParam("@IsActive",SqlDbType.Bit,1,ActiveOnly),
				BlogIDParam
			};
            lc.AddRange(dataService.QueryForList<Link>("blog_GetLinksByCategoryID", p));
            return lc;
        }

        #endregion

        #region Single Link

        public Link GetSingleLink(int linkID)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@LinkID",SqlDbType.Int,4,linkID),
				BlogIDParam
			};
            return dataService.QueryForObject<Link>("blog_GetSingleLink", p);
        }

        #endregion

        #region LinkCategoryCollection

        public IList<LinkCategory> GetCategoriesByType(CategoryType catType, bool ActiveOnly)
        {
            SqlParameter[] p ={MakeInParam("@CategoryType",SqlDbType.TinyInt,1,catType),
								  MakeInParam("@IsActive",SqlDbType.Bit,1,ActiveOnly),
								  BlogIDParam};
            return dataService.QueryForList<LinkCategory>("blog_GetCategoriesByType", p);
        }

        public IList<LinkCategory> GetCategoriesByParentID(CategoryType catType, int ParentID, bool ActiveOnly)
        {
            SqlParameter[] p ={
								  MakeInParam("@CategoryType",SqlDbType.TinyInt,1,catType),
								  MakeInParam("@IsActive",SqlDbType.Bit,1,ActiveOnly),
								  MakeInParam("@ParentID",SqlDbType.Int,4,ParentID)
							  };
            return dataService.QueryForList<LinkCategory>("blog_GetCategoriesByType", p);
        }

        public IList<LinkCategory> GetCategoriesByType(int BlogID, CategoryType catType, bool ActiveOnly)
        {
            SqlParameter[] p ={MakeInParam("@CategoryType",SqlDbType.TinyInt,1,catType),
								  MakeInParam("@IsActive",SqlDbType.Bit,1,ActiveOnly),
								  MakeInParam("@BlogID",SqlDbType.Int,4,BlogID)};
            return dataService.QueryForList<LinkCategory>("blog_GetCategoriesByType", p);
        }

        public IList<LinkCategory> GetCategoriesWithLinks(bool IsActive)
        {
            string query = @"SELECT 
	blc.CategoryID, blc.Title, blc.Active, blc.CategoryType, blc.[Description]
FROM 
	blog_LinkCategories blc
WHERE 
	blc.Active <> Case @IsActive When 1 then 0 Else -1 End and blc.BLOGID = @BlogID 
	and blc.CategoryType = 0
ORDER BY 
	blc.Title";

            SqlParameter[] p =
			{
				MakeInParam("@IsActive",SqlDbType.Bit,1,IsActive),
				BlogIDParam
			};
            IList<LinkCategory> lcc = dataService.QueryForList<LinkCategory>(query, p);

            query = @"SELECT 
	bl.LinkID, bl.Title, bl.Url, bl.Rss, bl.Active, bl.NewWindow, bl.CategoryID,  bl.PostID ,bl.UpdateTime 
FROM 
	blog_Links bl 
WHERE 
	bl.Active <> Case @IsActive When 1 then 0 Else -1 End AND bl.BLOGID = @BlogID
ORDER BY 
	bl.Title";

            IList<Link> links = dataService.QueryForList<Link>(query, p);

            foreach (LinkCategory lc in lcc)
            {
                foreach (Link ln in links)
                {
                    if (lc.CategoryID == ln.CategoryID)
                        lc.Links.Add(ln);
                }
            }

            return lcc;
        }

        #endregion

        #region LinkCategory

        public LinkCategory GetLinkCategory(int CategoryID, bool IsActive)
        {
            return GetLinkCategory(CategoryID, null, IsActive);
        }

        public LinkCategory GetLinkCategory(int CategoryID, string CategoryName, bool IsActive)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@CategoryID",SqlDbType.Int,4,NullCheck(CategoryID>0,CategoryID)),
				MakeInParam("@CategoryName",SqlDbType.NVarChar,150,NullCheck(CategoryName != null,CategoryName)),
				MakeInParam("@IsActive",SqlDbType.Bit,1,IsActive),
				BlogIDParam
			};
            return dataService.QueryForObject<LinkCategory>("blog_GetCategory", p);
        }

        public LinkCategory GetLinkCategory(int CategoryID, bool IsActive, int BlogID)
        {
            string categoryName = null;
            SqlParameter[] p = 
			{
				MakeInParam("@CategoryID",SqlDbType.Int,4,NullCheck(CategoryID>0,CategoryID)),
				MakeInParam("@CategoryName",SqlDbType.NVarChar,150,NullCheck(categoryName != null,categoryName)),
				MakeInParam("@IsActive",SqlDbType.Bit,1,IsActive),
				MakeInParam("@BlogID",SqlDbType.Int,4,BlogID)
			};
            return dataService.QueryForObject<LinkCategory>("blog_GetCategory", p);
        }

        public LinkCategory GetLinkCategory(string categoryName, bool IsActive)
        {
            return GetLinkCategory(0, categoryName, IsActive);
        }

        #endregion

        #region Edit Links/Categories

        public bool UpdateLink(Link link)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@Title",SqlDbType.NVarChar,150,link.Title),
				MakeInParam("@Url",SqlDbType.NVarChar,255,link.Url),
				MakeInParam("@Rss",SqlDbType.NVarChar,255,CheckNull(link.Rss)),
				MakeInParam("@Active",SqlDbType.Bit,1,link.IsActive),
				MakeInParam("@NewWindow",SqlDbType.Bit,1,link.NewWindow),
				MakeInParam("@CategoryID",SqlDbType.Int,4,link.CategoryID),
				MakeInParam("@LinkID",SqlDbType.Int,4,link.LinkID),
				BlogIDParam
			};
            return dataService.Update("blog_UpdateLink", p) > 0;
        }

        public int CreateLink(Link link)
        {
            SqlParameter myBlogIDParam;
            if (link.BlogID == -2)
            {
                myBlogIDParam = BlogIDParam;
            }
            else
            {
                myBlogIDParam = MakeInParam("@BlogID", SqlDbType.Int, 4, link.BlogID);
            }
            SqlParameter[] p = 
			{
				MakeInParam("@Title",SqlDbType.NVarChar,150,link.Title),
				MakeInParam("@Url",SqlDbType.NVarChar,255,link.Url),
				MakeInParam("@Rss",SqlDbType.NVarChar,255,CheckNull(link.Rss)),
				MakeInParam("@Active",SqlDbType.Bit,1,link.IsActive),
				MakeInParam("@NewWindow",SqlDbType.Bit,1,link.NewWindow),
				MakeInParam("@CategoryID",SqlDbType.Int,4,link.CategoryID),
				MakeInParam("@PostID",SqlDbType.Int,4,link.PostID),
				myBlogIDParam,
				MakeOutParam("@LinkID",SqlDbType.Int,4)
			};
            dataService.Insert("blog_InsertLink", p);
            return (int)p[8].Value;
        }

        public bool UpdateLinkCategory(LinkCategory lc)
        {
            SqlParameter myBlogIDParam;
            if (lc.BlogID == -2)
            {
                myBlogIDParam = BlogIDParam;
            }
            else
            {
                myBlogIDParam = MakeInParam("@BlogID", SqlDbType.Int, 4, lc.BlogID);
            }

            SqlParameter[] p =
			{
				MakeInParam("@Title",SqlDbType.NVarChar,150,lc.Title),
				MakeInParam("@Active",SqlDbType.Bit,1,lc.IsActive),
				MakeInParam("@CategoryID",SqlDbType.Int,4,lc.CategoryID),
				MakeInParam("@CategoryType",SqlDbType.TinyInt,1,lc.CategoryType),
				MakeInParam("@Description",SqlDbType.NVarChar,1000,CheckNull(lc.Description)),
				myBlogIDParam
			};
            return dataService.Update("blog_UpdateCategory", p) > 0;
        }

        public int CreateLinkCategory(LinkCategory lc)
        {
            SqlParameter myBlogIDParam;
            if (lc.BlogID == -2)
            {
                myBlogIDParam = BlogIDParam;
            }
            else
            {
                myBlogIDParam = MakeInParam("@BlogID", SqlDbType.Int, 4, lc.BlogID);
            }

            SqlParameter[] p =
			{
				MakeInParam("@Title",SqlDbType.NVarChar,150,lc.Title),
				MakeInParam("@Active",SqlDbType.Bit,1,lc.IsActive),
				MakeInParam("@CategoryType",SqlDbType.TinyInt,1,lc.CategoryType),
				MakeInParam("@Description",SqlDbType.NVarChar,1000,CheckNull(lc.Description)),
				myBlogIDParam,
				MakeInParam("@ParentID",SqlDbType.Int,4,lc.ParentID),
				MakeOutParam("@CategoryID",SqlDbType.Int,4)
			};
            dataService.Insert("blog_InsertCategory", p);
            return (int)p[5].Value;
        }

        public bool DeleteLinkCategory(int CategoryID)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@CategoryID",SqlDbType.Int,4,CategoryID),
				BlogIDParam
			};
            return dataService.Delete("blog_DeleteCategory", p) > 0;
        }

        public bool DeleteLinkCategory(int CategoryID, int BlogID)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@CategoryID",SqlDbType.Int,4,CategoryID),
				MakeInParam("@BlogID",SqlDbType.Int,4,BlogID)
			};
            return dataService.Delete("blog_DeleteCategory", p) > 0;
        }

        public bool DeleteLink(int LinkID)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@LinkID",SqlDbType.Int,4,LinkID),
				BlogIDParam
			};
            return dataService.Delete("blog_DeleteLink", p) > 0;
        }

        public void DeleteLinkCategoryByType(AbstractComponent node, CategoryType type)
        {
            string delsql = "delete from blog_LinkCategories where CategoryType=" + (int)type;
            dataService.Delete(delsql, null);
            DeleteLinkCategoryByType(node);
        }

        private void DeleteLinkCategoryByType(AbstractComponent node)
        {
            if (!node.isRoot())
            {
                LinkCategory lc = (LinkCategory)node.GetObject();
                SqlParameter[] p =
			{

				MakeInParam("@Title",SqlDbType.NVarChar,150,lc.Title),
				MakeInParam("@Active",SqlDbType.Bit,1,lc.IsActive),
				MakeInParam("@CategoryType",SqlDbType.TinyInt,1,lc.CategoryType),
				MakeInParam("@Description",SqlDbType.NVarChar,1000,CheckNull(lc.Description)),
				MakeInParam("@BlogID",SqlDbType.Int,4,-1),
				MakeInParam("@ParentID",SqlDbType.Int,4,lc.ParentID),
				MakeOutParam("@CategoryID",SqlDbType.Int,4)
			};
                dataService.ExecuteNonQuery("blog_InsertCategory", p);
            }

            while (node.GoNextChild())
            {
                DeleteLinkCategoryByType(node.GetChild());
            }
        }

        #endregion

        #endregion

        #region Stats

        public PagedList<Referrer> GetPagedReferrers(int pageIndex, int pageSize)
        {
            PagedList<Referrer> prc = new PagedList<Referrer>();
            SqlParameter[] p =
			{
				BlogIDParam,
				MakeInParam("@PageIndex", SqlDbType.Int, 4, pageIndex),
				MakeInParam("@PageSize", SqlDbType.Int, 4, pageSize)
			};
            prc.AddRange(dataService.QueryForList<Referrer>("blog_GetPageableReferrers", p));

            string query = "SELECT COUNT(*) FROM blog_Referrals WHERE BlogID = @BlogID AND UrlID NOT IN (SELECT UrlID FROM blog_URLs WHERE url LIKE '%google.%'))";
            prc.MaxItems = dataService.QueryForObject<int>(query, new SqlParameter[] { BlogIDParam });
            return prc;
        }

        public PagedList<Referrer> GetPagedReferrers(int pageIndex, int pageSize, int EntryID)
        {
            PagedList<Referrer> prc = new PagedList<Referrer>();
            SqlParameter[] p =
			{
				BlogIDParam,
				MakeInParam("@EntryID", SqlDbType.Int, 4, EntryID),
				MakeInParam("@PageIndex", SqlDbType.Int, 4, pageIndex),
				MakeInParam("@PageSize", SqlDbType.Int, 4, pageSize)
			};

            prc.AddRange(dataService.QueryForList<Referrer>("blog_GetPageableReferrersByEntryID", p));

            string query = "SELECT COUNT(*) FROM blog_Referrals WHERE BlogID = @BlogID AND EntryID = @EntryID";
            p = new SqlParameter[] { BlogIDParam, MakeInParam("@EntryID", SqlDbType.Int, 4, EntryID) };
            prc.MaxItems = dataService.QueryForObject<int>(query, p);
            return prc;
        }

        public bool TrackEntry(EntryView ev)
        {        
			SqlParameter[] p =	
					{
						MakeInParam("@EntryID",SqlDbType.Int,4,ev.EntryID),
						MakeInParam("@BlogID",SqlDbType.Int,4,ev.BlogID),
						MakeInParam("@URL",SqlDbType.NVarChar,255,CheckNull(ev.ReferralUrl)),
						MakeInParam("@IsWeb",SqlDbType.Bit,1,ev.PageViewType)
			};
			return dataService.ExecuteNonQuery("blog_TrackEntry",p) > 0;
        }

        #endregion

        #region  Configuration

        public bool UpdateConfigData(BlogConfig config)
        {
            SqlParameter[] p = 
					{
						MakeInParam("@UserName",SqlDbType.NVarChar,50,config.UserName),
						MakeInParam("@Password",SqlDbType.NVarChar,50,config.Password),
						MakeInParam("@Author",SqlDbType.NVarChar,100,config.Author),
						MakeInParam("@Email",SqlDbType.NVarChar,50,config.Email),
						MakeInParam("@Title",SqlDbType.NVarChar,100,config.Title),
						MakeInParam("@SubTitle",SqlDbType.NVarChar,250,config.SubTitle),
						MakeInParam("@Skin",SqlDbType.NVarChar,50,config.Skin.SkinName),
						MakeInParam("@Application",SqlDbType.NVarChar,50,config.CleanApplication),
						MakeInParam("@Host",SqlDbType.NVarChar,100,config.Host),
						MakeInParam("@TimeZone",SqlDbType.Int,4,config.TimeZone),
						MakeInParam("@Language",SqlDbType.NVarChar,10,config.Language),
						MakeInParam("@News",SqlDbType.Text,0,CheckNull(config.News)),
						MakeInParam("@ItemCount",SqlDbType.Int, 4,config.ItemCount),
						MakeInParam("@Flag",SqlDbType.Int, 4,(int)config.Flag),
						MakeInParam("@LastUpdated",SqlDbType.DateTime, 8,config.LastUpdated),
						MakeInParam("@SecondaryCss",SqlDbType.Text,0,CheckNull(config.Skin.SkinCssText)),
						MakeInParam("@SkinCssFile",SqlDbType.VarChar,100,CheckNull(config.Skin.SkinCssFile)),
						MakeInParam("@BlogID",SqlDbType.Int, 4,config.BlogID),
						MakeInParam("@NotifyMail",SqlDbType.NVarChar,50,config.NotifyMail),
						MakeInParam("@IsMailNotify",SqlDbType.Bit, 1,config.IsMailNotify),
						MakeInParam("@IsOnlyListTitle",SqlDbType.Bit, 1,config.IsOnlyListTitle)
					};


            return dataService.Update("blog_UpdateConfig", p) > 0;
        }

        public BlogConfig GetConfig(string hostname, string application)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@Host",SqlDbType.NVarChar,100,hostname),
				MakeInParam("@Application",SqlDbType.NVarChar,50,application)
			};
            return dataService.QueryForObject<BlogConfig>("blog_GetConfig", p);
        }

        public BlogConfig GetConfig(int BlogID)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@BlogID",SqlDbType.Int,4,BlogID)
			};
            return dataService.QueryForObject<BlogConfig>("blog_GetConfigByBlogID", p);
        }

        public BlogConfig GetConfig()
        {
            return dataService.QueryForObject<BlogConfig>("SELECT * FROM blog_config", null);
        }

        public BlogConfig[] GetConfigByRoleID(int RoleID)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@RoleID",SqlDbType.Int,4,RoleID)
			};
            IList<BlogConfig> cfgs = dataService.QueryForList<BlogConfig>("blog_GetConfigByRoleID", p);
            return new List<BlogConfig>(cfgs).ToArray();
        }

        public string[] GetBlogGroup(int BlogID)
        {
            SqlParameter[] p = 
            {
                MakeInParam("@BlogID",SqlDbType.Int,4,BlogID)
            };
            IList<string> groups = dataService.QueryForList<string>("blog_GetBlogGroupByBlogID", p);
            return new List<string>(groups).ToArray();
        }

        public BlogConfig GetConfig(string UserName)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@UserName",SqlDbType.NVarChar,50,UserName)
			};
            return dataService.QueryForObject<BlogConfig>("blog_GetConfigByUserName", p);
        }

        public BlogConfig GetConfigByApp(string app)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@Application",SqlDbType.NVarChar,50,app)
			};
            return dataService.QueryForObject<BlogConfig>("blog_GetConfigByApp", p);
        }

        public IList<SkinControl> GetSkinControlCollection(int BlogID)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@BlogID",SqlDbType.Int,4,BlogID)
			};
            return dataService.QueryForList<SkinControl>("blog_GetSkinControlByBlogID", p);
        }

        public bool UpateSkinControl(SkinControl sc)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@ControlID",SqlDbType.Int,4,sc.ID),
				MakeInParam("@Visible",SqlDbType.Bit,1,sc.Visible),
				BlogIDParam

			};
            return dataService.Update("blog_UpdateSkinControl", p) > 0;
        }

        public bool UpdateSingleSkinControl(int ControlID, bool visible, int BlogID)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@ControlID",SqlDbType.Int,4,ControlID),
				MakeInParam("@Visible",SqlDbType.Bit,1,visible),
				MakeInParam("@BlogID",SqlDbType.Int,4,BlogID)

			};
            return dataService.Update("blog_UpdateSkinControl", p) > 0;
        }

        #endregion

        #region KeyWords

        public KeyWord GetKeyWord(int KeyWordID)
        {
            SqlParameter[] p =
			{
				MakeInParam("@KeyWordID",SqlDbType.Int,4,KeyWordID),
				BlogIDParam
			};
            return dataService.QueryForObject<KeyWord>("blog_GetKeyWord", p);
        }

        public IList<KeyWord> GetKeyWords()
        {
            SqlParameter[] p =
			{
				BlogIDParam
			};
            return dataService.QueryForList<KeyWord>("blog_GetKeyWords", p);
        }

        public PagedList<KeyWord> GetPagedKeyWords(int pageIndex, int pageSize, bool sortDescending)
        {
            PagedList<KeyWord> pkwc = new PagedList<KeyWord>();
            SqlParameter[] p = 
			{
				MakeInParam("@PageIndex", SqlDbType.Int, 4, pageIndex),
				MakeInParam("@PageSize", SqlDbType.Int, 4, pageSize),
				MakeInParam("@SortDesc", SqlDbType.Bit, 1, sortDescending),
				BlogIDParam
			};
            pkwc.AddRange(dataService.QueryForList<KeyWord>("blog_GetPageableKeyWords", p));

            string query = "SELECT COUNT([KeywordID]) FROM blog_KeyWords WHERE blogID = @BlogID";
            pkwc.MaxItems = dataService.QueryForObject<int>(query, new SqlParameter[] { BlogIDParam });
            return pkwc;
        }

        public bool UpdateKeyWord(KeyWord kw)
        {
            SqlParameter[] p =
			{
				MakeInParam("@KeyWordID",SqlDbType.Int,4,kw.KeyWordID),
				MakeInParam("@Word",SqlDbType.NVarChar,100,kw.Word),
				MakeInParam("@Text",SqlDbType.NVarChar,100,kw.Text),
				MakeInParam("@ReplaceFirstTimeOnly",SqlDbType.Bit,1,kw.ReplaceFirstTimeOnly),
				MakeInParam("@OpenInNewWindow",SqlDbType.Bit,1,kw.OpenInNewWindow),
				MakeInParam("@CaseSensitive",SqlDbType.Bit,1,kw.CaseSensitive),
				MakeInParam("@Url",SqlDbType.NVarChar,255,kw.Url),
				MakeInParam("@Title",SqlDbType.NVarChar,100,kw.Title),
				BlogIDParam
			};
            return dataService.Update("blog_UpdateKeyWord", p) > 0;
        }

        public int InsertKeyWord(KeyWord kw)
        {
            SqlParameter[] p =
			{
				MakeInParam("@Word",SqlDbType.NVarChar,100,kw.Word),
				MakeInParam("@Text",SqlDbType.NVarChar,100,kw.Text),
				MakeInParam("@ReplaceFirstTimeOnly",SqlDbType.Bit,1,kw.ReplaceFirstTimeOnly),
				MakeInParam("@OpenInNewWindow",SqlDbType.Bit,1,kw.OpenInNewWindow),
				MakeInParam("@CaseSensitive",SqlDbType.Bit,1,kw.CaseSensitive),
				MakeInParam("@Url",SqlDbType.NVarChar,255,kw.Url),
				MakeInParam("@Title",SqlDbType.NVarChar,100,kw.Title),
				BlogIDParam,
				MakeOutParam("@KeyWordID",SqlDbType.Int,4)
			};
            dataService.Insert("blog_InsertKeyWord", p);
            return (int)p[8].Value;
        }

        public bool DeleteKeyWord(int KeyWordID)
        {
            SqlParameter[] p =
			{
				MakeInParam("@KeyWordID",SqlDbType.Int,4,KeyWordID),
				BlogIDParam
			};
            return dataService.Delete("blog_DeleteKeyWord", p) > 0;
        }

        #endregion

        #region Images

        public ImageCollection GetImagesByCategoryID(int catID, bool ActiveOnly)
        {            
            SqlParameter[] p =
			{
				MakeInParam("@CategoryID",SqlDbType.Int,4,catID),
				MakeInParam("@IsActive",SqlDbType.Bit,1,ActiveOnly),
				BlogIDParam
			};

            ImageCollection ic = new ImageCollection();
            ic.Category = dataService.QueryForObject<LinkCategory>("blog_GetImageCategory", p);
            ic.Add(dataService.QueryForObject<Image>("blog_GetImagesByCategory", p));
            return ic;
        }

        public Image GetSingleImage(int imageID, bool ActiveOnly)
        {
            SqlParameter[] p =
                {
                    MakeInParam("@ImageID",SqlDbType.Int,4,imageID),
                    MakeInParam("@IsActive",SqlDbType.Bit,1,ActiveOnly),
                    BlogIDParam
                };
            return dataService.QueryForObject<Image>("blog_GetSingleImage", p);
        }

        public int InsertImage(Dottext.Framework.Components.Image _image)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@Title",SqlDbType.NVarChar,250,_image.Title),
				MakeInParam("@CategoryID",SqlDbType.Int,4,_image.CategoryID),
				MakeInParam("@Width",SqlDbType.Int,4,_image.Width),
				MakeInParam("@Height",SqlDbType.Int,4,_image.Height),
				MakeInParam("@File",SqlDbType.NVarChar,50,_image.File),
				MakeInParam("@Active",SqlDbType.Bit,1,_image.IsActive),
				BlogIDParam,
				MakeOutParam("@ImageID",SqlDbType.Int,4)
			};
            dataService.Insert("blog_InsertImage", p);
            return (int)p[7].Value;
        }

        public bool UpdateImage(Dottext.Framework.Components.Image _image)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@Title",SqlDbType.NVarChar,250,_image.Title),
				MakeInParam("@CategoryID",SqlDbType.Int,4,_image.CategoryID),
				MakeInParam("@Width",SqlDbType.Int,4,_image.Width),
				MakeInParam("@Height",SqlDbType.Int,4,_image.Height),
				MakeInParam("@File",SqlDbType.NVarChar,50,_image.File),
				MakeInParam("@Active",SqlDbType.Bit,1,_image.IsActive),
				BlogIDParam,
				MakeInParam("@ImageID",SqlDbType.Int,4,_image.ImageID)
			};
            return dataService.Update("blog_UpdateImage", p) > 0;
        }

        public bool DeleteImage(int imageID)
        {
            SqlParameter[] p = 
			{
				BlogIDParam,
				MakeInParam("@ImageID",SqlDbType.Int,4,imageID)
			};
            return dataService.Delete("blog_DeleteImage", p) > 0;
        }

        #endregion

        #region Archives

        public IList<ArchiveCount> GetPostsByMonthArchive(PostType postType)
        {
            SqlParameter[] p =
			{
				MakeInParam("@PostType",SqlDbType.Int,4,postType),
				BlogIDParam
			};
            return dataService.QueryForList<ArchiveCount>("blog_GetPostsByMonthArchive", p);
        }

        public IList<ArchiveCount> GetPostsByYearArchive(PostType postType)
        {
            SqlParameter[] p =
			{
				MakeInParam("@PostType",SqlDbType.Int,4,postType),
				BlogIDParam
			};
            return dataService.QueryForList<ArchiveCount>("blog_GetPostsByYearArchive", p);
        }

        #endregion  

        #region ScheduledEvents
        public DateTime GetLastExecuteScheduledEventDateTime(string key, string serverName)
        {
            SqlParameter[] p = 
            {
                MakeInParam("@Key", SqlDbType.VarChar, 100, key),
                MakeInParam("@ServerName", SqlDbType.VarChar, 100, serverName),
                MakeOutParam("@LastExecuted", SqlDbType.DateTime, 8)
            };
            dataService.ExecuteNonQuery("blog_GetLastExecuteScheduledEventDateTime", p);
            return (DateTime)p[2].Value;
        }

        public void SetLastExecuteScheduledEventDateTime(string key, string serverName, DateTime dt)
        {
            SqlParameter[] p = 
            {
                MakeInParam("@Key", SqlDbType.VarChar, 100, key),
                MakeInParam("@ServerName", SqlDbType.VarChar, 100, serverName),
                MakeInParam("@LastExecuted", SqlDbType.DateTime, 8, dt),
            };
            dataService.ExecuteNonQuery("blog_SetLastExecuteScheduledEventDateTime", p);
        }

        #endregion

        #region Logger

        public int CreateLog(Log blogLog)
        {
            SqlParameter[] p =
			{
				MakeInParam("@Title",SqlDbType.VarChar,100,blogLog.Title),
				MakeInParam("@Message",SqlDbType.VarChar,8000,blogLog.Message),
				MakeInParam("@UserName",SqlDbType.VarChar,100,CheckNull(blogLog.UserName)),
				MakeInParam("@Url",SqlDbType.VarChar,100,CheckNull(blogLog.Url)),
				MakeInParam("@ServerName",SqlDbType.VarChar,100,blogLog.ServerName),
				MakeInParam("@BlogID",SqlDbType.Int,4,blogLog.BlogID),
				MakeInParam("@StartDate",SqlDbType.DateTime,8,blogLog.StartDate),
				MakeInParam("@EndDate",SqlDbType.DateTime,8,blogLog.EndDate),
				MakeOutParam("@LogID",SqlDbType.Int,4)
			};

            dataService.Insert("blog_InsertLog", p);
            return (int)p[8].Value;
        }

        #endregion

        #region Rate
        public int InsertRate(EntryRate er)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@EntryID",SqlDbType.Int,4,er.EntryID),
				BlogIDParam,
				MakeInParam("@ClientID",SqlDbType.NVarChar,50,er.ClientID),
				MakeInParam("@Score",SqlDbType.TinyInt,1,er.Score),
				MakeOutParam("@ID",SqlDbType.Int,4)
			};
            dataService.Insert("blog_InsertRate", p);
            return (int)p[3].Value;
        }

        public int GetRatePeople(int entryID, int score)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@EntryID",SqlDbType.Int,4,entryID),
				MakeInParam("@Score",SqlDbType.TinyInt,1,score),
			};
            return dataService.QueryForObject<int>("blog_GetRatePeople", p);
        }

        #endregion

        #region EntryCount
        public int GetEntryCount(EntryQuery query)
        {
            return dataService.QueryForObject<int>("blog_GenericGetEntriesCount_10", EntryQueryParameters(query));
        }
        #endregion

        #region Security
        public Role[] GetRoles(int BlogID)
        {
            SqlParameter[] p =
				{
					MakeInParam("@UserID",SqlDbType.Int,4,BlogID)
				};
            IList<Role> roles = dataService.QueryForList<Role>("blog_Roles_Get", p);
            return new List<Role>(roles).ToArray();
        }

        public bool AddUserToRole(int BlogID, int RoleID)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@UserID",SqlDbType.Int,4,BlogID),
				MakeInParam("@RoleID",SqlDbType.Int,4,RoleID)
				
			};
            return dataService.ExecuteNonQuery("blog_Role_AddUser", p) > 0;
        }

        public bool RemoveUserFromRole(int BlogID, int RoleID)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@UserID",SqlDbType.Int,4,BlogID),
				MakeInParam("@RoleID",SqlDbType.Int,4,RoleID)
			};
            return dataService.ExecuteNonQuery("blog_Role_RemoveUser", p) > 0;
        }

        #endregion

        #region MailNotify

        public IList<string> GetNotifyMailList(int EntryID)
        {
            SqlParameter[] p =
			{
				MakeInParam("@EntryID",SqlDbType.Int,4,EntryID)
			};
            return dataService.QueryForList<string>("blog_MailNotify_GetMailList", p);
        }

        public bool InsertNotifySubscibe(int EntryID, int BlogID, int SendToBlogID, string EMail)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@EntryID",SqlDbType.Int,4,EntryID),
				MakeInParam("@BlogID",SqlDbType.Int,4,BlogID),
				MakeInParam("@SendToBlogID",SqlDbType.Int,4,SendToBlogID),
				MakeInParam("@EMail",SqlDbType.NVarChar,150,EMail)
			};
            dataService.Insert("blog_MailNotify_Insert", p);
            return true;
        }

        public bool DeleteMailNotify(int EntryID, int SendToBlogID)
        {
            SqlParameter[] p = 
			{
				MakeInParam("@EntryID",SqlDbType.Int,4,EntryID),
				MakeInParam("@SendToBlogID",SqlDbType.Int,4,SendToBlogID)				
			};
            return dataService.Delete("blog_MailNotify_Delete", p) > 0;
        }

        #endregion

        #region Data Helper

        public DataSet ExecuteDataset(CommandType type, string text)
        {
            return dataService.QueryForDataSet(text, null);
        }

        public DataSet ExecuteDataset(CommandType type, string text, IDbDataParameter[] parameters)
        {
            return dataService.QueryForDataSet(text, parameters);
        }

        public int ExecuteNonQuery(CommandType type, string text)
        {
            return dataService.ExecuteNonQuery(text, null);
        }

        public int ExecuteNonQuery(CommandType type, string text, IDbDataParameter[] parameters)
        {
            return dataService.ExecuteNonQuery(text, parameters);
        }

        #endregion
    }
}
