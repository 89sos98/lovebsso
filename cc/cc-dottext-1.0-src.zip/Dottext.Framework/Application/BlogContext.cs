#region License
/*
 *  Copyright (C) 2005-2008 THE CCHENSOFT.COM
 *  
 *  This library is free software; you can redistribute it and/or modify it 
 *  under the terms of the GNU Lesser General Public License 2.1 or later, as
 *  published by the Free Software Foundation. See the included License.txt
 *  or http://www.cchensoft.com/opensource/license.txt for details. 
 */
#endregion

using System;
using System.Web;
using CchenSoft.Framework;
using FxConfiguration = CchenSoft.Framework.Config.Configuration;
using Dottext.Framework.Configuration;

namespace Dottext.Framework
{
	public class BlogContext
	{
        private IConfig iconfig;
        private BlogConfig config;

		// Methods
        public BlogContext(HttpContext ctx)
		{
            startTime = DateTime.Now;

            iconfig = (IConfig)FxConfiguration.Instance.GetBean("Config");
			this.context = ctx;

            config = iconfig.GetConfig(ctx);
            context.Items["BlogContext"] = this;
		}

        public BlogConfig Config
        {
            get { return config; }
        }

		// Properties
		public HttpContext Context
		{
			get
			{
				if (this.context == null)
				{
					return new HttpContext(null);
				}
				return this.context;
			}
		}

        public static BlogContext Current
		{
			get
			{
				{
                    BlogContext ctx = (BlogContext)HttpContext.Current.Items["BlogContext"];
					if (ctx == null)
					{
                        ctx = new BlogContext(HttpContext.Current);
                        HttpContext.Current.Items["BlogContext"] = ctx;
					}
					return ctx;
				}
			}
		}

        public DateTime StartTime
        {
            get { return startTime; }
        }

        // Fields
		private HttpContext context;
        private string cacheName;
        private string cookiesName;
        private DateTime startTime;
	}
}