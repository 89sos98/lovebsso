﻿#region License
/*
 *  Copyright (C) 2005-2008 THE CCHENSOFT.COM
 *  
 *  This library is free software; you can redistribute it and/or modify it 
 *  under the terms of the GNU Lesser General Public License 2.1 or later, as
 *  published by the Free Software Foundation. See the included License.txt
 *  or http://www.cchensoft.com/opensource/license.txt for details. 
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Web;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text.RegularExpressions;
using System.Web.Security;
using System.Security.Cryptography;
using System.Globalization;
using System.Configuration;

using Dottext.Framework.Components;
using Dottext.Framework.Configuration;
using Dottext.Framework.Data;
using Dottext.Framework.EntryHandling;
using Dottext.Framework.Util;
using Dottext.Framework.Logger;

using CchenSoft.Framework;
using CchenSoft.Framework.Data;
using CchenSoft.Framework.DataAccess;
using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Service;

namespace Dottext.Framework.Service
{
    public class BlogService : IService
    {
        static List<EntryView> queuedStatsList = null;
        IBlogDao blogDao;
        IMailService mailService;
        IAuthenticator auth;

        public IAuthenticator Authenticator
        {
            set { auth = value; }
        }

        public IBlogDao BlogDao
        {
            set { this.blogDao = value; }
        }

        public IMailService MailService
        {
            set { this.mailService = value; }
        }

        #region Security

        /// <summary>
        /// Check to see if the supplied credentials are valid for the current blog. If so, Set the user's FormsAuthentication Ticket
        /// This method will handle passwords for both hashed and non-hashed configurations
        /// </summary>
        /// <param name="username">Supplied UserName</param>
        /// <param name="password">Supplied Password</param>
        /// <returns>bool indicating successful login</returns>
        public int Authenticate(string username, string password)
        {
            return Authenticate(username, password, false);
        }

        /// <summary>
        /// Check to see if the supplied credentials are valid for the current blog. If so, Set the user's FormsAuthentication Ticket
        /// This method will handle passwords for both hashed and non-hashed configurations
        /// </summary>
        /// <param name="username">Supplied UserName</param>
        /// <param name="password">Supplied Password</param>
        /// <param name="persist">If valid, should we persist the login</param>
        /// <returns>bool indicating successful login</returns>
        public int Authenticate(string username, string password, bool persist)
        {
            //if we don't match username, don't bother with password
            if (IsValidUser(username, password))
            {
                SetTicket(username, persist);
                BlogConfig config = GetConfig(username);
                return config.BlogID;
            }
            return 0;
        }

        //Maybe this method should be public?

        /// <summary>
        /// Private method to set FormsAuthentication Ticket. 
        /// </summary>
        /// <param name="username">Username for the ticket</param>
        /// <param name="persist">Should this ticket be persisted</param>
        private void SetTicket(string username, bool persist)
        {
            //FormsAuthentication.SetAuthCookie(username, persist);
        }

        //From Forums Source Code

        /// <summary>
        /// Get hashed/encrypted representation of the password. This is a one-way hash.
        /// </summary>
        /// <param name="password">Supplied Password</param>
        /// <returns>Encrypted (Hashed) value</returns>
        public string Encrypt(string password)
        {
            // Force the string to lower case
            //
            password = password.ToLower();

            Byte[] clearBytes = new UnicodeEncoding().GetBytes(password);
            Byte[] hashedBytes = ((HashAlgorithm)CryptoConfig.CreateFromName("MD5")).ComputeHash(clearBytes);

            return BitConverter.ToString(hashedBytes);
        }

        /// <summary>
        /// Validates if the supplied credentials match the current blog
        /// </summary>
        /// <param name="username">Supplied Username</param>
        /// <param name="password">Supplied Password</param>
        /// <returns>bool value indicating if the user is valid.</returns>
        public bool IsValidUser(string username, string password)
        {
            BlogConfig config = GetConfig(username);
            //if(string.Compare(username,Config.CurrentBlog().UserName,true)==0)
            //{
            return IsValidPassword(config, password);
            //}
            //return false;
        }

        /// <summary>
        /// Check to see if the supplied password matches the password for the current blog. This method will check the BlogConfigurationSettings
        /// to see if the password should be Encrypted/Hashed
        /// </summary>
        /// <param name="password">Supplied Password</param>
        /// <returns>bool value indicating if the supplied password matches the current blog's password</returns>
        //public bool IsValidPassword(string password)
        //{
        //    if (config == null)
        //    {
        //        return false;
        //    }

        //    if (config.IsPasswordHashed)
        //    {
        //        password = Encrypt(password);
        //    }
        //    return string.Compare(password, config.Password, false) == 0;
        //}

        public bool IsValidPassword(BlogConfig blogConfig, string password)
        {
            if (blogConfig == null)
            {
                return false;
            }

            if (blogConfig.IsPasswordHashed)
            {
                password = Encrypt(password);
            }
            return string.Compare(password, blogConfig.Password, false) == 0;
        }

        /// <summary>
        /// When we Encrypt/Hash the password, we can not un-Encrypt/Hash the password. If user's need to retrieve this value, all we can
        /// do is reset the passowrd to a new value and send it.
        /// </summary>
        /// <returns>A New Password</returns>
        public string ResetPassword(BlogConfig current_config)
        {
            string password = RandomPassword();

            UpdatePassword(password, current_config);

            return password;
        }

        /// <summary>
        /// Updates the current users password to the supplied value. Handles hashing (or not hashing of the password)
        /// </summary>
        /// <param name="password">Supplied Password</param>
        public void UpdatePassword(string password)
        {
            BlogConfig CurrentConfig = BlogContext.Current.Config;
            if (CurrentConfig.IsPasswordHashed)
            {
                CurrentConfig.Password = Encrypt(password);
            }
            else
            {
                CurrentConfig.Password = password;
            }
            //Save new password.
            UpdateConfigData(CurrentConfig);
        }

        public void UpdatePassword(string password, BlogConfig current_config)
        {
            if (current_config.IsPasswordHashed)
            {
                current_config.Password = Encrypt(password);
            }
            else
            {
                current_config.Password = password;
            }
            //Save new password.
            UpdateConfigData(current_config);
        }

        /// <summary>
        /// Generates a "Random Enough" password. :)
        /// </summary>
        /// <returns></returns>
        public string RandomPassword()
        {
            return Guid.NewGuid().ToString().Substring(0, 8);
        }

        public bool IsAdmin
        {
            get
            {
                return string.Compare(GetCurrentUserName, BlogContext.Current.Config.UserName, true) == 0;
            }
        }

        public string GetCurrentUserName
        {
            get
            {
                if (auth.IsAuthenticated)
                {
                    try
                    {
                        return auth.IdentityName;
                    }
                    catch { }
                }
                return null;
            }
        }

        public bool IsAuthenticated
        {
            get { return auth.IsAuthenticated; }
        }

        public bool IsInManagers()
        {
            Role[] roles = GetRoles(Convert.ToInt32(auth.Identity));
            for (int i = 0; i < roles.Length; i++)
            {
                if ("administrators" == roles[i].Name.ToLower())
                {
                    return true;
                }
            }
            return false;
        }

        public bool IsInRole(string roleName)
        {
            BlogConfig config = GetConfig(GetCurrentUserName);
            if (config == null)
            {
                return false;
            }
            Role[] roles = GetRoles(config.BlogID);
            for (int i = 0; i < roles.Length; i++)
            {
                if (roleName.ToLower() == roles[i].Name.ToLower())
                {
                    return true;
                }
            }
            return false;
        }

        #endregion 

        #region Archives

        public IList<ArchiveCount> GetPostsByMonthArchive(PostType postType)
        {
            return blogDao.GetPostsByMonthArchive(postType);
        }

        public IList<ArchiveCount> GetPostsByYearArchive(PostType postType)
        {
            return blogDao.GetPostsByYearArchive(postType);
        }

        #endregion

        #region BlogFiles

        public BlogFileCollection GetBlogFileCollection(string localFolder, string webPath)
        {

            BlogFileCollection bfc = new BlogFileCollection();
            DirectoryInfo dirInfo = new DirectoryInfo(localFolder);
            FileInfo[] fileInfos = dirInfo.GetFiles();
            foreach (FileInfo fileInfo in fileInfos)
            {
                BlogFile blogfile = new BlogFile();
                blogfile.Name = fileInfo.Name;
                blogfile.LocalFolder = localFolder;
                blogfile.WebPath = webPath;
                blogfile.Size = fileInfo.Length;
                bfc.Add(blogfile);

            }
            return bfc;

        }

        #endregion

        #region Entries


        #region Paged Posts

        public PagedList<Entry> GetPagedEntryCollection(PagedEntryQuery query)
        {
            return blogDao.GetPagedEntryCollection(query);
        }


        #endregion

        #region EntryDays

        public EntryDay GetEntryDay(EntryQuery query)
        {
            return blogDao.GetEntryDay(query);
        }

        public IList<EntryDay> GetEntryDayCollection(EntryQuery query)
        {
            return blogDao.GetEntryDayCollection(query);
        }

        #endregion

        #region EntryCollections


        public IList<Entry> GetEntryCollection(EntryQuery query)
        {
            return blogDao.GetEntryCollection(query);
        }

        /// <summary>
        /// Returns a collection of Entries containing the feedback for a given post (via ParentID)
        /// </summary>
        /// <param name="ParrentID">Parent (EntryID) of the collection</param>
        /// <param name="BlogID">Current BlogID</param>
        /// <param name="UrlPattern">Format of the Url for each entry</param>
        /// <returns></returns>
        public IList<Entry> GetFeedBack(int ParrentID)
        {
            return blogDao.GetFeedBack(ParrentID);
        }

        public IList<Entry> GetFeedBack(Entry ParentEntry)
        {
            return blogDao.GetFeedBack(ParentEntry);
        }

        public IList<CategoryEntry> GetCategoryEntryCollection(EntryQuery query)
        {
            return blogDao.GetCategoryEntryCollection(query);
        }

        #endregion

        #region Single Entry

        public Entry GetEntry(int EntryID)
        {
            return blogDao.GetEntry(EntryID);
        }

        public Entry GetEntry(int EntryID, int BlogID)
        {
            return blogDao.GetEntry(EntryID, BlogID);
        }

        public EntryStatsView GetEntryStatView(int EntryID)
        {
            return blogDao.GetEntryStatsView(EntryID);
        }

        public Entry GetEntry(int EntryID, PostConfig config)
        {
            return blogDao.GetEntry(EntryID, null, config);
        }

        public Entry GetEntry(string EntryName, PostConfig config)
        {
            return blogDao.GetEntry(0, EntryName, config);
        }


        public CategoryEntry GetCategoryEntry(int EntryID, PostConfig config)
        {
            return blogDao.GetCategoryEntry(EntryID, null, config);
        }

        public CategoryEntry GetCategoryEntry(string EntryName, PostConfig config)
        {
            return blogDao.GetCategoryEntry(0, EntryName, config);
        }

        #endregion

        #region Delete

        public bool Delete(int EntryID)
        {
            return blogDao.Delete(EntryID);
        }

        #endregion

        #region Create

        /// <summary>
        /// Add a new .Text Entry to the datastore. ProcessEntry.PreCommit is fired before an attempted save. Proccess.PostCommit is fired after the item is saved
        /// </summary>
        /// <param name="entry"></param>
        /// <returns></returns>
        public int Create(Entry entry)
        {
            return Create(entry, null);
        }

        /// <summary>
        /// Add a new .Text Entry to the datastore. ProcessEntry.PreCommit is fired before an attempted save. Proccess.PostCommit is fired after the item is saved
        /// </summary>
        /// <param name="entry"></param>
        /// <param name="CategoryIDs"></param>
        /// <returns></returns>
        [Transaction(TransactionOption.Required)]
        public int Create(Entry entry, int[] CategoryIDs)
        {
            HandlerManager.PreCommit(entry, ProcessAction.Insert);

            int result = blogDao.Create(entry, CategoryIDs);

            if (result > 0)
            {
                HandlerManager.PostCommit(entry, ProcessAction.Insert);
            }

            return result;
        }

        #endregion

        #region Update

        public bool Update(Entry entry)
        {
            return Update(entry, null);
        }

        [Transaction(TransactionOption.Required)]
        public bool Update(Entry entry, int[] CategoryIDs)
        {
            HandlerManager.PreCommit(entry, ProcessAction.Update);

            bool result = blogDao.Update(entry, CategoryIDs);

            if (result)
            {
                HandlerManager.PostCommit(entry, ProcessAction.Update);
            }

            return result;
        }

        #endregion

        #region Entry Category List

        public bool SetEntryCategoryList(int EntryID, int[] Categories)
        {
            return blogDao.SetEntryCategoryList(EntryID, Categories);
        }

        #endregion

        #region Comments

        [Obsolete]
        public void InsertComment(Entry entry)
        {
            entry.Author = Globals.SafeFormat(entry.Author);
            entry.TitleUrl = Globals.SafeFormat(entry.TitleUrl);
            entry.Body = Globals.SafeFormatWithUrl(entry.Body);
            entry.Title = Globals.SafeFormat(entry.Title);
            //entry.SourceUrl = Globals.PostsUrl(entry.ParentID);
            entry.IsXHMTL = false;
            entry.IsActive = true;
            entry.DateCreated = entry.DateUpdated = BlogTime.CurrentBloggerTime;



            if (null == entry.SourceName || String.Empty == entry.SourceName)
                entry.SourceName = "N/A";


            // insert comment into backend, save the returned entryid for permalink anchor below
            int entryID = Create(entry);

            // if it's not the administrator commenting
            if (!IsAdmin)
            {
                try
                {

                    string blogTitle = BlogContext.Current.Config.Title;

                    // create and format an email to the site admin with comment details
                    //IMailProvider im = EmailProvider.Instance();

                    string To = BlogContext.Current.Config.Email;
                    string From = mailService.Sender;
                    string Subject = String.Format("Comment: {0} (via {1})", entry.Title, blogTitle);
                    string Body = String.Format("Comments from {0}:\r\n\r\nSender: {1}\r\nUrl: {2}\r\nIP Address: {3}\r\n=====================================\r\n\r\n{4}\r\n\r\n{5}\r\n\r\nSource: {6}#{7}",
                        blogTitle,
                        entry.Author,
                        entry.TitleUrl,
                        entry.SourceName,
                        entry.Title,
                        // we're sending plain text email by default, but body includes <br>s for crlf
                        entry.Body.Replace("<br>", "\n"),
                        entry.SourceUrl,
                        entryID);

                    mailService.Send(From, To, Subject, Body);
                }
                catch { }
            }
        }

        #endregion

        #region EntryCount
        public int GetEntryCount(EntryQuery query)
        {
            return blogDao.GetEntryCount(query);
        }
        #endregion

        #region MailNotify

        public IList<string> GetNotifyMailList(int EntryID)
        {
            return blogDao.GetNotifyMailList(EntryID);
        }

        public bool InsertNotifySubscibe(int EntryID, int BlogID, int SendToBlogID, string EMail)
        {
            return blogDao.InsertNotifySubscibe(EntryID, BlogID, SendToBlogID, EMail);
        }

        public bool DeleteMailNotify(int EntryID, int SendToBlogID)
        {
            return blogDao.DeleteMailNotify(EntryID, SendToBlogID);
        }

        #endregion

        #endregion

        #region Images

        public string LocalFilePath(HttpContext context)
        {
            return BlogContext.Current.Config.ImageDirectory;
        }

        public string LocalGalleryFilePath(HttpContext context, int categoryid)
        {
            return string.Format("{0}\\{1}\\", BlogContext.Current.Config.ImageDirectory, categoryid);
        }

        public string HttpGalleryFilePath(HttpContext context, int categoryid)
        {
            return string.Format("{0}{1}/", BlogContext.Current.Config.ImagePath, categoryid);
        }

        public string HttpFilePath(HttpContext context)
        {
            return BlogContext.Current.Config.ImagePath;
        }

        public byte[] GetFileStream(HttpPostedFile objFile)
        {
            if (objFile != null)
            {
                int len = objFile.ContentLength;
                byte[] input = new byte[len];
                Stream file = objFile.InputStream;
                try
                {
                    file.Read(input, 0, len);
                }
                finally
                {
                    file.Close();
                }
                return input;
            }
            return null;
        }

        public bool ValidateFile(string filepath)
        {
            if (File.Exists(filepath))
            {
                return false;
            }

            return Regex.IsMatch(filepath,
                "(?:[^\\/\\*\\?\\\"\\<\\>\\|\\n\\r\\t]+)\\.(?:jpg|jpeg|gif|png|bmp)",
                RegexOptions.IgnoreCase | RegexOptions.CultureInvariant
                );
        }

        public Size ResizeImage(int width, int height, int maxWidth, int maxHeight)
        {
            decimal MAX_WIDTH = (decimal)maxWidth;
            decimal MAX_HEIGHT = (decimal)maxHeight;
            decimal ASPECT_RATIO = MAX_WIDTH / MAX_HEIGHT;

            int newWidth, newHeight;

            decimal originalWidth = (decimal)width;
            decimal originalHeight = (decimal)height;

            if (originalWidth > MAX_WIDTH || originalHeight > MAX_HEIGHT)
            {
                decimal factor;
                // determine the largest factor 
                if (originalWidth / originalHeight > ASPECT_RATIO)
                {
                    factor = originalWidth / MAX_WIDTH;
                    newWidth = Convert.ToInt32(originalWidth / factor);
                    newHeight = Convert.ToInt32(originalHeight / factor);
                }
                else
                {
                    factor = originalHeight / MAX_HEIGHT;
                    newWidth = Convert.ToInt32(originalWidth / factor);
                    newHeight = Convert.ToInt32(originalHeight / factor);
                }
            }
            else
            {
                newWidth = width;
                newHeight = height;
            }

            return new Size(newWidth, newHeight);

        }

        public bool SaveImage(byte[] Buffer, string FileName)
        {
            FileStream fs = null;
            if (ValidateFile(FileName))
            {
                CheckDirectory(FileName);
                try
                {
                    fs = new FileStream(FileName, FileMode.Create);
                    fs.Write(Buffer, 0, Buffer.Length);
                }
                finally
                {
                    fs.Close();
                }
                return true;
            }
            return false;

        }

        public bool SaveFile(byte[] Buffer, string FileName)
        {
            FileStream fs = null;

            try
            {
                fs = new FileStream(FileName, FileMode.Create);
                fs.Write(Buffer, 0, Buffer.Length);
            }
            catch (Exception ex)
            {
                Dottext.Framework.Logger.LogManager.CreateExceptionLog(ex, "SaveFile");
            }
            finally
            {
                fs.Close();
            }
            return true;



        }

        public void MakeAlbumImages(ref Dottext.Framework.Components.Image _image)
        {

            System.Drawing.Image original = System.Drawing.Image.FromFile(_image.OriginalFilePath);

            Size _newSize = ResizeImage(original.Width, original.Height, 640, 480);
            _image.Height = _newSize.Height;
            _image.Width = _newSize.Width;
            System.Drawing.Image displayImage = new Bitmap(original, _newSize);
            System.Drawing.Image tbimage = new Bitmap(original, ResizeImage(original.Width, original.Height, 120, 120));
            original.Dispose();
            try
            {
                displayImage.Save(_image.ResizedFilePath, GetFormat(_image.File));
            }
            finally
            {
                displayImage.Dispose();
            }
            try
            {
                tbimage.Save(_image.ThumbNailFilePath, ImageFormat.Jpeg);
            }
            finally
            {
                tbimage.Dispose();
            }
        }

        public ImageFormat GetFormat(string name)
        {
            string ext = name.Substring(name.LastIndexOf(".") + 1);
            switch (ext.ToLower())
            {
                case "jpg":
                case "jpeg":
                    return ImageFormat.Jpeg;
                case "bmp":
                    return ImageFormat.Bmp;
                case "png":
                    return ImageFormat.Png;
                case "gif":
                    return ImageFormat.Gif;
                default:
                    return ImageFormat.Jpeg;
            }
        }

        public string GetFileName(string filepath)
        {
            if (filepath.IndexOf("\\") == -1)
            {
                return StripUrlCharsFromFileName(filepath);
            }
            else
            {
                int lastindex = filepath.LastIndexOf("\\");
                return StripUrlCharsFromFileName(filepath.Substring(lastindex + 1));
            }
        }

        private static string StripUrlCharsFromFileName(string filename)
        {
            const string replacement = "_";

            filename = filename.Replace("#", replacement);
            filename = filename.Replace("&", replacement);
            filename = filename.Replace("%", replacement);

            return filename;
        }

        public void CheckDirectory(string filepath)
        {
            string dir = filepath.Substring(0, filepath.LastIndexOf("\\"));
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }
        }

        #region Data Stuff

        public ImageCollection GetImagesByCategoryID(int catID, bool ActiveOnly)
        {
            return blogDao.GetImagesByCategoryID(catID, ActiveOnly);
        }

        public Dottext.Framework.Components.Image GetSingleImage(int imageID, bool ActiveOnly)
        {
            return blogDao.GetSingleImage(imageID, ActiveOnly);
        }

        public int InsertImage(Dottext.Framework.Components.Image _image, byte[] Buffer)
        {
            if (SaveImage(Buffer, _image.OriginalFilePath))
            {
                MakeAlbumImages(ref _image);
                return blogDao.InsertImage(_image);
            }
            return -1;
        }

        public bool UpdateImage(Dottext.Framework.Components.Image _image)
        {
            return blogDao.UpdateImage(_image);
        }

        // added
        public void Update(Dottext.Framework.Components.Image _image, byte[] Buffer)
        {
            if (SaveImage(Buffer, _image.OriginalFilePath))
            {
                MakeAlbumImages(ref _image);
                UpdateImage(_image);
            }
        }

        public void DeleteImage(Dottext.Framework.Components.Image _image)
        {
            blogDao.DeleteImage(_image.ImageID);
        }

        public void TryDeleteFile(string file)
        {
            if (File.Exists(file))
            {
                File.Delete(file);
            }
        }
        #endregion


        #endregion

        #region Links

        #region Paged Links

        public PagedList<Link> GetPagedLinks(int categoryTypeID, int pageIndex, int pageSize, bool sortDescending)
        {
            return blogDao.GetPagedLinks(categoryTypeID, pageIndex, pageSize, sortDescending);
        }

        #endregion

        #region LinkCollection

        public LinkCollection GetLinkCollectionByPostID(int PostID)
        {
            return blogDao.GetLinkCollectionByPostID(PostID);
        }

        public LinkCollection GetLinkCollectionByPostID(int BlogID, int PostID)
        {
            return blogDao.GetLinkCollectionByPostID(BlogID, PostID);
        }

        public LinkCollection GetLinksByCategoryID(int catID, bool ActiveOnly)
        {
            return blogDao.GetLinksByCategoryID(catID, ActiveOnly);
        }

        #endregion

        #region Single Link

        public Link GetSingleLink(int linkID)
        {
            return blogDao.GetSingleLink(linkID);
        }

        #endregion

        #region LinkCategoryCollection

        public IList<LinkCategory> GetCategoriesByType(CategoryType catType, bool ActiveOnly)
        {
            return blogDao.GetCategoriesByType(catType, ActiveOnly);
        }

        public IList<LinkCategory> GetCategoriesByParentID(CategoryType catType, int ParentID, bool ActiveOnly)
        {
            return blogDao.GetCategoriesByParentID(catType, ParentID, ActiveOnly);
        }

        public IList<LinkCategory> GetCategoriesByType(int BlogID, CategoryType catType, bool ActiveOnly)
        {
            return blogDao.GetCategoriesByType(BlogID, catType, ActiveOnly);
        }

        public IList<LinkCategory> GetCategoriesWithLinks(bool IsActive)
        {
            return blogDao.GetCategoriesWithLinks(IsActive);
        }

        #endregion

        #region LinkCategory

        public LinkCategory GetLinkCategory(int CategoryID, bool IsActive)
        {
            return blogDao.GetLinkCategory(CategoryID, IsActive);
        }

        public LinkCategory GetLinkCategory(int CategoryID, bool IsActive, int BlogID)
        {
            return blogDao.GetLinkCategory(CategoryID, IsActive, BlogID);
        }

        public LinkCategory GetLinkCategory(string CategoryName, bool IsActive)
        {
            return blogDao.GetLinkCategory(CategoryName, IsActive);
        }

        #endregion

        #region Edit Links/Categories

        public bool UpdateLink(Link link)
        {
            return blogDao.UpdateLink(link);
        }

        public int CreateLink(Link link)
        {
            return blogDao.CreateLink(link);
        }

        public bool UpdateLinkCategory(LinkCategory lc)
        {
            return blogDao.UpdateLinkCategory(lc);
        }

        public int CreateLinkCategory(LinkCategory lc)
        {
            return blogDao.CreateLinkCategory(lc);
        }

        public bool DeleteLinkCategory(int CategoryID)
        {
            return blogDao.DeleteLinkCategory(CategoryID);
        }

        public bool DeleteLinkCategory(int CategoryID, int BlogID)
        {
            return blogDao.DeleteLinkCategory(CategoryID, BlogID);
        }

        public bool DeleteLink(int LinkID)
        {
            return blogDao.DeleteLink(LinkID);
        }

        [Transaction(TransactionOption.Required)]
        public void DeleteLinkCategoryByType(AbstractComponent node, CategoryType type)
        {
            blogDao.DeleteLinkCategoryByType(node, type);
        }

        #endregion

        #endregion

        #region Rates

        public int InsertRate(EntryRate er)
        {
            return blogDao.InsertRate(er);
        }

        public void GetRateScore(EntryRate er)
        {

            for (int i = 0; i < er.RatingList.Length; i++)
            {
                er.RatingList[i] = blogDao.GetRatePeople(er.EntryID, i + 1);
            }
        }

        #endregion

        #region Roles

        public Role[] GetRoles(int BlogID)
        {
            return blogDao.GetRoles(BlogID);
        }

        public bool AddUserToRole(int BlogID, int RoleID)
        {
            return blogDao.AddUserToRole(BlogID, RoleID);
        }

        public bool RemoveUserFromRole(int BlogID, int RoleID)
        {
            return blogDao.RemoveUserFromRole(BlogID, RoleID);
        }

        #endregion

        #region SkinControls

        public IList<SkinControl> GetSkinControlCollection(int BlogID)
        {
            return blogDao.GetSkinControlCollection(BlogID);
        }

        public void UpdateSkinControl(IList<SkinControl> scc)
        {
            foreach (SkinControl sc in scc)
            {
                blogDao.UpateSkinControl(sc);
            }
            //return blogDao.GetSkinControlCollection(BlogID);
        }

        public bool UpdateSingleSkinControl(int ControlID, bool visible, int BlogID)
        {
            return blogDao.UpdateSingleSkinControl(ControlID, visible, BlogID);

        }

        #endregion

        #region Stats

		/// <summary>
		/// Clear Queue will empty the EntryViewCollection. The bool save value will determine if the results are
		/// saved to the datastore or not.
		/// </summary>
		/// <param name="save"></param>
		/// <returns></returns>
		public bool ClearQueue(bool save)
		{
			lock(queuedStatsList)
			{
				if(save)
				{
					EntryView[] eva = new EntryView[queuedStatsList.Count];
					queuedStatsList.CopyTo(eva,0);

                    ClearTrackEntryQueue(new List<EntryView>(eva));
					
				}
				queuedStatsList.Clear();	
			}
			return true;
		}

		/// <summary>
		/// Adds an EntryView to the in memory EntryViewCollection
		/// </summary>
		/// <param name="ev"></param>
		/// <returns></returns>
		public bool AddQueuedStats(EntryView ev)
		{
			if(queuedStatsList==null)
			{
                queuedStatsList = new List<EntryView>();
			}
			queuedStatsList.Add(ev);
			return true;
		}

		//Since we are now clearing the queue via a timer, do we even need to do this async?

		/// <summary>
		/// Internal method for asyc clearing of the EntryViewCollection. 
		/// </summary>
		/// <param name="evc"></param>
		/// <returns></returns>
        private bool ClearTrackEntryQueue(IList<EntryView> evc)
		{
			ProcessStats ps = new ProcessStats(this, evc);
			ps.Enqueue();
			
			return true;
		}

		private class ProcessStats
		{
            private BlogService _service;

            public ProcessStats(BlogService service, IList<EntryView> evc)
			{
                _service = service;
				_evc = evc;
			}
            protected IList<EntryView> _evc;

			public void Enqueue()
			{
				ManagedThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(Process));
			}

			private void Process(object state)
			{
				_service.TrackEntry(this._evc);
			}
		}

		#region Data

		public PagedList<Referrer> GetPagedReferrers(int pageIndex, int pageSize)
		{
			return blogDao.GetPagedReferrers(pageIndex, pageSize);
		}

		public PagedList<Referrer> GetPagedReferrers(int pageIndex, int pageSize, int EntryID)
		{
			return blogDao.GetPagedReferrers(pageIndex, pageSize, EntryID);
		}

		#endregion
		

		/// <summary>
		/// Adds an individual EntryView to the datastore
		/// </summary>
		/// <param name="ev"></param>
		/// <returns></returns>
		public bool TrackEntry(EntryView ev)
		{
			return blogDao.TrackEntry(ev);
		}

		/// <summary>
		/// Adds a collection of EntryViews to the datastore.
		/// </summary>
		/// <param name="evc"></param>
		/// <returns></returns>
        [Transaction(TransactionOption.RequiresNew)]
        public bool TrackEntry(IList<EntryView> evc)
		{
            foreach (EntryView ev in evc)
            {
                blogDao.TrackEntry(ev);
            }
            return true;
		}

        #endregion

        #region KeyWords

        #region Readers/Writers

        private enum ScanState : byte { Replace, InTag, InAnchor };

        public string Replace(string source, string oldValue, string newValue)
        {
            return Scan(source, oldValue, newValue, false, false, true);
        }

        public string Replace(string source, string oldValue, string newValue, bool onlyFirstMatch, bool CaseSensitive)
        {
            return Scan(source, oldValue, newValue, false, onlyFirstMatch, CaseSensitive);
        }

        /// <summary>
        /// Preforms a forward scan and replace for a given pattern. Replaces all finds and preforms a case sensitive search
        /// </summary>
        /// <param name="source">Text to search</param>
        /// <param name="oldValue">Pattern to search for</param>
        /// <param name="formatString">Replaced Pattern</param>
        /// <returns></returns>
        public string ReplaceFormat(string source, string oldValue, string formatString)
        {
            return Scan(source, oldValue, formatString, true, false, true);
        }

        /// <summary>
        /// Preforms a forward scan and replace for a given pattern. Can specify only to match first fine and if the pattern is CaseSensitive
        /// </summary>
        /// <param name="source">Text to search</param>
        /// <param name="oldValue">Pattern to search for</param>
        /// <param name="formatString">Replaced Pattern</param>
        /// <param name="onlyFirstMatch">Match First Only</param>
        /// <param name="CaseSensitive">Is CaseSensitive</param>
        /// <returns></returns>
        public string ReplaceFormat(string source, string oldValue, string formatString, bool onlyFirstMatch, bool CaseSensitive)
        {
            return Scan(source, oldValue, formatString, true, onlyFirstMatch, CaseSensitive);
        }

        private string Scan(string source, string oldValue, string newValue, bool isFormat, bool onlyFirstMatch, bool CaseSensitive)
        {
            const char tagOpen = '<';
            const char tagClose = '>';
            const string anchorOpen = "<a ";
            const string anchorClose = "</a";

            source += " ";

            bool lastIterMatched = false;

            ScanState state = ScanState.Replace;
            StringBuilder outputBuffer = new StringBuilder(source.Length);

            CharQueue tagstack =
                new CharQueue(anchorOpen.Length >= anchorClose.Length ? anchorOpen.Length : anchorClose.Length);

            for (int i = 0; i < source.Length; i++)
            {
                char nextChar = source[i];
                tagstack.Enqueue(nextChar);

                switch (state)
                {
                    case ScanState.Replace:
                        if (anchorOpen == tagstack.ToString(anchorOpen.Length))
                        {
                            state = ScanState.InAnchor;
                            break;
                        }
                        else
                        {
                            if (tagOpen == nextChar)
                            {
                                state = ScanState.InTag;
                                break;
                            }
                            else
                            {
                                string matchTarget;
                                if (source.Length - (i + tagstack.Length + oldValue.Length) > 0)
                                {
                                    // peek a head the next target length chunk + 1 boundary char
                                    matchTarget = source.Substring(i + tagstack.Length, oldValue.Length);
                                    //Do we want a case insesitive comparison?
                                    if (string.Compare(matchTarget, oldValue, !CaseSensitive) == 0)
                                    //if (matchTarget == oldValue)
                                    {
                                        int index = tagstack.Length - i;
                                        if (index != 0) //Skip if we are at the start of the block
                                        {
                                            char prevBeforeMatch = source[(i + tagstack.Length) - 1];
                                            if (prevBeforeMatch != '>' && prevBeforeMatch != '"' && !Char.IsWhiteSpace(prevBeforeMatch))
                                            {
                                                break;
                                            }
                                        }

                                        // check for word boundary
                                        char nextAfterMatch = source[i + tagstack.Length + oldValue.Length];
                                        if (!CharIsWordBoundary(nextAfterMatch))
                                            break;

                                        // format old with specifier else it's a straight replace
                                        if (isFormat)
                                            outputBuffer.AppendFormat(newValue, oldValue);
                                        else
                                            outputBuffer.Append(newValue);

                                        // if we're onlyFirstMatch, tack on remainder of source and return
                                        if (onlyFirstMatch)
                                        {
                                            outputBuffer.AppendFormat(source.Substring(i + oldValue.Length,
                                                source.Length - (i + oldValue.Length + 1)));
                                            return outputBuffer.ToString();
                                        }
                                        else // pop index ahead to end of match and continue
                                            i += oldValue.Length - 1;

                                        lastIterMatched = true;
                                        break;
                                    }
                                }
                            }
                        }

                        break;

                    case ScanState.InAnchor:
                        if (anchorClose == tagstack.ToString(anchorClose.Length))
                            state = ScanState.Replace;
                        break;

                    case ScanState.InTag:
                        if (anchorOpen == tagstack.ToString(anchorOpen.Length))
                            state = ScanState.InAnchor;
                        else if (tagClose == nextChar)
                            state = ScanState.Replace;
                        break;

                    default:
                        break;
                }

                if (!lastIterMatched)
                {
                    outputBuffer.Append(nextChar);
                }
                else
                    lastIterMatched = false;
            }

            return outputBuffer.ToString().Trim();
        }


        // cursory testing for word boundaries. there are still some cracks here for html,
        // e.g., &nbsp; and other boundary entities
        private bool CharIsWordBoundary(char value)
        {
            switch (value)
            {
                case '_':
                    return false;
                //				case '<' :
                //					return false;
                default:
                    return !Char.IsLetterOrDigit(value);
            }
        }


        #endregion

        #region Data

        public void Format(ref Entry entry)
        {
            IList<KeyWord> kwc = GetKeyWords();
            if (kwc != null && kwc.Count > 0)
            {
                KeyWord kw = null;
                for (int i = 0; i < kwc.Count; i++)
                {
                    kw = kwc[i];
                    entry.Body = ReplaceFormat(entry.Body, kw.Word, kw.GetFormat, kw.ReplaceFirstTimeOnly, kw.CaseSensitive);
                }
            }
        }

        public KeyWord GetKeyWord(int KeyWordID)
        {
            return blogDao.GetKeyWord(KeyWordID);
        }

        public IList<KeyWord> GetKeyWords()
        {
            return blogDao.GetKeyWords();
        }

        public PagedList<KeyWord> GetPagedKeyWords(int pageIndex, int pageSize, bool sortDescending)
        {
            return blogDao.GetPagedKeyWords(pageIndex, pageSize, sortDescending);
        }

        public void UpdateKeyWord(KeyWord kw)
        {
            blogDao.UpdateKeyWord(kw);
        }

        public int InsertKeyWord(KeyWord kw)
        {
            return blogDao.InsertKeyWord(kw);
        }

        public bool DeleteKeyWord(int KeyWordID)
        {
            return blogDao.DeleteKeyWord(KeyWordID);
        }

        #endregion

        #region CharQueue
        internal class CharQueue : object
        {
            private char[] _list;
            private int _charCount = 0;

            protected CharQueue() { }
            public CharQueue(int length)
            {
                _list = new char[length];
            }

            public char this[int i]
            {
                get { return _list[i]; }
                set { _list[i] = value; }
            }

            public void Enqueue(char x)
            {
                for (int i = 0; i < _list.Length; i++)
                {
                    if (i < _list.Length - 1)
                        _list[i] = _list[i + 1];
                    else
                        _list[i] = x;
                }
            }

            public int Length
            {
                get { return _charCount; }
            }

            public char Dequeue()
            {
                char result = _list[0];

                char[] compacted = new char[_list.Length - 1];
                _list.CopyTo(compacted, 1);
                _list = compacted;

                return result;
            }

            public bool Holds(string value)
            {
                return Holds(value, true);
            }

            public bool Holds(string value, bool ignoreCase)
            {
                return (0 == String.Compare(value, this.ToString(), ignoreCase,
                    CultureInfo.InvariantCulture));
            }

            public override string ToString()
            {
                return new string(_list);
            }

            public string ToString(int length)
            {
                if (length != _list.Length)
                {
                    char[] results = new char[length];
                    _list.CopyTo(results, 0);
                    return new string(results);
                }
                else
                    return this.ToString();
            }


        #endregion

        }

        #endregion

        #region ScheduledEvents
        public DateTime GetLastExecuteScheduledEventDateTime(string key, string serverName)
        {
            return blogDao.GetLastExecuteScheduledEventDateTime(key, serverName);
        }

        public void SetLastExecuteScheduledEventDateTime(string key, string serverName, DateTime dt)
        {
            blogDao.SetLastExecuteScheduledEventDateTime(key, serverName, dt);
        }

        #endregion

        #region Logger
        public int CreateLog(Log blogLog)
        {
            return blogDao.CreateLog(blogLog);
        }

        #endregion

        #region  Configuration

        public bool UpdateConfigData(BlogConfig config)
        {
            return blogDao.UpdateConfigData(config);
        }

        public BlogConfig GetConfig(int BlogID)
        {
            return blogDao.GetConfig(BlogID);
        }

        public BlogConfig GetConfig()
        {
            return blogDao.GetConfig();
        }

        public BlogConfig[] GetConfigByRoleID(int RoleID)
        {
            return blogDao.GetConfigByRoleID(RoleID);
        }

        public string[] GetBlogGroup(int BlogID)
        {
            return blogDao.GetBlogGroup(BlogID);
        }

        public BlogConfig GetConfig(string UserName)
        {
            return blogDao.GetConfig(UserName);
        }

        public BlogConfig GetConfigByApp(string application)
        {
            return blogDao.GetConfigByApp(application);
        }

        public BlogConfig GetConfig(string hostname, string application)
        {
            if (Config.Settings.EnableMultiHost)
            {
                BlogConfig result = blogDao.GetConfig(hostname, application);
                if (result == null)
                {
                    throw new BlogDoesNotExistException(
                        String.Format("A blog matching the location you requested was not found. Host = [{0}], Application = [{1}]",
                        hostname,
                        application));
                }
                return result;
            }
            else
            {
                return blogDao.GetConfigByApp(application);
            }
        }


        public bool UpateSkinControl(SkinControl sc)
        {
            return blogDao.UpateSkinControl(sc);
        }

        #endregion

        #region IService 成员

        public void Initialize()
        {
        }

        #endregion
    }
}
