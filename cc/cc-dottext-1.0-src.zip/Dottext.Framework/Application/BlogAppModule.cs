﻿#region License
/*
 *  Copyright (C) 2005-2008 THE CCHENSOFT.COM
 *  
 *  This library is free software; you can redistribute it and/or modify it 
 *  under the terms of the GNU Lesser General Public License 2.1 or later, as
 *  published by the Free Software Foundation. See the included License.txt
 *  or http://www.cchensoft.com/opensource/license.txt for details. 
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Configuration;
using FxConfiguration = CchenSoft.Framework.Config.Configuration;
using Dottext.Framework.Configuration;

namespace Dottext.Framework
{
    public class BlogAppModule : IHttpModule
    {
        private IConfig iconfig;

        #region IHttpModule 成员

        public void Dispose()
        {
        }

        public void Init(HttpApplication context)
        {
            iconfig = (IConfig)FxConfiguration.Instance.GetBean("Config");
            context.BeginRequest += new EventHandler(context_BeginRequest);
        }

        void context_BeginRequest(object sender, EventArgs e)
        {
            HttpContext hctx = (sender as HttpApplication).Context;

            string reqPath = hctx.Request.Path.ToLower();

            if (!reqPath.EndsWith(".aspx"))
                return;

            string blogRoot = Config.RootPath;
  
            if (!reqPath.StartsWith(blogRoot.ToLower()))
                return;

            BlogContext bctx = new BlogContext(hctx);

            // 如是单用户博客且未注册。
            if (iconfig.IsAggregateSite == false && bctx.Config == null)
                hctx.RewritePath(blogRoot + "register.aspx");
        }

        #endregion
    }
}
