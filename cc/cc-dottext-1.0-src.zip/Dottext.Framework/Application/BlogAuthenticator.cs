﻿#region License
/*
 *  Copyright (C) 2005-2008 THE CCHENSOFT.COM
 *  
 *  This library is free software; you can redistribute it and/or modify it 
 *  under the terms of the GNU Lesser General Public License 2.1 or later, as
 *  published by the Free Software Foundation. See the included License.txt
 *  or http://www.cchensoft.com/opensource/license.txt for details. 
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Framework;
using System.Web;
using Dottext.Framework.Service;

namespace Dottext.Framework
{
    public class BlogAuthenticator : IAuthenticator
    {
        private const string CookieKey = "cc-blog";
        private const string IdentityKey = "userId";
        private const string IdentityNameKey = "userName";
        private BlogService blogService;
        private string loginUrl;

        public BlogService BlogService
        {
            set { blogService = value; }
        }

        #region IAuthenticator 成员

        public int Authenticate(string name, string passwd, int persist)
        {
            int blogID = blogService.Authenticate(name, passwd);
            if (blogID > 0)
            {
                HttpCookie cookie = new HttpCookie(CookieKey);
                cookie[IdentityKey] = blogID.ToString();
                cookie[IdentityNameKey] = name;
                if (persist > 0)
                {
                    cookie.Expires = DateTime.Now.AddDays(persist);
                }
                HttpContext.Current.Response.Cookies.Add(cookie);
                return blogID;
            }
            return blogID;
        }

        public bool IsAuthenticated
        {
            get
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
                return cookie != null ? !string.IsNullOrEmpty(cookie[IdentityKey]) : false;
            }
        }

        public void CheckPermission(string resource, int action)
        {
        }

        public string Identity
        {
            get
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
                return (cookie != null) ? cookie[IdentityKey] : null;
            }
        }

        public string IdentityName
        {
            get
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
                return (cookie != null) ? cookie[IdentityNameKey] : null;
            }
        }

        public string LoginUrl
        {
            get { return loginUrl; }
            set { loginUrl = value; }
        }

        public void SignOut()
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
            if (cookie != null)
            {
                cookie.Expires = DateTime.Now.AddDays(-1);
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
        }

        #endregion
    }
}
