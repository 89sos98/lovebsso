#region License
/*
 *  Copyright (C) 2005-2008 THE CCHENSOFT.COM
 *  
 *  This library is free software; you can redistribute it and/or modify it 
 *  under the terms of the GNU Lesser General Public License 2.1 or later, as
 *  published by the Free Software Foundation. See the included License.txt
 *  or http://www.cchensoft.com/opensource/license.txt for details. 
 */
#endregion

using System;
using System.Collections;
using Dottext.Framework.Components;
using Dottext.Framework.Logger;
using Dottext.Framework.Configuration;
using System.Collections.Generic;
using System.Data;

namespace Dottext.Framework.Data
{
	/// <summary>
	/// Summary description for IDTOProvider.
	/// </summary>
	public interface IBlogDao
	{
		#region Entries

		#region EntryCollections

        IList<Entry> GetEntryCollection(EntryQuery query);
		IList<CategoryEntry> GetCategoryEntryCollection(EntryQuery query);
		IList<EntryDay> GetEntryDayCollection(EntryQuery query);
		PagedList<Entry> GetPagedEntryCollection(PagedEntryQuery query);
		EntryDay GetEntryDay(EntryQuery query);

        IList<Entry> GetFeedBack(int ParrentID);
        IList<Entry> GetFeedBack(Entry ParentEntry);

		#endregion

		#region Single Entry
		Entry GetEntry(int EntryID);
		Entry GetEntry(int EntryID,int BlogID);
		EntryStatsView GetEntryStatsView(int EntryID);
		Entry GetEntry(int EntryID, string EntryName, PostConfig config);
		CategoryEntry GetCategoryEntry(int EntryID, string EntryName, PostConfig config);
		
		#endregion

		#region Entry 
	
		bool Delete(int PostID);
        int Create(Entry entry, int[] CategoryIDs);
		bool Update(Entry entry, int[] CategoryIDs);

		#endregion

		#region Entry Category List

		bool SetEntryCategoryList(int EntryID, int[] Categories);

		#endregion

		#endregion

		#region Links/Categories

		#region Paged Links

		PagedList<Link> GetPagedLinks(int categoryTypeID, int pageIndex, int pageSize, bool sortDescending);

		#endregion

		#region LinkCollection

		LinkCollection GetLinkCollectionByPostID(int PostID);
		LinkCollection GetLinkCollectionByPostID(int BlogID,int PostID);
		LinkCollection GetLinksByCategoryID(int catID, bool ActiveOnly);
		
		#endregion

		#region Single Link

		Link GetSingleLink(int linkID);
		
		#endregion

		#region LinkCategoryCollection

		IList<LinkCategory> GetCategoriesByType(CategoryType catType, bool ActiveOnly);
        IList<LinkCategory> GetCategoriesByParentID(CategoryType catType, int ParentID, bool ActiveOnly);
        IList<LinkCategory> GetCategoriesByType(int BlogID, CategoryType catType, bool ActiveOnly);
        IList<LinkCategory> GetCategoriesWithLinks(bool IsActive);

		#endregion

		#region LinkCategory

		LinkCategory GetLinkCategory(int CategoryID, bool IsActive);
		LinkCategory GetLinkCategory(int CategoryID, bool IsActive,int BlogID);
		LinkCategory GetLinkCategory(string categoryName, bool IsActive);

		#endregion

		#region Edit Links/Categories

		bool UpdateLink(Link link);
		int CreateLink(Link link);
		bool UpdateLinkCategory(LinkCategory lc);
		int CreateLinkCategory(LinkCategory lc);
		bool DeleteLinkCategory(int CategoryID);
		bool DeleteLink(int LinkID);
		bool DeleteLinkCategory(int LinkID,int BlogID);
        void DeleteLinkCategoryByType(AbstractComponent node, CategoryType type);

		#endregion

		#endregion

		#region Stats

		PagedList<Referrer> GetPagedReferrers(int pageIndex, int pageSize);
		PagedList<Referrer> GetPagedReferrers(int pageIndex, int pageSize, int EntryID);

		bool TrackEntry(EntryView ev);

		#endregion

		#region  Configuration

		bool UpdateConfigData(BlogConfig config);
		BlogConfig GetConfig(string hostname, string application);
		BlogConfig GetConfig(int BlogID);
        BlogConfig GetConfig();
		BlogConfig[] GetConfigByRoleID(int RoleID);
		string[] GetBlogGroup(int BlogID);
		BlogConfig GetConfig(string UserName);
		BlogConfig GetConfigByApp(string application);
		IList<SkinControl> GetSkinControlCollection(int BlogID);
		bool UpateSkinControl(SkinControl sc);
		bool UpdateSingleSkinControl(int ControlID,bool visible,int BlogID);

		#endregion

		#region KeyWords

		KeyWord GetKeyWord(int KeyWordID);
		IList<KeyWord> GetKeyWords();
		PagedList<KeyWord> GetPagedKeyWords(int pageIndex, int pageSize,bool sortDescending);
		bool UpdateKeyWord(KeyWord kw);
		int InsertKeyWord(KeyWord kw);
		bool DeleteKeyWord(int KeyWordID);

		#endregion

		#region Images

		ImageCollection GetImagesByCategoryID(int catID, bool ActiveOnly);
		Image GetSingleImage(int imageID, bool ActiveOnly);
		int InsertImage(Dottext.Framework.Components.Image _image);
		bool UpdateImage(Dottext.Framework.Components.Image _image);
		bool DeleteImage(int ImageID);

		#endregion

		#region Archives
        IList<ArchiveCount> GetPostsByYearArchive(PostType postType);
        IList<ArchiveCount> GetPostsByMonthArchive(PostType postType);
		#endregion

		#region ScheduledEvents
		DateTime GetLastExecuteScheduledEventDateTime(string key, string serverName);
		void SetLastExecuteScheduledEventDateTime(string key, string serverName, DateTime dt);
		#endregion

		#region Logger
		int CreateLog(Log blogLog);
		#endregion

		#region Rate
		int InsertRate(EntryRate er);
		int GetRatePeople(int entryID,int score);
		#endregion

		#region EntryCount
		int GetEntryCount(EntryQuery query);
		#endregion

		#region Security
		Role[] GetRoles(int BlogID);
		bool AddUserToRole(int BlogID,int RoleID);
		bool RemoveUserFromRole(int BlogID,int RoleID);
		#endregion

		#region MailNotify

		IList<string> GetNotifyMailList(int EntryID);
		bool InsertNotifySubscibe(int EntryID,int BlogID,int SendToBlogID,string EMail);
		bool DeleteMailNotify(int EntryID,int SendToBlogID);

		#endregion

        DataSet ExecuteDataset(CommandType type, string text);

        DataSet ExecuteDataset(CommandType type, string text, IDbDataParameter[] parameters);

        int ExecuteNonQuery(CommandType type, string text);

        int ExecuteNonQuery(CommandType type, string text, IDbDataParameter[] parameters);
	}
}
