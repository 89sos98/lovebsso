using System;

namespace Dottext.Framework.Components
{
	/// <summary>
	/// Summary description for IBlogID.
	/// </summary>
	public interface IBlogIdentifier
	{
		int BlogID
		{
			get;
			set;
		}


	}
}
