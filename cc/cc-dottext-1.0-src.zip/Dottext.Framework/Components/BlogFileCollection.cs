using System;
using System.Collections;
using System.Collections.ObjectModel;

namespace Dottext.Framework.Components
{
	/// <summary>
	/// BlogFileCollection ��ժҪ˵����
	/// </summary>
	public class BlogFileCollection : Collection<BlogFile>	
	{
	
		public long TotalSize
		{
			get
			{
				return CalTotalSize();
			}

		}

		private long CalTotalSize()
		{
			long total=0;
			foreach(BlogFile file in this)
			{
				total+=file.Size;
			}
			return total;
		}

	}
}
