using System;
using System.Data;
using System.Data.SqlClient;
using Dottext.Framework.Data;
using System.Collections;
using System.Collections.Generic;
using Dottext.Framework.Service;

namespace Dottext.Framework.Components
{
	/// <summary>
	/// 
	/// </summary>
	public class CategoryTree:BuildTree
	{
		protected AbstractComponent rootnode;
		protected CategoryType _cateType=CategoryType.Global;
		protected bool _CateIsActiveOnly=true;
        protected BlogService blogService;

		public CategoryTree(int rootID)
		{
            blogService = CchenSoft.Framework.Config.Configuration.Instance.GetService<BlogService>();
			LinkCategory lc=new LinkCategory();
			lc.CategoryID=rootID;
			lc.Title=Framework.Util.Globals.GetWebConfig("AggregateTitle","CNDottext");
			rootnode=new Composite(null,lc);
			
		}

		public CategoryTree(int rootID,CategoryType cateType,bool ActiveOnly):this(rootID)
		{
			_cateType=cateType;
			_CateIsActiveOnly=ActiveOnly;
		}

		public AbstractComponent Build()
		{
			CreateNode(rootnode);
			return rootnode;
		}

		
		private void CreateNode(AbstractComponent node)
		{
			LinkCategory lc=(LinkCategory)node.GetObject();
            IList<LinkCategory> lcc = blogService.GetCategoriesByParentID(_cateType, lc.CategoryID, _CateIsActiveOnly);
			for(int i=0;i<lcc.Count;i++)
			{
				AbstractComponent childNode=new Composite(node,lcc[i]); 
				node.Add(childNode);
				CreateNode(childNode);
			}
		}
		
		public void Persistent()
		{
            blogService.DeleteLinkCategoryByType(this.rootnode, CategoryType.Global);
		}

		private void Traversal(AbstractComponent node)//�������ǰ�����
		{
			
			Stack  stk = new Stack(); 
			AbstractComponent ctlCurrent = node; // ��ǰ���ʵĿؼ� 
			AbstractComponent ctlParent = null;  // ���ؼ� 
			int index = 0; // ��ǰ�ؼ��Ǹ��ؼ��ĵ�i���ӿؼ� 

			do 
			{ 
				System.Web.HttpContext.Current.Response.Write("hello<br>");
				if(node.GetParent()!=null)
				{
					LinkCategory lc=(LinkCategory)node.GetObject();
                    blogService.CreateLinkCategory(lc);
					
				}
				
				if(ctlCurrent.GoNextChild()) // �����굱ǰ�ؼ������ȷ����ӿؼ� 
				{ 
					stk.Push(index); 
					index = 0; 
					ctlParent = ctlCurrent;  
					ctlCurrent = ctlCurrent.GetChild();
				} 
				else if(ctlParent != null && ctlCurrent.GoNextChild())  // ������һ���ֵܿؼ� 
				{ 
					ctlCurrent = ctlParent.GetChild(); 
				} 
				else  // û���ӿؼ�����һ���ֵܿؼ� 
				{ 
					while(true) 
					{ 
						if(ctlParent == null || ctlParent.Equals(node)) 
						{ 
							ctlCurrent = node; 
							break; 
						} 

						ctlCurrent = ctlParent; 
						ctlParent = (AbstractComponent)ctlCurrent.GetParent(); 
						index = (int)stk.Pop(); 

						if(ctlParent != null && ctlParent.GoNextChild()) 
						{ 
							ctlCurrent = ctlParent.GetChild(); 
							break; 
						} 
					} 
				} 
			}while(!ctlCurrent.Equals(node)); 

		}



		
		
	}
}
