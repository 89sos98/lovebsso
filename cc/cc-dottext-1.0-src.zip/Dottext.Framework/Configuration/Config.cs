using System;
using System.Web;
using System.Configuration;
using Dottext.Framework.Util;
using Dottext.Framework.Service;

namespace Dottext.Framework.Configuration
{
	/// <summary>
	/// Summary description for Config.
	/// </summary>
    public class Config
    {
        private static string rootPath = null;

        public static string RootPath
        {
            get 
            {
                if (rootPath == null)
                {
                    rootPath = ConfigurationManager.AppSettings["BlogRoot"];
                    if (string.IsNullOrEmpty(rootPath))
                        rootPath = "/";
                }
                return rootPath; 
            }
        }

        public static BlogConfigurationSettings Settings
        {
            get
            {
                return ((BlogConfigurationSettings)ConfigurationManager.GetSection("BlogConfigurationSettings"));
            }
        }

        #region SiteBlogConfig

        public static SiteBlogConfig GetSiteBlogConfig(int BlogID)
        {
            SiteBlogConfigCollection scc = GetSiteBlogConfigCollection();
            foreach (SiteBlogConfig sc in scc)
            {
                if (sc.BlogID == BlogID)
                {
                    sc.LastUpdated = DateTime.Now;
                    sc.FullyQualifiedUrl = Util.Globals.GetSiteQualifiedUrl();
                    return sc;
                }
            }
            return null;
        }

        public static SiteBlogConfig GetSiteBlogConfigByCategoryID(int CategoryID)
        {
            SiteBlogConfigCollection scc = GetSiteBlogConfigCollection();
            foreach (SiteBlogConfig sc in scc)
            {
                if (sc.CategoryID == CategoryID)
                {
                    return sc;
                }
            }
            return null;
        }

        public static SiteBlogConfig GetDefaultSiteBlogConfig()
        {
            SiteBlogConfigCollection scc = GetSiteBlogConfigCollection();
            foreach (SiteBlogConfig sc in scc)
            {
                if (sc.IsDefault)
                {
                    return sc;
                }
            }
            return null;
        }

        public static SiteBlogConfigCollection GetSiteBlogConfigCollection()
        {
            string dataFile = System.Web.HttpContext.Current.Server.MapPath(RootPath +  "/SiteBlogConfig.config");
            return (SiteBlogConfigCollection)Util.SerializationHelper.Load(typeof(SiteBlogConfigCollection), dataFile);
        }

        public static void SaveSiteBlogConfigCollection(SiteBlogConfigCollection sbcc)
        {
            string dataFile = System.Web.HttpContext.Current.Server.MapPath(RootPath + "/SiteBlogConfig.config");
            Dottext.Framework.Util.SerializationHelper.Save(sbcc, dataFile);

        }

        public static void RemoveSiteBlogConfigByCategoryID(int CategoryID)
        {
            SiteBlogConfigCollection scc = GetSiteBlogConfigCollection();
            foreach (SiteBlogConfig sc in scc)
            {
                if (sc.CategoryID == CategoryID)
                {
                    scc.Remove(sc);
                    SaveSiteBlogConfigCollection(scc);
                    return;
                }
            }
            return;

        }

        #endregion
    }
}
