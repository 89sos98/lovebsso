using System;
using Dottext.Framework;
using Dottext.Framework.Configuration;

namespace Dottext.Framework.Util
{
	/// <summary>
	/// Summary description for BlogTime.
	/// </summary>
	public class BlogTime
	{
		private BlogTime()
		{

		}

		public static DateTime ConvertToBloggerTime(DateTime dt, int ClientTimeZone)
		{
			return dt.AddHours(FromClientToServerFactor(ClientTimeZone,Config.Settings.ServerTimeZone));
		}

		public static DateTime ConvertToServerTime(DateTime dt, int ClientTimeZone)
		{
			return dt.AddHours(FromServerToClientFactor(ClientTimeZone,Config.Settings.ServerTimeZone));
		}

		public static DateTime CurrentBloggerTime
		{
			get
			{
				return DateTime.Now.AddHours(ClientToServerTimeZoneFactor);
			}
		}

		
		public static int ClientToServerTimeZoneFactor
		{
			get
			{
                return FromClientToServerFactor(BlogContext.Current.Config.TimeZone, Config.Settings.ServerTimeZone);
			}
		}

		public static int FromClientToServerFactor(int Client, int Server)
		{
			return Client - Server;
		}

		public static int FromServerToClientFactor(int Client, int Server)
		{
			return Server - Client;
		}

		public static int ServerToClientTimeZoneFactor
		{
			get
			{
                return FromServerToClientFactor(BlogContext.Current.Config.TimeZone, Config.Settings.ServerTimeZone);
			}
		}
	}
}
