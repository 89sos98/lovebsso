using System;
using System.Web;
using System.Web.Caching;
using Dottext.Framework.Configuration;
using Dottext.Framework.Util;
using Dottext.Framework.Service;

namespace Dottext.Common.Config
{
    /// <summary>
    /// A sample implementation of IConfig. This class will return the BlogConfig found at the current host/application, or the one found
    /// by configuring the Providers Host and Application values.
    /// </summary>
    public class SingleBlogConfig : BaseBlogConfig
    {
        private static readonly object ConfigLock = new object();

        private BlogService blogService;

        public SingleBlogConfig() { }

        public BlogService BlogService
        {
            set { blogService = value; }
        }

        //Part of IConfig
        public override bool IsAggregateSite
        {
            get { return false; }
        }

        //Part of IConfig
        public override BlogConfig GetConfig(HttpContext context)
        {
            BlogConfig config = (BlogConfig)context.Cache[cacheKey];
            if (config == null)
            {
                lock (ConfigLock)
                {
                    config = (BlogConfig)context.Cache[cacheKey];
                    if (config == null)
                    {
                        config = this.LoadSingleConfig(context);

                        this.CacheConfig(context.Cache, config, cacheKey);
                    }
                }
            }
            return config;
        }

        #region LoadSingleConfig
        private BlogConfig LoadSingleConfig(HttpContext context)
        {
            BlogConfig config = blogService.GetConfig();

            BlogConfigurationSettings settings = Dottext.Framework.Configuration.Config.Settings;

            if (settings.UseHost)
            {
                config.FullyQualifiedUrl = "http://." + settings.HostName + config.Host + Dottext.Framework.Configuration.Config.RootPath;
            }
            else
            {
                config.FullyQualifiedUrl = "http://" + config.Host + Dottext.Framework.Configuration.Config.RootPath;
            }

            config.ImagePath = string.Format("{0}images/", Dottext.Framework.Configuration.Config.RootPath);
            config.ImageDirectory = context.Server.MapPath(config.ImagePath);

            return config;
        }
        #endregion

        public override BlogConfig BuildConfig(BlogConfig config, HttpContext context)
        {
            return config;
        }
    }
}
