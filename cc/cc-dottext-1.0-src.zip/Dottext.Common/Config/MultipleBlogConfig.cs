using System;
using System.Web;
using System.Web.Caching;
using System.Text.RegularExpressions;
using Dottext.Framework.Util;
using Dottext.Framework.Configuration;
using Dottext.Framework.Service;

namespace Dottext.Common.Config
{
    /// <summary>
    /// A sample implemtation of a class that implements IConfig for a multiple blog system
    /// </summary>
    public class MultipleBlogConfig : BaseBlogConfig
    {
        private BlogService blogService;

        public MultipleBlogConfig() { }

        public BlogService BlogService
        {
            set { blogService = value; }
        }

        //part of IConfig
        public override bool IsAggregateSite
        {
            get { return true; }
        }


        /// <summary>
        /// Override abstract GetConfig() (also part of IConfig). Returns a BlogConfig instance for the current blog. 
        /// The object first checks the context for an existing object. It will next check the cache.
        /// </summary>
        /// <returns></returns>
        public override BlogConfig GetConfig(HttpContext context)
        {
            //First check the context for an existing BlogConfig. This saves us the trouble of having to figure out which blog we are at.

            BlogConfig config = (BlogConfig)context.Items[cacheKey];

            if (config == null)
            {
                string requestPath = context.Request.Path.ToLower();
                string blogroot = Dottext.Framework.Configuration.Config.RootPath.ToLower();
                if (requestPath.StartsWith(blogroot))
                    requestPath = requestPath.Substring(blogroot.Length).TrimStart('/');
                string[] strs = requestPath.Split('/');
                string appName = "";
                if (strs.Length > 0)
                {
                    if (strs.Length > 1 || !strs[0].EndsWith(".aspx"))
                        appName = strs[0];
                }

                //BlogConfig was not found in the context. It could be in the current cache.
                string mCacheKey = cacheKey + appName;

                if (appName == "" || appName == "comments")
                {
                    if (context.Request.QueryString["id"] != null)
                    {
                        mCacheKey += "id:" + context.Request.QueryString["id"];
                    }
                }

                config = (BlogConfig)context.Cache[mCacheKey];

                if (config == null)
                {
                    Host = GetCurrentHost(context.Request);

                    config = BuildConfig(Host, appName, context);
                    if (config == null)
                    {
                        return null;
                    }

                    CacheConfig(context.Cache, config, mCacheKey);
                    context.Items.Add(cacheKey, config);
                }
                else
                {
                    context.Items.Add(cacheKey, config);
                }
            }
            //Dottext.Framework.Logger.LogManager.Log(context.Request.RawUrl,config.BlogID.ToString());
            return config;
        }

        /*public override BlogConfig GetConfigByApp(HttpContext context,string app)
        {
            Host = GetCurrentHost(context.Request);
            config = BuildConfig(Host,app,context);
            return config;
        }*/

        protected virtual BlogConfig BuildConfig(string host, string appName, HttpContext context)
        {
            BlogConfig config = null;

            if (appName != "" && appName != "comments" && appName != "manage")
            {
                config = blogService.GetConfig(host, appName);
            }

            if (config == null)
            {
                string cateid = context.Request.QueryString["cateid"];
                if (string.IsNullOrEmpty(cateid))
                {
                    config = Dottext.Framework.Configuration.Config.GetDefaultSiteBlogConfig();
                }
                else
                {
                    config = Dottext.Framework.Configuration.Config.GetSiteBlogConfigByCategoryID(int.Parse(cateid));
                }
            }

            BlogConfigurationSettings settings = Dottext.Framework.Configuration.Config.Settings;

            //string app = Dottext.Framework.Configuration.Config.RootPath + config.Application;

            string formattedHost = settings.AggregateUrl;//GetFomrattedHost(host,settings.UseHost,settings.HostName);

            config.FullyQualifiedUrl = formattedHost + config.Application;

            //if (!app.EndsWith("/"))
            //{
            //    app += "/";
            //}

            string imagehost = host;
            if (imagehost.IndexOf(":") > 0)
            {
                imagehost = imagehost.Substring(0, imagehost.IndexOf(":"));
            }
            string virtualPath = string.Format("images/{0}/{1}/", Regex.Replace(imagehost, @"\.", "_"), appName);
            config.ImagePath = string.Format("{0}{1}", formattedHost, virtualPath);
            config.ImageDirectory = context.Server.MapPath(Dottext.Framework.Configuration.Config.RootPath + virtualPath);

            return config;
        }

        public override BlogConfig BuildConfig(BlogConfig config, HttpContext context)
        {
            BlogConfigurationSettings settings = Dottext.Framework.Configuration.Config.Settings;

            //string appPath = Globals.FormatApplicationPath(string.Format("{0}/{1}",app,config.Application));

            string formattedHost = Dottext.Framework.Configuration.Config.Settings.AggregateUrl;//GetFomrattedHost(config.Host,settings.UseHost,settings.HostName);

            config.FullyQualifiedUrl = formattedHost + config.Application;//Globals.GetAppUrl(context.Request)+config.Application.Remove(0,1);//formattedHost + appPath;

            //string app = Dottext.Framework.Configuration.Config.RootPath + config.Application;
            //if (!app.EndsWith("/"))
            //{
            //    app += "/";
            //}

            string imagehost = formattedHost;
            if (imagehost.IndexOf(":") > 0)
            {
                imagehost = imagehost.Substring(0, imagehost.IndexOf(":"));
            }
            string virtualPath = string.Format("images/{0}/{1}/", Regex.Replace(imagehost, @"\.", "_"), config.CleanApplication);
            config.ImagePath = string.Format("{0}{1}", formattedHost, virtualPath);
            config.ImageDirectory = context.Server.MapPath(Dottext.Framework.Configuration.Config.RootPath + virtualPath);

            return config;
        }
    }
}
