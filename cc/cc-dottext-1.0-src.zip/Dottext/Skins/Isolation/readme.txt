Isolation Skin for .Text
------------------------

Use:
1. Unzip contents (using folder names) to <.Textroot>/Skins.
2. Add the following line after the opening "<skin>" tag in <.Textroot>/Admin/Skins.config to register the new skin with .Text:
	<SkinTemplate SkinID = "isolation" Skin = "Isolation" />
2. Select Isolation skin in .Text Admin | Configure settings page.
3. Enjoy!

see sagetechnology.com for more .Text enhancements & other items or to make a donation