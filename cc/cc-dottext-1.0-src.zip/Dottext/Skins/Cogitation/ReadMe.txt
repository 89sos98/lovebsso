.Text Cogitation Skin
by Mark Wagner
http://blogs.crsw.com/mark


1) Extract the contents of the Cogitation.zip file into a folder named "DotTextWeb/Skins/Cogitation".


2) Add the following line of code to the Skins.config file located in the DotTextWeb/Admin folder.

   <SkinTemplate SkinID = "Cogitation" Skin="Cogitation" />