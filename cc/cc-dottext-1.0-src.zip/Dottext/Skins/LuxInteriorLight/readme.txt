Luxinterior Light Skin for .Text 0.95
Version 1.0

Copyright (c) 2004 Jaxon Rice. All rights reserved.

Install and customisation instructions can be found at:
http://mixtaper.com/blogs/gosatango/articles/221.aspx

1) Extract the contents of the luxlight.zip file into a folder named "DotTextWeb/Skins/luxinteriorlight/".


2) Add the following line of code to the Skins.config file located in the DotTextWeb/Admin folder.

   <SkinTemplate SkinID = "LuxInteriorLight" Skin="luxinteriorlight" />

Redistribution, with or without modification, are permitted provided
that this license and disclaimer is retained:

THIS DISTRIBUTION IS PROVIDED BY THE ABOVE AUTHOR(S) "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
NON-INFRINGEMENT, ARE DISCLAIMED.  IN NO EVENT SHALL THE ABOVE AUTHOR(S)
BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS DISTRIBUTION, EVEN IF ADVISED
OF THE POSSIBILITY OF SUCH DAMAGE.