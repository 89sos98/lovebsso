To install any of these skins, just unzip them and copy the folder in the zip file (named the same as the skin) 
to the \Skins directory of your .Text blog.  Then, edit the skins.config file in the \Admin directory of 
your .Text blog and add the following line to the list of configured skins:  

<SkinTemplate SkinID = "skinname" Skin = "skinname" />.  

Replace skinname with the name of the skin you�re installing � MTClean, MTTrendy, MTGABlue or MTRusty.  
Once you�ve installed the skin, you can then go into the .Text administration tool and change the blog skin 
under Options-Configure.  If you have problems or questions, email me at bob@roudybob.net.