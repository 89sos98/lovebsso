#region Disclaimer/Info
///////////////////////////////////////////////////////////////////////////////////////////////////
// .Text WebLog
// 
// .Text is an open source weblog system started by Scott Watermasysk. 
// Blog: http://ScottWater.com/blog 
// RSS: http://scottwater.com/blog/rss.aspx
// Email: Dottext@ScottWater.com
//
// For updated news and information please visit http://scottwater.com/dottext and subscribe to 
// the Rss feed @ http://scottwater.com/dottext/rss.aspx
//
// On its release (on or about August 1, 2003) this application is licensed under the BSD. However, I reserve the 
// right to change or modify this at any time. The most recent and up to date license can always be fount at:
// http://ScottWater.com/License.txt
// 
// Please direct all code related questions to:
// GotDotNet Workspace: http://www.gotdotnet.com/Community/Workspaces/workspace.aspx?id=e99fccb3-1a8c-42b5-90ee-348f6b77c407
// Yahoo Group http://groups.yahoo.com/group/DotText/
// 
///////////////////////////////////////////////////////////////////////////////////////////////////
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Dottext.Framework;
using Dottext.Framework.Configuration;
using CchenSoft.Framework.Attributes;

namespace Dottext.Web.Admin.Pages
{
	/// <summary>
	/// Summary description for _default.
	/// </summary>
	public partial class HomePageDefault : AdminPage
	{
        [Bean("Config")]
        protected IConfig iconfig;

		private void Page_Load(object sender, System.EventArgs e)
		{
            string path = iconfig.IsAggregateSite ? BlogContext.Current.Config.FullyQualifiedUrl : Config.RootPath;
            Response.Redirect(path + "admin/EditPosts.aspx");
		}

	}
}

