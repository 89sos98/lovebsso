#region Disclaimer/Info
///////////////////////////////////////////////////////////////////////////////////////////////////
// .Text WebLog
// 
// .Text is an open source weblog system started by Scott Watermasysk. 
// Blog: http://ScottWater.com/blog 
// RSS: http://scottwater.com/blog/rss.aspx
// Email: Dottext@ScottWater.com
//
// For updated news and information please visit http://scottwater.com/dottext and subscribe to 
// the Rss feed @ http://scottwater.com/dottext/rss.aspx
//
// On its release (on or about August 1, 2003) this application is licensed under the BSD. However, I reserve the 
// right to change or modify this at any time. The most recent and up to date license can always be fount at:
// http://ScottWater.com/License.txt
// 
// Please direct all code related questions to:
// GotDotNet Workspace: http://www.gotdotnet.com/Community/Workspaces/workspace.aspx?id=e99fccb3-1a8c-42b5-90ee-348f6b77c407
// Yahoo Group http://groups.yahoo.com/group/DotText/
// 
///////////////////////////////////////////////////////////////////////////////////////////////////
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using Dottext.Framework;
using Dottext.Framework.Components;
using Dottext.Framework.Util;
using System.Collections.Generic;


namespace Dottext.Web.Admin.Pages
{
	public partial class EditImage : AdminPage
	{
		protected const string VSKEY_IMAGEID = "ImageID";
		protected int _imageID;
		protected Dottext.Framework.Components.Image _image;
		protected string _galleryTitle;

		#region Accessors
		private int ImageID
		{
			get { return (int)ViewState[VSKEY_IMAGEID]; }
			set { ViewState[VSKEY_IMAGEID] = value; }
		}

		public Dottext.Framework.Components.Image Image
		{
			get 
			{
				if (null != _image)
					return _image;
				else
					throw new Exception("Image not defined.");
			}
		}

		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
			{
				if (null != Request.QueryString[Keys.QRYSTR_IMAGEID])
					ImageID = Convert.ToInt32(Request.QueryString[Keys.QRYSTR_IMAGEID]);

				BindImage();
			}
		}

		private void BindImage()
		{
			BindImage(this.ImageID);
		}

		private void BindImage(int imageID)
		{
			if (Constants.NULL_IMAGEID != imageID)
			{
                IList<LinkCategory> selectionList = blogService.GetCategoriesByType(CategoryType.ImageCollection, false);
				if (selectionList.Count > 0)
				{
					ddlGalleries.DataSource = selectionList;
					ddlGalleries.DataValueField = "CategoryID";
					ddlGalleries.DataTextField = "Title";

                    _image = blogService.GetSingleImage(imageID, false);
					lnkThumbnail.ImageUrl = EvalImageUrl(_image);
					lnkThumbnail.NavigateUrl = EvalImageNavigateUrl(_image);
					lnkThumbnail.Visible = true;

					ckbPublished.Checked = _image.IsActive;

					SetGalleryInfo(_image);

					Page.DataBind();

					ddlGalleries.Items.FindByValue(_image.CategoryID.ToString()).Selected = true;
					// HACK: we're disabling this until we do something with/around the provider
					// that will let us actually move the files too.
					ddlGalleries.Enabled = false;

					Advanced.Collapsed = Preferences.AlwaysExpandAdvanced;

					Control container = Page.FindControl("PageContainer");
					if (null != container && container is Dottext.Web.Admin.WebUI.Page)
					{	
						Dottext.Web.Admin.WebUI.Page page = (Dottext.Web.Admin.WebUI.Page)container;
						string title = String.Format("Editing Image \"{0}\"", _image.Title);

						page.BreadCrumbs.AddLastItem(title);
						page.Title = title;
					}
				}
				else
				{
					ImageDetails.Visible = false;
					this.Messages.ShowError("You must have at least one valid Gallery before working with individual images.");
				}
			}
			else
			{	
				ImageDetails.Visible = false;
				this.Messages.ShowError("An image identifier was not available, could not load your image.");
			}
		}

		protected void SetGalleryInfo(Dottext.Framework.Components.Image image)
		{
            _galleryTitle = blogService.GetLinkCategory(image.CategoryID, false).Title;
		}

		protected string EvalImageUrl(object imageObject)
		{
			if (imageObject is Dottext.Framework.Components.Image)
			{
				Dottext.Framework.Components.Image image = (Dottext.Framework.Components.Image)imageObject;
                return String.Format("{0}{1}", blogService.HttpGalleryFilePath(Context, image.CategoryID), 
					image.ThumbNailFile);
			}
			else
				return String.Empty;
		}

		protected string EvalImageNavigateUrl(object imageObject)
		{
			if (imageObject is Dottext.Framework.Components.Image)
			{
				Dottext.Framework.Components.Image image = (Dottext.Framework.Components.Image)imageObject;
                return BlogContext.Current.Config.UrlFormats.ImageUrl(null, image.ImageID);
			}
			else
				return String.Empty;
		}

		protected string GetImageGalleryUrl()
		{
			return String.Format("{0}?{1}={2}", Constants.URL_EDITGALLERIES, 
				Keys.QRYSTR_CATEGORYID, Image.CategoryID);
		}

		private void UpdateImage()
		{
			if (Page.IsValid)
			{
                _image = blogService.GetSingleImage(ImageID, false);
				_image.CategoryID = Convert.ToInt32(ddlGalleries.SelectedItem.Value);
				_image.Title = txbTitle.Text;
				_image.IsActive = ckbPublished.Checked;
				
				try
				{
                    blogService.UpdateImage(_image);

					// would need to also move files for this to work here. should happen
					// in the provider though.

					this.Messages.ShowMessage("The image was successfully updated.");
					BindImage();
				}
				catch(Exception ex)
				{
					this.Messages.ShowError(String.Format(Constants.RES_EXCEPTION, "TODO...", ex.Message));
				}
			}
		}

		private void ReplaceImage()
		{
			if (Page.IsValid)
			{
                _image = blogService.GetSingleImage(ImageID, false);
				_image.CategoryID = Convert.ToInt32(ddlGalleries.SelectedItem.Value);
				_image.Title = txbTitle.Text;
				_image.IsActive = ckbPublished.Checked;
				
				try
				{
                    _image.File = blogService.GetFileName(ImageFile.PostedFile.FileName);
                    _image.LocalFilePath = blogService.LocalGalleryFilePath(Context, _image.CategoryID);
                    blogService.Update(_image, blogService.GetFileStream(ImageFile.PostedFile));				

					this.Messages.ShowMessage("The image was successfully updated.");
					BindImage();
				}
				catch (Exception ex)
				{
					this.Messages.ShowError(String.Format(Constants.RES_EXCEPTION, "TODO...", ex.Message));
				}
			}
		}

		private void ConfirmDeleteImage(int imageID)
		{
			(Page as AdminPage).Command = new DeleteImageCommand(imageID);
			(Page as AdminPage).Command.RedirectUrl = Request.Url.ToString();
			Server.Transfer(Constants.URL_CONFIRM);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			ViewState[VSKEY_IMAGEID] = Constants.NULL_IMAGEID;
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.lkbUpdateImage.Click += new System.EventHandler(this.lkbUpdateImage_Click);
			this.lbkAddImage.Click += new System.EventHandler(this.lbkReplaceImage_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void lbkReplaceImage_Click(object sender, System.EventArgs e)
		{
			ReplaceImage();
		}

		private void lkbUpdateImage_Click(object sender, System.EventArgs e)
		{
			UpdateImage();		
		}
	}
}

