#region Disclaimer/Info
///////////////////////////////////////////////////////////////////////////////////////////////////
// .Text WebLog
// 
// .Text is an open source weblog system started by Scott Watermasysk. 
// Blog: http://ScottWater.com/blog 
// RSS: http://scottwater.com/blog/rss.aspx
// Email: Dottext@ScottWater.com
//
// For updated news and information please visit http://scottwater.com/dottext and subscribe to 
// the Rss feed @ http://scottwater.com/dottext/rss.aspx
//
// On its release (on or about August 1, 2003) this application is licensed under the BSD. However, I reserve the 
// right to change or modify this at any time. The most recent and up to date license can always be fount at:
// http://ScottWater.com/License.txt
// 
// Please direct all code related questions to:
// GotDotNet Workspace: http://www.gotdotnet.com/Community/Workspaces/workspace.aspx?id=e99fccb3-1a8c-42b5-90ee-348f6b77c407
// Yahoo Group http://groups.yahoo.com/group/DotText/
// 
///////////////////////////////////////////////////////////////////////////////////////////////////
#endregion
using System;
using System.Collections;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Text.RegularExpressions;

using Dottext.Framework;
using Dottext.Framework.Util;
using Dottext.Framework.Components;
using Dottext.Framework.Configuration;

using Dottext.Web.Admin;
using Dottext.Web.Admin.Pages;
using Dottext.Web.Admin.WebUI;
using System.Collections.Generic;
using Dottext.Web.UI.Controls;

namespace Dottext.Web.Admin.UserControls
{
    public partial class EntryFCKEditor : BaseControl
    {
        private const string VSKEY_POSTID = "PostID";
        private const string VSKEY_CATEGORYID = "CategoryID";
        private const string VSKEY_CATEGORYTYPE = "CategoryType";

        private int _filterCategoryID = Constants.NULL_CATEGORYID;
        private int _resultsPageNumber = 1;
        private PostType _entryType = PostType.BlogPost;
        private bool _isListHidden = false;

        protected System.Web.UI.WebControls.Button Post;
        protected System.Web.UI.WebControls.TextBox Textbox1;
        protected System.Web.UI.WebControls.TextBox Textbox2;

        protected System.Web.UI.WebControls.LinkButton lkbPriview;
        protected System.Web.UI.WebControls.RequiredFieldValidator valtbBodyRequired;
        protected System.Web.UI.WebControls.LinkButton lkbNewPost;

        #region Accessors
        // REFACTOR: are all of these still relevant when done?
        public PostType EntryType
        {
            get { return _entryType; }
            set { _entryType = value; }
        }

        public int PostID
        {
            get
            {
                if (ViewState[VSKEY_POSTID] != null)
                    return (int)ViewState[VSKEY_POSTID];
                else
                    return Constants.NULL_POSTID;
            }
            set { ViewState[VSKEY_POSTID] = value; }
        }

        private int CategoryID
        {
            get
            {
                if (ViewState[VSKEY_CATEGORYID] != null)
                    return (int)ViewState[VSKEY_CATEGORYID];
                else
                    return Constants.NULL_CATEGORYID;
            }
            set { ViewState[VSKEY_CATEGORYID] = value; }
        }

        public CategoryType CategoryType
        {
            get
            {
                if (ViewState[VSKEY_CATEGORYTYPE] != null)
                    return (CategoryType)ViewState[VSKEY_CATEGORYTYPE];
                else
                    throw new ApplicationException("CategoryType was not set");
            }
            set
            {
                ViewState[VSKEY_CATEGORYTYPE] = value;
            }
        }

        public bool IsListHidden
        {
            get { return _isListHidden; }
            set { _isListHidden = value; }
        }

        public string ResultsTitle
        {
            get
            {
                return Results.HeaderText;
            }
            set
            {
                Results.HeaderText = value;
            }
        }

        public string ResultsUrlFormat
        {
            set
            {
                this.ResultsPager.UrlFormat = value;
            }
        }

        #endregion

        private void Page_Load(object sender, System.EventArgs e)
        {
            if (!IsPostBack)
            {
                if (null != Request.QueryString[Keys.QRYSTR_PAGEINDEX])
                    _resultsPageNumber = Convert.ToInt32(Request.QueryString[Keys.QRYSTR_PAGEINDEX]);

                if (null != Request.QueryString[Keys.QRYSTR_CATEGORYID])
                    _filterCategoryID = Convert.ToInt32(Request.QueryString[Keys.QRYSTR_CATEGORYID]);

                ResultsPager.PageSize = Preferences.ListingItemCount;
                ResultsPager.PageIndex = _resultsPageNumber;
                Results.Collapsible = false;

                if (Constants.NULL_CATEGORYID != _filterCategoryID)
                    ResultsPager.UrlFormat += String.Format("&{0}={1}",
                        Keys.QRYSTR_CATEGORYID, _filterCategoryID);

                BindList();
                BindCategoryList();
                SetEditorMode();
                if (Request.QueryString["opt"] == "1" || Request.QueryString["opt"] == "2" || Request.QueryString["opt"] == "3")
                {
                    EditNewEntry();
                }
                if (Request.QueryString["postid"] != null)
                {
                    PostID = Convert.ToInt32(Request.QueryString["postid"]);
                    BindPostEdit();
                }

                fckBody.BasePath = Config.RootPath + "fckeditor/";
            }


        }

        private void BindList()
        {
            Edit.Visible = false;

            PagedEntryQuery query = new PagedEntryQuery();
            query.PostType = _entryType;
            query.CategoryID = _filterCategoryID;
            query.PageIndex = _resultsPageNumber;
            query.PageSize = ResultsPager.PageSize;
            query.PostConfig = PostConfig.Empty;

            PagedList<Entry> selectionList = blogService.GetPagedEntryCollection(query);


            //			PagedEntryCollection selectionList = Entries.GetPagedEntries(_entryType, _filterCategoryID, 
            //				_resultsPageNumber, ResultsPager.PageSize,true);		

            if (selectionList.Count > 0)
            {
                ResultsPager.ItemCount = selectionList.MaxItems;
                rprSelectionList.DataSource = selectionList;
                rprSelectionList.DataBind();
                NoMessagesLabel.Visible = false;
            }

            NoMessagesLabel.Visible = selectionList.Count <= 0;
            ResultsPager.Visible = selectionList.Count > 0;

        }

        private void BindCategoryList()
        {
            cklCategories.DataSource = blogService.GetCategoriesByType(CategoryType, false);
            cklCategories.DataValueField = "CategoryID";
            cklCategories.DataTextField = "Title";
            cklCategories.DataBind();
            IList<LinkCategory> lcc = blogService.GetCategoriesByType(-1, Dottext.Framework.Components.CategoryType.Global, true);
            //lcc.RemoveNumericFromTitle();
            cklGroups.DataSource = lcc;
            cklGroups.DataValueField = "CategoryID";
            cklGroups.DataTextField = "Title";
            cklGroups.DataBind();
            //cklGroups.Items.FindByText("�Ǽ�����").Selected=true;
        }

        private void SetConfirmation()
        {
            ConfirmationPage confirmPage = (ConfirmationPage)this.Page;
            confirmPage.IsInEdit = true;
            confirmPage.Message = "You will lose any unsaved content";

            this.lkbPost.Attributes.Add("OnClick", ConfirmationPage.ByPassFuncationName);
            this.lkbCancel.Attributes.Add("OnClick", ConfirmationPage.ByPassFuncationName);
            this.LkbPreview.Attributes.Add("OnClick", ConfirmationPage.ByPassFuncationName);
        }

        private void BindPostEdit()
        {

            SetConfirmation();

            Entry currentPost = blogService.GetEntry(PostID, PostConfig.Empty);

            if (currentPost == null)
            {
                return;
            }
            if (currentPost.BlogID != BlogContext.Current.Config.BlogID)
            {
                return;
            }

            Results.Collapsed = true;
            Edit.Visible = true;
            txbTitle.Text = currentPost.Title;

            txbExcerpt.Text = currentPost.Description;
            txbSourceUrl.Text = currentPost.SourceUrl;
            txbSourceName.Text = currentPost.SourceName;

            hlEntryLink.NavigateUrl = currentPost.Link;
            hlEntryLink.Text = currentPost.Link;
            hlEntryLink.Attributes.Add("title", "view: " + currentPost.Title);
            hlEntryLink.Visible = true;

            chkComments.Checked = currentPost.AllowComments;
            chkDisplayHomePage.Checked = currentPost.DisplayOnHomePage;
            chkMainSyndication.Checked = currentPost.IncludeInMainSyndication;
            chkSyndicateDescriptionOnly.Checked = currentPost.SyndicateDescriptionOnly;
            chkIsAggregated.Checked = currentPost.IsAggregated;
            chkUpdateCreatedTime.Visible = true;

            if (currentPost.PostType == PostType.BlogPost)
            {
                chkIsMoveTo.Text = "Move to Article";
                chkIsMoveTo.Visible = true;
            }
            else if (currentPost.PostType == PostType.Article)
            {
                chkIsMoveTo.Text = "Move to Post";
                chkIsMoveTo.Visible = true;
            }
            else
            {
                chkIsMoveTo.Visible = false;
            }


            SetEditorText(currentPost.Body);
            ckbPublished.Checked = currentPost.IsActive;

            for (int i = 0; i < cklCategories.Items.Count; i++)
                cklCategories.Items[i].Selected = false;
            for (int i = 0; i < cklGroups.Items.Count; i++)
                cklGroups.Items[i].Selected = false;

            LinkCollection postCategories = blogService.GetLinkCollectionByPostID(PostID);

            if (postCategories.Count > 0)
            {
                for (int i = 0; i < postCategories.Count; i++)
                {
                    try
                    {
                        cklCategories.Items.FindByValue(postCategories[i].CategoryID.ToString()).Selected = true;

                    }
                    catch { }
                }
            }
            if (postCategories.Count > 0)
            {
                for (int i = 0; i < postCategories.Count; i++)
                {
                    try
                    {
                        cklGroups.Items.FindByValue(postCategories[i].CategoryID.ToString()).Selected = true;

                    }
                    catch
                    {

                    }
                }
            }
            /*if(cklGroups.SelectedIndex<0)
            {
                cklGroups.Items.FindByText("�Ǽ�����").Selected=true;
            }
            */
            SetEditorMode();
            Results.Collapsible = true;
            Advanced.Collapsed = !Preferences.AlwaysExpandAdvanced;

            Control container = Page.FindControl("PageContainer");
            if (null != container && container is Dottext.Web.Admin.WebUI.Page)
            {
                Dottext.Web.Admin.WebUI.Page page = (Dottext.Web.Admin.WebUI.Page)container;
                string title = String.Format("Editing {0} \"{1}\"",
                    CategoryType == CategoryType.StoryCollection ? "Article" : "Post", currentPost.Title);

                page.BreadCrumbs.AddLastItem(title);
                page.Title = title;
            }

            if (currentPost.HasEntryName)
            {
                this.Advanced.Collapsed = false;
                txbEntryName.Text = currentPost.EntryName;
            }
        }

        public void EditNewEntry()
        {
            ResetPostEdit(true);
            SetConfirmation();
        }

        private void ResetPostEdit(bool showEdit)
        {

            PostID = Constants.NULL_POSTID;

            Results.Collapsible = showEdit;
            Results.Collapsed = showEdit;
            Edit.Visible = showEdit;

            hlEntryLink.NavigateUrl = String.Empty;
            hlEntryLink.Attributes.Clear();
            hlEntryLink.Visible = false;
            txbTitle.Text = String.Empty;
            txbExcerpt.Text = String.Empty;
            txbSourceUrl.Text = String.Empty;
            txbSourceName.Text = String.Empty;
            txbEntryName.Text = string.Empty;

            ckbPublished.Checked = Preferences.AlwaysCreateIsActive;
            chkComments.Checked = true;
            chkDisplayHomePage.Checked = true;
            chkMainSyndication.Checked = true;
            chkSyndicateDescriptionOnly.Checked = false;
            chkIsAggregated.Checked = true;//false;
            chkIsMoveTo.Checked = false;
            chkUpdateCreatedTime.Checked = false;
            chkUpdateCreatedTime.Visible = false;


            fckBody.Value = String.Empty;
            //txbBody.Text = String.Empty;
            /*if(Request.Cookies["tempsave"]!=null)
            {
                ftbBody.Text =Server.UrlDecode(Request.Cookies["tempsave"].Value);
            }*/

            /*this.BodyPreview.Text="";
            this.BodyPreview.Visible=false;
            this.LkbPreview.Text="PREVIEW";*/

            for (int i = 0; i < cklCategories.Items.Count; i++)
                cklCategories.Items[i].Selected = false;
            for (int i = 0; i < cklGroups.Items.Count; i++)
                cklGroups.Items[i].Selected = false;
            //cklGroups.Items.FindByText("�Ǽ�����").Selected=true;

            Advanced.Collapsed = !Preferences.AlwaysExpandAdvanced;

            SetEditorMode();
        }

        private void UpdatePost()
        {
            if (Page.IsValid)
            {
                string successMessage = Constants.RES_SUCCESSNEW;
                try
                {
                    Entry entry = new Entry(EntryType);

                    entry.Title = txbTitle.Text;
                    entry.Body = Globals.StripRTB(fckBody.Value, Request.Url.Host);
                    //Response.Write(entry.Body);
                    entry.IsActive = ckbPublished.Checked;
                    entry.SourceName = txbSourceName.Text;
                    entry.Author = BlogContext.Current.Config.Author;
                    entry.Email = BlogContext.Current.Config.Email;
                    entry.SourceUrl = txbSourceUrl.Text;
                    entry.Description = txbExcerpt.Text;
                    entry.TitleUrl = txbTitleUrl.Text;


                    entry.AllowComments = chkComments.Checked;
                    entry.DisplayOnHomePage = chkDisplayHomePage.Checked;
                    entry.IncludeInMainSyndication = chkMainSyndication.Checked;
                    entry.SyndicateDescriptionOnly = chkSyndicateDescriptionOnly.Checked;
                    entry.IsAggregated = chkIsAggregated.Checked;
                    entry.EntryName = txbEntryName.Text;

                    entry.BlogID = BlogContext.Current.Config.BlogID;

                    if (PostID > 0)
                    {
                        successMessage = Constants.RES_SUCCESSEDIT;
                        entry.DateUpdated = DateTime.Now;//BlogTime.CurrentBloggerTime;


                        entry.EntryID = PostID;
                        entry.Link = BlogContext.Current.Config.UrlFormats.EntryUrl(entry);
                        if (chkIsMoveTo.Checked)
                        {
                            entry.PostType = entry.PostType ^ ((PostType)3);

                        }
                        blogService.Update(entry);

                        //Add by dudu
                        if (Request.QueryString["pg"] != null)
                        {
                            _resultsPageNumber = int.Parse(Request.QueryString["pg"]);
                        }

                        if (null != Request.QueryString[Keys.QRYSTR_CATEGORYID])
                            _filterCategoryID = Convert.ToInt32(Request.QueryString[Keys.QRYSTR_CATEGORYID]);
                    }
                    else
                    {
                        entry.DateCreated = DateTime.Now;//BlogTime.CurrentBloggerTime;
                        PostID = blogService.Create(entry);
                    }

                    if (PostID > 0)
                    {
                        //LinkCollection lc = new LinkCollection();
                        ArrayList al = new ArrayList();
                        int count = cklCategories.Items.Count;
                        if (chkIsMoveTo.Checked)
                        {
                            count = 0;
                        }
                        //���·���
                        for (int i = 0; i < count; i++)
                        {
                            if (cklCategories.Items[i].Selected)
                            {
                                al.Add(Int32.Parse(cklCategories.Items[i].Value));
                            }
                        }
                        //��վ����
                        if (CategoryType == CategoryType.PostCollection)
                        {
                            count = cklGroups.Items.Count;
                            for (int i = 0; i < count; i++)
                            {
                                if (cklGroups.Items[i].Selected)
                                {
                                    al.Add(Int32.Parse(cklGroups.Items[i].Value));
                                }
                            }
                        }

                        int[] Categories = (int[])al.ToArray(typeof(int));
                        blogService.SetEntryCategoryList(PostID, Categories);

                        //this.Page.RegisterClientScriptBlock("TempSaveClear",@"<script>ClearTemp();</script>");
                        BindList();
                        this.Messages.ShowMessage(successMessage);
                        this.ResetPostEdit(false);
                    }
                    else
                        this.Messages.ShowError(Constants.RES_FAILUREEDIT
                            + " There was a baseline problem posting your entry.");
                }
                catch (Exception ex)
                {
                    this.Messages.ShowError(String.Format(Constants.RES_EXCEPTION,
                        Constants.RES_FAILUREEDIT, ex.Message));
                }
                finally
                {
                    Results.Collapsible = false;
                }
            }
        }

        private void SetEditorMode()
        {
            //valftbBodyRequired.Visible = ftbBody.Visible = Utilities.CheckIsIE55();
            //valtbBodyRequired.Visible = txbBody.Visible = !ftbBody.Visible;

            if (CategoryType == CategoryType.StoryCollection)
            {
                this.chkDisplayHomePage.Visible = false;
                this.chkIsAggregated.Visible = false;
                this.chkMainSyndication.Visible = false;
                this.chkSyndicateDescriptionOnly.Visible = false;
                this.cklGroups.Visible = false;
                this.literalGroup.Visible = false;
                this.LiteralOptions.Visible = false;

            }

        }

        private void SetEditorText(string bodyValue)
        {

            fckBody.Value = bodyValue;

        }

        private void ConfirmDelete(int postID)
        {
            (Page as AdminPage).Command = new DeletePostCommand(postID);
            (Page as AdminPage).Command.RedirectUrl = Request.Url.ToString();
            (Page as AdminPage).Command.TabSectionID = ((Dottext.Web.Admin.WebUI.Page)this.Parent.Page.FindControl("PageContainer")).TabSectionID;
            Server.Transfer(Constants.URL_CONFIRM);
        }

        public string CheckHiddenStyle()
        {
            if (_isListHidden)
                return Constants.CSSSTYLE_HIDDEN;
            else
                return String.Empty;
        }

        protected void lkbCancel_Click(object sender, System.EventArgs e)
        {
            ResetPostEdit(false);
        }

        protected void lkbPost_Click(object sender, System.EventArgs e)
        {
            UpdatePost();
        }

        protected void lkbNewPost_Click(object sender, System.EventArgs e)
        {
            ResetPostEdit(true);
        }

        protected void LkbPreview_Click(object sender, System.EventArgs e)
        {
            //ConfirmationPage confirmPage = (ConfirmationPage)this.Page;
            //confirmPage.IsInEdit = false;
            Entry entry = new Entry();
            entry.Title = txbTitle.Text;
            entry.Body = this.fckBody.Value;
            Context.Cache.Insert("PreviewPost", entry);
            System.Web.UI.Page thisPage = this.Page;
            //string url=Config.CurrentBlog().FullyQualifiedUrl+"PreviewPost.aspx";
            Dottext.Framework.Util.Globals.ShowModalDialog(ref thisPage, "PreviewPost.aspx", "800", "600");
            SetConfirmation();
        }

        protected void rprSelectionList_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
        {
            switch (e.CommandName.ToLower())
            {
                case "edit":
                    PostID = Convert.ToInt32(e.CommandArgument);
                    BindPostEdit();
                    break;
                case "delete":
                    ConfirmDelete(Convert.ToInt32(e.CommandArgument));
                    break;
                default:
                    break;
            }
        }
    }
}

