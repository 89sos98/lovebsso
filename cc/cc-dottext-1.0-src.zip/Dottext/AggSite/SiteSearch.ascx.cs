namespace Dottext.Web.AggSite
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		SiteSearch ��ժҪ˵����
	/// </summary>
	public partial class SiteSearch : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.TextBox tbSearch;
		protected System.Web.UI.WebControls.Button ButtonSearch;
		

		private void Page_Load(object sender, System.EventArgs e)
		{
			// �ڴ˴������û������Գ�ʼ��ҳ��
		}

		
	}
}
