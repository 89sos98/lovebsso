namespace Dottext.Web.AggSite
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using Dottext.Framework;
	using Dottext.Framework.Components;
    using System.Collections.Generic;
    using Dottext.Web.UI.Controls;

	/// <summary>
	///		PickedCategory ��ժҪ˵����
	/// </summary>
	public partial class PickedCategory : BaseControl
	{
        private void Page_Load(object sender, System.EventArgs e)
        {
            IList<LinkCategory> lcc = blogService.GetCategoriesByType(-1, CategoryType.Picked, false);
            LinkList.DataSource = lcc;
            LinkList.DataBind();
        }

		protected string GetTitle(string title,string cateid)
		{
			if(cateid!=null&&cateid!="")
			{
				return title+"("+GetRowsCount(int.Parse(cateid))+")";
			}
			return title;
		}

        private int GetRowsCount(int cateid)
        {
            EntryQuery query = new EntryQuery();
            query.PostType = PostType.BlogPost | PostType.Article;
            query.PostConfig = PostConfig.IsActive;
            query.CategoryID = cateid;
            return blogService.GetEntryCount(query);

        }
		
	}
}
