namespace Dottext.Web.AggSite
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Data.SqlClient;
	using Dottext.Framework.Data;
	using System.Configuration;

	/// <summary>
	///		CommentAuthorList ��ժҪ˵����
	/// </summary>
	public partial class CommentAuthorList : System.Web.UI.UserControl
	{
        private void Page_Load(object sender, System.EventArgs e)
        {
            IBlogDao blogDao = (IBlogDao)CchenSoft.Framework.Config.Configuration.Instance.GetBean("IBlogDao");
            string sql = "blog_GetAggregatedCommentAuthors";

            DataSet ds = blogDao.ExecuteDataset(CommandType.StoredProcedure, sql);
            Authors.DataSource = ds.Tables[0];
            literalBloggerCount.Text = ds.Tables[0].Rows.Count.ToString();
            Authors.DataBind();

            ds.Clear();
            ds.Dispose();
        }

		protected string GetUrl(string author)
		{
			return Dottext.Framework.Util.Globals.AddParamToUrl(Request.RawUrl,"author",Server.UrlEncode(author));
			
		}
	}
}
