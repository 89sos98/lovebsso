namespace Dottext.Web.AggSite
{
    using System;
    using System.Data;
    using System.Drawing;
    using System.Web;
    using System.Web.UI.WebControls;
    using System.Web.UI.HtmlControls;
    using System.Configuration;
    using Dottext.Web.UI.Controls;
    using Dottext.Framework;
    using Dottext.Framework.Configuration;

    /// <summary>
    ///		Header ��ժҪ˵����
    /// </summary>
    public partial class Header : BaseControl
    {
        private void Page_Load(object sender, System.EventArgs e)
        {
            TitleLink.Text = UI.UIText.SiteTitle;
            TitleLink.NavigateUrl = UI.UIText.SiteUrl;
            if (Dottext.Framework.Configuration.Config.Settings.Logo != null && Dottext.Framework.Configuration.Config.Settings.Logo != "")
            {
                TitleLink.ImageUrl = "~/images/" + Dottext.Framework.Configuration.Config.Settings.Logo;
            }

            if (blogService.IsAuthenticated)
            {
                lnkLogin.Text = "ע��";
                lnkLogin.NavigateUrl = Config.RootPath + "Logout.aspx";
            }
            else
            {
                lnkLogin.Text = "��¼";
                lnkLogin.NavigateUrl = Config.RootPath + "Login.aspx?ReturnURL=" + Request.RawUrl;
            }
        }

    }
}
