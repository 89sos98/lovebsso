namespace Dottext.Web.AggSite
{
    using System;
    using System.Data;
    using System.Configuration;
    using System.Drawing;
    using System.Web;
    using System.Web.UI.WebControls;
    using System.Web.UI.HtmlControls;
    using System.Data.SqlClient;

    using Dottext.Framework.Data;
    using Dottext.Framework.Configuration;

    /// <summary>
    ///		Summary description for BlogList.
    /// </summary>
    public partial class BlogList : System.Web.UI.UserControl
    {
        private string _storedProcedureName = "blog_GetAggregatedBloggers";

        public string StoredProcedureName
        {
            set
            {
                this._storedProcedureName = value;
            }
        }

        private string _title = "�������а�";
        public string Title
        {
            set
            {
                this._title = value;
            }
        }

        private int _groupID = -1;
        public int GroupID
        {
            get
            {
                return this._groupID;
            }
            set
            {
                this._groupID = value;
            }
        }

        private int _bloggerListCount = 200;
        public int BlogListCount
        {
            get
            {
                return this._bloggerListCount;
            }
            set
            {
                this._bloggerListCount = value;
            }
        }

        private void Page_Load(object sender, System.EventArgs e)
        {
            IBlogDao blogDao = (IBlogDao)CchenSoft.Framework.Config.Configuration.Instance.GetBean("IBlogDao");
            this.LiteralTitle.Text = this._title;
            string sql = this._storedProcedureName;

            SqlParameter[] p = 
                {
                    SqlHelper.MakeInParam("@ItemCount",SqlDbType.Int,4,BlogListCount), 
					SqlHelper.MakeInParam("@GroupID",SqlDbType.Int,4,GroupID)
                };

            DataSet ds = blogDao.ExecuteDataset(CommandType.StoredProcedure, sql, p);
            Bloggers.DataSource = ds.Tables[0];
            literalBloggerCount.Text = ds.Tables[0].Rows.Count.ToString();
            Bloggers.DataBind();

            ds.Clear();
            ds.Dispose();
        }

        #region GetFullUrl Method
        //private string appPath = null;

        //gjung modify
        const string fullUrl = "{0}/{1}";

        //protected System.Web.UI.WebControls.Literal literalBloggerCount;
        //string host = null;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x"></param>
        /// <param name="app"></param>
        /// <returns></returns>
        protected string GetFullUrl(string app)
        {
            return Config.RootPath + app + "/default.aspx";
        }

        protected string GetRssUrl(string app)
        {
            return Config.RootPath + app + "/rss.aspx";
        }

        #endregion

    }
}
