namespace Dottext.Web.AggSite
{
    using System;
    using System.Configuration;
    using System.Data;
    using System.Drawing;
    using System.Web;
    using System.Web.UI.WebControls;
    using System.Web.UI.HtmlControls;
    using Dottext.Framework.Logger;

    /// <summary>
    ///		Summary description for Template.
    /// </summary>
    public partial class AdvPageTemplate : System.Web.UI.UserControl
    {
        protected System.Web.UI.WebControls.HyperLink TitleLink;

        protected Literal TitleTag;

        private void Page_Load(object sender, System.EventArgs e)
        {
            //gjung modify
            string url;
            url = Dottext.Framework.Configuration.Config.Settings.AggregateUrl;
            if (url.EndsWith("/"))
            {
                url = url.Substring(0, url.Length - 1);
            }
            TitleLink.NavigateUrl = url;

            if (null != Request.QueryString["date"])
            {
                lnkReturnDefault.Visible = true;

            }
            else
            {
                lnkReturnDefault.Visible = false;
            }

            if (null != Request.QueryString["cate"] && null != Request.QueryString["title"])
            {
                lnkReturnDefault.NavigateUrl += string.Format("?cate={0}&title={1}", Request.QueryString["cate"], Request.QueryString["title"]);
                CalTitle.Text = Request.QueryString["title"];
            }

            DataSet ds = new DataSet();
            ds.ReadXml(UI.UIData.SiteCatalogXmlFile);
            LinkList.DataSource = ds;
            LinkList.DataBind();
        }

        protected bool CheckVisible(string cateid)
        {
            return !string.IsNullOrEmpty(cateid);
        }

    }
}
