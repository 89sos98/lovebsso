namespace Dottext.Web.AggSite
{
    using System;
    using System.Data;
    using System.Drawing;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using System.Web.UI.HtmlControls;
    using System.Data.SqlClient;
    using System.Text.RegularExpressions;
    using System.Globalization;
    using System.Configuration;
    using Dottext.Framework.Configuration;
    using Dottext.Framework.Data;
    using Dottext.Framework.Components;
    using Dottext.Framework;
    using Dottext.Web.UI.Controls;
    using Dottext.Framework.Util;
    /// <summary>
    ///		Summary description for RecentPosts.
    /// </summary>
    public partial class Homepage : BaseControl
    {

        private int _resultsPageNumber = 1;
        //private int _pagesize=40;
        //private DateTime seldate;
        private PostType _entryType = PostType.BlogPost;
        protected System.Web.UI.WebControls.Literal ltListTitle;
        private PostConfig _entryPostConfig = PostConfig.IsAggregated;
        private bool IsOnlyTitle = false;
        private string AppUrl;
        private string BlogUrl = "";
        private int _categoryID;

        #region Accessors

        public PostType PostType
        {
            get { return _entryType; }
            set { _entryType = value; }
        }


        public PostConfig PostConfig
        {
            get { return _entryPostConfig; }
            set { _entryPostConfig = value; }
        }

        public string Title
        {
            get { return ltListTitle.Text; }
            set { ltListTitle.Text = value; }
        }

        public int CatogryID
        {
            get { return this._categoryID; }
            set { this._categoryID = value; }
        }

        #endregion

        private void Page_Load(object sender, System.EventArgs e)
        {
            AppUrl = Dottext.Framework.Util.Globals.GetSiteQualifiedUrl();
            AppUrl = AppUrl.Remove(AppUrl.Length - 1, 1);


            #region ListControl
            if (Request.QueryString["onlytitle"] == "1")
            {
                this.IsOnlyTitle = true;
            }
            else
            {
                this.IsOnlyTitle = false;
            }
            #endregion


            if (null != Request.QueryString["page"])
                _resultsPageNumber = Convert.ToInt32(Request.QueryString["page"]);
            ResultsPager2.PageIndex = ResultsPager.PageIndex = _resultsPageNumber;

            #region Paging Format
            ResultsPager2.UrlFormat = ResultsPager.UrlFormat = Dottext.Framework.Util.Globals.AddParamToUrl(Request.RawUrl, "page", "{0}");//Request.Path+"?page={0}";

            #endregion

            PagedEntryQuery query = new PagedEntryQuery();
            query.PostType = PostType.BlogPost;
            query.ItemCount = 100;

            #region Date Query
            /*
			if(null != Request.QueryString["date"])
			{
				string datestr=Request.QueryString["date"];
				seldate=DateTime.ParseExact(datestr,"yyyy'/'MM'/'dd",CultureInfo.CurrentCulture,DateTimeStyles.None);
				query.StartDate=seldate;
				
			}*/
            #endregion

            query.PageIndex = _resultsPageNumber;
            query.PageSize = ResultsPager.PageSize = ResultsPager2.PageSize = BlogContext.Current.Config.ItemCount;
            query.PostConfig = PostConfig.IsActive | this._entryPostConfig;//PostConfig.IsAggregated|PostConfig.IsActive;

            query = (PagedEntryQuery)Dottext.Framework.Util.Globals.BuildEntryQuery(query, BlogContext.Current.Config);
            //Dottext.Framework.Logger.LogManager.Log("Config",Config.CurrentBlog(Context).BlogID.ToString());
            PagedList<Entry> PostList = null;
            PostList = blogService.GetPagedEntryCollection(query);
            if (PostList != null)
            {
                ResultsPager2.ItemCount = ResultsPager.ItemCount = PostList.MaxItems;
                ResultsPager2.PrefixText = ResultsPager.PrefixText = "��" + ResultsPager.MaxPages + "ҳ:";
                RecentPostsRepeater.DataSource = PostList;
                RecentPostsRepeater.DataBind();
            }
            CatalogTitle.Text = BlogContext.Current.Config.Title + "�������";


        }

        protected string CheckLength(string content)
        {
            string NoHtmStr = Dottext.Framework.Util.Globals.RemoveHtml(content);
            content = Framework.Util.Globals.FilterScript(content);
            content = Dottext.Framework.Util.Globals.RemoveHtmlTag(content, UI.UIData.HtmlFilter);

            if (this.IsOnlyTitle)
            {
                return String.Empty;
            }

            if (NoHtmStr.Length > UI.UIData.PostContentLength)
            {
                return string.Format("&nbsp;&nbsp;&nbsp;&nbsp;����ƪ���ϳ�,����<a href='{0}'>����</a>�Ķ�ȫ��", this.fullurl);

            }
            else
            {
                return content;
            }

            //return "";

        }

        protected string CheckViewCount(string count)
        {
            return count == "" ? "0" : count;
        }

        //gjung add
        #region GetFullUrl Method
        private string appPath = null;
        const string fullUrl = "http://{0}{1}{2}";
        string host = null;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x"></param>
        /// <param name="app"></param>
        /// <returns></returns>
        protected string GetFullUrl(int blogId)
        {
            if (appPath == null)
            {
                appPath = Globals.ApplicationPath;
                if (!appPath.ToLower().EndsWith("/"))
                {
                    appPath += "/";
                }
            }

            BlogConfig cfg = blogService.GetConfig(blogId);
            if (cfg != null)
                return appPath + cfg.Application + "default.aspx";
            return "";
        }
        #endregion


        private string fullurl = "";
        protected string BuildUrl(string titleUrl, string link,string sourceUrl,string postType)
        {
            BlogUrl = "";
            if (link != null && link != "")
            {
                if (!link.ToLower().StartsWith("http://"))
                {
                    link = "http://" + link;
                }

            }
            this.fullurl = link;
            if (postType == PostType.Comment.ToString())
            {
                if (sourceUrl != "" && sourceUrl != null)
                {
                    this.fullurl = sourceUrl;
                }

                if (link != titleUrl)
                {
                    BlogUrl = titleUrl;
                }
                else
                {
                    BlogUrl = "";
                }
            }
            else
            {
                BlogUrl = Globals.GetBlogAppUrl(link, Globals.ApplicationPath);
            }

            return fullurl;



        }

        protected string GetUrl()
        {
            if (this.fullurl == null)
            {
                fullurl = "";
            }
            return this.fullurl;
        }

        protected string GetBlogUrl()
        {
            return this.BlogUrl;
        }

        protected string GetTopUrl()
        {
            return Request.RawUrl + "#Top";
        }

        override protected void OnInit(EventArgs e)
        {
            this.ID = "RecentPostsRepeater";
            base.OnInit(e);
        }


        protected void RecentPostsRepeater_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
        {

        }
    }
}
