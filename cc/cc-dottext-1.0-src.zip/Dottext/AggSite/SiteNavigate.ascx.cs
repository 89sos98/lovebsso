namespace Dottext.Web.AggSite
{
    using System;
    using System.Data;
    using System.Drawing;
    using System.Web;
    using System.Web.UI.WebControls;
    using System.Web.UI.HtmlControls;
    using System.Text.RegularExpressions;
    using Dottext.Web.UI.Controls;
    using Dottext.Framework;
    using Dottext.Framework.Configuration;

    /// <summary>
    ///		SiteNavigate ��ժҪ˵����
    /// </summary>
    public partial class SiteNavigate : BaseControl
    {
        private void Page_Load(object sender, System.EventArgs e)
        {
            NavTitle.Text = BlogContext.Current.Config.Title;
            if (blogService.IsAuthenticated)
            {
                lnkLogin.Text = "ע��";
                lnkLogin.NavigateUrl = Config.RootPath + "Logout.aspx";
            }
            else
            {
                lnkLogin.Text = "��¼";
                lnkLogin.NavigateUrl = Config.RootPath + "Login.aspx?ReturnURL=" + Request.RawUrl;
            }
        }
    }
}
