using System;
using System.Configuration;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using Dottext.Framework.Data;
using Dottext.Framework.Components;
using Dottext.Framework;
using Dottext.Framework.Util;
using Dottext.Framework.Configuration;

namespace Dottext.Web.AggSite
{

    /// <summary>
	///		Summary description for AggStats.
	/// </summary>
	public partial class AggStats : System.Web.UI.UserControl
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
            IBlogDao blogDao = (IBlogDao)CchenSoft.Framework.Config.Configuration.Instance.GetBean("IBlogDao");
            string sql = "blog_GetAggregatedStats";

            DataSet ds = blogDao.ExecuteDataset(CommandType.StoredProcedure,sql);
            DataTable dtCounts = ds.Tables[0];
            
            if(dtCounts != null)
            {
                DataRow dr = dtCounts.Rows[0];
                BlogCount.Text = dr["BlogCount"].ToString();
                PostCount.Text = dr["PostCount"].ToString();
                StoryCount.Text = dr["StoryCount"].ToString();
                CommentCount.Text = dr["CommentCount"].ToString();
                PingtrackCount.Text =PingtrackCount.Text+dr["PingtrackCount"].ToString();
            }

            ds.Clear();
            ds.Dispose();
		}

	}
}
