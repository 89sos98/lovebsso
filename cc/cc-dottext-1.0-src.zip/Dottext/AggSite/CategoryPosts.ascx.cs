namespace Dottext.Web.AggSite
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Data.SqlClient;
	using System.Text.RegularExpressions;
	using System.Globalization;
	using System.Configuration;
	using Dottext.Framework.Configuration;
	using Dottext.Framework.Data;
	using Dottext.Framework.Components;
	using Dottext.Framework;
    using System.Collections.Generic;
    using Dottext.Web.UI.Controls;
    using Dottext.Framework.Util;


	/// <summary>
	///		CategoryPosts ��ժҪ˵����
	/// </summary>
	public partial class CategoryPosts : BaseControl
	{

		private int _categoryID = -1;
		public int CategoryID
		{
			get
			{
				return _categoryID;
			}
			set
			{
				_categoryID = value;
			}
		}


		private string BlogUrl="";
        //protected System.Web.UI.WebControls.HyperLink Title;
        //protected System.Web.UI.WebControls.Repeater RecentPostsRepeater;
		private string fullurl="";
        protected string BuildUrl(string titleUrl, string link, string sourceUrl, string postType)
        {
            BlogUrl = "";
            if (link != null && link != "")
            {
                if (!link.ToLower().StartsWith("http://"))
                {
                    link = "http://" + link;
                }

            }
            this.fullurl = link;
            if (postType == PostType.Comment.ToString())
            {
                if (sourceUrl != "" && sourceUrl != null)
                {
                    this.fullurl = sourceUrl;
                }

                if (link != titleUrl)
                {
                    BlogUrl = titleUrl;
                }
                else
                {
                    BlogUrl = "";
                }
            }
            else
            {
                BlogUrl = Globals.GetBlogAppUrl(link, Globals.ApplicationPath);
            }

            return fullurl;
        }

		private void Page_Load(object sender, System.EventArgs e)
		{
			string cateid=Request.QueryString["cateid"];
			if(cateid!=null && cateid!="")
			{
				CategoryID=Convert.ToInt32(cateid);
			}
			
			EntryQuery query = new	EntryQuery();
			query.PostType = PostType.BlogPost;
			SiteBlogConfig config=Config.GetSiteBlogConfigByCategoryID(CategoryID);
			if(config==null||config.IsAggregated==false)
			{
				this.Visible=false;
				return;
			}
			query.PostConfig = PostConfig.IsActive|PostConfig.IsAggregated;
			query=(EntryQuery)Dottext.Framework.Util.Globals.BuildEntryQuery(query,config);
			
			IList<Entry> PostList=null;
			try
			{
                PostList = blogService.GetEntryCollection(query);
				if(PostList==null)
				{
					return;
				}
				if(PostList.Count==0)
				{
					//this.Visible=false;
				}
				RecentPostsRepeater.DataSource = PostList;
				RecentPostsRepeater.DataBind();
			}
			finally
			{
				PostList.Clear();
				PostList=null;
			}
			Title.Text=config.Title;
			//Title.NavigateUrl="~/default.aspx?id="+BlogID;
		}
	}
}
