namespace Dottext.Web.AggSite
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Data.SqlClient;
	using System.Text.RegularExpressions;

	using System.Configuration;
	using Dottext.Framework.Configuration;
	using Dottext.Framework.Data;
    using Dottext.Framework.Util;
	/// <summary>
	///		Summary description for RecentPosts.
	/// </summary>
	public partial class TopPostList : System.Web.UI.UserControl
	{
		private string _StoredProcedureName;
		public string StoredProcedureName
		{
			set
			{
				_StoredProcedureName=value;
			}
		}

        private void Page_Load(object sender, System.EventArgs e)
        {
            IBlogDao blogDao = (IBlogDao)CchenSoft.Framework.Config.Configuration.Instance.GetBean("IBlogDao");
            DataSet ds = blogDao.ExecuteDataset(CommandType.StoredProcedure, _StoredProcedureName);
            RecentPostsRepeater.DataSource = ds.Tables[0];
            RecentPostsRepeater.DataBind();
            ds.Clear();
            ds.Dispose();
        }

        #region GetFullUrl Method
        private string appPath = null;
        const string fullUrl = "http://{0}{1}{2}";
		protected Dottext.Web.UI.WebControls.Pager ResultsPager;
        string host = null;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x"></param>
        /// <param name="app"></param>
        /// <returns></returns>
        protected string GetFullUrl(string app)
        {
            if(appPath == null)
            {
                appPath = Globals.ApplicationPath;
                if(!appPath.ToLower().EndsWith("/"))
                {
                    appPath += "/";
                }
            }
            if(host == null)
            {
                host = Request.Url.Host.ToLower();//.Replace("www.",string.Empty);
            }
            return string.Format(fullUrl,host,appPath,app);
        }
        #endregion

        #region GetEntryUrl Method
        /// <summary>
        /// 
        /// </summary>
        /// <param name="host"></param>
        /// <param name="app"></param>
        /// <param name="entryName"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        protected string GetEntryUrl(string host, string app, string entryName, DateTime dt)
        {
            return string.Format("{0}archive/{1}/{2}.aspx",GetFullUrl(app),dt.ToString("yyyy'/'MM'/'dd"),entryName);
        }
        #endregion

		protected string CheckViewCount(string count)
		{
			return count==""?"0":count;
		}

		override protected void OnInit(EventArgs e)
		{
            this.ID = "RecentPostsRepeater";
			base.OnInit(e);
		}
		
		protected void RecentPostsRepeater_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
		{
		
		}
	}
}
