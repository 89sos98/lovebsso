namespace Dottext.Web.AggSite
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Configuration;

	/// <summary>
	///		TrackBackTemplate ��ժҪ˵����
	/// </summary>
	public partial class TrackBackTemplate : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Literal Style;

		private void Page_Load(object sender, System.EventArgs e)
		{
            TitleTag.Text = TitleLink.Text = ConfigurationManager.AppSettings["AggregateTitle"] as string;
			TitleLink.NavigateUrl = Dottext.Framework.Configuration.Config.Settings.AggregateUrl;//ConfigurationSettings.AppSettings["AggregateUrl"] as string;

			//const string style = "<LINK href=\"{0}{1}\" type=\"text/css\" rel=\"stylesheet\">";
			//string apppath = Request.ApplicationPath.EndsWith("/") ? Request.ApplicationPath : Request.ApplicationPath + "/";
			//Style.Text = string.Format(style,apppath,"Style.css") + "\n" + string.Format(style,apppath,"blue.css");
		}

	}
}
