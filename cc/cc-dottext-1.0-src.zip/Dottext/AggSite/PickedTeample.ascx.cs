namespace Dottext.Web
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Configuration;

	/// <summary>
	///		PickedRecentPosts ��ժҪ˵����
	/// </summary>
	public partial class PickedTeample : System.Web.UI.UserControl
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			
			
		}
	}
}
