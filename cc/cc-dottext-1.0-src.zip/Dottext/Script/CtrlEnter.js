<script language="JavaScript">
function ctlent()
{
	if(event.ctrlKey && event.keyCode==13)
		{	
			doPostBack();
		}
		
}
</script>