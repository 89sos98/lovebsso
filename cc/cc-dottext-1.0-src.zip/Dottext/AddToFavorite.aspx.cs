using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

using Dottext.Framework.Data;
using Dottext.Framework.Components;
using Dottext.Framework;
using Dottext.Framework.Util;
using Dottext.Framework.Configuration;
using System.Collections.Generic;
using Dottext.Web.UI;

namespace Dottext.Web.Pages
{
    /// <summary>
    /// AddToFavorite ��ժҪ˵����
    /// </summary>
    public partial class AddToFavorite : BasePage
    {
        private BlogConfig config;
        private Entry entry;

        private void Page_Load(object sender, System.EventArgs e)
        {
            if (!blogService.IsAuthenticated)
            {
                Response.Redirect(Config.Settings.AggregateUrl + "login.aspx?ReturnURL=" + Request.Url.AbsoluteUri);
            }
            if (Request.QueryString["id"] == null)
            {
                throw new ApplicationException("����ѡ������");
            }

            config = blogService.GetConfig(blogService.GetCurrentUserName);
            entry = blogService.GetEntry(int.Parse(Request.QueryString["id"]));
            lbTitle.Text = entry.Title;
            lbAuthor.Text = entry.Author;
            if (entry == null)
            {
                throw new ApplicationException("��ѡ���²�����!");
            }
            ReturnLink.NavigateUrl = entry.TitleUrl;
            lnkEnterMyBlog.NavigateUrl = Config.Settings.AggregateUrl + config.CleanApplication + "/admin/EditFavorite.aspx";

            if (!IsPostBack)
            {
                GetCategoryList();
            }
        }

        private void GetCategoryList()
        {
            CategoryList.Items.Clear();
            IList<LinkCategory> categorys = blogService.GetCategoriesByType(config.BlogID, CategoryType.FavoriteCollention, false);
            if (categorys == null || categorys.Count == 0)
            {
                tbCreateCategory.Visible = true;
                tbAddFavorite.Visible = false;
            }
            else
            {
                foreach (LinkCategory category in categorys)
                {
                    CategoryList.Items.Add(new ListItem(category.Title, category.CategoryID.ToString()));
                }
                CategoryList.SelectedIndex = 0;
            }
        }


        private void AddToFav()
        {
            //string titleurl=Request.QueryString["url"];
            if (entry != null)
            {
                Link link = new Link();
                link.BlogID = config.BlogID;
                link.PostID = entry.EntryID;
                link.IsActive = true;
                link.NewWindow = ckbNewWindow.Checked;
                link.Title = entry.Title;
                /*BlogConfig config=Config.GetConfig(entry.BlogID);
                    if(config==null)
                    {
						
                        Message.Text="���ӵ��ղؼг���";
                        return;
                    }*/
                link.Url = entry.TitleUrl;//config.Application+config.UrlFormats.EntryUrl(entry);//entry.Link;//entry.TitleUrl;
                link.CategoryID = int.Parse(CategoryList.SelectedValue);
                int linkid = blogService.CreateLink(link);
                if (linkid > 0)
                {
                    Message.Text = "�ɹ����ӵ��ղؼ�!";
                    Submit.Visible = false;
                    //string url= System.Configuration.ConfigurationSettings.AppSettings["AggregateUrl"]+"/"+UserName+"/admin/EditFavorite.aspx";
                    //Response.Redirect(url);
                }
                else
                {
                    Message.Text = "���ӵ��ղؼг���";
                }
            }
        }

        protected void Submit_Click(object sender, System.EventArgs e)
        {
            AddToFav();
        }

        protected void btnNewCategory_Click(object sender, System.EventArgs e)
        {
            tbCreateCategory.Visible = true;
            tbAddFavorite.Visible = false;
        }

        protected void btnCreateCategory_Click(object sender, System.EventArgs e)
        {
            LinkCategory category = new LinkCategory();
            category.CategoryType = CategoryType.FavoriteCollention;
            category.Title = tbCategoryName.Text;
            category.BlogID = config.BlogID;
            blogService.CreateLinkCategory(category);
            tbCategoryName.Text = string.Empty;
            GetCategoryList();
            tbCreateCategory.Visible = false;
            tbAddFavorite.Visible = true;
        }

        protected void btnReturnBefore_Click(object sender, System.EventArgs e)
        {
            tbCreateCategory.Visible = false;
            tbAddFavorite.Visible = true;
        }
    }
}
