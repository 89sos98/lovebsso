using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using ActiproSoftware.CodeHighlighter;

namespace Dottext.Web
{
	/// <summary>
	/// InsertCode ��ժҪ˵����
	/// </summary>
	public partial class InsertCode : System.Web.UI.Page
	{

		private void Page_Load(object sender, System.EventArgs e)
		{
			Response.Expires=-1;
			if(!IsPostBack)
			{
				CodeHighlighterConfiguration codeConfig=(CodeHighlighterConfiguration)System.Configuration.ConfigurationManager.GetSection("codeHighlighter");
				foreach(string key in codeConfig.LanguageConfigs.Keys)
				{
					LanguageDropDownList.Items.Add(key);
					if(key=="C#")
					{
						LanguageDropDownList.SelectedIndex=LanguageDropDownList.Items.Count-1;
					}
				}
			}
		}

		protected void HighlightButton_Click(object sender, System.EventArgs e)
		{
			Codehighlighter1.LanguageKey=LanguageDropDownList.SelectedItem.Text;
			Codehighlighter1.OutliningEnabled=true;
			Codehighlighter1.Text = CodeText.Text.Replace("\\","\\\\");
			
			
		}

		public void CodeHighlighter_PostRender(object sender, System.EventArgs e)
		{
			if(IsPostBack)
			{
				string html=Codehighlighter1.Output.Replace("\"","\\\"");
				html=html.Replace("\r\n","<br>\"+\r\n\"");
				html=Dottext.Framework.Util.Globals.ReplaceSpace(html);
                string imgpath = Dottext.Framework.Util.Globals.GetSiteQualifiedUrl() + "Images/";
				html=html.Replace("...","<img src='"+imgpath+"dot.gif'>");
				//html=html.Replace("<div>",string.Empty);
				//html=html.Replace("</div>",string.Empty);
				//html=html.Replace(" ","&nbsp;");
				//html=html.Replace("\r","\"+\r");
				//html=html.Replace("\n","\"\n");
				/*System.IO.StreamWriter sw=new System.IO.StreamWriter("f:\\test.txt");
				sw.Write(html);
				sw.Flush();
				sw.Close();*/
				string divstr=@"<div style='BORDER-RIGHT: windowtext 0.5pt solid;PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 0.5pt solid; PADDING-LEFT: 5.4pt; BACKGROUND: #e6e6e6; PADDING-BOTTOM: 4px;PADDING-TOP: 4px; 	BORDER-LEFT: windowtext 0.5pt solid;WIDTH: 98%;	BORDER-BOTTOM: windowtext 0.5pt solid;word-break:break-all'>";
				Response.Write(@"
				<script language='javascript'>
				window.parent.returnValue = """+divstr+html+@"</div>"";
				window.parent.close();
				</script>");
				
			}
								
		}
		
		
	}
}
