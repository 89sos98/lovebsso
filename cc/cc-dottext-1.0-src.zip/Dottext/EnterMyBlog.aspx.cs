using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;
using Dottext.Framework.Util;
using Dottext.Web.UI;
using CchenSoft.Framework;
using CchenSoft.Framework.Attributes;
using Dottext.Framework.Configuration;
using Dottext.Framework;
namespace Dottext.Web.Pages
{
    /// <summary>
    /// EnterMyBlog ��ժҪ˵����
    /// ������ֱ�ӽ��벩��ҳ��
    /// </summary>
    public partial class EnterMyBlog : BasePage
    {
        private void Page_Load(object sender, System.EventArgs e)
        {
            if (!blogService.IsAuthenticated)
            {
                Response.Redirect("login.aspx?ReturnURL=" + Request.Url.AbsoluteUri);
            }
            else
            {
                BlogConfig cfg = blogService.GetConfig(blogService.GetCurrentUserName);
                string blogurl = Config.RootPath + cfg.Application;
                if (Request.QueryString["NewPost"] == "1")
                {
                    Response.Redirect(blogurl + "admin/EditPosts.aspx?opt=1");
                }
                else if (Request.QueryString["NewArticle"] == "1")
                {
                    Response.Redirect(blogurl + "admin/EditArticles.aspx?opt=1");
                }
                else
                {
                    Response.Redirect(blogurl + "default.aspx");
                }
            }

        }
    }
}
