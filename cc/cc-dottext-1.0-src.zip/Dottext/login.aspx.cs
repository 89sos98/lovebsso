#region Disclaimer/Info
///////////////////////////////////////////////////////////////////////////////////////////////////
// .Text WebLog
// 
// .Text is an open source weblog system started by Scott Watermasysk. 
// Blog: http://ScottWater.com/blog 
// RSS: http://scottwater.com/blog/rss.aspx
// Email: Dottext@ScottWater.com
//
// For updated news and information please visit http://scottwater.com/dottext and subscribe to 
// the Rss feed @ http://scottwater.com/dottext/rss.aspx
//
// On its release (on or about August 1, 2003) this application is licensed under the BSD. However, I reserve the 
// right to change or modify this at any time. The most recent and up to date license can always be fount at:
// http://ScottWater.com/License.txt
// 
// Please direct all code related questions to:
// GotDotNet Workspace: http://www.gotdotnet.com/Community/Workspaces/workspace.aspx?id=e99fccb3-1a8c-42b5-90ee-348f6b77c407
// Yahoo Group http://groups.yahoo.com/group/DotText/
// 
///////////////////////////////////////////////////////////////////////////////////////////////////
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Configuration;
using Dottext.Framework.Components;
using Dottext.Framework;
using Dottext.Framework.Configuration;
using Dottext.Framework.Util;
using Dottext.Web.UI;
using CchenSoft.Framework;
using CchenSoft.Framework.Attributes;


namespace Dottext.Web.Pages
{
    /// <summary>
    /// Summary description for login.
    /// </summary>
    public partial class login : BasePage
    {
        [Bean("Authenticator")]
        protected IAuthenticator auth;

        private string RedirectUrl;

        private void Page_Load(object sender, System.EventArgs e)
        {
            tbAuthenCode.Visible = Config.Settings.EnableLoginAuhenCode;
            if (!IsPostBack)
            {
                //gjung add
                string url = Config.Settings.AggregateUrl;
                url = url.Substring(0, url.Length - 1);
                lnkHome.NavigateUrl = url;

                if (auth.IsAuthenticated)
                {
                    Response.Redirect(Config.Settings.AggregateUrl + auth.IdentityName);
                }

                GenerateRandomCode();

                tbUserName.Attributes.Add("onKeyPress", "checkEnter(event,this)");
                tbPassword.Attributes.Add("onKeyPress", "checkEnter(event,this)");
                System.IO.StreamReader sr = null;
                try
                {
                    sr = new System.IO.StreamReader(MapPath("Script") + "\\LoginScript.js");
                    this.ClientScript.RegisterClientScriptBlock(this.GetType(), "LoginScript", sr.ReadToEnd());
                }
                finally
                {
                    sr.Close();
                }
            }
        }

        private void GenerateRandomCode()
        {
            if (Config.Settings.EnableLoginAuhenCode)
            {
                Response.Cookies["AreYouHuman"].Value = CaptchaImage.CaptchaImage.GenerateRandomCode();
            }
        }

        protected void lblLogin_Click(object sender, System.EventArgs e)
        {
            if (Config.Settings.EnableLoginAuhenCode && this.CodeNumberTextBox.Text != Request.Cookies["AreYouHuman"].Value)
            {

                // Display an error message.
                this.lblImage.Text = "ERROR: The code you entered was invalid, try again.";

                // Clear the input and create a new random code.
                this.CodeNumberTextBox.Text = "";
                Response.Cookies["AreYouHuman"].Value = CaptchaImage.CaptchaImage.GenerateRandomCode();
                return;
            }

            BlogConfig config = blogService.GetConfig(tbUserName.Text);
            if (config == null)
            {
                Message.Text = "���û�������!<br>";
                GenerateRandomCode();
                return;
            }
            int persist = chkRemember.Checked ? 90 : 0;

            if (auth.Authenticate(tbUserName.Text, tbPassword.Text, persist) > 0)
            {
                RedirectUrl = Request.QueryString["ReturnURL"];
                if (RedirectUrl != null)
                {
                    Response.Redirect(RedirectUrl);
                }
                else
                {
                    string url = Dottext.Framework.Configuration.Config.Settings.AggregateUrl + tbUserName.Text;
                    Response.Redirect(url);
                }
            }
            else
            {
                Message.Text = "�������!<br>";
                GenerateRandomCode();
            }
        }

        private void lbGetPassword_Click(object sender, System.EventArgs e)
        {
            tbPassword.Visible = false;
        }
    }
}

