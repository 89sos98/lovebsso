using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using Dottext.Framework.Configuration;
using Dottext.Framework.Data;

namespace Dottext.Web.Admin.Pages
{
	/// <summary>
	/// ManageUserDelete ��ժҪ˵����
	/// </summary>
	public partial class ManageUserDelete : ManagePage
	{

		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!IsPostBack)
			{
				btnDelete.Attributes.Add("onclick", "if(!confirm('�����Ҫɾ����?')) return false;if(!confirm('�ò�������ɾ�����ʺŵ���������, ��ȷ����?')) return false;return true;");
			}
		}

        protected void btnReadBlog_Click(object sender, System.EventArgs e)
        {
            BlogConfig config = blogService.GetConfig(tbUserName.Text);
            if (config != null)
            {
                ltBlogID.Text = config.BlogID.ToString();
                ltAuthor.Text = config.Author;
                ltTitle.Text = config.Title;
                ltSubTitle.Text = config.SubTitle;
                ltPostCount.Text = config.PostCount.ToString();
                ltStorycount.Text = config.StoryCount.ToString();
                BlogInfo.Visible = true;
            }
            else
            {
                Messages.ShowMessage("���ʻ�������!");
                Reset();
            }
        }
		
		private void Reset()
		{
			ltBlogID.Text=string.Empty;
			ltAuthor.Text=string.Empty;
			ltTitle.Text=string.Empty;
			ltSubTitle.Text=string.Empty;
			ltPostCount.Text=string.Empty;
			ltStorycount.Text=string.Empty;
			BlogInfo.Visible=false;
		}

        private void DeleteBlog(int BlogID)
        {
            IBlogDao blogDao = CchenSoft.Framework.Config.Configuration.Instance.GetService<IBlogDao>();
            SqlParameter[] p =
			{
				SqlHelper.MakeInParam("@BlogID",SqlDbType.Int,4,BlogID)
			};
            blogDao.ExecuteNonQuery(CommandType.StoredProcedure, "blog_DeleteBlogger", p);
        }

		protected void btnDelete_Click(object sender, System.EventArgs e)
		{
			DeleteBlog(Convert.ToInt32(ltBlogID.Text));
			Messages.ShowMessage("�ɹ�ɾ��"+tbUserName.Text+"�ʺ�!");
			Reset();
		}
	}
}
