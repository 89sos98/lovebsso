using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Dottext.Framework.Configuration;

namespace Dottext.Web.Admin.Pages
{
    /// <summary>
    /// ManageRoles ��ժҪ˵����
    /// </summary>
    public partial class ManageRoles : ManagePage
    {
        private void Page_Load(object sender, EventArgs e)
        {

            PageContainer.TabSectionID = "ManageSite";
            if (!IsPostBack)
            {
                bindRoleList();

            }

            buildLocalUI();

        }

        private void showMessage(string MessageText)
        {
            Messages.ShowMessage(MessageText);
        }

        private void bindRoleList()
        {
            Dottext.Framework.Components.Role[] roles = blogService.GetRoles(-1);
            ddlModuleList.DataSource = roles;
            ddlModuleList.DataTextField = "Name";
            ddlModuleList.DataValueField = "RoleId";

            ddlModuleList.DataBind();

            ddlModuleList.Items.Insert(0, "��ѡ�񡭡�");


        }

        private void showRoleUser(int ModuleId)
        {
            rptRoleUsers.DataSource = blogService.GetConfigByRoleID(ModuleId);
            rptRoleUsers.DataBind();
            Roles.Visible = true;
        }

        private void addRoleUser(int RoleId, string UserName)
        {
            BlogConfig config = blogService.GetConfig(UserName);
            if (config != null)
            {
                blogService.AddUserToRole(config.BlogID, RoleId);
            }
            else
            {
                Messages.ShowMessage("���û�������!");
            }
        }

        private void deleteRoleUser(int UserId, int RoleId)
        {
            blogService.RemoveUserFromRole(UserId, RoleId);
        }


        private void setUpdateButtonValid(bool IsValid)
        {
            btnAddUserToRole.Enabled = IsValid;
        }

        private void buildLocalUI()
        {
            DataTable dt = null;//Helper.getUserRoleModules(blogService.GetCurrentUserName);

            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        HyperLink hl = Utilities.CreateHyperLink(dt.Rows[i]["ModuleName"].ToString(), dt.Rows[i]["ModuleFile"].ToString());
                        PageContainer.AddToActions(hl);
                    }
                }
            }

        }

        protected void btnAddUserToRole_Click(object sender, System.EventArgs e)
        {
            if (ddlModuleList.SelectedIndex > 0)
            {
                string UserName = tbUserName.Text;
                int RoleId = Convert.ToInt32(ddlModuleList.SelectedValue);

                addRoleUser(RoleId, UserName);

                tbUserName.Text = "";

                showRoleUser(RoleId);
            }
        }

        protected void rptRoleUsers_ItemCreated(object sender, System.Web.UI.WebControls.RepeaterItemEventArgs e)
        {
            foreach (Control con in e.Item.Controls)//�õ�ÿ���ؼ�
            {
                if (con is LinkButton)//���ÿ���ؼ�,���Ƿ���DataGridLinkButton
                //��ֵ�����System.Web.UI.WebControls��û������࣬����ͨ��Response.Write(con.ToString())���ֵ�
                {
                    LinkButton lb = (LinkButton)con;
                    if (lb.CommandName == "Delete")
                    {
                        lb.Attributes.Add("onclick", "return confirm('�����Ҫɾ����')");
                    }
                }
            }
        }

        protected void rptRoleUsers_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
        {
            if (ddlModuleList.SelectedIndex > 0)
            {
                int UserId = Convert.ToInt32(e.CommandArgument);
                int RoleId = Convert.ToInt32(ddlModuleList.SelectedValue);

                switch (e.CommandName.ToLower())
                {
                    case "delete":
                        this.deleteRoleUser(UserId, RoleId);
                        this.showRoleUser(RoleId);
                        break;
                    default:
                        break;
                }
            }
        }

        protected void ddlModuleList_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            Dottext.Framework.Logger.LogManager.Log("test", "test");
            if (ddlModuleList.SelectedIndex > 0)
            {
                showRoleUser(Convert.ToInt32(ddlModuleList.SelectedValue));
                setUpdateButtonValid(true);
            }
            else
            {
                setUpdateButtonValid(false);
            }

        }


    }
}