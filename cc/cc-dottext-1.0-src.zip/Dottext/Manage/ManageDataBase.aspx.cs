using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Dottext.Framework.Data;
using System.Text.RegularExpressions;
using CchenSoft.Framework.Config;

namespace Dottext.Web.Admin.Pages
{
	/// <summary>
	/// ManageDataBase ��ժҪ˵����
	/// </summary>
	public partial class ManageDataBase : ManagePage
	{

		private void Page_Load(object sender, System.EventArgs e)
		{
			// �ڴ˴������û������Գ�ʼ��ҳ��
		}

        protected void btnExecSql_Click(object sender, System.EventArgs e)
        {
            IBlogDao blogDao = (IBlogDao)Configuration.Instance.GetBean("IBlogDao");
            string[] sqlCommands = Regex.Split(tbSqlText.Text, "\\sGO\\s", RegexOptions.IgnoreCase);
            for (int s = 0; s <= sqlCommands.GetUpperBound(0); s++)
            {
                string mySqlText = sqlCommands[s].Trim();
                if (mySqlText.Length > 0)
                {
                    blogDao.ExecuteNonQuery(CommandType.Text, mySqlText);
                }
            }

            Messages.ShowMessage("ִ�гɹ�");

        }
	}
}
