using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Configuration;
using Dottext.Framework.Components;
using Dottext.Framework;
using Dottext.Framework.Configuration;
using Dottext.Framework.Util;
using Dottext.Web.UI;
using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Service;

namespace Dottext.Web
{
    /// <summary>
    /// GetMyPassword ��ժҪ˵����
    /// </summary>
    public partial class GetMyPassword : BasePage
    {
        [Bean]
        protected IMailService mailService;

        private void Page_Load(object sender, System.EventArgs e)
        {
            // �ڴ˴������û������Գ�ʼ��ҳ��
        }

        protected void lblGetPwd_Click(object sender, System.EventArgs e)
        {
            BlogConfig config = blogService.GetConfig(tbUserName.Text);//.CurrentBlog(Context);
            if (config != null)//string.Compare(tbUserName.Text,config.UserName,true) == 0)
            {
                if (tbMail.Text != config.Email)
                {
                    Message.Text = "�û������ʼ���ַ��һ��,�޷�ȡ������";
                    return;
                }
                BlogConfigurationSettings settings = Config.Settings;
                string password = null;
                if (config.IsPasswordHashed)
                {
                    password = blogService.ResetPassword(config);

                }
                else
                {
                    password = config.Password;
                }

                string message = "��ĵ�¼�ʻ�:\n�û���: {0}\n����: {1}\n\n:{2}";
                string mainurl = Dottext.Framework.Configuration.Config.Settings.AggregateUrl;//ConfigurationSettings.AppSettings["AggregateUrl"];
                //IMailProvider mail = Dottext.Framework.Providers.EmailProvider.Instance();

                string To = config.Email;
                string From = mailService.Sender;
                string Subject = "��Ĳ��͵�¼��Ϣ";
                string Body = string.Format(message, config.UserName, password, mainurl);
                mailService.Send(From, To, Subject, Body);
                //Message.Text = "Login Credentials Sent<br>";
                Message.Text = "�������ѷ����������";
            }
            else
            {
                Message.Text = "���û�������";
            }
        }

    }
}
