﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Framework.Service;
using System.Collections;
using System.Data;
using System.Threading;
using CchenSoft.Framework.Utils;
using CchenSoft.Framework.Data;
using CchenSoft.Framework.Attributes;

namespace CchenSoft.Framework.DataAccess
{
    [BypassInterceptor]
    public class AdoDataService : IDataService
    {
        private IDataProvider provider;
        private IConverter converter;
        private string connectionString;

        public IDataProvider Provider
        {
            get { return provider; }
            set { provider = value; }
        }

        public IConverter Converter
        {
            get { return converter; }
            set { converter = value; }
        }

        public string ConnectionString
        {
            get { return connectionString; }
            set { connectionString = value; }
        }

        #region IDataService 成员

        public T Load<T>(object id)
        {
            throw new DataException("Please use QueryForObject.");
        }

        public object Insert(string statement, object parameter)
        {
            IDbConnection conn = GetConnection();
            try
            {
                CommandType cmdType = GetCommandType(statement);
                return provider.ExecuteInsert(conn, statement, cmdType, (IDbDataParameter[])parameter);
            }
            finally
            {
                CloseConnection(conn);
            }
        }

        public object QueryForObject(string statement, object parameter)
        {
            CommandType cmdType = GetCommandType(statement);
            IDataReader reader = null;
            IDbConnection conn = GetConnection();
            try
            {
                reader = provider.ExecuteReader(conn, statement, cmdType, (IDbDataParameter[])parameter);
                if (reader.Read())
                {
                    return GetValues(reader);
                }
                return null;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                CloseConnection(conn);
            }
        }

        public T QueryForObject<T>(string statement, object parameter)
        {
            CommandType cmdType = GetCommandType(statement);
            IDataReader reader = null;
            IDbConnection conn = GetConnection();
            try
            {
                reader = provider.ExecuteReader(conn, statement, cmdType, (IDbDataParameter[])parameter);
                if (reader.Read())
                {
                    return Converter.Convert<T>(reader);
                }
                return default(T);
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                CloseConnection(conn);
            }
        }

        public int Update(string statement, object parameter)
        {
            IDbConnection conn = GetConnection();
            try
            {
                CommandType cmdType = GetCommandType(statement);
                return provider.ExecuteNonQuery(conn, statement, cmdType, (IDbDataParameter[])parameter);
            }
            finally
            {
                CloseConnection(conn);
            }
        }

        public int Delete(string statement, object parameter)
        {
            IDbConnection conn = GetConnection();
            try
            {
                CommandType cmdType = GetCommandType(statement);
                return provider.ExecuteNonQuery(conn, statement, cmdType, (IDbDataParameter[])parameter);
            }
            finally
            {
                CloseConnection(conn);
            }
        }

        public IList QueryForList(string statement, object parameter)
        {
            IList result = new ArrayList();
            CommandType cmdType = GetCommandType(statement);
            IDataReader reader = null;
            IDbConnection conn = GetConnection();
            try
            {
                reader = provider.ExecuteReader(conn, statement, cmdType, (IDbDataParameter[])parameter);
                while (reader.Read())
                {
                    result.Add(GetValues(reader));
                }
                return result;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                CloseConnection(conn);
            }
        }

        public IList<T> QueryForList<T>(string statement, object parameter)
        {
            IList<T> result = new List<T>();
            CommandType cmdType = GetCommandType(statement);
            IDataReader reader = null;
            IDbConnection conn = GetConnection();
            try
            {
                reader = provider.ExecuteReader(conn, statement, cmdType, (IDbDataParameter[])parameter);
                while (reader.Read())
                {
                    result.Add(Converter.Convert<T>(reader));
                }
                return result;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                CloseConnection(conn);
            }
        }

        public IList QueryForList(string statement, object parameter, int firstResult, int maxResults)
        {
            IList result = new ArrayList();
            CommandType cmdType = GetCommandType(statement);
            IDataReader reader = null;
            IDbConnection conn = GetConnection();
            try
            {
                reader = provider.ExecuteReader(conn, statement, cmdType, (IDbDataParameter[])parameter);
                int skip = 0;
                while (reader.Read())
                {
                    if (skip++ < firstResult)
                        continue;

                    result.Add(GetValues(reader));

                    if (skip > firstResult + maxResults)
                        break;
                }
                return result;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                CloseConnection(conn);
            }
        }

        public IList<T> QueryForList<T>(string statement, object parameter, int firstResult, int maxResults)
        {
            IList<T> result = new List<T>();
            CommandType cmdType = GetCommandType(statement);
            IDataReader reader = null;
            IDbConnection conn = GetConnection();
            try
            {
                reader = provider.ExecuteReader(conn, statement, cmdType, (IDbDataParameter[])parameter);
                int skip = 0;
                while (reader.Read())
                {
                    if (skip++ < firstResult)
                        continue;

                    result.Add(Converter.Convert<T>(reader));

                    if (skip > firstResult + maxResults)
                        break;
                }
                return result;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                CloseConnection(conn);
            }
        }

        public IDbDataParameter CreateParameter(string name, object value)
        {
            IDbDataParameter parameter = provider.CreateParameter();
            parameter.ParameterName = name;
            parameter.Value = value;
            return parameter;
        }

        public DataSet QueryForDataSet(string statement, object parameter)
        {
            IDbConnection conn = GetConnection();
            try
            {
                CommandType cmdType = GetCommandType(statement);
                return provider.ExecuteDataSet(conn, statement, cmdType, (IDbDataParameter[])parameter);
            }
            finally
            {
                CloseConnection(conn);
            }
        }

        public IDataReader QueryForReader(string statement, object parameter)
        {
            IDbConnection conn = GetConnection();

            CommandType cmdType = GetCommandType(statement);
            return provider.ExecuteReader(conn, statement, cmdType, (IDbDataParameter[])parameter);
        }

        public T QueryForScalar<T>(string statement, object parameter)
        {
            IDbConnection conn = GetConnection();
            try
            {
                CommandType cmdType = GetCommandType(statement);
                object value = provider.ExecuteScalar(conn, statement, cmdType, (IDbDataParameter[])parameter);
                return (T)Convert.ChangeType(value, typeof(T));
            }
            finally
            {
                CloseConnection(conn);
            }
        }

        public int ExecuteNonQuery(string statement, object parameter)
        {
            IDbConnection conn = GetConnection();
            try
            {
                CommandType cmdType = GetCommandType(statement);
                return provider.ExecuteNonQuery(conn, statement, cmdType, (IDbDataParameter[])parameter);
            }
            finally
            {
                CloseConnection(conn);
            }
        }

        public ITransactionManager BeginTransaction()
        {
            AdoTransactionManager tm = new AdoTransactionManager();
            IDbConnection conn = provider.OpenConnection(connectionString);
            tm.Transaction = conn.BeginTransaction();
            ThreadUtil.SetVariable("tm", tm);
            return tm;
        }

        #endregion

        #region IService 成员

        public void Initialize()
        {
        }

        #endregion

        private IDictionary<string, object> GetValues(IDataReader reader)
        {
            IDictionary<string, object> vals = new Dictionary<string, object>();
            for (int i = 0; i < reader.FieldCount; i++)
            {
                vals[reader.GetName(i)] = reader.GetValue(i);
            }
            return vals;
        }

        private CommandType GetCommandType(string commandText)
        {
            int n = commandText.IndexOf(' ');
            return n > -1 ? CommandType.Text : CommandType.StoredProcedure;
        }

        private IDbConnection GetConnection()
        {
            object obj = ThreadUtil.GetVariable("tm");
            if (obj != null && obj is AdoTransactionManager)
                return ((AdoTransactionManager)obj).Transaction.Connection;

            return provider.OpenConnection(connectionString);
        }

        private void CloseConnection(IDbConnection conn)
        {
            object obj = ThreadUtil.GetVariable("tm");
            if (obj == null)
                conn.Close();
        }
    }
}
