﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.OleDb;

namespace CchenSoft.Framework.DataAccess
{
    public class OleDbDataProvider : IDataProvider
    {
        #region IDataProvider 成员

        public IDbConnection OpenConnection(string connectionString)
        {
            OleDbConnection conn = new OleDbConnection(connectionString);
            conn.Open();
            return conn;
        }

        public IDbDataParameter CreateParameter()
        {
            return new OleDbParameter();
        }

        public int ExecuteNonQuery(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters)
        {
            OleDbCommand cmd = new OleDbCommand(cmdText, (OleDbConnection)conn);
            cmd.CommandType = cmdType;
            AttachParameters(cmd, parameters);
            try
            {
                return cmd.ExecuteNonQuery();
            }
            finally
            {
                for (int i = 0; i < parameters.Length; i++)
                {
                    if (parameters[i].Direction != ParameterDirection.Input)
                        parameters[i].Value = cmd.Parameters[parameters[i].ParameterName].Value;
                }
            }
        }

        public object ExecuteInsert(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters)
        {
            OleDbCommand cmd = new OleDbCommand(cmdText, (OleDbConnection)conn);
            cmd.CommandType = cmdType;
            AttachParameters(cmd, parameters);
            cmd.ExecuteNonQuery();

            cmd = new OleDbCommand("SELECT @@Identity", (OleDbConnection)conn);
            cmd.CommandType = CommandType.Text;
            return cmd.ExecuteScalar();
        }

        public DataSet ExecuteDataSet(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters)
        {
            OleDbCommand cmd = new OleDbCommand(cmdText, (OleDbConnection)conn);
            cmd.CommandType = cmdType;
            AttachParameters(cmd, parameters);

            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }

        public IDataReader ExecuteReader(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters)
        {
            OleDbCommand cmd = new OleDbCommand(cmdText, (OleDbConnection)conn);
            cmd.CommandType = cmdType;
            AttachParameters(cmd, parameters);
            return cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }

        public object ExecuteScalar(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters)
        {
            OleDbCommand cmd = new OleDbCommand(cmdText, (OleDbConnection)conn);
            cmd.CommandType = cmdType;
            AttachParameters(cmd, parameters);
            return cmd.ExecuteScalar();
        }

        #endregion

        private void AttachParameters(OleDbCommand cmd, IDbDataParameter[] parameters)
        {
            if (parameters != null)
            {
                for (int i = 0; i < parameters.Length; i++)
                {
                    cmd.Parameters.Add(parameters[i]);
                }
            }
        }
    }
}
