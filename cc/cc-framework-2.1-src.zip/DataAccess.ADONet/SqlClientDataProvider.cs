﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace CchenSoft.Framework.DataAccess
{
    public class SqlClientDataProvider : IDataProvider
    {
        #region IDataProvider 成员

        public IDbConnection OpenConnection(string connectionString)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            return conn;
        }

        public IDbDataParameter CreateParameter()
        {
            return new SqlParameter();
        }

        public int ExecuteNonQuery(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters)
        {
            SqlCommand cmd = new SqlCommand(cmdText, (SqlConnection)conn);
            try
            {
                cmd.CommandType = cmdType;
                AttachParameters(cmd, parameters);
                return cmd.ExecuteNonQuery();
            }
            finally
            {
                for (int i = 0; i < parameters.Length; i++)
                {
                    if (parameters[i].Direction != ParameterDirection.Input)
                        parameters[i].Value = cmd.Parameters[parameters[i].ParameterName].Value;
                }
                cmd.Parameters.Clear();
            }
        }

        public object ExecuteInsert(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters)
        {
            SqlCommand cmd = new SqlCommand(cmdText, (SqlConnection)conn);
            try
            {
                cmd.CommandType = cmdType;
                AttachParameters(cmd, parameters);
                cmd.ExecuteNonQuery();

                cmd = new SqlCommand("SELECT @@Identity", (SqlConnection)conn);
                cmd.CommandType = CommandType.Text;
                return cmd.ExecuteScalar();
            }
            finally
            {
                cmd.Parameters.Clear();
            }
        }

        public DataSet ExecuteDataSet(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters)
        {
            SqlCommand cmd = new SqlCommand(cmdText, (SqlConnection)conn);
            try
            {
                cmd.CommandType = cmdType;
                AttachParameters(cmd, parameters);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds;
            }
            finally
            {
                cmd.Parameters.Clear();
            }
        }

        public IDataReader ExecuteReader(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters)
        {
            SqlCommand cmd = new SqlCommand(cmdText, (SqlConnection)conn);
            try
            {
                cmd.CommandType = cmdType;
                AttachParameters(cmd, parameters);
                return cmd.ExecuteReader();
            }
            finally
            {
                cmd.Parameters.Clear();
            }
        }

        public object ExecuteScalar(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters)
        {
            SqlCommand cmd = new SqlCommand(cmdText, (SqlConnection)conn);
            try
            {
                cmd.CommandType = cmdType;
                AttachParameters(cmd, parameters);
                return cmd.ExecuteScalar();
            }
            finally
            {
                cmd.Parameters.Clear();
            }
        }

        #endregion

        private void AttachParameters(SqlCommand cmd, IDbDataParameter[] parameters)
        {
            if (parameters != null)
            {
                for (int i = 0; i < parameters.Length; i++)
                {
                    cmd.Parameters.Add(parameters[i]);
                }
            }
        }
    }
}
