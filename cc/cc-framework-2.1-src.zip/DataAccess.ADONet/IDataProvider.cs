﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace CchenSoft.Framework.DataAccess
{
    public interface IDataProvider
    {
        IDbConnection OpenConnection(string connectionString);

        IDbDataParameter CreateParameter();

        int ExecuteNonQuery(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters);

        object ExecuteInsert(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters);

        DataSet ExecuteDataSet(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters);

        IDataReader ExecuteReader(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters);

        object ExecuteScalar(IDbConnection conn, string cmdText, CommandType cmdType, IDbDataParameter[] parameters);
    }
}
