﻿using System;
using System.Collections.Generic;
using System.Text;
using IBatisNet.DataMapper.TypeHandlers;
using System.Globalization;

namespace CchenSoft.Framework.DataAccess
{
    public class DateTimeTypeHandler : ITypeHandlerCallback
    {
        #region ITypeHandlerCallback Members

        public object NullValue
        {
            get { return null; }
        }

        public object ValueOf(string s)
        {
            return s;
        }

        public object GetResult(IResultGetter getter)
        {
            if (getter.Value != DBNull.Value)
                return Convert.ToDateTime(getter.Value);
            return null;
        }

        public void SetParameter(IParameterSetter setter, object parameter)
        {
            if (parameter is DateTime)
            {
                setter.Value = ((DateTime)parameter).ToString("yyyy-MM-dd HH:mm:ss");
            }
            else
            {
                DateTime? dt = (DateTime?)parameter;
                if (dt.HasValue)
                    setter.Value = dt.Value.ToString("yyyy-MM-dd HH:mm:ss");
            }
        }

        #endregion
    }
}
