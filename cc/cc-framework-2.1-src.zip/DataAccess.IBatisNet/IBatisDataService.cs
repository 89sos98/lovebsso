#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using IBatisNet.DataMapper;
using IBatisNet.DataMapper.Configuration;
using System.Data;
using System.Collections;
using System.Xml;
using System.IO;
using System.Web;
using CchenSoft.Framework.Data;
using CchenSoft.Framework.Utils;
using System.Reflection;
using IBatisNet.DataMapper.SessionStore;
using System.Globalization;
using CchenSoft.Framework.Attributes;

namespace CchenSoft.Framework.DataAccess
{
    [BypassInterceptor]
    public class IBatisDataService : IDataService
    {
        private ISqlMapper mapper;
        private string connectionString;
        private string excludeAssemblies;
        private IList mappings;

        public IBatisDataService()
        {
        }

        public string ConnectionString
        {
            get { return connectionString; }
            set { connectionString = value; }
        }

        public string ExcludeAssemblies
        {
            get { return excludeAssemblies; }
            set { excludeAssemblies = value; }
        }

        public IList Mappings
        {
            get { return mappings; }
            set { mappings = value; }
        }

        public void Initialize()
        {
            string rootpath = "";
            string binpath = "";

            if (HttpContext.Current != null)
            {
                rootpath = HttpContext.Current.Server.MapPath("~/");
                binpath = rootpath + "\\bin\\";
            }
            else
            {
                rootpath = AppDomain.CurrentDomain.BaseDirectory;
                binpath = rootpath;
            }

            string xml = "";
            using (StreamReader reader = new StreamReader(rootpath + "sqlmap.config"))
            {
                xml = reader.ReadToEnd();
            }

            StringBuilder sb = new StringBuilder();

            // add files.
            if (mappings != null)
            {
                for (int i = 0; i < mappings.Count; i++)
                {
                    sb.AppendFormat("<sqlMap resource=\"{0}\"/>", mappings[i])
                        .AppendFormat(Environment.NewLine);
                }
            }

            // add embeddeds.
            if (!string.IsNullOrEmpty(excludeAssemblies))
            {
                string[] excludes = excludeAssemblies.Split(new char[] { ',', ';' });

                string[] files = Directory.GetFiles(binpath, "*.dll");
                for (int i = 0; i < files.Length; i++)
                {
                    string fullname = files[i];
                    string filename = Path.GetFileName(fullname);
                    bool skip = false;
                    for (int j = 0; j < excludes.Length; j++)
                    {
                        if (filename.StartsWith(excludes[j], StringComparison.CurrentCultureIgnoreCase))
                        {
                            skip = true;
                            break;
                        }
                    }

                    if (skip) continue;

                    Assembly assm = Assembly.LoadFrom(fullname);

                    string[] resNames = assm.GetManifestResourceNames();
                    for (int j = 0; j < resNames.Length; j++)
                    {
                        if (resNames[j].EndsWith(".ibm.xml", StringComparison.CurrentCultureIgnoreCase))
                        {
                            sb.AppendFormat("<sqlMap embedded=\"{0},{1}\"/>", resNames[j], assm.FullName)
                                .AppendFormat(Environment.NewLine);
                        }
                    }
                }
            }

            xml = xml.Replace("#sqlMaps#", sb.ToString());
            xml = xml.Replace("#connectionString#", connectionString);

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);

            DomSqlMapBuilder builder = new DomSqlMapBuilder();
            mapper = builder.Configure(doc);

            //CallContextSessionStore ss = new CallContextSessionStore(mapper.Id);
            //mapper.SessionStore = ss;
        }

        public T Load<T>(object id)
        {
            throw new DataException("Please use QueryForObject.");
        }

        public object Insert(string statement, object parameter)
        {
            return mapper.Insert(statement, parameter);
        }

        public object QueryForObject(string statement, object parameter)
        {
            return mapper.QueryForObject(statement, parameter);
        }

        public T QueryForObject<T>(string statement, object parameter)
        {
            return mapper.QueryForObject<T>(statement, parameter);
        }

        public int Update(string statement, object parameter)
        {
            return mapper.Update(statement, parameter);
        }

        public int Delete(string statement, object parameter)
        {
            return mapper.Delete(statement, parameter);
        }

        public IList QueryForList(string statement, object parameter)
        {
            return mapper.QueryForList(statement, parameter);
        }

        public IList<T> QueryForList<T>(string statement, object parameter)
        {
            return mapper.QueryForList<T>(statement, parameter);
        }

        public IList QueryForList(string statement, object parameter, int firstResult, int maxResults)
        {
            return mapper.QueryForList(statement, parameter, firstResult, maxResults);
        }

        public IList<T> QueryForList<T>(string statement, object parameter, int firstResult, int maxResults)
        {
            return mapper.QueryForList<T>(statement, parameter, firstResult, maxResults);
        }

        public ITransactionManager BeginTransaction()
        {
            IBatisTransactionManager tm = new IBatisTransactionManager();
            tm.Session = mapper.BeginTransaction();
            ThreadUtil.SetVariable("tm", tm);
            return tm;
        }

        public IDbDataParameter CreateParameter(string name, object value)
        {
            if (!mapper.IsSessionStarted)
                mapper.OpenConnection();

            IDbDataParameter parameter = mapper.LocalSession.CreateDataParameter();
            parameter.ParameterName = name;
            parameter.Value = value;

            return parameter;
        }

        public T QueryForScalar<T>(string statement, object parameter)
        {
            return QueryForObject<T>(statement, parameter);
        }

        public DataSet QueryForDataSet(string statement, object parameter)
        {
            if (!mapper.IsSessionStarted)
                mapper.OpenConnection();

            IDbCommand command = mapper.LocalSession.CreateCommand(CommandType.Text);
            command.CommandText = statement;
            AttachParameters(command, parameter);

            IDbDataAdapter adapter = mapper.LocalSession.CreateDataAdapter(command);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            return ds;
        }

        public IDataReader QueryForReader(string statement, object parameter)
        {
            if (!mapper.IsSessionStarted)
                mapper.OpenConnection();

            IDbCommand command = mapper.LocalSession.CreateCommand(CommandType.Text);
            command.CommandText = statement;
            AttachParameters(command, parameter);

            command.Prepare();
            return command.ExecuteReader();
        }

        public int ExecuteNonQuery(string statement, object parameter)
        {
            if (!mapper.IsSessionStarted)
                mapper.OpenConnection();

            IDbCommand command = mapper.LocalSession.CreateCommand(CommandType.Text);
            command.CommandText = statement;
            AttachParameters(command, parameter);

            return command.ExecuteNonQuery();
        }

        private void AttachParameters(IDbCommand cmd, object parameter)
        {
            if (parameter != null)
            {
                if (parameter is IList<IDbDataParameter>)
                {
                    IList<IDbDataParameter> parameters = (IList<IDbDataParameter>)parameter;
                    foreach (IDbDataParameter param in parameters)
                    {
                        cmd.Parameters.Add(param);
                    }
                }
            }
        }
    }
}
