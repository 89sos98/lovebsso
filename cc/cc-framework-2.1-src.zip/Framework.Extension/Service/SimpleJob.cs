﻿using System;
using System.Collections.Generic;
using System.Text;
using Quartz;
using CchenSoft.Framework.Config;
using System.Reflection;
using System.Collections.Specialized;

namespace CchenSoft.Framework.Extension.Service
{
    public class SimpleJob
    {
        private string beanName;
        private string method;
        private int minutes;
        private string name;
        public int count;
        private DateTime? lastExecuted;

        public string BeanName
        {
            get { return beanName; }
            set { beanName = value; }
        }

        public string Method
        {
            get { return method; }
            set { method = value; }
        }

        public int Minutes
        {
            get { return minutes; }
            set { minutes = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public DateTime? LastExecuted
        {
            get { return lastExecuted; }
        }

        public int Count
        {
            get { return count; }
        }

        private object beanObject;
        private MethodInfo invokeMethod;
        private bool running = false;

        public void Execute()
        {
            if (running)
                return;

            running = true;
            try
            {
                if (beanObject == null)
                {
                    beanObject = FxConfiguration.Instance.GetBean(beanName);
                    if (beanObject != null)
                    {
                        string mname = string.IsNullOrEmpty(method) ? "Execute" : method;
                        invokeMethod = beanObject.GetType().GetMethod(mname, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
                    }
                }

                if (beanObject != null && invokeMethod != null)
                {
                    invokeMethod.Invoke(beanObject, null);

                    lastExecuted = DateTime.Now;
                    count++;
                }
            }
            finally
            {
                running = false;
            }
        }
    }
}
