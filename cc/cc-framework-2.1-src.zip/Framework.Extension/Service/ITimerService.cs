﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Framework.Extension.Service
{
    public interface ITimerService : IService
    {
        string Configuration { get; set; }

        ICollection<SimpleJob> Jobs { get; }

        void ScheduleJob(SimpleJob job);

        void Shutdown();
    }
}
