﻿using System;
using System.Collections.Generic;
using System.Text;
using Quartz;
using Quartz.Impl;
using System.Xml;
using CchenSoft.Framework.Utils;

namespace CchenSoft.Framework.Extension.Service.Impl
{
    public class TimerServiceImpl : ITimerService
    {
        private IScheduler sched;
        private string configuration;
        private IList<SimpleJob> jobs;

        public TimerServiceImpl()
        {
            jobs = new List<SimpleJob>();
        }

        #region ITimerService 成员

        public string Configuration
        {
            get { return configuration; }
            set { configuration = value; }
        }

        public ICollection<SimpleJob> Jobs
        {
            get { return jobs; }
        }

        public void ScheduleJob(SimpleJob job)
        {
            string cron = string.Format("0 0/{0} * * * ?", job.Minutes);
            JobDetail detail = new JobDetail(job.Name, null, typeof(QuartzJob));
            detail.JobDataMap["job"] = job;
            CronTrigger trigger = new CronTrigger(job.Name + "Trigger", null, job.Name, null, cron);
            sched.AddJob(detail, true);
            sched.ScheduleJob(trigger);
        }

        public void Shutdown()
        {
            if (sched != null)
            {
                sched.Shutdown(true);
            }
        }

        #endregion

        #region IService 成员

        public void Initialize()
        {
            sched = new StdSchedulerFactory().GetScheduler();

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(configuration);

            XmlNodeList nodes = doc.DocumentElement.SelectNodes("job");
            foreach (XmlNode node in nodes)
            {
                SimpleJob job = new SimpleJob();

                foreach (XmlAttribute attr in node.Attributes)
                {
                    ReflectUtil.SetPropertyValue(job, attr.Name, attr.Value);
                }

                jobs.Add(job);

                ScheduleJob(job);
            }

            // 启动调度
            sched.Start();
        }

        #endregion

        private class QuartzJob : IJob
        {
            #region IJob 成员

            public void Execute(JobExecutionContext context)
            {
                SimpleJob job = (SimpleJob)context.JobDetail.JobDataMap["job"];
                job.Execute();
            }

            #endregion
        }
    }
}
