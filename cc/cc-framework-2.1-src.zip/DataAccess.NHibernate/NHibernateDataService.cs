#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Collections;
using System.Web;
using System.Data;
using System.IO;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Context;
using NHibernate.Engine;
using NHibernateEnvironment = NHibernate.Cfg.Environment;

using CchenSoft.Framework.Data;
using CchenSoft.Framework.Utils;
using NHibernate.Type;
using System.Globalization;
using CchenSoft.Framework.Attributes;

namespace CchenSoft.Framework.DataAccess
{
    [BypassInterceptor]
    public class NHibernateDataService : IDataService
    {
        private static ISessionFactory sessionFactory = null;
        private string connectionString;
        private string parameterClass;
        private string dataAdapterClass;
        private string excludeAssemblies;
        private IList mappings;
        private ICurrentSessionContext csc;
        private IInterceptor interceptor;

        public NHibernateDataService()
        {
            mappings = new ArrayList();
        }

        public IInterceptor Interceptor
        {
            set { interceptor = value; }
            get { return interceptor; }
        }

        public void Initialize()
        {
            string rootpath = "";
            string binpath = "";
            if (HttpContext.Current != null)
            {
                rootpath = HttpContext.Current.Server.MapPath("~/");
                binpath = rootpath + "\\bin\\";
            }
            else
            {
                rootpath = AppDomain.CurrentDomain.BaseDirectory;
                binpath = rootpath;
            }

            Configuration cfg = new Configuration().Configure(rootpath + "hibernate.cfg.xml");
            cfg.SetProperty(NHibernateEnvironment.ConnectionString, connectionString);

            // add files.
            if (mappings != null)
            {
                foreach (string xmlfile in mappings)
                {
                    cfg.AddFile(rootpath + xmlfile);
                }
            }

            // add embeddeds.
            if (!string.IsNullOrEmpty(excludeAssemblies))
            {
                string[] excludes = excludeAssemblies.Split(new char[] { ',', ';' });

                string[] files = Directory.GetFiles(binpath, "*.dll");
                for (int i = 0; i < files.Length; i++)
                {
                    string fullname = files[i];
                    string filename = Path.GetFileName(fullname);
                    bool skip = false;
                    for (int j = 0; j < excludes.Length; j++)
                    {
                        if (filename.StartsWith(excludes[j], StringComparison.CurrentCultureIgnoreCase))
                        {
                            skip = true;
                            break;
                        }
                    }

                    if (skip) continue;

                    Assembly assm = Assembly.LoadFrom(fullname);
                    cfg.AddAssembly(assm);
                }
            }

            if (interceptor != null)
                cfg.Interceptor = interceptor;
            sessionFactory = cfg.BuildSessionFactory();
            csc = new ThreadStaticSessionContext((ISessionFactoryImplementor)sessionFactory);
        }

        public string ExcludeAssemblies
        {
            get { return excludeAssemblies; }
            set { excludeAssemblies = value; }
        }

        public IList Mappings
        {
            get { return mappings; }
            set { mappings = value; }
        }

        public string ParameterClass
        {
            get { return parameterClass; }
            set { parameterClass = value; }
        }

        public string DataAdapterClass
        {
            get { return dataAdapterClass; }
            set { dataAdapterClass = value; }
        }

        public string ConnectionString
        {
            get { return connectionString; }
            set { connectionString = value; }
        }

        protected ISession OpenSession()
        {
            return csc.CurrentSession();
        }

        protected ISessionFactory SessionFactory
        {
            get { return sessionFactory; }
        }

        #region IDataService ��Ա

        private void AttachParameters(IQuery query, object parameter)
        {
            if (parameter is IDictionary<string, object>)
            {
                IDictionary<string, object> dict = (IDictionary<string, object>)parameter;
                foreach (string name in dict.Keys)
                {
                    if (dict[name] is ICollection)
                        query.SetParameterList(name, (ICollection)dict[name]);
                    else
                        query.SetParameter(name, dict[name]);
                }
            }
        }

        public T QueryForObject<T>(string statement, object parameter)
        {
            ISession session = OpenSession();

            T obj = default(T);
            IQuery query = session.CreateQuery(statement);
            AttachParameters(query, parameter);

            IList list = query.List();
            if (list.Count > 0)
                obj = (T)Convert.ChangeType(list[0], typeof(T));

            return obj;
        }

        public object QueryForObject(string statement, object parameter)
        {
            ISession session = OpenSession();

            object obj = null;
            IQuery query = session.CreateQuery(statement);
            AttachParameters(query, parameter);
            IList list = query.List();
            if (list.Count > 0)
                obj = (list[0]);

            return obj;
        }

        public IList QueryForList(string statement, object parameter)
        {
            ISession session = OpenSession();

            IQuery query = session.CreateQuery(statement);
            AttachParameters(query, parameter);

            return query.List();
        }

        public IList QueryForList(string statement, object parameter, int firstResult, int maxResults)
        {
            ISession session = OpenSession();

            IQuery query = session.CreateQuery(statement);
            AttachParameters(query, parameter);

            query.SetFirstResult(firstResult);
            query.SetMaxResults(maxResults);
            return query.List();
        }

        public IList<T> QueryForList<T>(string statement, object parameter)
        {
            ISession session = OpenSession();

            IQuery query = session.CreateQuery(statement);
            AttachParameters(query, parameter);

            return query.List<T>();
        }

        public IList<T> QueryForList<T>(string statement, object parameter, int firstResult, int maxResults)
        {
            ISession session = OpenSession();

            IQuery query = session.CreateQuery(statement);
            AttachParameters(query, parameter);

            query.SetFirstResult(firstResult);
            query.SetMaxResults(maxResults);
            return query.List<T>();
        }


        public T Load<T>(object id)
        {
            ISession s = OpenSession();
            return s.Get<T>(id);
        }

        public object Insert(string statement, object parameter)
        {
            ISession s = OpenSession();

            s.Save(parameter);
            s.Flush();
            return parameter;
        }

        public int Update(string statement, object parameter)
        {
            ISession s = OpenSession();
            s.Update(parameter);
            s.Flush();
            return 1;
        }

        public int Delete(string statement, object parameter)
        {
            if (string.IsNullOrEmpty(statement))
            {
                ISession s = OpenSession();
                s.Delete(parameter);
                s.Flush();
                return 1;
            }
            else
            {
                int ret = 0;
                ISession s = OpenSession();
                if (parameter == null)
                {
                    ret = s.Delete(statement);
                }
                else if (parameter is IDictionary<int, object>)
                {
                    IDictionary<int, object> objects = (IDictionary<int, object>)parameter;
                    object[] values = new object[objects.Count];
                    IType[] types = new IType[values.Length];

                    foreach (int n in objects.Keys)
                    {
                        values[n] = objects[n];
                        types[n] = NHibernateUtil.GuessType(values[n]);
                    }

                    ret = s.Delete(statement, values, types);
                }
                else
                {
                    ret = s.Delete(statement, parameter, NHibernateUtil.GuessType(parameter));
                }

                return ret;
            }
        }

        public IDbDataParameter CreateParameter(string name, object value)
        {
            Type parameterClazz = Type.GetType(parameterClass);
            IDbDataParameter parameter = (IDbDataParameter)Activator.CreateInstance(parameterClazz);
            parameter.ParameterName = name;
            parameter.Value = value;
            return parameter;
        }

        private IDbDataAdapter CreateDataAdapter()
        {
            Type dataAdpaterClazz = Type.GetType(dataAdapterClass);
            return (IDbDataAdapter)Activator.CreateInstance(dataAdpaterClazz);
        }

        public T QueryForScalar<T>(string statement, object parameter)
        {
            return QueryForObject<T>(statement, parameter);
        }

        public DataSet QueryForDataSet(string statement, object parameter)
        {
            IDbConnection conn = sessionFactory.ConnectionProvider.GetConnection();
            IDbCommand command = conn.CreateCommand();
            command.CommandType = CommandType.Text;
            command.CommandText = statement;
            AttachParameters(command, parameter);
            IDbDataAdapter adapter = CreateDataAdapter();
            adapter.SelectCommand = command;
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            return ds;
        }

        public IDataReader QueryForReader(string statement, object parameter)
        {
            IDbConnection conn = sessionFactory.ConnectionProvider.GetConnection();
            IDbCommand command = conn.CreateCommand();
            command.CommandType = CommandType.Text;
            command.CommandText = statement;
            AttachParameters(command, parameter);
            command.Prepare();
            return command.ExecuteReader();
        }

        public int ExecuteNonQuery(string statement, object parameter)
        {
            IDbConnection conn = sessionFactory.ConnectionProvider.GetConnection();
            IDbCommand command = conn.CreateCommand();
            command.CommandType = CommandType.Text;
            command.CommandText = statement;
            AttachParameters(command, parameter);
            return command.ExecuteNonQuery();
        }

        public ITransactionManager BeginTransaction()
        {
            NHibernateTransactionManager tm = new NHibernateTransactionManager();
            ISession session = OpenSession();
            tm.Transaction = session.BeginTransaction();
            ThreadUtil.SetVariable("tm", tm);
            return tm;
        }

        private void AttachParameters(IDbCommand cmd, object parameter)
        {
            if (parameter != null)
            {
                if (parameter is IList<IDbDataParameter>)
                {
                    IList<IDbDataParameter> parameters = (IList<IDbDataParameter>)parameter;
                    foreach (IDbDataParameter param in parameters)
                    {
                        cmd.Parameters.Add(param);
                    }
                }
            }
        }

        #endregion
    }
}
