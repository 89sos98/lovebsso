﻿using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Framework.Interceptors;

namespace CchenSoft.Framework
{
    public interface IFactory
    {
        void Initialize();

        object Create(IServiceInterceptor[] interceptors);
    }
}
