﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Interceptors;
using CchenSoft.Framework.Utils;
using CchenSoft.Framework.Config;
using Castle.DynamicProxy;
using System.Web.SessionState;

namespace CchenSoft.Framework
{
    public class FxModule : IHttpModule
    {
        #region IHttpModule 成员

        public void Dispose()
        {
        }

        public void Init(HttpApplication context)
        {
            //context.BeginRequest += new EventHandler(context_BeginRequest);
            context.PreRequestHandlerExecute += new EventHandler(context_PreRequestHandlerExecute);
        }

        void context_PreRequestHandlerExecute(object sender, EventArgs e)
        {        
            HttpContext context = ((HttpApplication)sender).Context;
            
            BypassInterceptorAttribute[] bypassAttrs = ReflectUtil.GetCustomAttributes<BypassInterceptorAttribute>(context.Handler.GetType());
            
            IServiceInterceptor[] interceptors = FxConfiguration.Instance.PageInterceptors;
            if (bypassAttrs.Length == 0 && interceptors != null && interceptors.Length > 0)
            {
                // 创建 proxy.
                ProxyGenerator gen = new ProxyGenerator();
                Type[] intfs = new Type[] { typeof(IHttpHandler), typeof(IRequiresSessionState) };
                context.Handler = (IHttpHandler)gen.CreateInterfaceProxyWithTarget(typeof(IHttpHandler), intfs, context.Handler, new ServiceInterceptor(interceptors));
            }
        }

        #endregion
    }
}
