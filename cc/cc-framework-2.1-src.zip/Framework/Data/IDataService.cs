﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;

namespace CchenSoft.Framework.Data
{
    public interface IDataService : IService
    {
        T Load<T>(object id);

        object Insert(string statement, object parameter);

        object QueryForObject(string statement, object parameter);

        T QueryForObject<T>(string statement, object parameter);

        int Update(string statement, object parameter);

        int Delete(string statement, object parameter);

        IList QueryForList(string statement, object parameter);

        IList<T> QueryForList<T>(string statement, object parameter);

        IList QueryForList(string statement, object parameter, int firstResult, int maxResults);

        IList<T> QueryForList<T>(string statement, object parameter, int firstResult, int maxResults);

        IDbDataParameter CreateParameter(string name, object value);

        DataSet QueryForDataSet(string statement, object parameter);

        IDataReader QueryForReader(string statement, object parameter);

        T QueryForScalar<T>(string statement, object parameter);

        int ExecuteNonQuery(string statement, object parameter);

        ITransactionManager BeginTransaction();
    }
}
