﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Framework.Utils;
using System.Reflection;

namespace CchenSoft.Framework.Config
{
    public class RefInfo
    {
        private object target;
        private MethodInfo setter;
        private string refBean;

        public RefInfo(string refBean)
        {
            this.refBean = refBean;
        }

        public RefInfo(string refBean, object target, MethodInfo setter)
        {
            this.refBean = refBean;
            this.target = target;
            this.setter = setter;
        }

        public string RefBean
        {
            get { return refBean; }
        }

        public object Target
        {
            set { target = value; }
            get { return target; }
        }

        public MethodInfo Setter
        {
            set { setter = value; }
            get { return setter; }
        }

        public virtual void SetRef(Dictionary<string, object> beans)
        {
            if (beans.ContainsKey(refBean))
            {
                object bean = beans[refBean];
                if (typeof(IFactory).IsInstanceOfType(bean))
                    bean = ((IFactory)bean).Create(FxConfiguration.Instance.ServiceInterceptors);

                setter.Invoke(target, new object[] { bean });
            }
        }
    }
}
