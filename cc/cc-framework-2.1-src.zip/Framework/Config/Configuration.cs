#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Xml;
using Castle.DynamicProxy;
using System.Collections;
using System.Reflection;
using CchenSoft.Framework.Interceptors;
using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Utils;
using System.Web;
using System.IO;

namespace CchenSoft.Framework.Config
{
    [Obsolete("Please use FxConfiguration class.")]
    public class Configuration : FxConfiguration
    {
       
    }
}
