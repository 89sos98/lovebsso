#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Xml;
using Castle.DynamicProxy;
using System.Collections;
using System.Reflection;
using CchenSoft.Framework.Interceptors;
using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Utils;
using System.Web;
using System.IO;
using System.Security.Permissions;

namespace CchenSoft.Framework.Config
{
    public class FxConfiguration
    {
        private static FxConfiguration instance;
        private static readonly object lockObj = new object();

        private Dictionary<string, IService> services;
        private Dictionary<string, object> beans;
        private List<IServiceInterceptor> serviceInterceptors;
        private List<IServiceInterceptor> pageInterceptors;
        private List<RefInfo> refs;
        private List<string> serviceInterceptorRefs;
        private List<string> pageInterceptorRefs;

        protected FxConfiguration()
        {
            refs = new List<RefInfo>();
            beans = new Dictionary<string, object>();
            services = new Dictionary<string, IService>();
            
            serviceInterceptors = new List<IServiceInterceptor>();
            serviceInterceptorRefs = new List<string>();

            pageInterceptors = new List<IServiceInterceptor>();
            pageInterceptorRefs = new List<string>();

            XmlNode node = (XmlNode)ConfigurationManager.GetSection("cc-framework");
            Configure(node);

            // newst.
            XmlNode cfgNode = node.SelectSingleNode("configsFolder");
            string configsFolder = (cfgNode != null) ? cfgNode.InnerText : "";
            if (!string.IsNullOrEmpty(configsFolder))
            {
                string folder = GetFolder(configsFolder);

                string[] files = Directory.GetFiles(folder, "*.config");
                for (int i = 0; i < files.Length; i++)
                    Configure(files[i]);

                WatchConfigs(folder);
            }
        }

        [PermissionSet(SecurityAction.Demand, Name = "FullTrust")]
        private void WatchConfigs(string folder)
        {
            // watch configs.
            FileSystemWatcher watcher = new FileSystemWatcher(folder, "*.config");

            watcher.Changed += new FileSystemEventHandler(OnChanged);
            watcher.Created += new FileSystemEventHandler(OnChanged);
            watcher.Deleted += new FileSystemEventHandler(OnChanged);
            watcher.Renamed += new RenamedEventHandler(OnRenamed);

            // Begin watching.
            watcher.EnableRaisingEvents = true;
        }

        private void OnChanged(object sender, FileSystemEventArgs e)
        {
            lock (lockObj)
            {
                instance = null;
            }
        }

        private void OnRenamed(object sender, RenamedEventArgs e)
        {
            lock (lockObj)
            {
                instance = null;
            }
        }

        private static string GetFolder(string configsFolder)
        {
            return HttpContext.Current != null 
                ? HttpContext.Current.Server.MapPath(configsFolder)
                : AppDomain.CurrentDomain.BaseDirectory + "\\" + configsFolder;
        }

        public IServiceInterceptor[] ServiceInterceptors
        {
            get { return serviceInterceptors.ToArray(); }
        }

        public IServiceInterceptor[] PageInterceptors
        {
            get { return pageInterceptors.ToArray(); }
        }

        public static FxConfiguration Instance
        {
            get 
            {
                lock (lockObj)
                {
                    if (instance == null)
                    {
                        instance = new FxConfiguration();
                        instance.Initialize();
                    }
                    return instance;
                }
            }
        }

        private void Configure(XmlNode node)
        {
            // service interceptor.
            ParseInterceptors(node.SelectSingleNode("service-interceptors"), serviceInterceptors, serviceInterceptorRefs);

            // page interceptor.
            ParseInterceptors(node.SelectSingleNode("page-interceptors"), pageInterceptors, pageInterceptorRefs);

            // beans.
            ParseBeans(node.SelectNodes("bean"));
        }

        public void Configure(string fileName)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(fileName);
            Configure(doc.DocumentElement);
        }

        private void Initialize()
        {
            // handle interceptor
            foreach (string beanName in serviceInterceptorRefs)
            {
                if (beans.ContainsKey(beanName))
                {
                    object bean = beans[beanName];
                    IServiceInterceptor si = bean as IServiceInterceptor;
                    if (si != null)
                        serviceInterceptors.Add(si);
                }
            }

            foreach (string beanName in pageInterceptorRefs)
            {
                if (beans.ContainsKey(beanName))
                {
                    object obj = beans[beanName];
                    if (obj is IServiceInterceptor)
                        pageInterceptors.Add((IServiceInterceptor)obj);
                }
            }

            // Inject
            foreach (RefInfo ri in refs)
            {
                ri.SetRef(beans);
            }

            foreach (object bean in beans.Values)
            {
                ReflectUtil.InjectBeans(bean);  // ���� BeanAttribute ע��

                if (bean is IService)
                    ((IService)bean).Initialize();
                else if (bean is IFactory)
                    ((IFactory)bean).Initialize();
            }
        }

        public T GetService<T>()
        {
            string serviceName = typeof(T).Name;
            if (services.ContainsKey(serviceName))
                return (T)services[serviceName];

            if (beans.ContainsKey(serviceName))
            {
                object obj = beans[serviceName];
                if (obj is IFactory)
                    return (T)((IFactory)obj).Create(serviceInterceptors.ToArray());
            }

            return default(T);
        }

        public object GetBean(string beanName)
        {
            if (beans.ContainsKey(beanName))
                return beans[beanName];
            return null;
        }

        private void ParseInterceptors(XmlNode node,
            List<IServiceInterceptor> interceptors, List<string> interceptorRefs)
        {
            if (node == null)
                return;

            XmlNodeList list = node.SelectNodes("interceptor");
            foreach (XmlNode interceptorNode in list)
            {
                XmlAttribute attrRef = (XmlAttribute)interceptorNode.Attributes.GetNamedItem("ref");
                if (attrRef != null)
                {
                    interceptorRefs.Add(attrRef.Value);
                }
                else
                {
                    XmlAttribute attrType = (XmlAttribute)interceptorNode.Attributes.GetNamedItem("type");
                    if (attrType != null)
                    {
                        string typeName = attrType.Value;
                        Type type = Type.GetType(typeName);
                        if (type == null)
                            throw new ConfigurationException("�޷�ȡ��Interceptor����: " + typeName);

                        IServiceInterceptor interceptor = (IServiceInterceptor)Activator.CreateInstance(type);
                        XmlNodeList list2 = interceptorNode.SelectNodes("property");

                        foreach (XmlNode node2 in list2)
                        {
                            string name = node2.Attributes.GetNamedItem("name").Value;
                            object value = GetNodeValue(node2);
                            ReflectUtil.SetPropertyValue(interceptor, name, value);
                        }

                        interceptors.Add(interceptor);
                    }
                }
            }
        }

        private void ParseBeans(XmlNodeList list)
        {
            foreach (XmlNode node in list)
            {
                string beanName = node.Attributes.GetNamedItem("name").Value;
                string typeName = node.Attributes.GetNamedItem("type").Value;
                Type beanType = Type.GetType(typeName);
                if (beanType == null)
                    throw new ConfigurationException("�޷�ȡ��Bean����: " + typeName);

                object bean = Activator.CreateInstance(beanType);

                XmlNodeList list2 = node.SelectNodes("property");

                foreach (XmlNode node2 in list2)
                {
                    string name = node2.Attributes.GetNamedItem("name").Value;
                    XmlAttribute attrRef = (XmlAttribute)node2.Attributes.GetNamedItem("ref");
                    if (attrRef == null)
                    {
                        object value = GetNodeValue(node2);
                        RefInfo ri = value as RefInfo;
                        if (ri != null)
                        {
                            PropertyInfo pi = beanType.GetProperty(name);
                            if (pi != null)
                            {
                                ri.Target = bean;
                                ri.Setter = pi.GetSetMethod();
                                refs.Add(ri);
                            }
                        }
                        else
                        {
                            ReflectUtil.SetPropertyValue(bean, name, value);
                        }
                    }
                    else
                    {
                        PropertyInfo pi = beanType.GetProperty(name);
                        if (pi != null)
                        {
                            RefInfo ri = new RefInfo(attrRef.Value, bean, pi.GetSetMethod());
                            refs.Add(ri);
                        }
                    }
                }

                beans.Add(beanName, bean);

                IService service = bean as IService;
                if (service != null)
                {
                    BypassInterceptorAttribute[] bypassAttrs = ReflectUtil.GetCustomAttributes<BypassInterceptorAttribute>(beanType);

                    IServiceInterceptor[] interceptors = serviceInterceptors.ToArray();

                    if (bypassAttrs.Length > 0 || interceptors == null || interceptors.Length == 0)
                    {
                        services.Add(beanName, service);
                    }
                    else
                    {
                        // ���� proxy.
                        ProxyGenerator gen = new ProxyGenerator();
                        IService serviceProxy = (IService)gen.CreateInterfaceProxyWithTarget(typeof(IService), beanType.GetInterfaces(), service, new ServiceInterceptor(interceptors));
                        services.Add(beanName, serviceProxy);
                    }
                }
            }

        }

        private object GetNodeValue(XmlNode node)
        {
            object value = null;

            if (node.ChildNodes.Count > 0)
            {
                XmlNode valueNode = node.ChildNodes[0];

                if (valueNode.Name.Equals("string"))
                {
                    value = valueNode.InnerText;
                }
                else if (valueNode.Name.Equals("integer") || valueNode.Name.Equals("int"))
                {
                    value = ConvertUtil.ToInt32(valueNode.InnerText);
                }
                else if (valueNode.Name.Equals("xml"))
                {
                    value = valueNode.InnerXml;
                }
                else if (valueNode.Name.Equals("type"))
                {
                    Type type = Type.GetType(valueNode.InnerText);
                    if (type != null)
                        value = Activator.CreateInstance(type);
                }
                else if (valueNode.Name.Equals("bean"))
                {
                    XmlAttribute attrRef = (XmlAttribute)valueNode.Attributes.GetNamedItem("ref");
                    XmlAttribute typeName = (XmlAttribute)valueNode.Attributes.GetNamedItem("type");
                    if (attrRef != null)
                    {
                        value = new RefInfo(attrRef.Value);
                    }
                    else if (typeName != null)
                    {
                        Type type = Type.GetType(typeName.Value);
                        if (type != null)
                            value = Activator.CreateInstance(type);
                    }
                }
                else if (valueNode.Name.Equals("delegate"))
                {
                    XmlAttribute typeAttr = (XmlAttribute)valueNode.Attributes.GetNamedItem("type");
                    XmlAttribute methodAttr = (XmlAttribute)valueNode.Attributes.GetNamedItem("method");
                    if (typeAttr != null && methodAttr != null)
                    {
                        Type type = Type.GetType(typeAttr.Value);

                        XmlAttribute beanTypeAttr = (XmlAttribute)valueNode.Attributes.GetNamedItem("beanType");
                        XmlAttribute beanNameAttr = (XmlAttribute)valueNode.Attributes.GetNamedItem("beanName");
                        if (beanNameAttr != null)
                        {
                            value = new DelegateRefInfo(type, beanNameAttr.Value, methodAttr.Value);
                        }
                        else if (beanTypeAttr != null)
                        {
                            Type beanType = Type.GetType(beanTypeAttr.Value);
                            value = Delegate.CreateDelegate(type, beanType, methodAttr.Value, true);
                        }
                    }
                }
                else if (valueNode.Name.Equals("list"))
                {
                    ArrayList items = new ArrayList();

                    XmlNodeList itemList = valueNode.SelectNodes("item");
                    foreach (XmlNode itemNode in itemList)
                    {
                        object obj = GetNodeValue(itemNode);
                        if (obj is RefInfo)
                        {
                            RefInfo ri = (RefInfo)obj;
                            ri.Setter = typeof(ArrayList).GetMethod("Add");
                            ri.Target = items;
                            refs.Add(ri);
                        }
                        else
                        {
                            items.Add(obj);
                        }
                    }

                    value = items;
                }
                else if (valueNode.Name.Equals("map"))
                {
                    Hashtable items = new Hashtable();
                    XmlNodeList itemList = valueNode.SelectNodes("item");
                    foreach (XmlNode itemNode in itemList)
                    {
                        string key = itemNode.Attributes.GetNamedItem("key").Value;
                        items[key] = itemNode.InnerText;
                    }

                    value = items;
                }
                else
                {
                    value = node.InnerText;
                }
            }
            else
            {
                value = node.InnerText;
            }

            return value;
        }

    }
}
