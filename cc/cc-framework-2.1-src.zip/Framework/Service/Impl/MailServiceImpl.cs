﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Mail;
using System.Net;

namespace CchenSoft.Framework.Service.Impl
{
    public class MailServiceImpl : IMailService
    {
        private string smtpServer;
        private int smtpPort;
        private string username;
        private string password;
        private int needAuthenticate;
        private string sender;

        public string SmtpServer 
        {
            get { return smtpServer; }
            set { smtpServer = value; } 
        }

        public int SmtpPort 
        {
            get { return smtpPort; }
            set { smtpPort = value; }
        }

        public string UserName 
        {
            get { return username; }
            set { username = value; }
        }

        public string Password 
        {
            get { return password; }
            set { password = value; } 
        }

        public int NeedAuthenticate
        {
            get { return needAuthenticate; }
            set { needAuthenticate = value; }
        }

        public string Sender
        {
            get { return sender; }
            set { sender = value; }
        }

        public int Send(string from, string mailto, string subject, string message)
        {
            Send(from, mailto, subject, message, true, Encoding.Default);
            return 0;
        }

        public int Send(string from, string mailto, string subject, string message, bool isHtml, Encoding encoding)
        {
            MailMessage mmsg = new MailMessage();
            mmsg.Sender = new MailAddress(sender);
            mmsg.ReplyTo = new MailAddress(sender);
            mmsg.From = new MailAddress(from);

            string[] emails = mailto.Split(new char[] {';', ' ', ';'});
            foreach (string email in emails)
                mmsg.To.Add(email);

            mmsg.Subject = subject;
            mmsg.Body = message;
            mmsg.IsBodyHtml = isHtml;

            mmsg.SubjectEncoding = encoding;
            mmsg.BodyEncoding = encoding;

            SmtpClient client = new SmtpClient(smtpServer, smtpPort);

            if (needAuthenticate == 1)
            {
                client.UseDefaultCredentials = false;
                client.Credentials = new NetworkCredential(username, password);
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
            }
            else
            {
                client.UseDefaultCredentials = true; //不验证
            }

            client.Send(mmsg);
            return 0;
        }     
    }
}
