#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Framework.Attributes;

namespace CchenSoft.Framework.Service.Impl
{
    [BypassInterceptor]
    public class CacheServiceImpl : ICacheService
    {
        private IDictionary<string, CacheItem> items = new Dictionary<string, CacheItem>();
        private int cacheMinutes;

        private class CacheItem
        {
            private string key;
            private object target;
            private DateTime expiresDate;

            public CacheItem(string key, object target, DateTime expiresDate)
            {
                this.key = key;
                this.target = target;
                this.expiresDate = expiresDate;
            }

            public string Key
            {
                get { return key; }
            }

            public object Target
            {
                get { return target; }
            }

            public DateTime ExpiresDate
            {
                get { return expiresDate; }
            }
        }

        public int CacheMinutes
        {
            get { return cacheMinutes; }
            set { cacheMinutes = value; }
        }

        public void AddItem(string key, object item)
        {
            RemoveItem(key);
            if (item != null)
            {
                items.Add(key, new CacheItem(key, item, DateTime.Now.AddMinutes(cacheMinutes)));
            }
        }

        public IList<string> Items
        {
            get { return new List<string>(items.Keys); }
        }

        public void RemoveItem(string key)
        {
            if (items.ContainsKey(key))
                items.Remove(key);
        }

        public object GetItem(string key)
        {
            if (items.ContainsKey(key))
            {
                CacheItem item = items[key];
                if (item.ExpiresDate > DateTime.Now)
                {
                    return item.Target;
                }
                items.Remove(key);
            }

            return null;
        }

        public void Initialize()
        {
        }
    }
}
