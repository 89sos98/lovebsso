#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using log4net.Config;
using System.IO;
using System.Web;
using log4net;
using CchenSoft.Framework.Attributes;

namespace CchenSoft.Framework.Service.Impl
{
    [BypassInterceptor]
    public class Log4NetServiceImpl : ILogService
    {
        public Log4NetServiceImpl()
        {
        }

        #region IService ��Ա

        public void Initialize()
        {
            string path = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
            string filename = Path.Combine(path, "log4net.config");
            FileInfo fi = new FileInfo(filename);
            if (fi.Exists)
                XmlConfigurator.Configure(fi);
            else
                XmlConfigurator.Configure();
        }

        #endregion

        #region ILogService ��Ա

        public void Info(Type type, string message)
        {
            ILog log = LogManager.GetLogger(type);
            log.Info(message);
        }

        public void Debug(Type type, string message)
        {
            ILog log = LogManager.GetLogger(type);
            log.Debug(message);
        }

        public void Warn(Type type, string message)
        {
            ILog log = LogManager.GetLogger(type);
            log.Warn(message);
        }

        public void Fatal(Type type, string message)
        {
            ILog log = LogManager.GetLogger(type);
            log.Error(message);
        }

        public void Fatal(Type type, Exception ex)
        {
            ILog log = LogManager.GetLogger(type);
            log.Error(ex.Message, ex);
        }

        #endregion
    }
}
