﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Framework.Service
{
    public interface IMailService
    {
        string SmtpServer { get; set; }

        int SmtpPort { get; set; }

        string UserName { get; set; }

        string Password { get; set; }

        int NeedAuthenticate { get; set; }

        string Sender { get; set; }

        int Send(string from, string mailto, string subject, string message);

        int Send(string from, string mailto, string subject, string message, bool isHtml, Encoding encoding);
    }
}
