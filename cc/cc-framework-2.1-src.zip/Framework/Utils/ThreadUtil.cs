﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace CchenSoft.Framework.Utils
{
    public sealed class ThreadUtil
    {
        private ThreadUtil() { }

        public static void SetVariable(string name, object val)
        {
            LocalDataStoreSlot slot = Thread.AllocateNamedDataSlot(name);
            Thread.SetData(slot, val);
        }

        public static object GetVariable(string name)
        {
            LocalDataStoreSlot slot = Thread.GetNamedDataSlot(name);
            return Thread.GetData(slot);
        }
    }
}
