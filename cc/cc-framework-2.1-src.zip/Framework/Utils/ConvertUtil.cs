#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace CchenSoft.Framework.Utils
{
    public sealed class ConvertUtil
    {
        private ConvertUtil() { }

        public static decimal ToDecimal(string value)
        {
            if (string.IsNullOrEmpty(value))
                return 0;

            return Convert.ToDecimal(value);
        }

        public static int ToInt32(string value)
        {
            if (string.IsNullOrEmpty(value))
                return 0;

            return Convert.ToInt32(value);
        }

        public static string GetSafeString(string str)
        {
            return str != null ? str : "";
        }

        public static string ToString(object val)
        {
            if (val == null)
                return string.Empty;

            return val.ToString();
        }

        public static bool ToBoolean(object val)
        {
            if (val == null)
                return false;

            return Convert.ToBoolean(val);
        }

        public static string ToBase64String(string value)
        {
            return Convert.ToBase64String(Encoding.Default.GetBytes(value));
        }

        public static string FromBase64String(string value)
        {
            return Encoding.Default.GetString(Convert.FromBase64String(value));
        }

        public static DateTime ToDateTime(string value)
        {
            return Convert.ToDateTime(value);
        }
    }
}
