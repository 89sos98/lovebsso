#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Framework.Interceptors;
using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Config;
using CchenSoft.Framework.Utils;
using CchenSoft.Framework.Service;
using System.Collections;
using System.Globalization;

namespace CchenSoft.Framework.Interceptors
{
    public class LogInterceptor : IServiceInterceptor
    {
        private ILogService logService;

        public ILogService LogService
        {
            set { logService = value; }
            get { return logService; }
        }

        #region IServiceInterceptor ��Ա

        public object Invoke(IServiceInvocation invocation)
        {
            LogAttribute[] attrs = ReflectUtil.GetCustomAttributes<LogAttribute>(invocation.Method);
            if (attrs != null && attrs.Length > 0)
            {
                object result = invocation.InvokeNext();

                object[] args = new ArrayList(invocation.Args).ToArray();
                string text = string.Format(attrs[0].Text, args);

                logService.Info(invocation.Method.ReflectedType, text);

                return result;
            }

            return invocation.InvokeNext();
        }

        #endregion
    }
}
