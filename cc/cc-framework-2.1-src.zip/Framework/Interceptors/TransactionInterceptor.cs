#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Framework.Interceptors;
using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Utils;
using CchenSoft.Framework.Config;
using CchenSoft.Framework.Data;

namespace CchenSoft.Framework.Interceptors
{
    public class TransactionInterceptor : IServiceInterceptor
    {
        private IDataService dataService;

        public IDataService DataService
        {
            set { dataService = value; }
            get { return dataService; }
        }

        #region IServiceInterceptor ��Ա

        public object Invoke(IServiceInvocation invocation)
        {
            TransactionAttribute[] attrs = ReflectUtil.GetCustomAttributes<TransactionAttribute>(invocation.Method);
            if (attrs != null && attrs.Length > 0)
            {
                TransactionAttribute attr = attrs[0];
                bool requireTrans = false;
                if (attr.Option == TransactionOption.RequiresNew // Ŀǰ��֧������Ƕ�ס�
                    || attr.Option == TransactionOption.Required)
                {                    
                    object obj = ThreadUtil.GetVariable("tm");
                    if (obj == null)
                        requireTrans = true;
                }

                if (requireTrans)
                {
                    ITransactionManager tm = dataService.BeginTransaction();
                    try
                    {
                        object result = invocation.InvokeNext();
                        tm.Commit();
                        return result;
                    }
                    catch
                    {
                        tm.Rollback();
                        throw;
                    }
                    finally
                    {
                        ThreadUtil.SetVariable("tm", null);
                    }
                }
            }

            return invocation.InvokeNext();
        }

        #endregion
    }
}
