#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License 2.1 or later, as
 * published by the Free Software Foundation. See the included License.txt
 * or http://www.gnu.org/copyleft/lesser.html for details.
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Framework.Interceptors;
using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Config;
using CchenSoft.Framework.Utils;
using CchenSoft.Framework.Service;
using System.Collections;

namespace CchenSoft.Framework.Interceptors
{
    public class CacheInterceptor : IServiceInterceptor
    {
        private ICacheService cacheService;

        public ICacheService CacheService
        {
            set { cacheService = value; }
            get { return cacheService; }
        }

        #region IServiceInterceptor ��Ա

        public object Invoke(IServiceInvocation invocation)
        {
            CacheableAttribute[] attrs = ReflectUtil.GetCustomAttributes<CacheableAttribute>(invocation.Method);
            if (attrs != null && attrs.Length > 0)
            {
                string key = invocation.Method.Name + GetCacheKey(invocation.Args);

                object result = cacheService.GetItem(key);

                if (result == null)
                {
                    result = invocation.InvokeNext();
                    cacheService.AddItem(key, result);
                }

                return result;
            }

            return invocation.InvokeNext();
        }

        #endregion

        private static string GetCacheKey(ICollection args)
        {
            if (args == null)
                return "";

            string result = "";

            foreach (object val in args)
            {
                result += "_" + ((val != null) ? val : "nil");
            }

            return result;
        }
    }
}
