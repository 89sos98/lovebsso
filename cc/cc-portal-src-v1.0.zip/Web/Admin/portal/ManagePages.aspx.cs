﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Utils;

using CchenSoft.Portal.Service;
using CchenSoft.Portal.Model;
using System.Collections.Generic;
using System.Text;

public partial class Admin_Portal_ManagePages : AdminPage
{
    [Bean]
    protected IPortalService portalService;

    private string action;
    private int pageId;
    private string pagesTreeScript;

    protected string PagesTreeScript
    {
        get { return pagesTreeScript; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        action = Request["action"];
        pageId = ConvertUtil.ToInt32(Request["page"]);

        if (!IsPostBack)
        {
            dlstParent.Items.Add(new ListItem("(无)", "0"));
            AddItems(0, 0);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<script type='text/javascript'>");
            sb.AppendLine("d = new dTree('d');");
            sb.AppendLine("d.add(0, -1, 'ROOT', 'javascript: void(0);');");

            int count = 1;
            AddPages(sb, 0, 0, ref count);

            sb.AppendLine("document.write(d);");
            sb.AppendLine("</script>");

            pagesTreeScript = sb.ToString();

            if ("add" == action)
            {
                pc.Enabled = true;
            }
            else if ("edit" == action)
            {
                PortalPage page = null;
                if (pageId > 0)
                    page = portalService.LoadPage(pageId);

                if (page != null)
                {
                    tn.Text = page.Name;
                    tu.Text = page.FriendlyUrl;
                    tt.Text = page.Title;
                    tk.Text = page.Keywords;
                    td.Text = page.Description;
                    tl.Text = page.LayoutId;
                    ts.Text = page.SortNo.ToString();
                    dlstParent.SelectedValue = page.ParentId.ToString();

                    pc.Enabled = true;

                    lnkConfig.NavigateUrl = "viewpage.aspx?pid=" + page.PageId;
                    lnkConfig.Visible = true;

                    lbtnBuild.Visible = true;
                    btnDel.Visible = true;
                }
            }
        }
    }

    private void AddPages(StringBuilder sb, int nodeId, int parentId, ref int count)
    {
        IList<PortalPage> pages = portalService.GetPages(parentId);
        foreach (PortalPage pg in pages)
        {
            sb.AppendFormat("d.add({0},{1},'{2}','managepages.aspx?action=edit&page={3}');\r\n", count, nodeId, pg.Name, pg.PageId);
            int parent = count;
            count++;
            AddPages(sb, parent, pg.PageId, ref count);
        }
    }

    protected void lbtnBuild_Click(object sender, EventArgs e)
    {
        PortalPage page = null;
        if (pageId > 0)
            page = portalService.LoadPage(pageId);

        if (page != null)
            portalService.CreateHtmlFile(page);

        Response.Redirect(Request.Url.ToString());
    }

    protected void lbb_Click(object sender, EventArgs e)
    {
        IList<PortalPage> pages = portalService.GetPages();
        foreach (PortalPage page in pages)
        {
            portalService.CreateHtmlFile(page);
        }
        Response.Redirect(Request.Url.ToString());
    }

    protected void btnOK_Click(object sender, EventArgs e)
    {
        if ("add" == action)
        {
            PortalPage page = new PortalPage();
            page.Name = tn.Text;
            page.PageType = "page";
            page.ParentId = ConvertUtil.ToInt32(dlstParent.SelectedValue);
            page.FriendlyUrl = tu.Text;
            page.Title = tt.Text;
            page.Keywords = tk.Text;
            page.Description = td.Text;
            page.LayoutId = tl.Text;
            page.SortNo = ConvertUtil.ToInt32(ts.Text);
            portalService.SavePage(page);
        }
        else if ("edit" == action)
        {
            PortalPage page = null;
            if (pageId > 0)
                page = portalService.LoadPage(pageId);

            if (page != null)
            {
                page.Name = tn.Text;
                page.ParentId = ConvertUtil.ToInt32(dlstParent.SelectedValue);
                page.FriendlyUrl = tu.Text;
                page.Title = tt.Text;
                page.Keywords = tk.Text;
                page.Description = td.Text;
                page.LayoutId = tl.Text;
                page.SortNo = ConvertUtil.ToInt32(ts.Text);
                page.Settings = portalService.GetSettings(page);
                portalService.UpdatePage(page);
            }
        }

        Response.Redirect(Request.Url.ToString());
    }

    protected void btnDel_Click(object sender, EventArgs e)
    {
        portalService.DeletePage(pageId);
        Response.Redirect(Request.Path.ToString());
    }

    private void AddItems(int parent, int depth)
    {
        IList<PortalPage> pages = portalService.GetPages(parent);
        foreach (PortalPage page in pages)
        {
            dlstParent.Items.Add(new ListItem(GetIndent(depth) + page.Name, page.PageId.ToString()));

            AddItems(page.PageId, depth + 1);
        }
    }

    private string GetIndent(int depth)
    {
        string str = "";
        for (int i = 0; i < depth; i++)
        {
            str += "　";
        }
        return str;
    }
}
