﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

using CchenSoft.Framework.Attributes;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Attributes;
using CchenSoft.Portal;

public partial class Admin_Portal_ListPortlets : AdminPage
{
    [Bean]
    protected IPortalService portalService;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            rptC.DataSource = portalService.Portlets;
            rptC.DataBind();
        }
    }

    protected void rptC_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        Portlet portlet = (Portlet)e.Item.DataItem;

        ((Literal)e.Item.FindControl("ltName")).Text = portlet.Name;
        ((Literal)e.Item.FindControl("ltDesc")).Text = portlet.Description;
        ((Literal)e.Item.FindControl("ltGroup")).Text = portlet.Group;
        ((Literal)e.Item.FindControl("ltType")).Text = portlet.ControlType.FullName;
    }
}
