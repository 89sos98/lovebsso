﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Utils;

using CchenSoft.Portal.Service;
using CchenSoft.Portal;

public partial class Admin_Portal_Config : AdminPage
{
    [Bean]
    protected IPortalService portalService;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PortalConfig config = portalService.GetConfig();

            tt.Text = config.Title;
            tm.Text = config.Theme;
            imgLogo.ImageUrl = config.LogoUrl;
            imgBanner.ImageUrl = config.BannerLink;
            tbl.Text = config.BannerUrl;
            tc.Text = config.Copyright;
        }
    }

    protected void btnOK_Click(object sender, EventArgs e)
    {
        PortalConfig config = portalService.GetConfig();

        config.Title = tt.Text;
        config.Theme = tm.Text;
        config.BannerLink = tbl.Text;
        config.Copyright = tc.Text;

        if (fl.HasFile)
        {
            config.LogoUrl = "~/images/" + fl.PostedFile.FileName;
            fl.PostedFile.SaveAs(Server.MapPath(config.LogoUrl));
        }

        if (fbi.HasFile)
        {
            config.BannerUrl = "~/images/" + fbi.PostedFile.FileName;
            fl.PostedFile.SaveAs(Server.MapPath(config.BannerUrl));
        }

        portalService.UpdateConfig(config);
    }

}
