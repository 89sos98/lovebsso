﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal.Web;
using CchenSoft.Framework;
using CchenSoft.Framework.Attributes;

public partial class Admin_Logout : BasePage
{
    [Bean("AdminAuthenticator")]
    protected IAuthenticator auth;

    protected void Page_Load(object sender, EventArgs e)
    {
        auth.SignOut();
        Response.Redirect("~/");
    }
}
