﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Configuration;
using CchenSoft.Framework;
using CchenSoft.Framework.Attributes;

public partial class Admin_Login : BasePage
{
    [Bean("AdminAuthenticator")]
    protected IAuthenticator auth;

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        int ret = auth.Authenticate(txtUser.Text, txtPasswd.Text, 0);
        if (ret > 0)
        {
            string from = Request["from"];
            if (string.IsNullOrEmpty(from))
                from = "default.aspx";

            Response.Redirect(from);
        }
    }

}
