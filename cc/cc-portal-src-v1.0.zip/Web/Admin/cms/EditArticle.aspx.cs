﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using CchenSoft.CMS.Model;
using CchenSoft.CMS.Service;
using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Utils;

public partial class Admin_cms_EditArticle : AdminPage
{
    [Bean]
    protected ICmsService cmsService;

    private int aid;

    protected void Page_Load(object sender, EventArgs e)
    {
        aid = RequestUtil.GetInt32("aid");
        if (!IsPostBack)
        {
            Article art = cmsService.LoadArticle(aid);
            if (art != null)
            {
                txtTitle.Text = art.Title;
                editor.Content = art.Content;
                txtKeyword.Text = art.Tags;
            }
        }
    }

    protected void btnSave_Click(object sender, System.EventArgs e)
    {
        Article art = cmsService.LoadArticle(aid);
        if (art != null)
        {
            art.Title = txtTitle.Text;
            art.Content = editor.Content;
            art.Tags = txtKeyword.Text.Trim();

            cmsService.UpdateArticle(art);
            Response.Write("<script language=JavaScript>alert('更新成功！');location.href='listarticles.aspx';</script>");
            Response.End();
        }
    }
}
