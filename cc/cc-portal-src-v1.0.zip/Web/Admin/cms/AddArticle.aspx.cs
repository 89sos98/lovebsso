﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using CchenSoft.CMS.Model;
using CchenSoft.CMS.Service;
using CchenSoft.Framework.Attributes;

public partial class Admin_cms_AddArticle : AdminPage
{
    [Bean]
    protected ICmsService cmsService;

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnSave_Click(object sender, System.EventArgs e)
    {
        Article art = new Article();
        art.Title = txtTitle.Text;
        art.Content = editor.Content;
        art.Tags = txtKeyword.Text.Trim();

        cmsService.SaveArticle(art);
        Response.Write("<script language=JavaScript>alert('添加成功！');location.href='listarticles.aspx';</script>");
        Response.End();
    }
}
