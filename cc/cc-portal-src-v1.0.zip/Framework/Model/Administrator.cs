﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.Model
{
    public class Administrator
    {
        private int adminId;
        private string loginName;
        private string passwd;

        public int AdminId
        {
            get { return adminId; }
            set { adminId = value; }
        }

        public string LoginName
        {
            get { return loginName; }
            set { loginName = value; }
        }

        public string Passwd
        {
            get { return passwd; }
            set { passwd = value; }
        }
    }
}
