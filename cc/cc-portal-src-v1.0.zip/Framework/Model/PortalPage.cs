#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.IO;

namespace CchenSoft.Portal.Model
{
    public class PortalPage
    {
        private int pageId;
        private string name;
        private string pageType;
        private string settings;
        private int parentId;
        private string friendlyUrl;
        private string layoutId;
        //private string themeId;
        private int sortNo;
        private bool newWindow;
        private string redirectUrl;

        private string title;
        private string keywords;
        private string description;

        private ColumnInfo[] columns;

        public int PageId
        {
            get { return pageId; }
            set { pageId = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        
        public string PageType
        {
            get { return pageType; }
            set { pageType = value; }
        }

        public string Settings
        {
            get { return settings; }
            set
            {
                settings = value;
                columns = null;
            }
        }

        /// <summary>
        /// ��Id
        /// </summary>
        public int ParentId
        {
            get { return parentId; }
            set { parentId = value; }
        }

        /// <summary>
        /// �Ѻ�Url
        /// </summary>
        public string FriendlyUrl
        {
            get { return friendlyUrl; }
            set { friendlyUrl = value; }
        }

        /// <summary>
        /// ����Id
        /// </summary>
        public string LayoutId
        {
            get { return layoutId; }
            set { layoutId = value; }
        }

        /// <summary>
        /// ����Id
        /// </summary>
        //public string ThemeId
        //{
        //    get { return themeId; }
        //    set { themeId = value; }
        //}

        /// <summary>
        /// �����
        /// </summary>
        public int SortNo
        {
            get { return sortNo; }
            set { sortNo = value; }
        }

        /// <summary>
        /// �Ƿ���´���
        /// </summary>
        public bool NewWindow
        {
            get { return newWindow; }
            set { newWindow = value; }
        }

        public string RedirectUrl
        {
            get { return redirectUrl; }
            set { redirectUrl = value; }
        }

        /// <summary>
        /// title
        /// </summary>
        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        /// <summary>
        /// �ؼ���
        /// </summary>
        public string Keywords
        {
            get { return keywords; }
            set { keywords = value; }
        }

        /// <summary>
        /// ����
        /// </summary>
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public ColumnInfo[] Columns
        {
            get
            {
                if (string.IsNullOrEmpty(settings))
                    return null;

                if (columns == null)
                {
                    XmlSerializer ser = new XmlSerializer(typeof(ColumnInfo[]));
                    columns = (ColumnInfo[])ser.Deserialize(new StringReader(settings));
                }

                return columns;
            }
        }
    }
}
