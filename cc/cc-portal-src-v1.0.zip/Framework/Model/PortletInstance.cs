#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Xml;

namespace CchenSoft.Portal.Model
{
    public class PortletInstance
    {
        private int id;
        private string portletName;
        private string title;
        private bool showTitle;
        private int pageId;
        private string preferences;

        public PortletInstance()
        {
            preferences = "<preferences></preferences>";
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public bool ShowTitle
        {
            get { return showTitle; }
            set { showTitle = value; }
        }

        public string PortletName
        {
            get { return portletName; }
            set { portletName = value; }
        }

        public int PageId
        {
            get { return pageId; }
            set { pageId = value; }
        }

        public string Preferences
        {
            get { return preferences; }
            set { preferences = value; }
        }

        Dictionary<string, string> prefs;

        public string GetPreference(string name)
        {
            if (prefs == null)
                prefs = Parse();

            if (prefs.ContainsKey(name))
                return prefs[name];

            return null;
        }

        private Dictionary<string, string> Parse()
        {
            Dictionary<string, string> prefs = new Dictionary<string, string>();

            if (!string.IsNullOrEmpty(preferences))
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(preferences);

                XmlNodeList nodes = doc.DocumentElement.ChildNodes;

                foreach (XmlNode node in nodes)
                {
                    prefs[node.Name] = node.InnerText;
                }
            }

            return prefs;
        }
    }
}
