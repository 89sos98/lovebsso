﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.Attributes
{
    [AttributeUsage(AttributeTargets.Field)]
    public class ConfigAttribute : Attribute
    {
        private string name;
        private string title;
        private Type uiType;

        public ConfigAttribute(string name, string title, Type uiType)
        {
            this.name = name;
            this.title = title;
            this.uiType = uiType;
        }

        public string Name
        {
            get { return name; }
        }

        public string Title
        {
            get { return title; }
        }

        public Type UIType 
        {
            get { return uiType; }
        }
    }
}
