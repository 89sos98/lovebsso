﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal.Attributes
{
    [AttributeUsage(AttributeTargets.Class)]
    public class PortletAttribute : Attribute
    {
        private string name;
        private string group;
        private string description;

        public PortletAttribute(string name, string group, string description)
        {
            this.name = name;
            this.group = group;
            this.description = description;
        }

        public string Name
        {
            get { return name; }
        }

        public string Group
        {
            get { return group; }
        }

        public string Description
        {
            get { return description; }
        }
    }
}
