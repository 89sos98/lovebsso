#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

using CchenSoft.Framework;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Attributes;

namespace CchenSoft.Portal.Service
{
    public interface IPortalService : IService
    {
        string PortletsPath { get; }

        string FileSuffix { get; }

        ICollection<Portlet> Portlets { get; }

        ICollection<LayoutTemplate> Layouts { get; }

        ICollection<Theme> Themes { get; }

        Administrator ValidateLogin(string name, string passwd);

        Portlet GetPortlet(string portletName);

        void CreateHtmlFile(PortalPage page);

        PortalConfig GetConfig();

        void UpdateConfig(PortalConfig cfg);

        PortletInstance LoadPortlet(int portletId);

        PortalPage GetPageByUrl(string path);

        void SavePage(PortalPage page);

        void RemovePortlet(int pageId, int instanceId);

        void AddPortlet(int pageId, string portlet, int columnIndex);

        void AddPortlet(int pageId, string portlet);

        void UpdateColumnInstances(int pageId, int columnIndex, string[] instances);

        LayoutTemplate LoadLayoutTemplate(string layoutId);

        Theme LoadTheme(string themeId);

        IList<PortalPage> GetPages();

        IList<PortalPage> GetPages(int parentId);

        PortalPage LoadPage(int pageId);

        void UpdatePage(PortalPage page);

        void DeletePage(int pageId);

        void UpdatePortlet(PortletInstance instance, IDictionary<string, string> prefs);

        void UpdateSettings(int pageId, string settings);

        string GetSettings(PortalPage page);

        string GetPageUrl(PortalPage page);
    }
}
