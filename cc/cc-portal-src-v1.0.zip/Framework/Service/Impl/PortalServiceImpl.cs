#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Xml;
using System.IO;
using System.Collections;
using System.Reflection;

using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Data;
using CchenSoft.Framework.Utils;

using CchenSoft.Portal.Model;
using CchenSoft.Portal.Attributes;
using System.Xml.Serialization;
using System.Net;

namespace CchenSoft.Portal.Service.Impl
{
    public class PortalServiceImpl : IPortalService
    {
        private IDataService dataService;
        private string fileSuffix;
        private string layoutsPath;
        private string themesPath;
        private string portletsPath;
        private string configsPath;
        private string excludeAssemblies;
        private PortalConfig config;

        private Dictionary<string, LayoutTemplate> layouts;
        private Dictionary<string, Theme> themes;
        private Dictionary<string, Portlet> controls;

        public IDataService DataService
        {
            get { return dataService; }
            set { dataService = value; }
        }

        public string LayoutsPath
        {
            get { return layoutsPath; }
            set { layoutsPath = value; }
        }

        public string ThemesPath
        {
            get { return themesPath; }
            set { themesPath = value; }
        }

        public string PortletsPath
        {
            get { return portletsPath; }
            set { portletsPath = value; }
        }

        public string ConfigsPath
        {
            get { return configsPath; }
            set { configsPath = value; }
        }

        public string ExcludeAssemblies
        {
            get { return excludeAssemblies; }
            set { excludeAssemblies = value; }
        }

        public PortalServiceImpl()
        {
            layouts = new Dictionary<string, LayoutTemplate>();
            themes = new Dictionary<string, Theme>();
            controls = new Dictionary<string, Portlet>();
        }

        #region IService ��Ա

        public void Initialize()
        {
            ParseLayouts();
            ParseThemes();
            ParsePortlets();
            GetConfig();
        }

        #endregion

        private void ParseLayouts()
        {
            string folder = HttpContext.Current.Server.MapPath(layoutsPath);

            string[] folders = Directory.GetDirectories(folder);
            for (int i = 0; i < folders.Length; i++)
            {
                string filename = folders[i] + "\\layout.config";
                if (File.Exists(filename))
                {
                    string[] part = folders[i].Split('\\');

                    string rootPath = layoutsPath + part[part.Length - 1] + "/";

                    XmlDocument doc = new XmlDocument();
                    doc.Load(filename);

                    XmlNode node = doc.DocumentElement;

                    LayoutTemplate layout = new LayoutTemplate();
                    layout.TempId = node.SelectSingleNode("id").InnerText;
                    layout.Name = node.SelectSingleNode("name").InnerText;
                    layout.Control = rootPath + node.SelectSingleNode("control").InnerText;
                    layout.ThumbImage = rootPath + node.SelectSingleNode("thumbimage").InnerText;
                    layout.Zone = node.SelectSingleNode("zone").InnerText;
                    layouts[layout.TempId] = layout;
                }
            }
        }

        private void ParseThemes()
        {
            string folder = HttpContext.Current.Server.MapPath(themesPath);
            string[] folders = Directory.GetDirectories(folder);
            for (int i = 0; i < folders.Length; i++)
            {
                string filename = folders[i] + "\\theme.config";
                if (File.Exists(filename))
                {
                    string[] part = folders[i].Split('\\');

                    XmlDocument doc = new XmlDocument();
                    doc.Load(filename);

                    XmlNode node = doc.DocumentElement;

                    Theme theme = new Theme();
                    theme.RootPath = themesPath + part[part.Length - 1] + "/";
                    theme.ThemeId = node.SelectSingleNode("id").InnerText;
                    theme.Name = node.SelectSingleNode("name").InnerText;
                    theme.TemplatePath = theme.RootPath + node.SelectSingleNode("templatePath").InnerText;
                    theme.ThumbImage = theme.RootPath + node.SelectSingleNode("thumbimage").InnerText;
                    themes[theme.ThemeId] = theme;
                }
            }
        }

        private void ParsePortlets()
        {
            string rootpath = "";
            string binpath = "";
            if (HttpContext.Current != null)
            {
                rootpath = HttpContext.Current.Server.MapPath("~/");
                binpath = rootpath + "\\bin\\";
            }
            else
            {
                rootpath = AppDomain.CurrentDomain.BaseDirectory;
                binpath = rootpath;
            }

            string[] excludes = excludeAssemblies.Split(new char[] { ',', ';' });

            string[] files = Directory.GetFiles(binpath, "*.dll");
            for (int i=0; i<files.Length; i++)
            {
                string fullname = files[i];
                string filename = Path.GetFileName(fullname).ToLower();
                bool skip = false;
                for (int j = 0; j < excludes.Length; j++)
                {
                    if (filename.StartsWith(excludes[j]))
                    {
                        skip = true;
                        break;
                    }
                }

                if (skip) continue;

                Assembly assm = Assembly.LoadFrom(fullname);

                Type[] types = assm.GetTypes();
                foreach (Type type in types)
                {
                    PortletAttribute[] attrs = ReflectUtil.GetCustomAttributes<PortletAttribute>(type);
                    if (attrs != null && attrs.Length > 0)
                    {
                        Portlet cc = new Portlet();
                        cc.Name = attrs[0].Name;
                        cc.Group = attrs[0].Group;
                        cc.Description = attrs[0].Description;
                        cc.ControlType = type;
                        cc.Configs = GetConfigAttributes(type);

                        controls[cc.Name] = cc;
                    }
                }
            }
        }

        #region IPortalService ��Ա

        public string FileSuffix
        {
            get { return fileSuffix; }
            set { fileSuffix = value; }
        }

        public ICollection<LayoutTemplate> Layouts 
        {
            get { return layouts.Values; }
        }

        public ICollection<Theme> Themes 
        {
            get { return themes.Values; }
        }

        public ICollection<Portlet> Portlets
        {
            get { return controls.Values; }
        }

        public Administrator ValidateLogin(string name, string passwd)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            dict["name"] = name;
            dict["passwd"] = passwd;
            return dataService.QueryForObject<Administrator>("portal.ValidateLogin", dict);
        }

        public Portlet GetPortlet(string controlName)
        {
            if (controls.ContainsKey(controlName))
                return controls[controlName];
            return null;
        }

        private ConfigAttribute[] GetConfigAttributes(Type portletType)
        {
            List<ConfigAttribute> list = new List<ConfigAttribute>();

            FieldInfo[] fields = portletType.GetFields(BindingFlags.Instance | BindingFlags.NonPublic);
            foreach (FieldInfo field in fields)
            {
                ConfigAttribute[] attrs = ReflectUtil.GetCustomAttributes<ConfigAttribute>(field);
                if (attrs != null && attrs.Length > 0)
                    list.Add(attrs[0]);
            }

            return list.ToArray();
        }
 
        public PortalConfig GetConfig()
        {
            if (config == null)
            {
                string filename = HttpContext.Current.Server.MapPath("~/portal.config");
                using (FileStream fs = new FileStream(filename, FileMode.Open))
                {
                    XmlSerializer ser = new XmlSerializer(typeof(PortalConfig));
                    config = (PortalConfig)ser.Deserialize(fs);
                    fs.Close();
                }
            }
            return config;
        }

        public void UpdateConfig(PortalConfig pc)
        {
            string filename = HttpContext.Current.Server.MapPath("~/portal.config");
            using (TextWriter writer = new StreamWriter(filename))
            {
                XmlSerializer ser = new XmlSerializer(typeof(PortalConfig));
                ser.Serialize(writer, pc);
                writer.Flush();
                writer.Close();
            }
            config = pc;
        }

        public PortalPage LoadPage(int pageId)
        {
            return dataService.QueryForObject<PortalPage>("portal.SelectPage", pageId);
        }

        public IList<PortalPage> GetPages()
        {
            return dataService.QueryForList<PortalPage>("portal.SelectPage", null);
        }

        public void SavePage(PortalPage page)
        {
            page.Settings = GetSettings(page);
            dataService.Insert("portal.InsertPage", page);
            CreateHtmlFile(page);
        }

        [Cacheable]
        public PortalPage GetPageByUrl(string pageUrl)
        {
            return dataService.QueryForObject<PortalPage>("portal.GetPageByUrl", pageUrl);
        }

        [Cacheable]
        public PortletInstance LoadPortlet(int portletId)
        {
            return dataService.QueryForObject<PortletInstance>("portal.SelectPortlet", portletId);
        }

        public IList<PortalPage> GetPages(int parentId)
        {
            return dataService.QueryForList<PortalPage>("portal.GetPagesByParent", parentId);
        }

        public void UpdatePortlet(PortletInstance instance, IDictionary<string,string> prefs)
        {
            MemoryStream ms = new MemoryStream();
            XmlTextWriter writer = new XmlTextWriter(ms, Encoding.Default);
            writer.WriteStartElement("preferences");

            foreach (string name in prefs.Keys)
            {
                writer.WriteElementString(name, prefs[name]);
            }

            writer.WriteEndElement();
            writer.Flush();

            instance.Preferences = Encoding.Default.GetString(ms.GetBuffer(), 0, (int)ms.Length);

            ms.Close();
            ms = null;

            dataService.Update("portal.UpdatePortlet", instance);
        }

        public void UpdateSettings(int pageId, string settings)
        {
            PortalPage page = LoadPage(pageId);
            if (page != null)
            {
                if (settings.EndsWith(";"))
                    settings = settings.TrimEnd(';');

                string[] columns = settings.Split(';');
                List<ColumnInfo> cols = new List<ColumnInfo>();

                for (int i = 0; i < columns.Length; i++)
                {
                    string[] strs = columns[i].Split('=');
                    ColumnInfo col = new ColumnInfo();

                    if (strs.Length > 0)
                    {
                        col.Name = strs[0];
                    }

                    if (strs.Length > 1)
                    {
                        string[] ids = strs[1].Split(',');
                        for (int j = 0; j < ids.Length; j++)
                        {
                            if (!string.IsNullOrEmpty(ids[j]))
                            {
                                string id = ids[j];
                                int n = id.LastIndexOf('_');
                                if (n != -1)
                                {
                                    col.Add(ConvertUtil.ToInt32(id.Substring(n + 1)));
                                }
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(col.Name))
                        cols.Add(col);
                }

                page.Settings = GetSettings(cols.ToArray());
                UpdatePage(page);
            }
        }

        public void UpdatePage(PortalPage page)
        {
            dataService.Update("portal.UpdatePage", page);
            CreateHtmlFile(page);
        }

        [Transaction(TransactionOption.Required)]
        public void DeletePage(int pageId)
        {
            PortalPage page = LoadPage(pageId);
            if (page != null)
            {
                List<string> insts = new List<string>();
                for (int i=0; i<page.Columns.Length; i++)
                {
                    for (int j=0; j<page.Columns[i].Instances.Length; j++)
                        insts.Add(page.Columns[i].Instances[j].ToString());
                }
                if (insts.Count > 0)
                {
                    dataService.Delete("portal.DeletePagePortlets", string.Join(",", insts.ToArray()));
                }

                dataService.Delete("portal.DeletePage", pageId);
            }
        }

        public void CreateHtmlFile(PortalPage page)
        {
            HttpContext context = HttpContext.Current;
            string virtualpath = page.FriendlyUrl + ".aspx";
            string filename = context.Server.MapPath("~" + page.FriendlyUrl + "." + fileSuffix);
            string path = filename.Substring(0, filename.LastIndexOf("\\") + 1);
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);

            int n = context.Request.ApplicationPath.Length;
            if (n > 1)
                virtualpath = context.Request.ApplicationPath + virtualpath;

            Uri uri = context.Request.Url;
            string url = string.Format("http://{0}:{1}", uri.Host, uri.Port) + virtualpath;

            HttpWebRequest webReq = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)webReq.GetResponse();
            string content = "";
            if (response.StatusCode == HttpStatusCode.OK)
            {
                StringBuilder sb = new StringBuilder();
                StreamReader sr = new StreamReader(response.GetResponseStream());
                int BufferLengh = 8 * 1024;  // 16K
                char[] buf = new char[BufferLengh];
                int len = sr.Read(buf, 0, BufferLengh);
                while (len > 0)
                {
                    sb.Append(new string(buf, 0, len));
                    len = sr.Read(buf, 0, BufferLengh);
                }
                response.Close();
                sr.Close();
                content = sb.ToString();
            }

            if (!string.IsNullOrEmpty(content))
            {
                using (StreamWriter writer = new StreamWriter(filename))
                {
                    writer.Write(content);
                    writer.Flush();
                }                
            }
        }

        [Transaction(TransactionOption.Required)]
        public void RemovePortlet(int pageId, int instanceId)
        {
            PortalPage page = LoadPage(pageId);
            if (page != null)
            {
                dataService.Delete("portal.DeletePortlet", instanceId);
                ColumnInfo[] cols = page.Columns;
                for (int i = 0; i < cols.Length; i++)
                    cols[i].Remove(instanceId);
                page.Settings = GetSettings(cols);
                UpdatePage(page);
            }
        }

        [Transaction(TransactionOption.Required)]
        public void AddPortlet(int pageId, string portlet, int columnIndex)
        {
            //// add portlet instance.
            PortalPage page = LoadPage(pageId);
            if (page != null)
            {
                Portlet prt = GetPortlet(portlet);
                if (prt != null)
                {
                    PortletInstance instance = new PortletInstance();
                    instance.PortletName = prt.Name;
                    instance.Title = prt.Description;
                    instance.PageId = page.PageId;

                    dataService.Insert("portal.InsertPortlet", instance);

                    ColumnInfo[] columns = GetColumns(page);
                    if (columns.Length > columnIndex)
                    {
                        columns[columnIndex].Add(instance.Id);
                        page.Settings = GetSettings(columns);
                        UpdatePage(page);
                    }
                }
            }
        }

        public string GetSettings(PortalPage page)
        {
            ColumnInfo[] cols = GetColumns(page);
            return GetSettings(cols);
        }

        private ColumnInfo[] GetColumns(PortalPage page)
        {
            Dictionary<string, ColumnInfo> cols = new Dictionary<string, ColumnInfo>();
            ColumnInfo[] arr = page.Columns;
            if (arr != null)
            {
                for (int i = 0; i < arr.Length; i++)
                    cols[arr[i].Name] = arr[i];
            }

            LayoutTemplate lt = layouts[page.LayoutId];
            string[] layCols = lt.Zone.Split(',');

            for (int i = 0; i < layCols.Length; i++)
            {
                if (!cols.ContainsKey(layCols[i]))
                {
                    ColumnInfo ci = new ColumnInfo();
                    ci.Name = layCols[i];
                    cols[ci.Name] = ci;
                }
            }

            return new List<ColumnInfo>(cols.Values).ToArray();
        }

        private string GetSettings(ColumnInfo[] columns)
        {
            XmlSerializer ser = new XmlSerializer(typeof(ColumnInfo[]));
            StringBuilder sb = new StringBuilder();
            StringWriter sw = new StringWriter(sb);
            ser.Serialize(sw, columns);

            return sb.ToString();
        }

        public void AddPortlet(int pageId, string portlet)
        {
            AddPortlet(pageId, portlet, 0);
        }

        public void UpdateColumnInstances(int pageId, int columnIndex, string[] instances)
        {
            //PortalPage page = GetPortalPageById(pageId);
            //string[] columns = page.Settings.Split(';');
            //if (columns.Length > columnIndex)
            //{
            //    string name = columns[columnIndex].Split('=')[0];
            //    columns[columnIndex] = name + '=' + string.Join(",", instances) + ",";

            //    page.Settings = string.Join(";", columns);

            //    UpdatePortalPage(page);
            //}
        }

        public LayoutTemplate LoadLayoutTemplate(string layoutId)
        {
            if (layouts.ContainsKey(layoutId))
                return layouts[layoutId];

            return null;
        }

        public Theme LoadTheme(string themeId)
        {
            if (themes.ContainsKey(themeId))
                return themes[themeId];

            return null;
        }

        public string GetPageUrl(PortalPage page)
        {
            if (PortalContext.Current.IsAdmin)
            {
                return "/admin/portal/viewpage.aspx?pid=" + page.PageId;
            }

            return page.FriendlyUrl + "." + fileSuffix;
        }

        #endregion

    }
}
