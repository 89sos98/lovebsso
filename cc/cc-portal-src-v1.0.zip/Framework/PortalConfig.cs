﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace CchenSoft.Portal
{
    [Serializable]
    [XmlRootAttribute("Configuration", Namespace = "http://www.cchensoft.com/products/portal/")]
    public class PortalConfig
    {
        private string title;
        private string theme;
        private string logoUrl;
        private string copyright;
        private string bannerUrl;
        private string bannerLink;

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public string Theme
        {
            get { return theme; }
            set { theme = value; }
        }

        public string LogoUrl
        {
            get { return logoUrl; }
            set { logoUrl = value; }
        }

        public string Copyright
        {
            get { return copyright; }
            set { copyright = value; }
        }

        public string BannerUrl
        {
            get { return bannerUrl; }
            set { bannerUrl = value; }
        }

        public string BannerLink
        {
            get { return bannerLink; }
            set { bannerLink = value; }
        }

    }
}
