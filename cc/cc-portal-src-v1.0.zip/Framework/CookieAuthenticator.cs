﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using CchenSoft.Framework;
using System.Web.Security;
using System.Web.Configuration;

namespace CchenSoft.Portal
{
    public class CookieAuthenticator : IAuthenticator
    {
        private const string CookieKey = "portal";
        private const string IdentityKey = "userId";
        private const string IdentityNameKey = "userName";

        private string loginUrl;

        #region IAuthenticator 成员

        public string LoginUrl
        {
            get { return loginUrl; }
            set { loginUrl = value; }
        }

        public int Authenticate(string name, string passwd, int persist)
        {
            int identity = (MD5(passwd) == "E41A3196DBDA107FAE7933B4553A7A41") ? 1 : 0;  // "abc123def"
            if (identity > 0)
            {
                HttpCookie cookie = new HttpCookie(CookieKey);
                cookie[IdentityKey] = identity.ToString();
                cookie[IdentityNameKey] = name;
                if (persist > 0)
                {
                    cookie.Expires = DateTime.Now.AddDays(persist);
                }
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
            return identity;
        }

        public bool IsAuthenticated
        {
            get
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
                return cookie != null ? !string.IsNullOrEmpty(cookie[IdentityKey]) : false;
            }
        }

        public string Identity
        {
            get
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
                return (cookie != null) ? cookie[IdentityKey] : null;
            }
        }

        public string IdentityName
        {
            get
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
                return (cookie != null) ? cookie[IdentityNameKey] : null;
            }
        }

        public void SignOut()
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
            if (cookie != null)
            {
                cookie.Expires = DateTime.Now.AddDays(-1);
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
        }

        public void CheckPermission(string resource, int action)
        {
            
        }

        #endregion

        private string MD5(string str)
        {
            return FormsAuthentication.HashPasswordForStoringInConfigFile(str, FormsAuthPasswordFormat.MD5.ToString());
        }
    }
}
