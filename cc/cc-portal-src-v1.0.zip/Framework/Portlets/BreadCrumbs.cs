﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

using CchenSoft.Portal.Model;
using CchenSoft.Portal.Web;
using CchenSoft.Portal.Attributes;

namespace CchenSoft.Portal.Portlets
{
    [PortletAttribute("breadcrumbs", "Common", "页面位置")]
    public class BreadCrumbs : PortletControl
    {
        [Config("prefixtext", "前置文本", typeof(TextBoxConfigControl))]
        private string prefixText;

        [Config("separator", "分隔符", typeof(TextBoxConfigControl))]
        private string separator;

        public BreadCrumbs(PortletInstance portlet)
            : base(portlet)
        {
            skinFileName = "common/breadcrumbs.ascx";
        }

        protected override void Configure()
        {
            prefixText = portlet.GetPreference("prefixtext");
            if (string.IsNullOrEmpty(prefixText))
                prefixText = "当前位置: ";
            separator = portlet.GetPreference("separator");
            if (string.IsNullOrEmpty(separator))
                separator = "-";
        }

        protected override void InitializeSkin(Control control)
        {
            Literal lprefix = (Literal)control.FindControl("l");
            if (lprefix != null)
                lprefix.Text = prefixText;

            //HyperLink ld = (HyperLink)control.FindControl("ld");
            Literal ldt = (Literal)control.FindControl("ldt");
            ldt.Text = separator;

            Repeater r = (Repeater)control.FindControl("r");
            if (r != null)
            {
                r.ItemDataBound += new RepeaterItemEventHandler(r_ItemDataBound);
                r.DataSource = GetPages();
                r.DataBind();
            }
        }

        void r_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                PortalPage page = (PortalPage)e.Item.DataItem;
                HyperLink h = (HyperLink)e.Item.FindControl("h");
                h.Text = page.Name;
                h.NavigateUrl = portalService.GetPageUrl(page);
            }
            else if (e.Item.ItemType == ListItemType.Separator)
            {
                Literal lt = (Literal)e.Item.FindControl("lt");
                lt.Text = separator;
            }
        }

        private Stack<PortalPage> GetPages()
        {
            Stack<PortalPage> pages = new Stack<PortalPage>();

            PortalPage page = PortalContext.Current.PortalPage;
            do
            {
                pages.Push(page);
                page = portalService.LoadPage(page.ParentId);
            } while (page != null);

            return pages;
        }
    }
}
