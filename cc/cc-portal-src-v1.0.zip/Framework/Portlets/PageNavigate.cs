﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Web.UI.HtmlControls;

using CchenSoft.Portal.Model;
using CchenSoft.Portal.Attributes;
using CchenSoft.Portal.Web;

namespace CchenSoft.Portal.Portlets
{
    [Portlet("pagenav", "Common", "页面导航控件")]
    public class PageNavigate : PortletControl
    {
        public PageNavigate(PortletInstance portlet)
            : base(portlet)
        {
            skinFileName = "common/pagenavigate.ascx";
        }

        protected override void InitializeSkin(Control control)
        {
            Repeater rp = (Repeater)control.FindControl("rp");
            rp.ItemDataBound += new RepeaterItemEventHandler(rc_ItemDataBound);
            IList<PortalPage> pages = portalService.GetPages(PortalContext.Current.PortalPage.PageId);
            if (pages.Count == 0)
                pages = portalService.GetPages(PortalContext.Current.PortalPage.ParentId);

            rp.DataSource = pages;
            rp.DataBind();
        }

        private void rc_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            PortalPage page = (PortalPage)e.Item.DataItem;

            HyperLink hp = (HyperLink)e.Item.FindControl("hp");
            hp.Text = page.Name;
            hp.NavigateUrl = portalService.GetPageUrl(page);
        }

        protected override void Configure()
        {
        }
    }
}
