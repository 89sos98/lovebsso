﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Web.UI.HtmlControls;

using CchenSoft.Portal.Model;
using CchenSoft.Portal.Attributes;
using CchenSoft.Portal.Web;

namespace CchenSoft.Portal.Portlets
{
    [Portlet("iframe", "Common", "IFrame控件")]
    public class IFrameControl : PortletControl
    {
        [Config("src", "地址", typeof(TextBoxConfigControl))]
        private string src;

        public IFrameControl(PortletInstance portlet)
            : base(portlet)
        {
            skinFileName = "common/iframe.ascx";
        }

        protected override void InitializeSkin(Control control)
        {
            HtmlGenericControl fra = (HtmlGenericControl)control.FindControl("fra");
            fra.Attributes["src"] = src;
        }

        protected override void Configure()
        {
            src = portlet.GetPreference("src");
            if (src == null)
                src = "about:blank";
        }
    }
}
