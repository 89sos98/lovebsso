﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

using CchenSoft.Portal.Model;
using CchenSoft.Portal.Attributes;
using CchenSoft.Portal.Web;

namespace CchenSoft.Portal.Portlets
{
    [Portlet("htmltext", "Common", "HTML文本控件")]
    public class HtmlTextControl : PortletControl
    {
        [Config("text", "文本", typeof(HtmlTextConfigControl))]
        private string text;

        public HtmlTextControl(PortletInstance portlet)
            : base(portlet)
        {
            skinFileName = "common/htmltext.ascx";
        }

        protected override void InitializeSkin(Control control)
        {
            Literal lblContent = (Literal)control.FindControl("lblContent");
            lblContent.Text = text;
        }

        protected override void Configure()
        {
            text = portlet.GetPreference("text");
        }
    }
}
