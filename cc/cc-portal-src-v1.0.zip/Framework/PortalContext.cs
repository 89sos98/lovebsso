#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Framework.Config;

namespace CchenSoft.Portal
{
    public class PortalContext
    {
        private const string CONTEXT_KEY = "cms.context";

        private PortalPage page;
        private LayoutTemplate layout;
        private Theme theme;
        private bool isAdmin;

        public PortalContext(PortalPage page, HttpContext httpCtx)
        {
            IPortalService portalService = Configuration.Instance.GetService<IPortalService>();

            this.page = page;
            layout = portalService.LoadLayoutTemplate(page.LayoutId);
            theme = portalService.LoadTheme(portalService.GetConfig().Theme);
            httpCtx.Items[CONTEXT_KEY] = this;
        }

        public static PortalContext Current
        {
            get { return (PortalContext)HttpContext.Current.Items[CONTEXT_KEY]; }
        }

        public PortalPage PortalPage
        {
            get { return page; }
        }

        public LayoutTemplate Layout
        {
            get { return layout; }
        }

        public Theme Theme
        {
            get { return theme; }
        }

        public bool IsAdmin
        {
            get { return isAdmin; }
            set { isAdmin = value; }
        }

    }
}
