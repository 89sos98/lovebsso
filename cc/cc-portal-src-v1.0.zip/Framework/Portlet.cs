﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Attributes;

namespace CchenSoft.Portal
{
    public class Portlet
    {
        private string name;
        private string group;
        private string description;
        private Type controlType;
        private string preferences;
        private ConfigAttribute[] configs;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Group
        {
            get { return group; }
            set { group = value; }
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public Type ControlType
        {
            get { return controlType; }
            set { controlType = value; }
        }

        public string Preferences
        {
            get { return preferences; }
            set { preferences = value; }
        }

        public ConfigAttribute[] Configs
        {
            get { return configs; }
            set { configs = value; }
        }
    }
}
