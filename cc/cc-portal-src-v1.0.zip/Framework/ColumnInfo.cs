﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Model;

namespace CchenSoft.Portal
{
    [Serializable]
    public class ColumnInfo
    {
        public ColumnInfo()
        {
            instances = new int[0];
        }

        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private int[] instances;

        public int[] Instances
        {
            get { return instances; }
            set { instances = value; }
        }

        public void Add(int instance)
        {
            List<int> list = new List<int>(instances);
            list.Add(instance);
            instances = list.ToArray();
        }

        public void Remove(int instance)
        {
            List<int> list = new List<int>(instances);
            list.Remove(instance);
            instances = list.ToArray();
        }
    }
}
