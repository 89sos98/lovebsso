#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.Portal
{
    public class LayoutTemplate
    {
        private string tempId;
        private string name;
        private string control;
        private string zone;
        private string thumbImage;

        public string TempId
        {
            get { return tempId; }
            set { tempId = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Control
        {
            get { return control; }
            set { control = value; }
        }

        public string Zone
        {
            get { return zone; }
            set { zone = value; }
        }

        public string ThumbImage
        {
            get { return thumbImage; }
            set { thumbImage = value; }
        }

    }
}
