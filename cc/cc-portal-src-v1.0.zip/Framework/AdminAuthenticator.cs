﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using CchenSoft.Framework;
using System.Web.Security;
using System.Web.Configuration;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Model;

namespace CchenSoft.Portal
{
    public class AdminAuthenticator : IAuthenticator
    {
        private const string CookieKey = "portal_admin";
        private const string IdentityKey = "adminId";
        private const string IdentityNameKey = "adminName";

        private string loginUrl;
        private IPortalService portalService;

        public IPortalService PortalService
        {
            set { this.portalService = value; }
        }

        #region IAuthenticator 成员

        public string LoginUrl
        {
            get { return loginUrl; }
            set { loginUrl = value; }
        }

        public int Authenticate(string name, string passwd, int persist)
        {
            Administrator admin = portalService.ValidateLogin(name, passwd);
            int identity = (admin != null) ? admin.AdminId : 0;
            if (identity > 0)
            {
                HttpCookie cookie = new HttpCookie(CookieKey);
                cookie[IdentityKey] = identity.ToString();
                cookie[IdentityNameKey] = name;
                if (persist > 0)
                {
                    cookie.Expires = DateTime.Now.AddDays(persist);
                }
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
            return identity;
        }

        public bool IsAuthenticated
        {
            get
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
                return cookie != null ? !string.IsNullOrEmpty(cookie[IdentityKey]) : false;
            }
        }

        public string Identity
        {
            get
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
                return (cookie != null) ? cookie[IdentityKey] : null;
            }
        }

        public string IdentityName
        {
            get
            {
                HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
                return (cookie != null) ? cookie[IdentityNameKey] : null;
            }
        }

        public void SignOut()
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[CookieKey];
            if (cookie != null)
            {
                cookie.Expires = DateTime.Now.AddDays(-1);
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
        }

        public void CheckPermission(string resource, int action)
        {
            
        }

        #endregion
    }
}
