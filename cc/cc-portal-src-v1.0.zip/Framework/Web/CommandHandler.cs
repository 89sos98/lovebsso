#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Collections;

using CchenSoft.Framework.Utils;
using CchenSoft.Framework.Config;

using CchenSoft.Portal.Service;
using CchenSoft.Portal.Model;

namespace CchenSoft.Portal.Web
{
    public class CommandHandler : IHttpHandler
    {
        #region IHttpHandler ��Ա

        public bool IsReusable
        {
            get { return false; }
        }

        public void ProcessRequest(HttpContext context)
        {
            string action = context.Request["action"];
            if (!string.IsNullOrEmpty(action))
            {
                ICommand command = CommandFactory.CreateCommand(action.ToLower());
                if (command != null)
                    command.Execute(context);
            }
        }

        #endregion
    }

    public class CommandFactory
    {
        private static IDictionary<string, ICommand> commands = new Dictionary<string, ICommand>();

        static CommandFactory()
        {
            commands.Add("removeportlet", new RemovePortletCommand());
            commands.Add("addportlet", new AddPortletCommand());
            commands.Add("updatepage", new UpdatePageCommand());
        }

        public static ICommand CreateCommand(string name)
        {
            if (commands.ContainsKey(name))
                return commands[name];
            return null;
        }
    }

    public interface ICommand
    {
        void Execute(HttpContext context);
    }

    public class RemovePortletCommand : ICommand
    {
        #region ICommand ��Ա

        public void Execute(HttpContext context)
        {
            IPortalService service = Configuration.Instance.GetService<IPortalService>();

            int instanceId = ConvertUtil.ToInt32(context.Request["instance"]);
            int pageId = ConvertUtil.ToInt32(context.Request["page"]);

            service.RemovePortlet(pageId, instanceId);
        }

        #endregion
    }

    public class AddPortletCommand : ICommand
    {
        #region ICommand ��Ա

        public void Execute(HttpContext context)
        {
            IPortalService service = Configuration.Instance.GetService<IPortalService>();

            string portlet = context.Request["portlet"];
            int pageId = ConvertUtil.ToInt32(context.Request["page"]);

            service.AddPortlet(pageId, portlet);
        }

        #endregion
    }

    public class UpdatePageCommand : ICommand
    {
        #region ICommand ��Ա

        public void Execute(HttpContext context)
        {
            IPortalService service = Configuration.Instance.GetService<IPortalService>();

            string settings = context.Request["settings"];
            int pageId = ConvertUtil.ToInt32(context.Request["page"]);

            service.UpdateSettings(pageId, settings);
        }

        #endregion
    }
}
