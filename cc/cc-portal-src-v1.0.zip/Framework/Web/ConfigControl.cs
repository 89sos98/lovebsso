﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;

using CchenSoft.Framework.Utils;

namespace CchenSoft.Portal.Web
{
    public abstract class ConfigControl : CompositeControl
    {
        protected ConfigControl()
            : base()
        {
            ReflectUtil.InjectBeans(this);
        }

        public virtual void Process() { }

        public abstract string Text { get; set; }
    }
}
