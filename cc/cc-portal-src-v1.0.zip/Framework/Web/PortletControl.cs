#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using System.Web;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal.Model;

namespace CchenSoft.Portal.Web
{
    [ParseChildren(true)]
    public abstract class PortletControl : ThemeControl
    {
        protected PortletInstance portlet;

        public PortletControl(PortletInstance portlet)
        {
            this.portlet = portlet;
            Configure();
        }

        protected override Control LoadSkin()
        {
            Control control = Page.LoadControl(portalService.PortletsPath + skinFileName);
            return control;
        }


        protected string RawRequestPath
        {
            get
            {
                string url = Page.Request.RawUrl;
                int n = url.IndexOf('?');
                return n > 0 ? url.Substring(0, n) : url;
            }
        }

        protected abstract void Configure();
    }
}
