﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;

using CchenSoft.Framework.Utils;
using CchenSoft.Framework.Config;

using CchenSoft.Portal.Service;
using CchenSoft.Portal.Model;

namespace CchenSoft.Portal.Web
{
    public class ViewPageFactoryHandler : IHttpHandlerFactory
    {

        #region IHttpHandlerFactory 成员

        public IHttpHandler GetHandler(HttpContext context, string requestType, string url, string pathTranslated)
        {
            int pageId = ConvertUtil.ToInt32(context.Request["pid"]);

            string sendToUrl = url;
            string filePath = pathTranslated;

            if (pageId > 0)
            {
                IPortalService portalService = Configuration.Instance.GetService<IPortalService>();

                PortalPage page = portalService.LoadPage(pageId);

                if (page != null)
                {
                    PortalContext cmsCtx = new PortalContext(page, context);
                    cmsCtx.IsAdmin = true;

                    sendToUrl = cmsCtx.Theme.TemplatePath + "main.aspx";
                    filePath = context.Server.MapPath(sendToUrl);

                    context.RewritePath(sendToUrl);

                    //portalService.CreateHtmlFile(page);
                }

                return PageParser.GetCompiledPageInstance(sendToUrl, filePath, context);
            }

            return PageParser.GetCompiledPageInstance(url, filePath, context);
        }

        public void ReleaseHandler(IHttpHandler handler)
        {
        }

        #endregion
    }
}
