#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using CchenSoft.Portal.Service;
using CchenSoft.Framework.Attributes;

namespace CchenSoft.Portal.Web
{
    [ParseChildren(true)]
    public abstract class ThemeControl : ChildControl
    {
        [Bean]
        protected IPortalService portalService;

        protected string skinFileName;

        public string SkinFileName
        {
            get { return skinFileName; }
            set { skinFileName = value; }
        }

        protected override Control LoadSkin()
        {
            Control control = Page.LoadControl(PortalContext.Current.Theme.TemplatePath + skinFileName);
            return control;
        }
    }
}
