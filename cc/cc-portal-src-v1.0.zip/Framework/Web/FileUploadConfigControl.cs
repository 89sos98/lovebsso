﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Web;

namespace CchenSoft.Portal.Web
{
    [ToolboxData("<{0}:FileUploadConfig runat=\"server\"> </{0}:FileUploadConfig>")]
    public class FileUploadConfigControl : ConfigControl
    {
        private Label titleLabel;
        private Label fnameLabel;
        private FileUpload fileUpd;

        public string Title
        {
            get
            {
                EnsureChildControls();
                return titleLabel.Text;
            }
            set
            {
                EnsureChildControls();
                titleLabel.Text = value;
            }
        }

        public override string Text
        {
            get
            {
                EnsureChildControls();
                return fnameLabel.Text;
            }
            set
            {
                EnsureChildControls();
                fnameLabel.Text = value;
            }
        }

        public override void Process()
        {
            if (fileUpd.HasFile)
            {
                string fname = "~/upload/" + fileUpd.FileName;
                fileUpd.PostedFile.SaveAs(Page.Server.MapPath(fname));
                fnameLabel.Text = fname;
            }
        }

        protected override void RecreateChildControls()
        {
            EnsureChildControls();
        }

        protected override void CreateChildControls()
        {
            Controls.Clear();

            titleLabel = new Label();
            fnameLabel = new Label();

            fileUpd = new FileUpload();
            fileUpd.ID = "fileUpd";

            this.Controls.Add(titleLabel);
            this.Controls.Add(fileUpd);
            this.Controls.Add(fnameLabel);
        }

        protected override void Render(HtmlTextWriter writer)
        {
            AddAttributesToRender(writer);

            writer.AddAttribute(
                HtmlTextWriterAttribute.Cellpadding,
                "1", false);
            titleLabel.RenderControl(writer);
            fileUpd.RenderControl(writer);
            fnameLabel.RenderControl(writer);
        }

    }
}
