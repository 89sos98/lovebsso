﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Web;

namespace CchenSoft.Portal.Web
{
    [ToolboxData("<{0}:TextBoxConfig runat=\"server\"> </{0}:TextBoxConfig>")]
    public class TextBoxConfigControl : ConfigControl
    {
        private Label titleLabel;
        private TextBox textBox;

        public string Title
        {
            get
            {
                EnsureChildControls();
                return titleLabel.Text;
            }
            set
            {
                EnsureChildControls();
                titleLabel.Text = value;
            }
        }

        public override string Text
        {
            get
            {
                EnsureChildControls();
                return textBox.Text;
            }
            set
            {
                EnsureChildControls();
                textBox.Text = value;
            }
        }

        protected override void RecreateChildControls()
        {
            EnsureChildControls();
        }

        protected override void CreateChildControls()
        {
            Controls.Clear();

            titleLabel = new Label();

            textBox = new TextBox();
            textBox.ID = "textBox1";

            this.Controls.Add(titleLabel);
            this.Controls.Add(textBox);
        }


        protected override void Render(HtmlTextWriter writer)
        {
            AddAttributesToRender(writer);

            writer.AddAttribute(
                HtmlTextWriterAttribute.Cellpadding,
                "1", false);
            titleLabel.RenderControl(writer);
            textBox.RenderControl(writer);
        }

    }
}
