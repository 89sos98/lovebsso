#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using System.Web;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal.Model;

namespace CchenSoft.Portal.Web.Controls
{
    [ParseChildren(true)]
    public class ExceptionControl : ThemeControl
    {
        private Exception ex;
        private int instanceId;

        public ExceptionControl(int instanceId, Exception ex)
        {
            SkinFileName = "portletview.ascx";
            this.instanceId = instanceId;
            this.ex = ex;
        }

        protected override void InitializeSkin(Control control)
        {
            Literal title = (Literal)control.FindControl("title");
            title.Text = "Error";

            HtmlContainerControl box = (HtmlContainerControl)control.FindControl("portlet_box");
            if (box != null)
                box.ID = "_" + instanceId;

            HtmlContainerControl box_h = (HtmlContainerControl)control.FindControl("portlet_box_h");
            if (box_h != null)
                box_h.ID = "_" + instanceId + "_h";

            HtmlContainerControl box_c = (HtmlContainerControl)control.FindControl("portlet_box_c");
            if (box_c != null)
                box_c.ID = "_" + instanceId + "_c";

            HyperLink hlnkCfg = (HyperLink)control.FindControl("hlnkCfg");
            hlnkCfg.Visible = false;

            HyperLink hlnkClose = (HyperLink)control.FindControl("hlnkClose");
            if (PortalContext.Current.IsAdmin)
            {
                hlnkClose.NavigateUrl = string.Format(hlnkClose.NavigateUrl, box.ClientID);
            }
            else
            {
                hlnkClose.Visible = false;
            }

            PlaceHolder ph = (PlaceHolder)control.FindControl("content");
            Literal lt = new Literal();
            lt.Text = ex.ToString();
            ph.Controls.Add(lt);
        }
    }
}
