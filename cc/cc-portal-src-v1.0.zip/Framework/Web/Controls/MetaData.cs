#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using CchenSoft.Framework.Utils;

using CchenSoft.Portal.Model;
using CchenSoft.Portal;

namespace CchenSoft.Portal.Web.Controls
{
    public class MetaData : HtmlContainerControl
    {
        protected override void Render(HtmlTextWriter writer)
        {
            PortalPage page = PortalContext.Current.PortalPage;
            writer.Write(string.Format("<meta name=\"{0}\" content=\"{1}\">", this.ID, ReflectUtil.GetPropertyValue(page, this.ID)));
        }
    }
}
