#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Web.UI.Design;

namespace CchenSoft.Portal.Web.Controls
{
    [Designer(typeof(ContainerControlDesigner))]
    [ToolboxData("<{0}:Form runat=server></{0}:Form>")]
    public class Form : HtmlForm
    {
        protected override void RenderAttributes(HtmlTextWriter writer)
        {
            writer.WriteAttribute("action", Page.Request.RawUrl);
            base.Attributes.Remove("action");

            this.Attributes.Render(writer);

            if (base.ID != null)
                writer.WriteAttribute("id", base.ClientID);
        } 
    }
}
