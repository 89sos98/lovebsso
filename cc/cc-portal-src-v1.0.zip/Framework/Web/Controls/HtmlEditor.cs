#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using CchenSoft.Portal.Model;
using FredCK.FCKeditorV2;

namespace CchenSoft.Portal.Web.Controls
{
    [ParseChildren(true)]
    public class HtmlEditor : ChildControl
    {
        private FCKeditor editor;
        private string content;
        protected string skinFileName;

        public HtmlEditor()
        {
            skinFileName = "fckeditor.ascx";
        }

        public string SkinFileName
        {
            get { return skinFileName; }
            set { skinFileName = value; }
        }

        protected override void InitializeSkin(Control control)
        {
            editor = (FCKeditor)control.FindControl("editor");
            editor.Value = content;
        }

        public string Content
        {
            get 
            {
                content = editor.Value;
                return content; 
            }
            set { content = value; }
        }

        protected override Control LoadSkin()
        {
            Control control = Page.LoadControl("~/editors/" + skinFileName);
            return control;
        }
    }
}
