#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using CchenSoft.Portal.Model;

namespace CchenSoft.Portal.Web.Controls
{
    [ParseChildren(true)]
    public class Pager : ThemeControl
    {
        private int pageSize = 20;
        private int count;
        private int pageNo;
        private string pagerUrl;
        private PagerMode mode;

        public Pager()
        {
            skinFileName = "pager.ascx";
        }

        protected override void InitializeSkin(Control control)
        {
            HyperLink hf = (HyperLink)control.FindControl("hf");
            HyperLink hp = (HyperLink)control.FindControl("hp");
            HyperLink hn = (HyperLink)control.FindControl("hn");
            HyperLink hl = (HyperLink)control.FindControl("hl");
            Literal info = (Literal)control.FindControl("info");

            if (count > 0)
            {
                int pageCount = (count + pageSize - 1) / pageSize;

                if (pageNo > 1)
                {
                    hf.NavigateUrl = string.Format(pagerUrl, 1);
                    hp.NavigateUrl = string.Format(pagerUrl, pageNo - 1);
                }

                if (pageNo < pageCount)
                {
                    hn.NavigateUrl = string.Format(pagerUrl, pageNo + 1);
                    hl.NavigateUrl = string.Format(pagerUrl, pageCount);
                }

                info.Text = string.Format("��¼��:{0} ҳ��:{1}/{2}", count, pageNo, pageCount);
            }
            else
            {
                hf.Visible = false;
                hp.Visible = false;
                hn.Visible = false;
                hl.Visible = false;
                info.Visible = false;
            }
        }

        public string PagerUrl
        {
            get { return pagerUrl; }
            set { pagerUrl = value; }
        }

        public PagerMode Mode
        {
            get { return mode; }
            set { mode = value; }
        }

        public int PageSize
        {
            get { return pageSize; }
            set { pageSize = value; }
        }

        public int PageNo
        {
            get { return pageNo; }
            set { pageNo = value; }
        }

        public int Count
        {
            get { return count; }
            set { count = value; }
        }
    }

    public enum PagerMode : int
    {
        NextPrev,
        Numeric
    }
}
