#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;

namespace CchenSoft.Portal.Web.Controls
{
    [ParseChildren(true)]
    public class Bottom : ThemeControl
    {
        public Bottom()
        {
            SkinFileName = "bottom.ascx";
        }

        protected override void InitializeSkin(Control control)
        {
            Literal lcw = (Literal)control.FindControl("lcr");
            if (lcw != null)
            {
                string copyright = portalService.GetConfig().Copyright;
                lcw.Text = "<div class='copyright'>" + copyright + "</div> <div class='powerby'>Power by: <a href='http://www.cchensoft.com/products/portal/' target='_blank'>����Portal</a></div>";
            }
            else
            {
                throw new Exception("�Ҳ����ؼ���");
            }
        }
    }
}
