#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Framework.Config;

namespace CchenSoft.Portal.Web.Controls
{
    public class Title : HtmlContainerControl
    {
        protected override void Render(HtmlTextWriter writer)
        {
            IPortalService portalService = Configuration.Instance.GetService<IPortalService>();
            StringBuilder sb = new StringBuilder();
            PortalPage page = PortalContext.Current.PortalPage;
            do
            {
                sb.Append(page.Title).Append(" - ");
                page = portalService.LoadPage(page.ParentId);
            } while (page != null);

            sb.Append(portalService.GetConfig().Title);

            writer.Write(string.Format("<title>{0}</title>", sb.ToString()));
        }
    }
}
