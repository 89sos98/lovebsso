#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using CchenSoft.Portal.Model;

namespace CchenSoft.Portal.Web.Controls
{
    [ParseChildren(true)]
    public class Top : ThemeControl
    {
        public Top()
        {
            SkinFileName = "top.ascx";
        }

        protected override void InitializeSkin(Control control)
        {
            Image imgLogo = (Image)control.FindControl("imgLogo");
            HyperLink lnkBanner = (HyperLink)control.FindControl("lnkBanner");
            Image imgBanner = (Image)control.FindControl("imgBanner");

            PortalConfig config = portalService.GetConfig();
            if (imgLogo != null)
            {
                imgLogo.ImageUrl = config.LogoUrl;
                imgLogo.AlternateText = config.Title;
            }

            if (lnkBanner != null)
                lnkBanner.NavigateUrl = config.BannerLink;

            if (imgBanner != null)
                imgBanner.ImageUrl = config.BannerUrl;

            Repeater rm = (Repeater)control.FindControl("rm");
            if (rm != null)
            {
                rm.DataSource = portalService.GetPages(0);
                rm.ItemDataBound += new RepeaterItemEventHandler(rm_ItemDataBound);
                rm.DataBind();
            }
        }

        void rm_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                PortalPage page = (PortalPage)e.Item.DataItem;

                HyperLink hMenu = (HyperLink)e.Item.FindControl("hm");
                hMenu.Text = page.Name;
                hMenu.NavigateUrl = portalService.GetPageUrl(page);
            }
        }
    }
}
