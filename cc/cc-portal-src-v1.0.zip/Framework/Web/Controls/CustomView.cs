#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using System.Web;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal.Model;

namespace CchenSoft.Portal.Web.Controls
{
    [ParseChildren(true)]
    public class CustomView : ThemeControl
    {
        private PortletInstance portlet;

        public CustomView(PortletInstance portlet)
        {
            this.portlet = portlet;
            SkinFileName = "portletview.ascx";
        }

        //protected override 
        protected override void InitializeSkin(Control control)
        {           
        }
    }
}
