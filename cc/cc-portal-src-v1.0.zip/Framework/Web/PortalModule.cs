#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.IO;
using System.Collections.Generic;

using CchenSoft.Framework.Config;

using CchenSoft.Portal.Model;
using CchenSoft.Portal.Service;

namespace CchenSoft.Portal.Web
{
    public class PortalModule : IHttpModule
    {
        private void Application_BeginRequest(object sender, EventArgs e)
        {
            HttpContext context = ((HttpApplication)sender).Context;
            
            // process portal page.
            string path = context.Request.Path.ToLower();
            if (path.EndsWith("/"))
                path += "default.aspx";

            if (path.EndsWith(".aspx"))
            {
                IPortalService service = Configuration.Instance.GetService<IPortalService>();

                int n = context.Request.ApplicationPath.Length;
                if (n > 1)
                    path = path.Substring(n);
                path = path.Substring(0, path.Length - 5);
                PortalPage page = service.GetPageByUrl(path);

                if (page != null)
                {
                    //log.Info("found page: " + page.Name, this.GetType());

                    PortalContext cmsCtx = new PortalContext(page, context);
                    context.RewritePath(cmsCtx.Theme.TemplatePath + "main.aspx");
                }
            }
        }

        #region IHttpModule ��Ա

        public void Dispose()
        {
        }

        public void Init(HttpApplication context)
        {
            context.BeginRequest += new EventHandler(Application_BeginRequest);
        }

        #endregion
    }
}
