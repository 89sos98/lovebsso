﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Reflection;

using CchenSoft.Framework.Config;

using CchenSoft.Portal.Model;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Attributes;
using CchenSoft.Portal.Web;

namespace CchenSoft.Portal
{
    public class PortletFactory
    {
        public static PortletControl Create(PortletInstance portlet)
        {
            IPortalService service = Configuration.Instance.GetService<IPortalService>();
            Portlet cc = service.GetPortlet(portlet.PortletName);
            if (cc != null)
            {
                ConstructorInfo ci = cc.ControlType.GetConstructor(new Type[] { typeof(PortletInstance) });
                if (ci != null)
                {
                    return (PortletControl)ci.Invoke(new object[] { portlet });
                }
            }

            return null;
        }
    }
}
