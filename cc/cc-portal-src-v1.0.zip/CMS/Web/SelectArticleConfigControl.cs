﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.Portal.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CchenSoft.CMS.Web
{
    [ToolboxData("<{0}:SelectArticleConfig runat=\"server\"> </{0}:SelectArticleConfig>")]
    public class SelectArticleConfigControl : ConfigControl
    {        
        private Label titleLabel;
        private TextBox textBox;
        private HyperLink lnkSelect;

        public string Title
        {
            get
            {
                EnsureChildControls();
                return titleLabel.Text;
            }
            set
            {
                EnsureChildControls();
                titleLabel.Text = value;
            }
        }

        public override string Text
        {
            get
            {
                EnsureChildControls();
                return textBox.Text;
            }
            set
            {
                EnsureChildControls();
                textBox.Text = value;
            }
        }

        protected override void RecreateChildControls()
        {
            EnsureChildControls();
        }

        protected override void CreateChildControls()
        {
            Controls.Clear();

            titleLabel = new Label();

            textBox = new TextBox();
            textBox.ID = "textBox1";

            lnkSelect = new HyperLink();
            lnkSelect.Text = "选择";
            lnkSelect.CssClass = "thickbox";
            lnkSelect.NavigateUrl = "../cms/SelectArticle.aspx?KeepThis=true&TB_iframe=true&height=350&width=550";

            this.Controls.Add(titleLabel);
            this.Controls.Add(textBox);
            this.Controls.Add(lnkSelect);
        }

        protected override void Render(HtmlTextWriter writer)
        {
            AddAttributesToRender(writer);

            writer.AddAttribute(
                HtmlTextWriterAttribute.Cellpadding,
                "1", false);
            titleLabel.RenderControl(writer);
            textBox.RenderControl(writer);
            lnkSelect.RenderControl(writer);
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<script type='text/javascript'>")
            .AppendLine("   function selectComplete(result) {")
            .AppendLine("      tb_remove();")
            .AppendFormat("      document.getElementById('{0}').value = result;", textBox.ClientID)
            .AppendLine()
            .AppendLine("   }")
            .AppendLine("</script>");

            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "selectComplete", sb.ToString());
        }

    }
}
