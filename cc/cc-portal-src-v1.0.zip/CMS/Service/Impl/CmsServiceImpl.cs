﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.CMS.Model;
using CchenSoft.Framework.Data;

namespace CchenSoft.CMS.Service.Impl
{
    public class CmsServiceImpl : ICmsService
    {
        private IDataService dataService;

        public IDataService DataService
        {
            set { dataService = value; }
        }

        #region Articles

        public Article LoadArticle(int id)
        {
            return dataService.QueryForObject<Article>("cms.SelectArticle", id);
        }

        public void SaveArticle(Article article)
        {
            dataService.Insert("cms.InsertArticle", article);
        }

        public void UpdateArticle(Article article)
        {
            dataService.Update("cms.UpdateArticle", article);
        }

        public void DeleteArticle(int id)
        {
            dataService.Delete("cms.DeleteArticle", id);
        }

        public IList<Article> FindArticles(string keywords, int pageNo, int pageSize, ref int count)
        {
            count = Convert.ToInt32(dataService.QueryForObject("cms.GetArticlesCount", keywords));
            return dataService.QueryForList<Article>("cms.FindArticles", keywords, (pageNo - 1) * pageSize, pageSize);
        }

        #endregion
    }
}
