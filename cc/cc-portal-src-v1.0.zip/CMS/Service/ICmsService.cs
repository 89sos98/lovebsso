﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using CchenSoft.CMS.Model;

namespace CchenSoft.CMS.Service
{
    public interface ICmsService
    {
        #region Articles

        Article LoadArticle(int id);

        void SaveArticle(Article article);

        void UpdateArticle(Article article);

        void DeleteArticle(int id);

        IList<Article> FindArticles(string keywords, int pageNo, int pageSize, ref int count);

        #endregion
    }
}
