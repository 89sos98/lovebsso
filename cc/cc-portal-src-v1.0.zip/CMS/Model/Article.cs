﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace CchenSoft.CMS.Model
{
    public class Article
    {
        private int articleId;
        private string title;
        private string content;
        private string tags;
        private DateTime createDate;

        public Article()
        {
            createDate = DateTime.Now;
        }

        public int ArticleId
        {
            get { return articleId; }
            set { articleId = value; }
        }

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public string Content
        {
            get { return content; }
            set { content = value; }
        }

        public string Tags
        {
            get { return tags; }
            set { tags = value; }
        }

        public DateTime CreateDate
        {
            get { return createDate; }
            set { createDate = value; }
        }


    }
}
