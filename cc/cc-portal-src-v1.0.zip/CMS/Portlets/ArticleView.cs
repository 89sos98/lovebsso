﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

using CchenSoft.Framework.Utils;
using CchenSoft.Framework.Attributes;
using CchenSoft.Portal.Web;
using CchenSoft.Portal.Attributes;
using CchenSoft.Portal.Model;
using CchenSoft.CMS.Service;
using CchenSoft.CMS.Model;
using CchenSoft.CMS.Web;

namespace CchenSoft.CMS.Portlets
{
    [Portlet("ArticleView", "CMS", "文章查看")]
    public class ArticleView : PortletControl
    {
        [Bean]
        protected ICmsService cmsService;

        [Config("articleid", "文章ID", typeof(SelectArticleConfigControl))]
        private int articleId;

        [Config("showtitle", "显示标题", typeof(CheckBoxConfigControl))]
        private bool showTitle;

        public ArticleView(PortletInstance portlet)
            : base(portlet)
        {
            skinFileName = "cms/articleview.ascx";
        }

        protected override void Configure()
        {
            articleId = ConvertUtil.ToInt32(portlet.GetPreference("articleid"));
            showTitle = "true".Equals(portlet.GetPreference("showtitle"));
        }

        protected override void InitializeSkin(Control control)
        {
            Literal lc = (Literal)control.FindControl("lc");
            Literal lt = (Literal)control.FindControl("lt");

            if (articleId > 0)
            {
                Article art = cmsService.LoadArticle(articleId);
                if (art != null)
                {
                    if (showTitle)
                        lt.Text = art.Title;
                    else
                        lt.Visible = true;

                    lc.Text = art.Content;
                }
                else
                {
                    lc.Text = "找不到文章。";
                }
            }
            else
            {
                lc.Text = "没有配置文章。";
            }
        }
    }
}
