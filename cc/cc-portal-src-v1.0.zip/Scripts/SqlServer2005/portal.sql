SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[portal_portlets]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[portal_portlets](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[portlet_name] [nvarchar](50) NULL,
	[page_id] [int] NULL,
	[title] [nvarchar](50) NULL,
	[show_title] [bit] NULL,
	[preferences] [nvarchar](max) NULL,
 CONSTRAINT [PK_cms_portlets] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cms_articles]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[cms_articles](
	[article_id] [int] IDENTITY(1,1) NOT NULL,
	[title] [nvarchar](100) NULL,
	[content_] [nvarchar](max) NULL,
	[tags] [nvarchar](200) NULL,
	[create_date] [datetime] NULL,
 CONSTRAINT [PK_cms_articles] PRIMARY KEY CLUSTERED 
(
	[article_id] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[portal_pages]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[portal_pages](
	[page_id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](50) NULL,
	[page_type] [nvarchar](50) NOT NULL,
	[settings] [nvarchar](max) NULL,
	[parent_id] [int] NULL,
	[friendly_url] [nvarchar](500) NULL,
	[new_window] [bit] NULL,
	[redirect_url] [nvarchar](500) NULL,
	[layout_id] [nvarchar](50) NULL,
	[theme_id] [nvarchar](50) NULL,
	[sort_no] [int] NULL,
	[title] [nvarchar](100) NULL,
	[keywords] [nvarchar](500) NULL,
	[description] [nvarchar](500) NULL,
 CONSTRAINT [PK_cms_pages] PRIMARY KEY CLUSTERED 
(
	[page_id] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
