﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Xml;

using CchenSoft.Framework.Utils;
using CchenSoft.Framework.Attributes;

using CchenSoft.Portal.Web;
using CchenSoft.Portal.Service;
using CchenSoft.Portal.Model;
using CchenSoft.Portal.Attributes;
using CchenSoft.Portal;

public partial class Admin_Portal_PortletConfigure : AdminPage
{
    [Bean]
    protected IPortalService portalService;

    private PortletInstance instance;

    protected void Page_Load(object sender, EventArgs e)
    {
        int id = ConvertUtil.ToInt32(Request["id"]);

        instance = portalService.LoadPortlet(id);
        if (instance != null)
        {
            if (!IsPostBack)
            {
                tt.Text = instance.Title;
                ct.Checked = instance.ShowTitle;
            }

            Portlet cc = portalService.GetPortlet(instance.PortletName);

            if (cc != null)
            {
                rptConfig.DataSource = cc.Configs;
                rptConfig.DataBind();
            }
        }
    }

    protected void rptConfig_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        ConfigAttribute ca = (ConfigAttribute)e.Item.DataItem;

        Literal lblName = (Literal)e.Item.FindControl("lblName");
        lblName.Visible = false;
        lblName.Text = ca.Name;

        ((Literal)e.Item.FindControl("lblTitle")).Text = ca.Title;

        Control c = e.Item.FindControl("holder");

        ConfigControl cc = (ConfigControl)Activator.CreateInstance(ca.UIType);
        cc.ID = "cc_" + ca.Name;
        cc.Text = instance.GetPreference(ca.Name);

        c.Controls.Add(cc);
    }

    protected void btnOK_Click(object sender, EventArgs e)
    {
        Dictionary<string, string> prefs = new Dictionary<string, string>();

        foreach (RepeaterItem item in rptConfig.Items)
        {
            string name = ((Literal)item.FindControl("lblName")).Text;
            ConfigControl cc = (ConfigControl)(item.FindControl("holder").Controls[0]);
            cc.Process();
            string value = cc.Text;
            prefs[name] = value;
        }

        instance.Title = tt.Text;
        instance.ShowTitle = ct.Checked;
        portalService.UpdatePortlet(instance, prefs);
        
        Response.Write("<script type='text/javascript'>javascript:parent.configComplete('OK');</script>");
        Response.End();
    }
}
