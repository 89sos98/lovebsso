﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CchenSoft.Portal.Service;
using CchenSoft.Framework.Attributes;
using CchenSoft.Portal;

public partial class Admin_portal_SelectLayout : AdminPage
{
    [Bean]
    protected IPortalService portalService;

    private string current;

    protected void Page_Load(object sender, EventArgs e)
    {
        current = Request["current"];
        if (!IsPostBack)
        {
            dl.DataSource = portalService.Layouts;
            dl.DataBind();
        }
    }

    public string Current
    {
        get { return string.IsNullOrEmpty(current) ? "none" : current; }
    }

    protected void dl_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        LayoutTemplate lt = (LayoutTemplate)e.Item.DataItem;

        ((Image)e.Item.FindControl("imgThumb")).ImageUrl = lt.ThumbImage;
        ((Literal)e.Item.FindControl("lblName")).Text = lt.Name;
    }

    protected void btnOK_Click(object sender, EventArgs e)
    {
        string selected = Request["layout"];
        Response.Write(string.Format("<script type='text/javascript'>parent.layoutSelected('{0}');</script>", selected));
        Response.End();
    }
}
