﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Text;

public partial class Admin_Menu : System.Web.UI.Page
{
    private string menuScript;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<script type='text/javascript'>");
            sb.AppendLine("d = new dTree('d');");
            sb.AppendLine("d.config.target = 'frmright';");
            sb.AppendLine("d.add(0, -1, '管理菜单', 'javascript: void(0);');");
            int count = 1;
            IList<MenuInfo> menus = GetMenus();
            foreach (MenuInfo menu in menus)
            {
                sb.AppendFormat("d.add({0},0,'{1}','javascript: void(0);');\r\n", count, menu.Name);
                int parent = count;
                count++;
                foreach (ItemInfo item in menu.Items)
                {
                    sb.AppendFormat("d.add({0},{1},'{2}','{3}');\r\n", count, parent, item.Name, item.Url);
                    count++;
                }
            }

            sb.AppendLine("document.write(d);");
            sb.AppendLine("</script>");

            menuScript = sb.ToString();
        }
    }

    protected string MenuScript
    {
        get { return menuScript; }
    }

    private IList<MenuInfo> GetMenus()
    {
        SortedList<int, MenuInfo> menus = new SortedList<int, MenuInfo>();

        string[] folders = Directory.GetDirectories(Server.MapPath("~/admin"));
        for (int i = 0; i < folders.Length; i++)
        {
            FileInfo fi = new FileInfo(folders[i] + "\\menus.config");
            if (fi.Exists)
            {
                List<MenuInfo> list = Parse(fi);
                foreach (MenuInfo mi in list)
                    menus.Add(mi.Sortno, mi);
            }
        }

        return menus.Values;
    }

    private List<MenuInfo> Parse(FileInfo fi)
    {
        List<MenuInfo> menus = new List<MenuInfo>();

        XmlDocument doc = new XmlDocument();
        doc.Load(fi.FullName);

        XmlNodeList mNodes = doc.DocumentElement.SelectNodes("menu");
        foreach (XmlNode mn in mNodes)
        {
            MenuInfo mi = new MenuInfo();
            mi.Name = mn.Attributes.GetNamedItem("name").Value;
            mi.Sortno = Convert.ToInt32(mn.Attributes.GetNamedItem("sortno").Value);
            string[] paths = fi.FullName.Split('\\');
            mi.Folder = paths[paths.Length - 2];

            XmlNodeList nodes = mn.SelectNodes("item");
            mi.Items = new List<ItemInfo>();
            foreach (XmlNode n in nodes)
            {
                ItemInfo ii = new ItemInfo();
                ii.Name = n.Attributes.GetNamedItem("name").Value;
                ii.Url = mi.Folder + "/" + n.InnerText;
                mi.Items.Add(ii);
            }

            menus.Add(mi);
        }

        return menus;
    }

    private class MenuInfo
    {
        public string Name;
        public int Sortno;
        public string Folder;
        public List<ItemInfo> Items;
    }

    private class ItemInfo
    {
        public string Name;
        public string Url;
    }
}
