﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_Pager : System.Web.UI.UserControl
{
    private int pageSize = 20;
    private int count;
    private int pageNo;
    private string pagerUrl;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            int pageCount = (count + pageSize - 1) / pageSize;

            if (pageNo > 1)
            {
                lnkFirst.NavigateUrl = string.Format(pagerUrl, 1);
                lnkPrior.NavigateUrl = string.Format(pagerUrl, pageNo - 1);
            }

            if (pageNo < pageCount)
            {
                lnkNext.NavigateUrl = string.Format(pagerUrl, pageNo + 1);
                lnkLast.NavigateUrl = string.Format(pagerUrl, pageCount);
            }

            lblInfo.Text = string.Format("记录数:{0} 页数:{1}/{2}", count, pageNo, pageCount);
        }
    }

    public string PagerUrl
    {
        get { return pagerUrl; }
        set { pagerUrl = value; }
    }

    public int PageSize
    {
        get { return pageSize; }
        set { pageSize = value; }
    }

    public int PageNo
    {
        get { return pageNo; }
        set { pageNo = value; }
    }

    public int Count
    {
        get { return count; }
        set { count = value; }
    }
}
