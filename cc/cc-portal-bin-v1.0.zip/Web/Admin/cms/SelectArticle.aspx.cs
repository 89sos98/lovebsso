﻿#region license
/*
 * Copyright (C) 2007 CchenSoft.com
 * 
 * See http://www.cchensoft.com/opensource/cc-portal/license.txt
 * 
 * Author: Billy Zhang
 * Email: billy_zh@126.com
 */
#endregion

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CchenSoft.CMS.Model;
using CchenSoft.CMS.Service;
using CchenSoft.Framework.Attributes;
using CchenSoft.Framework.Utils;

public partial class Admin_cms_SelectArticle : AdminPage
{
    private int pageIndex;
    private int pageSize = 20;

    [Bean]
    protected ICmsService cmsService;

    protected void Page_Load(object sender, EventArgs e)
    {
        pageIndex = ConvertUtil.ToInt32(Request["page"]);
        if (pageIndex < 1)
            pageIndex = 1;

        if (!IsPostBack)
        {
            int rowCount = 0;

            ra.DataSource = cmsService.FindArticles("", pageIndex, pageSize, ref rowCount);
            ra.DataBind();
        }
    }

    protected void ra_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item ||
            e.Item.ItemType == ListItemType.AlternatingItem)
        {
            Article dr = (Article)e.Item.DataItem;
            ((Literal)e.Item.FindControl("lt")).Text = dr.Title;

            HyperLink he = (HyperLink)e.Item.FindControl("he");
            he.NavigateUrl = string.Format(he.NavigateUrl, dr.ArticleId);
        }
    }
}
