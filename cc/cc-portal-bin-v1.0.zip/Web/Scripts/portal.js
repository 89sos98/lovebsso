﻿
var server = location.host;
    
function getTicks() {
    var d,s;
   d = new Date();
   s += d.getDate() + "-";
   s += d.getHours() + "-";
   s += d.getMinutes() + "-";
   s += d.getSeconds() + "-";
   s += d.getMilliseconds();
   return(s);
}

var Portal  = new Object();

// 关闭Portlet实例.
Portal.closePortlet = function(instance) {
    document.getElementById(instance).style.display = "none";            
    var url = "http://" + server + "/command.aspx?action=removeportlet&instance=" + instance.substring(1) + "&page=" + Portal.page;
    //AjaxUtil.request(url);
    $.get(url);
}

// 添加一个Portlet.
Portal.addPortlet = function(portlet) {
    var url = "http://" + server + "/command.aspx?action=addportlet&portlet=" + portlet + "&page=" + Portal.page + "&t=" + getTicks();
    $.get(url, addPortletCompleted);
}

function addPortletCompleted(response) {
    alert("completed");
    location.reload();
}

// 拖拽结束.
Portal.dragComplete = function(columns) {
    var settings = "";
    for (var i=0; i<columns.length; i++) {
        settings += columns[i] + ";";
    }
    
    var url = "http://" + server + "/command.aspx?action=updatepage&settings=" + escape(settings) + "&page=" + Portal.page;
    $.get(url);
}

// 显示添加Content层
Portal.showPortlets = function() {
    var obj = document.getElementById("portal_portlets");
    obj.style.display = "block";
}

// 关闭添加Content层
Portal.closePortlets = function() {
    var obj = document.getElementById("portal_portlets");
    obj.style.display = "none";
}

// 初始化.   
Portal.initialize = function(page) {    
    Portal.page = page;
}