//*******************************************************
// purpose: ���к�̨ҳ��Ļ��ࡣ
// author: billy
// created: 2006-03-10
//**********************************************************
using System;
using System.Configuration;
using System.Web;
using System.Web.UI;
using CchenSoft.Framework.Utils;
using CchenSoft.Framework;
using CchenSoft.Framework.Attributes;

	/// <summary>
	/// BasePage ��ժҪ˵����
	/// </summary>
public class BasePage : Page
{
    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        ReflectUtil.InjectBeans(this);
    }
}
