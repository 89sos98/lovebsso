﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using Iesi.Collections.Generic;

namespace DomainModel.Entities
{
    public class Customer
    {
        public virtual int CustomerId { get; set; }
        //使用Name后要屏蔽这2个属性和映射
        public virtual string Firstname { get; set; }
        public virtual string Lastname { get; set; }
        //版本控制
        public virtual int Version { get; set; }
    }
}
