﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//

using NUnit.Framework;
using DomainModel.Entities;
using NHibernate;

namespace DAL.Test
{
    [TestFixture]
    public class NHibernateSampleFixture
    {
        private ISession _session;
        private SessionManager _helper;
        private NHibernateSample _sample;
        [TestFixtureSetUp]
        public void TestFixtureSetup()
        {
            _helper = new SessionManager();
        }
        [SetUp]
        public void Setup()
        {
            _session = _helper.GetSession();
            _sample = new NHibernateSample(_session);
        }
        [Test]
        public void GetCustomerById1Test()
        {
            NHibernateSample _sample = new NHibernateSample(_session);
            Assert.AreEqual(1, _sample.GetCustomerById(1).CustomerId);
        }
        [Test]
        public void GetCustomerByIdTest()
        {
            Customer customer = _sample.GetCustomerById(1);
            int customerId = customer.CustomerId;
            Assert.AreEqual(1,customerId);
        }
    }
}
