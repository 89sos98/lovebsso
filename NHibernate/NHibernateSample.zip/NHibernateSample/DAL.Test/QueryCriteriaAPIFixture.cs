﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using NUnit.Framework;
using DomainModel.Entities;
using NHibernate;
using NHibernate.Criterion;

namespace DAL.Test
{
    [TestFixture]
    public class QueryCriteriaAPIFixture
    {
        private SessionManager _helper;
        private ISession _session;
        private QueryCriteriaAPI _queryCriteriaAPI;
        [TestFixtureSetUp]
        public void TestFixtureSetup()
        {
            _helper = new SessionManager();
        }
        [SetUp]
        public void Setup()
        {
            _session = _helper.GetSession();
            _queryCriteriaAPI = new QueryCriteriaAPI(_session);
        }
        #region 语法测试
        [Test]
        public void CreateCriteriaTest()
        {
            IList<Customer> customers = _queryCriteriaAPI.CreateCriteria();
            Assert.AreEqual(2, customers.Count);
        }
        [Test]
        public void NarrowingTest()
        {
            IList<Customer> customers = _queryCriteriaAPI.Narrowing();
            Assert.AreEqual(1, customers.Count);
        }
        [Test]
        public void OrderTest()
        {
            IList<Customer> customers = _queryCriteriaAPI.Order();
            Assert.AreEqual(1, customers.Count);
        }
        #endregion
        #region 实例测试
        [Test]
        public void CanUseCriteriaAPI_GetCustomersByFirstname()
        {
            IList<Customer> customers = _queryCriteriaAPI.UseCriteriaAPI_GetCustomersByFirstname("Y");
            Assert.AreEqual(1, customers.Count);
        }

        [Test]
        public void CanUseCriteriaAPI_GetCustomerByFirstnameAndLastname()
        {
            IList<Customer> customers = _queryCriteriaAPI.UseCriteriaAPI_GetCustomersByFirstnameAndLastname("Y", "JingLee");
            Assert.AreEqual(1, customers.Count);
        }

        [Test]
        public void CanUseCriteriaAPI_CanGetCustomersWithIdGreaterThan()
        {
            IList<Customer> customers = _queryCriteriaAPI.UseCriteriaAPI_GetCutomersWithIdGreaterThan(1);
            foreach (Customer c in customers)
            {
                Assert.GreaterOrEqual(c.CustomerId, 1);
            }
        }
        #endregion
    }
}
