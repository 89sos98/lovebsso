﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;

namespace DAL.Test
{
    public class Schema
    {
        private void CreateDatabase()
        {
            Configuration cfg = new Configuration();
            cfg.Configure();
            SchemaExport schema = new SchemaExport(cfg);
            //schema.Drop(true, false);
            //相当于：Execute(script, export, true, true)
            schema.SetOutputFile("log.txt");
            schema.Create(true, false);
            //相当于：Execute(script, export, false, true)


            //schema.Execute(true, false, false, false);

            //schema.Execute(true, true, false, true);
            //注意关系：foreign-key="FK_CustomerOrders",unique-key="UC_CustomerName"
            //一些属性：unique="true",index="IX_ProductName"

            //生成视图注意.
        }
    }
}
