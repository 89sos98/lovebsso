﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using NUnit.Framework;
using DomainModel.Entities;
using NHibernate;

namespace DAL.Test
{
    [TestFixture]
    public class QueryHQLFixture
    {
        private SessionManager _helper;
        private ISession _session;
        private QueryHQL _queryHQL;
        [TestFixtureSetUp]
        public void TestFixtureSetup()
        {
            _helper = new SessionManager();
        }
        [SetUp]
        public void Setup()
        {
            _session = _helper.GetSession();
            _queryHQL = new QueryHQL(_session);
        }
        [Test]
        public void FromTest()
        {
            IList<Customer> customers = _queryHQL.From();
            Assert.AreEqual(1, customers.Count);
        }
        [Test]
        public void FromAliasTest()
        {
            IList<Customer> customers = _queryHQL.FromAlias();
            Assert.AreEqual(1, customers.Count);
        }
        [Test]
        public void FromCartesianproductTest()
        {
            IList<Customer> customers = _queryHQL.FromCartesianproduct();
            Assert.AreEqual(1, customers.Count);
        }
        [Test]
        public void Select()
        {
            IList<int> customerId =_queryHQL.Select();
            foreach (var cId in customerId)
            {
                Assert.AreEqual(1, customerId.Count<int>(x => x == cId));
            }
        }
        [Test]
        public void SelectObjectTest()
        {
            IList<object[]> firstnameCounts =_queryHQL.SelectObject();
            Dictionary<string, int> expectedCounts = new Dictionary<string, int>();
            expectedCounts.Add("YJing", 1);//给定关键字不在字典中异常
            foreach (var item in firstnameCounts)
            {
                Assert.AreEqual(expectedCounts[item[0].ToString()], item[1]);
                Assert.IsTrue(expectedCounts.ContainsKey(item[0].ToString()));
            }
        }
        //[Test]
        //public void SelectNetObjectTest()
        //{
        //    IList<CustomerFirstnameCounter> firstnameCounts = _queryHQL.SelectNetObject();
        //    Dictionary<string, int> expectedCounts = new Dictionary<string, int>();
        //    expectedCounts.Add("Y", 1);
        //    expectedCounts.Add("li", 1);
        //    foreach (var item in firstnameCounts)
        //    {
        //        Assert.AreEqual(expectedCounts[item.Firstname], item.Count);
        //        Assert.IsTrue(expectedCounts.ContainsKey(item.Firstname));
        //    }
        //}
        [Test]
        public void AggregateFunctionTest()
        {
            IList<object[]> aggregateCounts = _queryHQL.AggregateFunction();
            foreach (var item in aggregateCounts)
            {
                Assert.AreEqual(1, item[1]);//item[1]为CustomerId的总和
            }
        }
        [Test]
        public void DistinctTest()
        {
            IList<string> firstnames = _queryHQL.Distinct();
            foreach (var fn in firstnames)
            {
                Assert.AreEqual(1, firstnames.Count<string>(x => x == fn));
            }
        }
        [Test]
        public void WhereTest()
        {
            IList<Customer> customers = _queryHQL.Where();
            Assert.AreEqual(1, customers.Count);
        }
        [Test]
        public void WhereExpressionTest()
        {
            IList<Customer> customers = _queryHQL.WhereExpression();
            Assert.AreEqual(1, customers.Count);
        }
        [Test]
        public void OrderbyTest()
        {
            IList<Customer> customers = _queryHQL.Orderby();
            Assert.AreEqual(1, customers.Count);
        }
        [Test]
        public void GroupbyTest()
        {
            IList<object[]> firstnameCounts = _queryHQL.Groupby();
            Dictionary<string, int> expectedCounts = new Dictionary<string, int>();
            expectedCounts.Add("YJing", 1);//给定关键字不在字典中异常
            expectedCounts.Add("li", 1);
            foreach (var item in firstnameCounts)
            {
                Assert.AreEqual(expectedCounts[item[0].ToString()], item[1]);
                Assert.IsTrue(expectedCounts.ContainsKey(item[0].ToString()));
            }
        }
        [Test]
        public void SubqueryTest()
        {
            IList<Customer> customers = _queryHQL.Subquery();
            Assert.AreEqual(1, customers.Count);
        }

        #region 实例测试
        [Test]
        public void CanGetCustomerByFirstname()
        {
            IList<Customer> customers = _queryHQL.GetCustomersByFirstname("Y");
            if (customers.Count == 0)
            {
                //输出
            }
            Assert.AreEqual(1, customers.Count);
            foreach (var c in customers)
            {
                Assert.AreEqual("Y", c.Firstname);
            }
        }

        [Test]
        public void CanGetCustomerByFirnameAndLastname()
        {
            IList<Customer> customers = _queryHQL.GetCustomersByFirstnameAndLastname("Y", "JingLee");
            Assert.AreEqual(1, customers.Count);
        }

        [Test]
        public void CanGetCustomersWithCustomerIdGreaterThan()
        {
            IList<Customer> customers = _queryHQL.GetCustomersWithCustomerIdGreaterThan(1);
            foreach (Customer c in customers)
            {
                Assert.GreaterOrEqual(c.CustomerId, 1);
            }
        }
        [Test]
        public void CanGetDistinctCustomerFirstnames()
        {
            IList<string> firstnames = _queryHQL.GetDistinctCustomerFirstnames();
            //IList<string> foundFirstname = new List<string>();
            foreach (var fn in firstnames)
            {
                Assert.AreEqual(1, firstnames.Count<string>(x => x == fn));
                //if (foundFirstname.Count != 0)
                //    Assert.IsFalse(foundFirstname.Contains(fn));
                //foundFirstname.Add(fn);
            }
        }
        [Test]
        public void CanGetCustomersOrderedByLastname()
        {
            IList<Customer> customers = _queryHQL.GetCustomersOrderedByLastnames();
            Customer priorCustomer = null;
            foreach (Customer c in customers)
            {
                if (priorCustomer != null)
                    Assert.GreaterOrEqual(string.Compare(c.Lastname, priorCustomer.Lastname), 0);
                priorCustomer = c;
            }
        }
        #endregion


        #region 源代码学习


        #endregion
    }
}
