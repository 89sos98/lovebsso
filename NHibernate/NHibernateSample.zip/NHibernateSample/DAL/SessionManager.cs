﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using NHibernate;
using NHibernate.Cfg;

namespace DAL
{
    public class SessionManager
    {
        private ISessionFactory _sessionFactory;
        public SessionManager()
        {
            _sessionFactory = GetSessionFactory();
        }
        private ISessionFactory GetSessionFactory()
        {
            return (new Configuration()).Configure().BuildSessionFactory();
        }
        public ISession GetSession()
        {
            return _sessionFactory.OpenSession();
        }
    }
}
