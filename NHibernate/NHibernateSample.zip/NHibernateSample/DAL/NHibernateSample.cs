﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//添加以下命名空间
using DomainModel.Entities;
using NHibernate;
using NHibernate.Cfg;

namespace DAL
{
    public class NHibernateSample
    {
        private ISession _session;
        public ISession Session
        {
            set
            {
                _session = value;
            }
        }
        public NHibernateSample(ISession session)
        {
            _session = session;
        }
        private static ISession GetSession()
        {
            ISessionFactory sessionFactory = (new Configuration()).Configure().BuildSessionFactory();
            ISession session = sessionFactory.OpenSession();
            return session;
        }

        public Customer GetCustomerById(int customerId)
        {
            //Configuration config = new Configuration();
            //config.Configure();
            //ISessionFactory sessionFactory = config.BuildSessionFactory();
            //ISession session = sessionFactory.OpenSession();
            //return (Customer)session.Get(typeof(Customer), customerId);
            return _session.Get<Customer>(customerId);
        }
        public Customer GetCustomerById2(int customerId)
        {
            ISessionFactory sessionFactory = (new Configuration()).Configure().BuildSessionFactory();
            ISession session = sessionFactory.OpenSession();
            return session.Get<Customer>(customerId);
        }
        //标准写法
        public Customer GetCustomerById3(int customerId)
        {
            return _session.Get<Customer>(customerId);
        }
    }
}